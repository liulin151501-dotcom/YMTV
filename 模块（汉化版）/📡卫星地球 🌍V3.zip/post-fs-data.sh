#!/system/bin/sh

#!/system/bin/sh

# ===============================
# TCP / IP 优化
# ===============================
sysctl -w net.ipv4.tcp_fastopen=3
sysctl -w net.ipv4.tcp_sack=1
sysctl -w net.ipv4.tcp_timestamps=0
sysctl -w net.ipv4.tcp_low_latency=1
sysctl -w net.ipv4.tcp_fin_timeout=15
sysctl -w net.ipv4.tcp_keepalive_time=300
sysctl -w net.ipv4.tcp_keepalive_intvl=30
sysctl -w net.ipv4.tcp_keepalive_probes=5

# TCP 缓冲区（高速 + 低抖动）
sysctl -w net.ipv4.tcp_rmem="4096 87380 16777216"
sysctl -w net.ipv4.tcp_wmem="4096 65536 16777216"

# 队列与积压
sysctl -w net.core.netdev_max_backlog=6000
sysctl -w net.core.somaxconn=4096

# 丢包减少
sysctl -w net.ipv4.tcp_mtu_probing=1

# 默认队列规则（如果支持）
if [ -e /proc/sys/net/core/default_qdisc ]; then
  echo fq_codel > /proc/sys/net/core/default_qdisc
fi
