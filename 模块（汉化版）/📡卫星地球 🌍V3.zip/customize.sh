ui_print "***************************************"
ui_print "- 名称            : $(grep_prop name "${TMPDIR}/module.prop")"
sleep 0.2
ui_print "- 版本             : $(grep_prop version "${TMPDIR}/module.prop")"
sleep 0.2
ui_print "- 作者           : $(grep_prop author "${TMPDIR}/module.prop")"
ui_print "***************************************"
ui_print "- 设备           : $(getprop ro.product.board)"
sleep 0.2
ui_print "- 制造商        : $(getprop ro.product.manufacturer)"
sleep 0.2
ui_print "- Android 版本 : $(getprop ro.build.version.release)"
sleep 0.2
ui_print "- 内核           : $(uname -r) "
sleep 0.2
ui_print "- 处理器        : $(getprop ro.product.board) "
sleep 0.2
ui_print "- Cpu             : $(getprop ro.hardware) "
sleep 0.2
ui_print "- 内存             : $(free | grep Mem |  awk '{print $2}') "
sleep 0.2
ui_print "***************************************"
sleep 0.2
if [ -d "/data/adb/ksu" ]; then
    ROOT_METHOD="KernelSU"
    if command -v su &>/dev/null; then
        ROOT_VERSION=$(su --version 2>/dev/null | cut -d ':' -f 1)
    fi
elif [ -d "/data/adb/magisk" ]; then
    ROOT_METHOD="Magisk"
    if command -v magisk &>/dev/null; then
        ROOT_VERSION=$(magisk -V)
    fi
elif [ -d "/data/adb/ap" ]; then
    ROOT_METHOD="APatch"
    if [ -f "/data/adb/ap/version" ]; then
        ROOT_VERSION=$(cat /data/adb/ap/version)
    fi
fi
ui_print "- 使用 ${ROOT_METHOD} (${ROOT_VERSION}) 安装"
sleep 0.5

# === 权限 ===
ui_print "- 正在设置可执行权限..."
ui_print "- 正在解压模块文件"
unzip -o "$ZIPFILE" 'system/*' -d $MODPATH >&2
sleep 0.5
ui_print "- 于 $(date "+%d, %b - %H:%M %Z") 成功完成 !!"
