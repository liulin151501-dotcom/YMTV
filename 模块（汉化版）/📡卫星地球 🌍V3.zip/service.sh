#!/system/bin/sh

MODPATH="${0%/*}"

sleep 1

LOG=/storage/emulated/0/network_booster.log

# ===============================
# 基础优化（普通模式）
# ===============================
normal_mode() {
  sysctl -w net.ipv4.tcp_low_latency=1
  sysctl -w net.core.netdev_max_backlog=4000
  settings put global wifi_scan_throttle_enabled 0
  cmd power set-fixed-performance-mode-enabled false
  echo "$(date) 普通模式" >> $LOG
}

# ===============================
# 加速模式（弱信号）
# ===============================
boost_mode() {
  sysctl -w net.ipv4.tcp_low_latency=1
  sysctl -w net.core.netdev_max_backlog=8000
  sysctl -w net.ipv4.tcp_rmem="4096 87380 33554432"
  sysctl -w net.ipv4.tcp_wmem="4096 65536 33554432"

  # 保持移动数据活跃
  settings put global mobile_data_always_on 1

  # 减少游戏抖动
  iptables -t mangle -C POSTROUTING -p udp -j TOS --set-tos 0x10 2>/dev/null || \
  iptables -t mangle -A POSTROUTING -p udp -j TOS --set-tos 0x10

  cmd power set-fixed-performance-mode-enabled true
  echo "$(date) 加速模式（弱信号）" >> $LOG
}

chmod 0755 "$MODPATH/system/bin/sateliteearthd-RS"

# Root 执行文件 
/data/adb/modules/Satellite_Earth/system/bin/sateliteearthd-RS

# 非 Root 执行文件 
/data/data/com.android.shell/AxManager/plugins/Satellite_Earth/system/bin/sateliteearthd-RS

cmd notification post -S bigtext -t '🌎卫星地球📡'🔥 '系统' '✅ 已激活' > /dev/null 2>&1 & 

if [ "$(id -u)" = "0" ]; then
    su -lp 2000 -c "cmd notification post -S bigtext -t '🌎 卫星地球📡🔥' tag '系统 : ✅ 已激活'" >/dev/null 2>&1
fi
