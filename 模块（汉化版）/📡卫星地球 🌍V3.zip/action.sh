#!/system/bin/sh


MODPATH="${0%/*}"

chmod 0755 "$MODPATH/system/bin/sateliteearthd-C++"

ui_print "- 正在检查信息 ℹ️ " 

exec "$MODPATH/system/bin/sateliteearthd-C++"
