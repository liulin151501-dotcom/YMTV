#!/system/bin/sh
# ================================================================
#   Alya Exynos Tweak - customize.sh
#   Magisk Module Customization Script
#   Dieksekusi saat instalasi via Magisk / KernelSU / APatch
#
#   Version  : 3.7
#   Author   : Xyaeve
#   Platform : Samsung Exynos
# ================================================================
#
#   Variabel tersedia dari Magisk:
#     MAGISK_VER_CODE  - Versi kode Magisk
#     BOOTMODE         - true jika instalasi saat boot
#     MODPATH          - Path module sementara
#     TMPDIR           - Direktori temporary
#     ZIPFILE          - Path file zip modul
#     ARCH             - Arsitektur (arm, arm64, x86, x64)
#     IS64BIT          - true jika 64-bit
#     API              - Level Android API
# ================================================================

# ── Warna ANSI (hanya tampil di terminal tertentu) ────────────
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
CYAN='\033[0;36m'
BOLD='\033[1m'
RESET='\033[0m'

# ── Header ────────────────────────────────────────────────────
ui_print " "
ui_print "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
ui_print "      ░█████╗░██╗░░░░░██╗░░░██╗░█████╗░"
ui_print "      ██╔══██╗██║░░░░░╚██╗░██╔╝██╔══██╗"
ui_print "      ███████║██║░░░░░░╚████╔╝░███████║"
ui_print "      ██╔══██║██║░░░░░░░╚██╔╝░░██╔══██║"
ui_print "      ██║░░██║███████╗░░░██║░░░██║░░██║"
ui_print "      ╚═╝░░╚═╝╚══════╝░░░╚═╝░░░╚═╝░░╚═╝"
ui_print " "
ui_print "         Exynos Tweak v3.7 by Xyaeve"
ui_print "         AxManager Module"
ui_print "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
ui_print " "
sleep 1

# ================================================================
#   [1] DEVICE DETECTION
# ================================================================
ui_print "  [1/5] Membaca informasi perangkat..."
sleep 1

MODEL=$(getprop ro.product.model)
BRAND=$(getprop ro.product.brand)
DEVICE=$(getprop ro.product.device)
SOC=$(getprop ro.board.platform)
CHIPSET=$(getprop ro.hardware)
ANDROID_VER=$(getprop ro.build.version.release)
SDK_VER=$(getprop ro.build.version.sdk)
BUILD_ID=$(getprop ro.build.id)
KERNEL=$(uname -r)
CPU_ARCH=$(getprop ro.product.cpu.abi)

ui_print "  ┌─────────────────────────────────────┐"
ui_print "  │  Model   : $MODEL"
ui_print "  │  Brand   : $BRAND"
ui_print "  │  Device  : $DEVICE"
ui_print "  │  SoC     : $SOC"
ui_print "  │  Android : $ANDROID_VER (API $SDK_VER)"
ui_print "  │  Kernel  : $KERNEL"
ui_print "  │  Arch    : $CPU_ARCH"
ui_print "  │  Build   : $BUILD_ID"
ui_print "  └─────────────────────────────────────┘"
sleep 1

# ── Deteksi RAM total ─────────────────────────────────────────
TOTAL_MEM_KB=$(grep MemTotal /proc/meminfo | awk '{print $2}')
TOTAL_MEM_GB=$(( TOTAL_MEM_KB / 1024 / 1024 ))

ui_print "  │  RAM     : ~${TOTAL_MEM_GB}GB (${TOTAL_MEM_KB} KB)"
ui_print " "

# ================================================================
#   [2] COMPATIBILITY CHECK
# ================================================================
ui_print "  [2/5] Memeriksa kompatibilitas perangkat..."
sleep 1

ABORT=0

# Cek Brand Samsung
case "$BRAND" in
  samsung|Samsung)
    ui_print "  [✓] Brand Samsung terdeteksi"
    ;;
  *)
    ui_print "  [✗] Brand bukan Samsung! ($BRAND)"
    ui_print "  [!] Module ini dioptimasi untuk Samsung Exynos."
    ui_print "  [!] Melanjutkan instalasi dengan risiko sendiri..."
    ABORT=0  # Ubah ke 1 jika ingin hard abort
    sleep 2
    ;;
esac

# Cek SoC Exynos
case "$SOC" in
  exynos*|s5e*|universal*)
    ui_print "  [✓] Chipset Exynos terdeteksi: $SOC"
    EXYNOS_DETECTED=1
    ;;
  *)
    ui_print "  [!] Chipset non-Exynos: $SOC"
    ui_print "  [!] Beberapa tweak GPU/CPU mungkin tidak kompatibel."
    EXYNOS_DETECTED=0
    sleep 1
    ;;
esac

# Cek versi Android minimum (Android 10 / API 29)
if [ "$SDK_VER" -lt 29 ]; then
  ui_print "  [✗] Android terlalu lama! Minimal Android 10 (API 29)."
  ui_print "  [!] Android terdeteksi: $ANDROID_VER (API $SDK_VER)"
  ABORT=1
else
  ui_print "  [✓] Versi Android kompatibel: $ANDROID_VER (API $SDK_VER)"
fi

# Cek apakah 64-bit
if $IS64BIT; then
  ui_print "  [✓] Arsitektur 64-bit"
else
  ui_print "  [!] Arsitektur 32-bit — beberapa tweak mungkin tidak optimal"
fi

# Abort jika tidak kompatibel
if [ "$ABORT" = "1" ]; then
  ui_print " "
  ui_print "  [✗] Instalasi dibatalkan karena perangkat tidak kompatibel."
  ui_print "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
  abort "  Perangkat tidak memenuhi syarat minimum!"
fi

sleep 1

# ================================================================
#   [3] PROFILE SELECTION (Berdasarkan RAM)
# ================================================================
ui_print " "
ui_print "  [3/5] Memilih profil berdasarkan RAM..."
sleep 1

if [ "$TOTAL_MEM_GB" -le 3 ]; then
  RAM_PROFILE="low"
  ui_print "  [~] Profil RAM: LOW (≤3GB) — mode hemat memori aktif"
elif [ "$TOTAL_MEM_GB" -le 5 ]; then
  RAM_PROFILE="mid"
  ui_print "  [~] Profil RAM: MID (4-6GB) — mode seimbang"
elif [ "$TOTAL_MEM_GB" -le 7 ]; then
  RAM_PROFILE="high"
  ui_print "  [~] Profil RAM: HIGH (6-8GB) — mode performa"
else
  RAM_PROFILE="ultra"
  ui_print "  [~] Profil RAM: ULTRA (>8GB) — mode performa penuh"
fi

# Simpan profil ke file config untuk dibaca service.sh
mkdir -p "$MODPATH/config"
echo "RAM_PROFILE=$RAM_PROFILE" > "$MODPATH/config/device_profile.conf"
echo "EXYNOS_DETECTED=$EXYNOS_DETECTED" >> "$MODPATH/config/device_profile.conf"
echo "SOC=$SOC" >> "$MODPATH/config/device_profile.conf"
echo "MODEL=$MODEL" >> "$MODPATH/config/device_profile.conf"
echo "TOTAL_MEM_GB=$TOTAL_MEM_GB" >> "$MODPATH/config/device_profile.conf"
echo "ANDROID_VER=$ANDROID_VER" >> "$MODPATH/config/device_profile.conf"
echo "SDK_VER=$SDK_VER" >> "$MODPATH/config/device_profile.conf"

ui_print "  [✓] Profil disimpan ke config/device_profile.conf"
sleep 1

# ================================================================
#   [4] SET PERMISSIONS
# ================================================================
ui_print " "
ui_print "  [4/5] Mengatur permission file..."
sleep 1

# Set permission script sh agar bisa dieksekusi
set_perm "$MODPATH/service.sh"       root root 0755 0022
set_perm "$MODPATH/post-fs-data.sh"  root root 0755 0022
set_perm "$MODPATH/install.sh"       root root 0755 0022
set_perm "$MODPATH/customize.sh"     root root 0755 0022

# Set permission config folder
set_perm_recursive "$MODPATH/config" root root 0755 0644

# Set permission module.prop & system.prop
set_perm "$MODPATH/module.prop"  root root 0644 0022
set_perm "$MODPATH/system.prop"  root root 0644 0022

ui_print "  [✓] Permission service.sh      → 0755"
ui_print "  [✓] Permission post-fs-data.sh → 0755"
ui_print "  [✓] Permission config/         → 0755/0644"
sleep 1

# ================================================================
#   [5] FINALIZE
# ================================================================
ui_print " "
ui_print "  [5/5] Finalisasi instalasi..."
sleep 1

# Informasi runtime
INSTALL_MODE="Unknown"
if $BOOTMODE; then
  INSTALL_MODE="Online (saat boot)"
else
  INSTALL_MODE="Offline (Recovery)"
fi

ui_print "  [i] Mode instalasi  : $INSTALL_MODE"
ui_print "  [i] Magisk ver code : $MAGISK_VER_CODE"
ui_print "  [i] Module path     : $MODPATH"
sleep 1

# ── Summary ───────────────────────────────────────────────────
ui_print " "
ui_print "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
ui_print "  Tweaks yang akan diaktifkan:"
ui_print "   • CPU Governor   → schedutil + rate limit"
ui_print "   • Kernel Sched   → latency & granularity tuning"
ui_print "   • GPU Mali       → simple_ondemand governor"
ui_print "   • Memory / VM    → swappiness, dirty ratio, LMK"
ui_print "   • I/O Block      → mq-deadline, read-ahead 128KB"
ui_print "   • Network TCP    → fast open, ECN, buffer size"
ui_print "   • SurfaceFlinger → latch unsignaled, VDS"
ui_print "   • Dalvik / ART   → dex2oat speed compilation"
ui_print "   • Thermal        → semua zone enabled"
ui_print "   • Logging        → /data/local/tmp/axmanager_exynos.log"
ui_print "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
ui_print " "
ui_print "  [✓] Alya Exynos Tweak v3.7 siap digunakan!"
ui_print "  [✓] Reboot perangkat untuk mengaktifkan semua tweak."
ui_print " "
ui_print "  Terima kasih telah menggunakan Alya Exynos Tweak!"
ui_print "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
ui_print " "
