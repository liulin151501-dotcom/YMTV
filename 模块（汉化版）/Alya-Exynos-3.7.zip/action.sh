#!/system/bin/sh
# ================================================================
#   Alya Exynos Tweak - action.sh
#   Dieksekusi saat user menekan tombol "Action" di Magisk /
#   KernelSU / APatch app
#
#   Version  : 3.7
#   Author   : Xyaeve
#   Platform : Samsung Exynos
# ================================================================

# ── Path & Config ─────────────────────────────────────────────
MODDIR="/data/adb/modules/AET"
CONFIG_DIR="$MODDIR/config"
PROFILE_CONF="$CONFIG_DIR/device_profile.conf"
LOG="/data/local/tmp/axmanager_exynos.log"
ACTION_LOG="/data/local/tmp/axmanager_action.log"

# ── Load profil device jika tersedia ─────────────────────────
if [ -f "$PROFILE_CONF" ]; then
  . "$PROFILE_CONF"
fi

# ── Helper: tulis ke sysfs ─────────────────────────────────────
write() {
  [ -f "$1" ] && echo "$2" > "$1" 2>/dev/null
}

# ── Helper: baca nilai sysfs ─────────────────────────────────
read_node() {
  [ -f "$1" ] && cat "$1" 2>/dev/null || echo "N/A"
}

# ── Helper: separator ─────────────────────────────────────────
line() {
  echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
}

# ── Timestamp log ─────────────────────────────────────────────
log_action() {
  echo "[$(date '+%Y-%m-%d %H:%M:%S')] $1" >> "$ACTION_LOG"
}

# ================================================================
#   FUNGSI: TAMPILKAN STATUS SISTEM
# ================================================================
show_status() {
  echo " "
  line
  echo "   ALYA EXYNOS TWEAK v3.7 — STATUS SISTEM"
  line

  # Info perangkat
  echo " "
  echo "  [ DEVICE INFO ]"
  echo "  Model    : $(getprop ro.product.model)"
  echo "  Android  : $(getprop ro.build.version.release) (API $(getprop ro.build.version.sdk))"
  echo "  Kernel   : $(uname -r)"
  echo "  Uptime   : $(uptime | awk '{print $3, $4}' | sed 's/,//')"
  echo " "

  # Status RAM
  TOTAL_MEM=$(grep MemTotal /proc/meminfo | awk '{print $2}')
  FREE_MEM=$(grep MemFree /proc/meminfo | awk '{print $2}')
  AVAIL_MEM=$(grep MemAvailable /proc/meminfo | awk '{print $2}')
  USED_MEM=$(( TOTAL_MEM - AVAIL_MEM ))
  USED_PCT=$(( USED_MEM * 100 / TOTAL_MEM ))

  echo "  [ MEMORY ]"
  echo "  Total    : $(( TOTAL_MEM / 1024 )) MB"
  echo "  Used     : $(( USED_MEM / 1024 )) MB ($USED_PCT%)"
  echo "  Available: $(( AVAIL_MEM / 1024 )) MB"
  echo "  Swappiness: $(read_node /proc/sys/vm/swappiness)"
  echo " "

  # Status CPU
  echo "  [ CPU ]"
  CPU_COUNT=0
  for cpu_dir in /sys/devices/system/cpu/cpu[0-9]*; do
    [ -d "$cpu_dir" ] && CPU_COUNT=$(( CPU_COUNT + 1 ))
  done
  echo "  Core     : ${CPU_COUNT} cores"

  # Governor semua core
  GOV_LIST=""
  for cpu_dir in /sys/devices/system/cpu/cpu[0-9]*/cpufreq; do
    if [ -f "$cpu_dir/scaling_governor" ]; then
      GOV=$(cat "$cpu_dir/scaling_governor" 2>/dev/null)
      CORE=$(echo "$cpu_dir" | grep -o 'cpu[0-9]*')
      GOV_LIST="$GOV_LIST $CORE:$GOV"
    fi
  done
  echo "  Governor : $GOV_LIST"

  # Freq CPU0
  CUR_FREQ=$(read_node /sys/devices/system/cpu/cpu0/cpufreq/scaling_cur_freq)
  MAX_FREQ=$(read_node /sys/devices/system/cpu/cpu0/cpufreq/scaling_max_freq)
  MIN_FREQ=$(read_node /sys/devices/system/cpu/cpu0/cpufreq/scaling_min_freq)
  if [ "$CUR_FREQ" != "N/A" ]; then
    echo "  Freq cpu0: $(( CUR_FREQ / 1000 )) MHz (min: $(( MIN_FREQ / 1000 )) / max: $(( MAX_FREQ / 1000 )) MHz)"
  fi
  echo " "

  # Status GPU Mali
  echo "  [ GPU (Mali) ]"
  GPU_GOV=$(read_node /sys/class/devfreq/mali/governor)
  GPU_CUR=$(read_node /sys/class/devfreq/mali/cur_freq)
  GPU_MAX=$(read_node /sys/class/devfreq/mali/max_freq)
  GPU_LOAD=$(read_node /sys/class/devfreq/mali/load)
  echo "  Governor : $GPU_GOV"
  if [ "$GPU_CUR" != "N/A" ]; then
    echo "  Freq     : $(( GPU_CUR / 1000000 )) MHz (max: $(( GPU_MAX / 1000000 )) MHz)"
  fi
  [ "$GPU_LOAD" != "N/A" ] && echo "  Load     : $GPU_LOAD"
  echo " "

  # Status I/O
  echo "  [ I/O ]"
  IO_SCHED=$(read_node /sys/block/sda/queue/scheduler)
  IO_RA=$(read_node /sys/block/sda/queue/read_ahead_kb)
  echo "  Scheduler: $IO_SCHED"
  echo "  Read-ahead: ${IO_RA} KB"
  echo " "

  # Status Thermal
  echo "  [ THERMAL ]"
  ZONE_COUNT=0
  for zone in /sys/class/thermal/thermal_zone*/mode; do
    [ -f "$zone" ] && ZONE_COUNT=$(( ZONE_COUNT + 1 ))
  done
  echo "  Zones    : $ZONE_COUNT zones aktif"
  # Suhu CPU/GPU (jika tersedia)
  for zone_dir in /sys/class/thermal/thermal_zone*/; do
    TTYPE=$(cat "${zone_dir}type" 2>/dev/null)
    TTEMP=$(cat "${zone_dir}temp" 2>/dev/null)
    case "$TTYPE" in
      cpu*|exynos*|big*|little*)
        if [ -n "$TTEMP" ] && [ "$TTEMP" -gt 0 ] 2>/dev/null; then
          echo "  $TTYPE : $(( TTEMP / 1000 ))°C"
        fi
        ;;
    esac
  done
  echo " "

  # Status Kernel Scheduler
  echo "  [ KERNEL SCHEDULER ]"
  echo "  sched_latency_ns       : $(read_node /proc/sys/kernel/sched_latency_ns)"
  echo "  sched_min_granularity  : $(read_node /proc/sys/kernel/sched_min_granularity_ns)"
  echo "  sched_autogroup        : $(read_node /proc/sys/kernel/sched_autogroup_enabled)"
  echo " "

  # Status Network
  echo "  [ NETWORK TCP ]"
  echo "  tcp_fastopen           : $(read_node /proc/sys/net/ipv4/tcp_fastopen)"
  echo "  tcp_ecn                : $(read_node /proc/sys/net/ipv4/tcp_ecn)"
  echo "  tcp_slow_start_idle    : $(read_node /proc/sys/net/ipv4/tcp_slow_start_after_idle)"
  echo " "

  # Profil aktif
  if [ -n "$RAM_PROFILE" ]; then
    echo "  [ PROFIL AKTIF ]"
    echo "  RAM Profile : $RAM_PROFILE"
    echo "  SOC         : ${SOC:-$(getprop ro.board.platform)}"
    echo " "
  fi

  # Status module
  echo "  [ MODULE ]"
  if [ -f "$MODDIR/disable" ]; then
    echo "  Status   : DISABLED"
  else
    echo "  Status   : ENABLED"
  fi
  if [ -f "$LOG" ]; then
    LAST_LINE=$(tail -1 "$LOG" 2>/dev/null)
    echo "  Last log : $LAST_LINE"
  fi
  line
  echo " "
}

# ================================================================
#   FUNGSI: TERAPKAN ULANG SEMUA TWEAK
# ================================================================
apply_tweaks() {
  echo " "
  line
  echo "   MENERAPKAN ULANG SEMUA TWEAK..."
  line
  echo " "

  log_action "Manual re-apply tweaks dimulai"

  # CPU Governor
  echo "  [*] CPU Governor → schedutil..."
  for cpu in /sys/devices/system/cpu/cpu*/cpufreq/scaling_governor; do
    write "$cpu" "schedutil"
  done
  for rate in /sys/devices/system/cpu/cpu*/cpufreq/schedutil/rate_limit_us; do
    write "$rate" "2000"
  done
  echo "  [✓] CPU Governor selesai"

  # Kernel Scheduler
  echo "  [*] Kernel Scheduler..."
  write /proc/sys/kernel/sched_latency_ns          "1000000"
  write /proc/sys/kernel/sched_min_granularity_ns  "100000"
  write /proc/sys/kernel/sched_wakeup_granularity_ns "50000"
  write /proc/sys/kernel/sched_autogroup_enabled   "1"
  write /proc/sys/kernel/sched_child_runs_first    "0"
  echo "  [✓] Kernel Scheduler selesai"

  # Memory / VM
  echo "  [*] Memory / VM Tweaks..."
  write /proc/sys/vm/swappiness             "10"
  write /proc/sys/vm/vfs_cache_pressure     "50"
  write /proc/sys/vm/dirty_background_ratio "5"
  write /proc/sys/vm/dirty_ratio            "20"
  write /proc/sys/vm/dirty_expire_centisecs "3000"
  write /proc/sys/vm/dirty_writeback_centisecs "3000"
  write /proc/sys/vm/page-cluster           "0"
  write /proc/sys/vm/stat_interval          "10"
  echo "  [✓] Memory / VM selesai"

  # I/O
  echo "  [*] I/O Scheduler..."
  for queue in /sys/block/*/queue/scheduler; do
    write "$queue" "mq-deadline"
  done
  for nr_req in /sys/block/*/queue/nr_requests; do
    write "$nr_req" "64"
  done
  for read_ahead in /sys/block/*/queue/read_ahead_kb; do
    write "$read_ahead" "128"
  done
  echo "  [✓] I/O Scheduler selesai"

  # GPU Mali
  echo "  [*] GPU Mali..."
  write /sys/class/devfreq/mali/governor           "simple_ondemand"
  write /sys/class/devfreq/mali/polling_interval   "100"
  write /sys/devices/platform/mali.0/power_policy  "coarse_demand"
  echo "  [✓] GPU Mali selesai"

  # Network TCP
  echo "  [*] Network TCP..."
  write /proc/sys/net/ipv4/tcp_fastopen              "3"
  write /proc/sys/net/ipv4/tcp_slow_start_after_idle "0"
  write /proc/sys/net/ipv4/tcp_ecn                   "1"
  write /proc/sys/net/ipv4/tcp_timestamps            "1"
  write /proc/sys/net/core/rmem_max                  "8388608"
  write /proc/sys/net/core/wmem_max                  "8388608"
  echo "  [✓] Network TCP selesai"

  # LMK
  echo "  [*] LMK (Low Memory Killer)..."
  write /sys/module/lowmemorykiller/parameters/enable_adaptive_lmk "1"
  write /sys/module/lowmemorykiller/parameters/vmpressure_file_min "81920"
  echo "  [✓] LMK selesai"

  # Thermal
  echo "  [*] Thermal Zones..."
  for thermal in /sys/class/thermal/thermal_zone*/mode; do
    write "$thermal" "enabled"
  done
  echo "  [✓] Thermal selesai"

  log_action "Manual re-apply tweaks selesai"

  echo " "
  echo "  [✓] Semua tweak berhasil diterapkan ulang!"
  line
  echo " "
}

# ================================================================
#   FUNGSI: GANTI CPU GOVERNOR
# ================================================================
set_cpu_governor() {
  GOV="$1"
  echo " "
  echo "  [*] Mengganti CPU Governor ke: $GOV"

  CHANGED=0
  for cpu in /sys/devices/system/cpu/cpu*/cpufreq/scaling_governor; do
    if [ -f "$cpu" ]; then
      AVAIL=$(cat "$(dirname $cpu)/scaling_available_governors" 2>/dev/null)
      case "$AVAIL" in
        *"$GOV"*)
          write "$cpu" "$GOV"
          CHANGED=$(( CHANGED + 1 ))
          ;;
        *)
          echo "  [!] $(echo $cpu | grep -o 'cpu[0-9]*'): $GOV tidak tersedia, skip"
          ;;
      esac
    fi
  done

  # Rate limit khusus schedutil
  if [ "$GOV" = "schedutil" ]; then
    for rate in /sys/devices/system/cpu/cpu*/cpufreq/schedutil/rate_limit_us; do
      write "$rate" "2000"
    done
  fi

  log_action "CPU Governor diubah ke: $GOV ($CHANGED core)"
  echo "  [✓] Governor $GOV diterapkan ke $CHANGED core"
  echo " "
}

# ================================================================
#   FUNGSI: TAMPILKAN LOG
# ================================================================
show_log() {
  echo " "
  line
  echo "   LOG — ALYA EXYNOS TWEAK"
  line
  echo " "
  if [ -f "$LOG" ]; then
    echo "  [ Service Log: $LOG ]"
    echo " "
    cat "$LOG"
  else
    echo "  [!] Service log belum tersedia."
    echo "  [!] Tweak belum pernah berjalan sejak boot terakhir."
  fi
  echo " "
  if [ -f "$ACTION_LOG" ]; then
    echo "  [ Action Log: $ACTION_LOG ]"
    echo " "
    cat "$ACTION_LOG"
  fi
  line
  echo " "
}

# ================================================================
#   FUNGSI: HAPUS LOG
# ================================================================
clear_log() {
  echo " " > "$LOG" 2>/dev/null
  echo " " > "$ACTION_LOG" 2>/dev/null
  log_action "Log dibersihkan"
  echo "  [✓] Log berhasil dibersihkan."
}

# ================================================================
#   FUNGSI: INFO MODULE
# ================================================================
show_info() {
  echo " "
  line
  echo "   ALYA EXYNOS TWEAK — INFO MODULE"
  line
  echo " "
  echo "  Nama      : Alya Exynos Tweak"
  echo "  Versi     : 3.7"
  echo "  Author    : Xyaieve"
  echo "  Platform  : Samsung Exynos"
  echo "  Framework : Magisk / KernelSU / APatch"
  echo " "
  echo "  Deskripsi:"
  echo "  Module ini mengoptimasi performa Samsung Exynos"
  echo "  dengan menyetel CPU governor, kernel scheduler,"
  echo "  GPU Mali, manajemen memori, I/O block, jaringan"
  echo "  TCP, SurfaceFlinger, Dalvik/ART, dan thermal."
  echo " "
  echo "  File yang digunakan:"
  echo "   • customize.sh    — Dieksekusi saat instalasi"
  echo "   • post-fs-data.sh — Dieksekusi sebelum /data mount"
  echo "   • service.sh      — Dieksekusi setelah boot selesai"
  echo "   • system.prop     — System properties permanen"
  echo "   • action.sh       — Dieksekusi via tombol Action"
  echo " "
  echo "  Config:"
  if [ -f "$PROFILE_CONF" ]; then
    echo "   • Profil tersimpan: $PROFILE_CONF"
    cat "$PROFILE_CONF" | sed 's/^/     /'
  else
    echo "   • Belum ada config tersimpan"
  fi
  echo " "
  echo "  Log paths:"
  echo "   • Service : $LOG"
  echo "   • Action  : $ACTION_LOG"
  line
  echo " "
}

# ================================================================
#   FUNGSI: TOGGLE DISABLE / ENABLE MODULE
# ================================================================
toggle_module() {
  if [ -f "$MODDIR/disable" ]; then
    rm -f "$MODDIR/disable"
    log_action "Module di-ENABLE via action"
    echo "  [✓] Module sekarang: ENABLED"
    echo "  [!] Reboot untuk menerapkan perubahan."
  else
    touch "$MODDIR/disable"
    log_action "Module di-DISABLE via action"
    echo "  [✓] Module sekarang: DISABLED"
    echo "  [!] Reboot untuk menerapkan perubahan."
  fi
}

# ================================================================
#   FUNGSI: BENCHMARK SINGKAT (CPU)
# ================================================================
run_benchmark() {
  echo " "
  line
  echo "   BENCHMARK SINGKAT — CPU STRESS TEST"
  line
  echo " "
  echo "  [*] Menjalankan benchmark 5 detik..."
  echo "  [!] Ini hanya estimasi kasar, bukan benchmark resmi."
  echo " "

  START=$(date +%s%N)

  # Hitung loop sederhana
  COUNT=0
  END_TIME=$(( $(date +%s) + 5 ))
  while [ $(date +%s) -lt $END_TIME ]; do
    COUNT=$(( COUNT + 1 ))
  done

  END=$(date +%s%N)
  ELAPSED=$(( (END - START) / 1000000 ))

  echo "  Iterasi   : $COUNT loop dalam 5 detik"
  echo "  Waktu     : ${ELAPSED} ms"
  echo " "

  # Suhu setelah benchmark
  for zone_dir in /sys/class/thermal/thermal_zone*/; do
    TTYPE=$(cat "${zone_dir}type" 2>/dev/null)
    TTEMP=$(cat "${zone_dir}temp" 2>/dev/null)
    case "$TTYPE" in
      cpu*|big*|little*)
        if [ -n "$TTEMP" ] && [ "$TTEMP" -gt 0 ] 2>/dev/null; then
          echo "  Suhu $TTYPE: $(( TTEMP / 1000 ))°C (setelah test)"
        fi
        ;;
    esac
  done

  log_action "Benchmark dijalankan — $COUNT iterasi dalam 5 detik"
  echo " "
  line
  echo " "
}

# ================================================================
#   FUNGSI: GANTI PROFIL MANUAL
# ================================================================
set_profile() {
  PROFILE="$1"
  mkdir -p "$CONFIG_DIR"

  case "$PROFILE" in
    low)
      write /proc/sys/vm/swappiness         "20"
      write /proc/sys/vm/vfs_cache_pressure "80"
      write /proc/sys/vm/dirty_background_ratio "3"
      write /sys/class/devfreq/mali/governor "powersave"
      ;;
    mid)
      write /proc/sys/vm/swappiness         "10"
      write /proc/sys/vm/vfs_cache_pressure "50"
      write /proc/sys/vm/dirty_background_ratio "5"
      write /sys/class/devfreq/mali/governor "simple_ondemand"
      ;;
    high)
      write /proc/sys/vm/swappiness         "5"
      write /proc/sys/vm/vfs_cache_pressure "30"
      write /proc/sys/vm/dirty_background_ratio "5"
      write /sys/class/devfreq/mali/governor "simple_ondemand"
      ;;
    ultra)
      write /proc/sys/vm/swappiness         "0"
      write /proc/sys/vm/vfs_cache_pressure "10"
      write /proc/sys/vm/dirty_background_ratio "3"
      write /sys/class/devfreq/mali/governor "performance"
      ;;
    *)
      echo "  [!] Profil tidak dikenal: $PROFILE"
      return
      ;;
  esac

  # Update config
  sed -i "s/^RAM_PROFILE=.*/RAM_PROFILE=$PROFILE/" "$PROFILE_CONF" 2>/dev/null \
    || echo "RAM_PROFILE=$PROFILE" >> "$PROFILE_CONF"

  log_action "Profil manual diubah ke: $PROFILE"
  echo "  [✓] Profil $PROFILE diterapkan."
}

# ================================================================
#   MAIN — MENU UTAMA
# ================================================================
main() {
  echo " "
  line
  echo "      ALYA EXYNOS TWEAK v3.7 — ACTION"
  echo "              by Xyaeve"
  line
  echo " "
  echo "  Pilih opsi:"
  echo " "
  echo "   [1] Tampilkan status sistem"
  echo "   [2] Terapkan ulang semua tweak"
  echo "   [3] Ganti CPU Governor"
  echo "        [3a] schedutil   (default, hemat + responsif)"
  echo "        [3b] performance (performa maksimum)"
  echo "        [3c] powersave   (hemat daya)"
  echo "        [3d] ondemand    (ondemand klasik)"
  echo "   [4] Ganti profil tweak manual"
  echo "        [4a] low   — RAM ≤3GB"
  echo "        [4b] mid   — RAM 4-6GB"
  echo "        [4c] high  — RAM 6-8GB"
  echo "        [4d] ultra — RAM >8GB"
  echo "   [5] Benchmark singkat CPU"
  echo "   [6] Tampilkan log"
  echo "   [7] Hapus log"
  echo "   [8] Enable / Disable module"
  echo "   [9] Info module"
  echo " "
  line
  echo " "

  # Baca argumen pertama sebagai pilihan (untuk non-interactive)
  ACTION="$1"

  # Jika tidak ada argumen → jalankan default: status + apply tweaks
  if [ -z "$ACTION" ]; then
    show_status
    echo "  [i] Tidak ada argumen, menerapkan ulang tweak..."
    sleep 1
    apply_tweaks
    return
  fi

  case "$ACTION" in
    1|status)           show_status ;;
    2|apply)            apply_tweaks ;;
    3a|gov_schedutil)   set_cpu_governor "schedutil" ;;
    3b|gov_performance) set_cpu_governor "performance" ;;
    3c|gov_powersave)   set_cpu_governor "powersave" ;;
    3d|gov_ondemand)    set_cpu_governor "ondemand" ;;
    4a|profile_low)     set_profile "low" ;;
    4b|profile_mid)     set_profile "mid" ;;
    4c|profile_high)    set_profile "high" ;;
    4d|profile_ultra)   set_profile "ultra" ;;
    5|bench)            run_benchmark ;;
    6|log)              show_log ;;
    7|clearlog)         clear_log ;;
    8|toggle)           toggle_module ;;
    9|info)             show_info ;;
    *)
      echo "  [!] Opsi tidak dikenal: $ACTION"
      echo "  [i] Gunakan: 1-9 atau keyword (status, apply, log, bench, info, toggle)"
      ;;
  esac
}

# ── Jalankan main ─────────────────────────────────────────────
main "$1"
