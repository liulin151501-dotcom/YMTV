#!/system/bin/sh
# ============================================================
#   Alya Exynos Tweak - post-fs-data
#   Runs early in boot before /data is mounted
#   Version  : 3.7
#   Author   : Xyaeve
# ============================================================

LOG="/cache/axmanager_exynos_post.log"
echo "=== Alya Exynos post-fs-data started ===" > $LOG

# ── Faster app launch ─────────────────────────────────────
setprop debug.sf.latch_unsignaled 1
setprop debug.sf.disable_backpressure 1
setprop debug.hwui.renderer skiagl
echo "[+] App launch tweaks applied" >> $LOG

# ── Touch latency improvement ─────────────────────────────
setprop ro.input.noresample 1
setprop debug.input.resampling 0
echo "[+] Touch latency tweaks applied" >> $LOG

# ── Network / TCP optimization ───────────────────────────
setprop net.tcp.buffersize.default 4096,87380,256960,4096,16384,256960
setprop net.tcp.buffersize.wifi 4096,87380,256960,4096,16384,256960
setprop net.tcp.buffersize.lte 4096,87380,1220608,4096,16384,1220608
setprop net.tcp.buffersize.umts 4096,87380,256960,4096,16384,256960
setprop net.tcp.buffersize.gprs 4096,87380,256960,4096,16384,256960
echo "[+] Network tweaks applied" >> $LOG

# ── SurfaceFlinger tweaks ─────────────────────────────────
setprop debug.sf.enable_hwc_vds 1
setprop debug.sf.recomputecrop 0
setprop debug.sf.early_phase_offset_ns 500000
setprop debug.sf.early_app_phase_offset_ns 500000
echo "[+] SurfaceFlinger tweaks applied" >> $LOG

# ── Dalvik / ART optimization ─────────────────────────────
setprop dalvik.vm.dex2oat-filter speed
setprop dalvik.vm.image-dex2oat-filter speed
setprop pm.dexopt.boot speed
setprop pm.dexopt.install speed
echo "[+] Dalvik/ART tweaks applied" >> $LOG

echo "=== post-fs-data done ===" >> $LOG
