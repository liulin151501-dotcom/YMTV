#!/system/bin/sh
# ============================================================
#   Alya Exynos Tweak - Installer
#   Version  : 3.7
#   Author   : Xyaeve
#   Platform : Samsung Exynos
# ============================================================

ui_print "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
ui_print "   Alya Exynos Tweak v3.7"
ui_print "   by Xyaeve — AxManager Module"
ui_print "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
sleep 1

# Device info
BRAND=$(getprop ro.product.brand)
SOC=$(getprop ro.board.platform)
ANDROID=$(getprop ro.build.version.release)
ARCH=$(getprop ro.product.cpu.abi)

ui_print "[*] Device  : $(getprop ro.product.model)"
ui_print "[*] Brand   : $BRAND"
ui_print "[*] SoC     : $SOC"
ui_print "[*] Android : $ANDROID"
ui_print "[*] Arch    : $ARCH"
sleep 1

# Warn if not Samsung
case "$BRAND" in
  samsung|Samsung) ;;
  *)
    ui_print "[!] WARNING: Device brand is not Samsung."
    ui_print "[!] Module may not work as expected."
    sleep 1
    ;;
esac

ui_print " "
ui_print "[*] Installing module files..."
sleep 1
ui_print "[+] Applying system props..."
sleep 1
ui_print "[+] Registering service scripts..."
sleep 1
ui_print "[+] Registering post-fs-data scripts..."
sleep 1

ui_print " "
ui_print "[✓] Installation complete!"
ui_print "[✓] Reboot your device to apply tweaks."
ui_print "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
