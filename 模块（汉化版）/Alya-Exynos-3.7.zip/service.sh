#!/system/bin/sh
# ============================================================
#   Alya Exynos Tweak - service
#   Runs after boot complete
#   Version  : 3.7
#   Author   : Xyaeve
# ============================================================

# Wait for boot to complete
until [ "$(getprop sys.boot_completed)" = "1" ]; do
  sleep 2
done
sleep 5

LOG="/data/local/tmp/axmanager_exynos.log"
echo "=== Alya Exynos Tweak v3.7 started ===" > $LOG
echo "Date: $(date)" >> $LOG

# ── Helper function ───────────────────────────────────────
write() {
  [ -f "$1" ] && echo "$2" > "$1" 2>/dev/null && echo "[+] $1 = $2" >> $LOG
}

# ── CPU governor optimization ─────────────────────────────
for cpu in /sys/devices/system/cpu/cpu*/cpufreq/scaling_governor; do
  write "$cpu" "schedutil"
done

# ── CPU schedutil rate limit ──────────────────────────────
for rate in /sys/devices/system/cpu/cpufreq/schedutil/rate_limit_us; do
  write "$rate" "2000"
done
for rate in /sys/devices/system/cpu/cpu*/cpufreq/schedutil/rate_limit_us; do
  write "$rate" "2000"
done

# ── Scheduler latency tuning ─────────────────────────────
write /proc/sys/kernel/sched_latency_ns         "1000000"
write /proc/sys/kernel/sched_min_granularity_ns "100000"
write /proc/sys/kernel/sched_wakeup_granularity_ns "50000"
write /proc/sys/kernel/sched_tunable_scaling    "1"
write /proc/sys/kernel/sched_child_runs_first   "0"
write /proc/sys/kernel/sched_autogroup_enabled  "1"
echo "[+] Scheduler tweaks applied" >> $LOG

# ── Memory / VM tweaks ───────────────────────────────────
write /proc/sys/vm/swappiness             "10"
write /proc/sys/vm/vfs_cache_pressure     "50"
write /proc/sys/vm/dirty_background_ratio "5"
write /proc/sys/vm/dirty_ratio            "20"
write /proc/sys/vm/dirty_expire_centisecs "3000"
write /proc/sys/vm/dirty_writeback_centisecs "3000"
write /proc/sys/vm/page-cluster           "0"
write /proc/sys/vm/stat_interval          "10"
echo "[+] Memory tweaks applied" >> $LOG

# ── I/O scheduler optimization ───────────────────────────
for queue in /sys/block/*/queue/scheduler; do
  write "$queue" "mq-deadline"
done

# ── I/O queue depth & read-ahead ─────────────────────────
for nr_req in /sys/block/*/queue/nr_requests; do
  write "$nr_req" "64"
done
for read_ahead in /sys/block/*/queue/read_ahead_kb; do
  write "$read_ahead" "128"
done
for iosched in /sys/block/*/queue/iosched/fifo_batch; do
  write "$iosched" "16"
done
echo "[+] I/O tweaks applied" >> $LOG

# ── GPU optimization (Mali) ──────────────────────────────
write /sys/class/devfreq/mali/governor                   "simple_ondemand"
write /sys/class/devfreq/mali/polling_interval           "100"
write /sys/devices/platform/mali.0/power_policy          "coarse_demand"
for gpu_gov in /sys/class/devfreq/*/governor; do
  write "$gpu_gov" "simple_ondemand"
done
echo "[+] GPU tweaks applied" >> $LOG

# ── Thermal management ───────────────────────────────────
for thermal in /sys/class/thermal/thermal_zone*/mode; do
  write "$thermal" "enabled"
done
echo "[+] Thermal tweaks applied" >> $LOG

# ── Disable verbose kernel logging ───────────────────────
write /proc/sys/kernel/printk          "0 0 0 0"
write /proc/sys/kernel/dmesg_restrict  "0"

# ── Network stack optimization ───────────────────────────
write /proc/sys/net/ipv4/tcp_fastopen              "3"
write /proc/sys/net/ipv4/tcp_slow_start_after_idle "0"
write /proc/sys/net/ipv4/tcp_ecn                   "1"
write /proc/sys/net/ipv4/tcp_timestamps            "1"
write /proc/sys/net/core/rmem_max                  "8388608"
write /proc/sys/net/core/wmem_max                  "8388608"
echo "[+] Network stack tweaks applied" >> $LOG

# ── LMK (Low Memory Killer) tweaks ───────────────────────
write /sys/module/lowmemorykiller/parameters/enable_adaptive_lmk "1"
write /sys/module/lowmemorykiller/parameters/vmpressure_file_min "81920"
echo "[+] LMK tweaks applied" >> $LOG

echo " " >> $LOG
echo "=== All tweaks applied successfully ===" >> $LOG
