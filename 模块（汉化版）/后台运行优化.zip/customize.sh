#!/system/bin/sh
echo "尽情享受吧！"