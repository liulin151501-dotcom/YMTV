#!/system/bin/sh
MODDIR=${0%/*}
device_config put activity_manager use_compaction true
nohup $MODDIR/other/swap.sh&disown