#!/system/bin/sh
exec>/dev/null 2>&1

iorenice $$ 7 idle
renice -n 19 -p $$

while :; do

mem_total=$(awk '/MemTotal/ {print $2}' /proc/meminfo)  
mem_avail=$(awk '/MemAvailable/ {print $2}' /proc/meminfo)  
mem_pct=$(( (mem_total - mem_avail) * 100 / mem_total ))  

sleep_time=60    

# 如果内存使用率在65%到72%之间，进行轻度内存压缩  
if [ "$mem_pct" -gt 65 ] && [ "$mem_pct" -le 72 ]; then  
    compact_done=0  
    # 遍历所有后台用户进程并尝试压缩其内存（完整压缩）  
    for pid in $(ps -o pid,user,pcy | awk '/u0_.*bg/ {print $1}'); do  
        cmd activity compact full "$pid" && compact_done=1  
        cmd activity compact native full "$pid" && compact_done=1  
    done  
    # 对系统服务进行完整内存压缩  
    cmd activity compact system && compact_done=1  
    # 若执行了压缩操作，延长休眠时间至90秒  
    [ "$compact_done" -eq 1 ] && sleep_time=90  
# 如果内存使用率超过72%，强制停止部分第三方应用以释放内存  
elif [ "$mem_pct" -gt 72 ]; then  
    force_done=0  
    # 获取当前用户的第三方应用包名列表并保存到临时文件  
    cmd package list packages --user 0 -3 | cut -d: -f2 > /tmp/user_pkgs.txt  
    # 遍历后台用户进程，对属于第三方应用的进程执行强制停止  
    ps -o pid,user,pcy \  
    | awk '/u0_.*bg/ {print $1}' \  
    | xargs -r -n1 -P4 sh -c '  
        pid="$1"  
        [ -r "/proc/$pid/cmdline" ] || exit 0  

        # 从进程命令行提取包名  
        pkg=$(tr "\0" "\n" < /proc/$pid/cmdline | head -n1)  
        # 仅处理在第三方应用列表中的包  
        grep -qx "$pkg" /tmp/user_pkgs.txt || exit 0  

        # 强制停止该应用，并在成功时标记  
        cmd activity force-stop "$pkg" && echo 1 >> /tmp/force_flag  
    ' _  

    # 检查是否有成功强制停止的应用，若有则延长休眠时间至120秒  
    [ -f /tmp/force_flag ] && force_done=1 && rm -f /tmp/force_flag  
    [ "$force_done" -eq 1 ] && sleep_time=120  
fi  

sleep "$sleep_time"  