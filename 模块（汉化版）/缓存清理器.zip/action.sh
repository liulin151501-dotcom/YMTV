#!/system/bin/sh

trim_c() {
  echo "[缓存] 正在修剪系统缓存…"
  disksize=$(df -h /data | awk 'NR==2 {print $2}' | tr -d 'G')
  diskmath=$((disksize + 50))
  pm trim-caches "${diskmath}G"
  echo "[缓存] 系统缓存修剪完成"
}

appcache_clearonsize() {
  limitsize=$((15 * 1024))
  fg=$(cmd activity stack list | awk -F'[/{]' '/0,.*true/{print $3; exit}')

  echo "[缓存] 跳过的 foreground 应用: ${fg:-无}"
  echo "[缓存] 正在清除超过15MB的应用缓存…"

  pm list packages -u | cut -d: -f2 | while read -r a; do
    [ -z "$a" ] && continue
    [ "$a" = "$fg" ] && continue

    for cache in \
      "/sdcard/Android/data/$a/cache" \
      "/data/data/$a/cache" \
      "/data/user/0/$a/cache"
    do
      [ -d "$cache" ] || continue
      size=$(du -sk "$cache" 2>/dev/null | awk '{print $1}')
      [ -z "$size" ] && continue

      if [ "$size" -gt "$limitsize" ]; then
        rm -rf "$cache"/*
        echo "[缓存] 已清除应用缓存: $a"
      fi
    done
  done

  echo "[缓存] 应用缓存清理完成"
}

sdcard_thumbnail_cleanup() {
  echo "[缓存] 正在清理缩略图缓存…"

  for p in \
    "/sdcard/.thumbnails" \
    "/sdcard/.thumbnail" \
    "/sdcard/DCIM/.thumbnails" \
    "/sdcard/DCIM/.thumbnail" \
    "/sdcard/Pictures/.thumbnails" \
    "/sdcard/Pictures/.thumbnail"
  do
    [ -e "$p" ] || continue

    if [ -d "$p" ]; then
      rm -rf "$p"/*
      echo "[缓存] 已清空目录: $p"
    else
      rm -f "$p"
      echo "[缓存] 已移除文件: $p"
    fi
  done

  echo "[缓存] 缩略图清理完成"
}

trim_c
appcache_clearonsize
sdcard_thumbnail_cleanup
