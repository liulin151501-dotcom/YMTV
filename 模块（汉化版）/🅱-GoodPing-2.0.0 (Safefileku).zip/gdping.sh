#!/system/bin/sh

LOG="/data/local/tmp/goodping.log"
log() { echo "$(date): $1" >> "$LOG"; }

# 等待系统启动
until [ "$(getprop sys.boot_completed)" = "1" ]; do sleep 2; done
log "System boot completed."

# === DNS 设置（使用 ndc）===
ndc resolver setnetdns 0 "" 1.1.1.1 1.0.0.1
ndc resolver setnetdns 1 "" 9.9.9.9 8.8.8.8
ndc resolver flushdefaultif
for iface in $(ls /sys/class/net | grep -Ev 'lo|dummy'); do
    ndc resolver flushif "$iface" 2>/dev/null
done
log "DNS configured."

# === 内核参数设置（安全写入）===
set_sysctl() {
    local path="/proc/sys/net/${1//./\/}"
    [ -f "$path" ] && echo "$2" > "$path" 2>/dev/null && log "Set $1=$2"
}
set_sysctl net.ipv4.tcp_fastopen 1
set_sysctl net.ipv4.tcp_keepalive_time 30
set_sysctl net.ipv4.tcp_fin_timeout 15
set_sysctl net.ipv4.tcp_sack 1

# 激进网络优化（适合游戏/低延迟场景）
settings put global private_dns_mode opportunistic
settings put global private_dns_specifier cloudflare-dns.com
settings put global wifi_framework_scan_interval_ms 5000
settings put global wifi_supplicant_scan_interval_ms 5000
settings put global wifi_scan_throttle_enabled 0
settings put global network_scoring_ui_enabled 0
settings put global network_recommendations_enabled 0
settings put global network_prediction_enabled 1
settings put global data_activity_timeout_mobile -1
settings put global data_activity_timeout_wifi -1
cmd wifi force-hi-perf-mode enabled
cmd wifi set-connected-score 80
cmd connectivity set-multipath-preference true


# === 清理（可选）===
# dumpsys netstats --clear
# dumpsys connectivity --reset

log "🅱️-GoodPing 优化已激活"
cmd notification post -t "GoodPing" "网络优化完成" >/dev/null 2>&1.