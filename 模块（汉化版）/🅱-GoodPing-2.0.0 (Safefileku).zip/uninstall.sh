#!/system/bin/sh

LOG="/data/local/tmp/goodping_restore.log"
log() { echo "$(date): $1" >> "$LOG"; }

# 等待系统启动
until [ "$(getprop sys.boot_completed)" = "1" ]; do
    sleep 2
done
log "System boot completed. Starting restore..."

# ========================================
# 🔁 1. 恢复 DNS 设置（使用 ndc 清除自定义 DNS）
# ========================================
ndc resolver flushdefaultif
for iface in $(ls /sys/class/net | grep -Ev 'lo|dummy'); do
    ndc resolver flushif "$iface" 2>/dev/null
done
# 清除移动网络和 WiFi 的自定义 DNS（设为空 = 使用 DHCP/默认）
ndc resolver setnetdns 0 "" "" ""
ndc resolver setnetdns 1 "" "" ""
log "DNS restored to default (cleared custom DNS)."

# ========================================
# 🔁 2. 恢复 Private DNS 设置
# ========================================
settings put global private_dns_mode off
settings delete global private_dns_specifier
log "Private DNS disabled and specifier removed."

# ========================================
# 🔁 3. 恢复 WiFi 相关设置（回到保守值）
# ========================================
settings put global wifi_framework_scan_interval_ms 15000      # 默认约15秒
settings put global wifi_supplicant_scan_interval_ms 15000
settings put global wifi_scan_throttle_enabled 1              # 重新启用节流
settings put global wifi_watchdog_poor_network_test_enabled 1 # 恢复弱网检测
settings put global wifi_verbose_logging_enabled 0

# 恢复 WiFi 性能模式（关闭高性能模式）
cmd wifi force-hi-perf-mode disabled 2>/dev/null
cmd wifi set-connected-score 60                             # 默认评分
cmd wifi set-poll-rssi-interval-msecs 3000                   # 默认3秒

log "WiFi scan interval and performance mode restored."

# ========================================
# 🔁 4. 恢复网络行为设置（关闭激进优化）
# ========================================
settings put global network_scoring_ui_enabled 1              # 恢复UI提示
settings put global network_recommendations_enabled 1         # 恢复网络推荐
settings put global network_prediction_enabled 0              # 关闭预测（默认）
settings put global network_prefetch_enabled 0                # 关闭预取（默认）
settings put global data_activity_timeout_mobile 0            # 恢复超时断开（默认0=立即？实际看ROM，这里设为0或删）
settings put global data_activity_timeout_wifi 0
settings put global preferred_network_mode -1                 # 恢复自动选择（或删除）
settings put global network_switch_notification_daily_limit 3 # 恢复默认通知限制
settings put global network_switch_notification_rate_limit_millis 60000
settings put global network_watchlist_enabled null
settings put global network_avoid_bad_wifi 1                  # 恢复避开差WiFi
settings put global connectivity_metrics_buffer_size 1024     # 恢复默认缓冲

# 恢复 multipath 和后台策略
cmd connectivity set-multipath-preference false
cmd netpolicy set restrict-background true
cmd netpolicy set metered-network true

log "Network behavior settings restored to default."

# ========================================
# 🔁 5. 恢复 Airplane Mode 和网络状态（确保正常）
# ========================================
cmd connectivity airplane-mode disable
cmd connectivity set-default-network-active true
cmd netd resolver flushdefaultif
cmd netd resolver flushnet 0
cmd netd resolver flushnet 1
dumpsys connectivity --reset 2>/dev/null

log "Connectivity services reset."

# ========================================
# 🔁 6. （可选）恢复内核参数（谨慎！可能影响性能）
# ========================================
# 注意：这些参数可能被其他程序修改，恢复不一定精确
# 以下为常见默认值，仅作参考
restore_sysctl() {
    local path="/proc/sys/net/${1//./\/}"
    case "$1" in
        net.ipv4.tcp_fastopen)
            echo 0 > "$path" 2>/dev/null ;;  # 默认通常为 0 或 3（客户端+服务端）
        net.ipv4.tcp_keepalive_time)
            echo 7200 > "$path" 2>/dev/null ;; # 默认 2小时
        net.ipv4.tcp_fin_timeout)
            echo 60 > "$path" 2>/dev/null ;;   # 默认 60 秒
        net.ipv4.tcp_sack)
            echo 1 > "$path" 2>/dev/null ;;   # SACK 通常默认开启
    esac
    log "Restored $1 to default (approx)."
}

# 取消注释以下行以启用内核参数恢复（需 root）
# restore_sysctl net.ipv4.tcp_fastopen
# restore_sysctl net.ipv4.tcp_keepalive_time
# restore_sysctl net.ipv4.tcp_fin_timeout
# restore_sysctl net.ipv4.tcp_sack

# ========================================
# ✅ 完成还原
# ========================================
log "🅱️-GoodPing 优化已完全还原至默认状态。"
cmd notification post -t "GoodPing" "网络优化已还原" >/dev/null 2>&1

exit 0