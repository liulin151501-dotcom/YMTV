#!/system/bin/sh
exec>/dev/null 2>&1;while [ "$(getprop sys.boot_completed)" != 1 ];do sleep 5;done;MODDIR="${0%/*}"
alias cmd='/system/bin/nice -n -20 /system/bin/cmd';for a in /proc/sys/kernel/*panic*;do echo 0>"$a";done

# common root tweaks
sync;su -c sh "$MODDIR/other/root.sh" common

# update performance list
cmd package list packages --user 0 antutu|cut -f2 -d:>/storage/emulated/0/Android/media/.sosp/perflist.txt
cmd package list packages --user 0|grep -Eo "$(cat "$MODDIR/other/perflist.txt")">>/storage/emulated/0/Android/media/.sosp/perflist.txt

# start ./loop.sh
nohup "$MODDIR/other/loop.sh"&disown