#!/system/bin/sh
exec>/dev/null 2>&1;pgrep -f $0|grep -v $$|xargs kill -9;MODDIR="${0%/*}"
alias cmd='/system/bin/nice -n 19 /system/bin/cmd'
alias preload=/data/local/tmp/touch
cmd activity force-stop "$(cmd activity stack list|grep -m1 0,0.*=true|awk -F'[/{]' '{print$3}')"
chrt -i -p $$ 0;iorenice "$$" 7 idle;renice -n 19 -p "$$"
file_limit="$(echo "$(grep MemTotal /proc/meminfo|awk '{print$2}')/(2^16)"|bc)"
for a in 1 2 4 8 10 20 40 80 100 200 400 800 1000 2000 4000 8000;do taskset -ap "$a" $$;done
img="file:///storage/emulated/0/Android/media/.sosp/sac.jpg"
while true;do sleep 10

  # check top app
  top_app="$(cmd activity stack list|grep -m1 0,0.*=true|awk -F'[/{]' '{print$3}')"

  # check current app
  if [ "$current_app" != "$top_app" ];then current_app="$top_app"

    # check playing game
    if grep -m1 "$top_app" /storage/emulated/0/Android/media/.sosp/perflist.txt;then

      # auto preload
      if [ "$(grep preload /storage/emulated/0/Android/media/.sosp/settings.ini|cut -f2 -d=)" = "true" ];then
        cmd notification post -t Preloading -i "$img" -I "$img" apl $top_app
        su -lp 2000 -c "cmd notification post -t Preloading -i '$img' -I '$img' apl $top_app"
        for package_assets in $(find "/data/user/0/$top_app" "/storage/emulated/0/Android/data/$top_app" "$(dumpsys package "$top_app"|grep -o codePath=.*|sed 's/codePath=//')" -type f -exec du -b {} +|sort -n|tail -n$file_limit|awk '{$1="";sub(/^/,"");print}');do
          target="$package_assets $target"
        done;preload $target
        cmd notification post -t Preloaded -i "$img" -I "$img" apl $top_app
        su -lp 2000 -c "cmd notification post -t Preloaded -i '$img' -I '$img' apl $top_app"
      fi
      # auto preload

      # automatic mode
      if [ "$current_mode" != "gaming" ];then current_mode="gaming"
        cmd settings put system light_speed_app "$top_app"
        for background in $(cmd package list packages --user 0|cut -f2 -d:);do cmd activity kill --user 0 "$background"&done
        sh "$MODDIR/option.sh" $(grep gaming /storage/emulated/0/Android/media/.sosp/settings.ini|cut -f2 -d=)
      fi
    else
      if [ "$current_mode" != "daily" ];then current_mode="daily"
        cmd settings delete system light_speed_app
        cmd activity compact system;cmd activity force-stop com.android.shell;cmd battery reset
        sh "$MODDIR/option.sh" $(grep daily /storage/emulated/0/Android/media/.sosp/settings.ini|cut -f2 -d=)
      fi
      # automatic mode

    fi
    # check playing game

  fi
  # check current app

  # minimize loop cpu load
  if [ "$current_mode" = "gaming" ];then

    # uncheck anything while gaming
    while true;do
      grep -Em1 'top-app|foreground' "/proc/$(pidof $top_app)/cgroup"&&sleep 10||break
      cmd battery reset;cmd battery set temp 200
    done
    # uncheck anything while gaming

  else

    # longer loop delay when power off
    if [ "$(cmd deviceidle get screen)" = false ];then sleep 1m

      # run in every 3am
      if [ "$(date +%H)" = 03 ];then
        sm fstrim
        if [ "$(grep compile /storage/emulated/0/Android/media/.sosp/settings.ini|cut -f2 -d=)" = "true" ];then
          warning()([ "$(cmd deviceidle get screen)" = false ]&&input keyevent 26;cmd activity force-stop com.android.shell;cmd notification post -t "dex2oat is running" sai "do not use your device";su -lp 2000 -c "cmd notification post -t 'dex2oat is running' sai 'do not use your device'")
          for a in $(cmd package list packages --user 0 -3|cut -f2 -d:);do warning
            dumpsys package "$a"|grep -m1 status=speed&&continue
            cmd package delete-dexopt "$a"
            cmd package compile -m speed -f "$a"
          done&
          for b in $(cmd package list packages --user 0 -s|cut -f2 -d:);do warning
            dumpsys package "$b"|grep -m1 status=space&&continue
            cmd package delete-dexopt "$b"
            cmd package compile -m space -f "$b"
          done&
          wait;cmd activity force-stop com.android.shell
          [ "$(cmd deviceidle get screen)" = true ]&&input keyevent 26
        fi
        sleep 1h
      fi
      # run in every 3am

    else

      # run in every 10 minute
      current_minute="$(($(date +%M)/10))"
      if [ "$current_minute" != "$minute" ];then minute="$current_minute"

        # minimize logging
        ps -eo PID,USER|awk '/u0_/{print$1}'|while read process_id;do
          cmd activity app-logging "$process_id" 0 disable-text
          cmd activity profile stop "$process_id"
          cmd activity set-watch-heap "$process_id" 0
        done
        logcat -P "$(ps -eo %cpu,pid|grep -Ev '%|0.0'|awk '{print "~"$2}')"
        logcat --wrap
        pkill -f dumpsys logcat
        # minimize logging

      fi
      # run in every 10 minute

    fi
    # longer loop delay when power off

  fi
  # minimize loop cpu load

  # reset mode if settings changed
  current_checksum="$(md5sum -b /storage/emulated/0/Android/media/.sosp/settings.ini)"
  if [ "$current_checksum" != "$checksum" ];then checksum="$current_checksum" current_app="reset" current_mode="reset";fi
  # reset mode if settings changed

done