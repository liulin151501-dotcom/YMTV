#!/system/bin/sh
exec>/dev/null 2>&1;pgrep -f $0|grep -v $$|xargs kill -9
a="$(echo 2^30|bc)"
for b in $(dumpsys game|grep -Eo 'package [^ ]+|Name:[^ ]+'|sed 's/.* //;s/Name://');do
  cmd device_config put game_overlay "$b" "mode=2,downscaleFactor=$1,useAngle=false,fps=240,loadingBoost=$a"
  cmd game set --mode 2 --downscale "$1" --fps 240 "$b"
done