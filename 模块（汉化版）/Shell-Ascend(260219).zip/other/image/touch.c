/*
  credit: t.me/Koneko_dev (t.me/Droid_ch)
  modder: t me/HoyoSlave (t.me/S_O_S_P)
*/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <time.h>
#include <pthread.h>
#include <dlfcn.h>
#include <sys/sysinfo.h>
#include <sys/resource.h>
#include <sys/stat.h>
#include <sys/mman.h>
#include <fcntl.h>
#include <errno.h>
#include <signal.h>
#include <limits.h>
#include <stdarg.h>
#define PATH_MAX_LEN 1024
static int THREADS=0;
static volatile sig_atomic_t shutdown_flag = 0;
static volatile sig_atomic_t cycle_shutdown_flag = 0;
static pthread_mutex_t lock=PTHREAD_MUTEX_INITIALIZER;
static pthread_cond_t task_cond=PTHREAD_COND_INITIALIZER;
typedef struct preload_task {
  char path[PATH_MAX_LEN];
  struct preload_task *next;
} preload_task_t;
static preload_task_t *task_queue=NULL;
static preload_task_t *task_queue_tail=NULL;
static size_t queued_count=0;
static void task_push(const char *path){
  if(!path||strlen(path)>=PATH_MAX_LEN) return;
  preload_task_t *n=malloc(sizeof(*n));
  if(!n) return;
  strncpy(n->path,path,PATH_MAX_LEN-1); n->path[PATH_MAX_LEN-1]=0;
  n->next=NULL;
  pthread_mutex_lock(&lock);
  if(task_queue_tail){task_queue_tail->next=n;}else{task_queue=n;}
  task_queue_tail=n; queued_count++;
  pthread_cond_signal(&task_cond);
  pthread_mutex_unlock(&lock);
}
static preload_task_t* task_pop(void){
  pthread_mutex_lock(&lock);
  while(!task_queue && !shutdown_flag && !cycle_shutdown_flag)
    pthread_cond_wait(&task_cond,&lock);
  preload_task_t *n=task_queue;
  if(n){
    task_queue=n->next; if(!task_queue) task_queue_tail=NULL;
    queued_count--;
  }
  pthread_mutex_unlock(&lock); return n;
}
static void do_fadvise(const char *path){
  int fd=open(path,O_RDONLY|O_CLOEXEC); if(fd<0) return;
  posix_fadvise(fd,0,0,POSIX_FADV_WILLNEED);
  close(fd);
}
static void do_mmap(const char *path){
  int fd=open(path,O_RDONLY|O_CLOEXEC); if(fd<0) return;
  struct stat st; if(fstat(fd,&st)<0||st.st_size==0){close(fd);return;}
  if(st.st_size>512*1024*1024){close(fd);return;}
  void *m=mmap(NULL,st.st_size,PROT_READ,MAP_SHARED|MAP_POPULATE,fd,0);
  if(m!=MAP_FAILED){
    munmap(m,st.st_size);
  }else{do_fadvise(path);}
  close(fd);
}
static void do_dlopen(const char *path){
  void *h=dlopen(path,RTLD_LAZY|RTLD_LOCAL);
  if(h){dlclose(h);}
}
static void* worker_thread(void *arg){
  (void)arg;
  while(!shutdown_flag && !cycle_shutdown_flag){
    preload_task_t *t=task_pop();
    if(!t) continue;
    char *ext=strrchr(t->path,'.');
    int is_so=(ext&&strcmp(ext,".so")==0);
    if(is_so) do_dlopen(t->path);
    else do_mmap(t->path);
    free(t);
  }
  return NULL;
}
static void process_paths(int argc, char *argv[]){
  for(int i=1; i<argc; i++){
    const char *path = argv[i];
    struct stat st;
    if(stat(path,&st)==0 && S_ISREG(st.st_mode)){
      task_push(path);
    }
  }
}
static void sighnd(int sig){
  (void)sig;
  shutdown_flag=1;
  cycle_shutdown_flag=1;
  pthread_cond_broadcast(&task_cond);
}
int main(int argc,char *argv[]){
  signal(SIGINT,sighnd); signal(SIGTERM,sighnd);
  if(argc<2) return 0;
  if(THREADS<=0) THREADS=get_nprocs_conf();
  if(!getuid()){setpriority(PRIO_PROCESS,0,-20);}
  else{setpriority(PRIO_PROCESS,0,-15);}
  cycle_shutdown_flag = 0;
  process_paths(argc, argv);
  if(!queued_count) return 0;
  pthread_t *th=calloc(THREADS,sizeof(pthread_t));
  for(int i=0;i<THREADS;i++) pthread_create(&th[i],NULL,worker_thread,NULL);
  while(1) {
    pthread_mutex_lock(&lock);
    size_t qc = queued_count;
    pthread_mutex_unlock(&lock);
    if (qc == 0) break;
    usleep(100000);
    if(shutdown_flag) break;
  }
  cycle_shutdown_flag = 1;
  pthread_cond_broadcast(&task_cond);
  for(int i=0;i<THREADS;i++) pthread_join(th[i],NULL);
  free(th);
  return shutdown_flag?1:0;
}