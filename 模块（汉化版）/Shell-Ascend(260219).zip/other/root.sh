#!/system/bin/sh
# credit: t.me/Rem01Gaming (t.me/rem01schannel)
# modder: t me/HoyoSlave (t.me/S_O_S_P)
exec>/dev/null 2>&1
apply()(
  chmod 644 "$2"
  echo "$1" >"$2"
  chmod 444 "$2"
)
common()(
  for dir in /sys/block/*;do
    apply 0 "$dir/queue/iostats"
    apply 0 "$dir/queue/add_random"
  done
  for algo in bbr3 bbr2 bbrplus bbr westwood cubic;do
    if grep "$algo" /proc/sys/net/ipv4/tcp_available_congestion_control;then
      apply "$algo" /proc/sys/net/ipv4/tcp_congestion_control
      break
    fi
  done
  apply 1 /proc/sys/net/ipv4/tcp_low_latency
  apply 1 /proc/sys/net/ipv4/tcp_ecn
  apply 3 /proc/sys/net/ipv4/tcp_fastopen
  apply 1 /proc/sys/net/ipv4/tcp_sack
  apply 0 /proc/sys/net/ipv4/tcp_timestamps
  apply 3 /proc/sys/kernel/perf_cpu_time_max_percent
  apply 0 /proc/sys/kernel/sched_schedstats
  apply 0 /proc/sys/kernel/task_cpustats_enable
  apply 0 /proc/sys/kernel/sched_autogroup_enabled
  apply 1 /proc/sys/kernel/sched_child_runs_first
  apply 32 /proc/sys/kernel/sched_nr_migrate
  apply 50000 /proc/sys/kernel/sched_migration_cost_ns
  apply 1000000 /proc/sys/kernel/sched_min_granularity_ns
  apply 1500000 /proc/sys/kernel/sched_wakeup_granularity_ns
  apply 0 /proc/sys/vm/page-cluster
  apply 15 /proc/sys/vm/stat_interval
  apply 0 /proc/sys/vm/compaction_proactiveness
  apply 0 /sys/module/mmc_core/parameters/use_spi_crc
  apply 0 /sys/module/opchain/parameters/chain_on
  apply 0 /sys/module/cpufreq_bouncing/parameters/enable
  apply 0 /proc/task_info/task_sched_info/task_sched_info_enable
  apply 0 /proc/oplus_scheduler/sched_assist/sched_assist_enabled
  apply "libunity.so, libil2cpp.so, libmain.so, libUE4.so, libgodot_android.so, libgdx.so, libgdx-box2d.so, libminecraftpe.so, libLive2DCubismCore.so, libyuzu-android.so, libryujinx.so, libcitra-android.so, libhdr_pro_engine.so, libandroidx.graphics.path.so, libeffect.so" /proc/sys/kernel/sched_lib_name
  apply 255 /proc/sys/kernel/sched_lib_mask_force
  for dir in /sys/class/thermal/thermal_zone*;do
    apply "step_wise" "$dir/policy"
  done
)
performance_profile()(
  if [ -f /sys/module/battery_saver/parameters/enabled ];then
    if grep '[0-9]\+' /sys/module/battery_saver/parameters/enabled;then
      apply 0 /sys/module/battery_saver/parameters/enabled
    else
      apply N /sys/module/battery_saver/parameters/enabled
    fi
  fi
  apply 0 /proc/sys/kernel/split_lock_mitigate
  if [ -f "/sys/kernel/debug/sched_features" ];then
    apply NEXT_BUDDY /sys/kernel/debug/sched_features
    apply NO_TTWU_QUEUE /sys/kernel/debug/sched_features
  fi
  if [ -d "/dev/stune/" ];then
    apply 1 /dev/stune/top-app/schedtune.prefer_idle
    apply 1 /dev/stune/top-app/schedtune.boost
  fi
  if [ -d "/proc/touchpanel" ];then
    apply 1 /proc/touchpanel/game_switch_enable
    apply 0 /proc/touchpanel/oplus_tp_limit_enable
    apply 0 /proc/touchpanel/oppo_tp_limit_enable
    apply 1 /proc/touchpanel/oplus_tp_direction
    apply 1 /proc/touchpanel/oppo_tp_direction
  fi
  apply 80 /proc/sys/vm/vfs_cache_pressure
  for dir in /sys/block/mmcblk0 /sys/block/mmcblk1 /sys/block/sd*;do
    apply 32 "$dir/queue/read_ahead_kb"
    apply 32 "$dir/queue/nr_requests"
  done
  echo 3 >/proc/sys/vm/drop_caches
)
balance_profile()(
  if [ -f /sys/module/battery_saver/parameters/enabled ];then
    if grep '[0-9]\+' /sys/module/battery_saver/parameters/enabled;then
      apply 0 /sys/module/battery_saver/parameters/enabled
    else
      apply N /sys/module/battery_saver/parameters/enabled
    fi
  fi
  apply 1 /proc/sys/kernel/split_lock_mitigate
  if [ -f "/sys/kernel/debug/sched_features" ];then
    apply NEXT_BUDDY /sys/kernel/debug/sched_features
    apply TTWU_QUEUE /sys/kernel/debug/sched_features
  fi
  if [ -d "/dev/stune/" ];then
    apply 0 /dev/stune/top-app/schedtune.prefer_idle
    apply 1 /dev/stune/top-app/schedtune.boost
  fi
  if [ -d "/proc/touchpanel" ];then
    apply 0 /proc/touchpanel/game_switch_enable
    apply 1 /proc/touchpanel/oplus_tp_limit_enable
    apply 1 /proc/touchpanel/oppo_tp_limit_enable
    apply 0 /proc/touchpanel/oplus_tp_direction
    apply 0 /proc/touchpanel/oppo_tp_direction
  fi
  apply 120 /proc/sys/vm/vfs_cache_pressure
  for dir in /sys/block/mmcblk0 /sys/block/mmcblk1 /sys/block/sd*;do
    apply 128 "$dir/queue/read_ahead_kb"
    apply 64 "$dir/queue/nr_requests"
  done
)
powersave_profile()(
  balance_profile
  if [ -f /sys/module/battery_saver/parameters/enabled ];then
    if grep '[0-9]\+' /sys/module/battery_saver/parameters/enabled;then
      apply 1 /sys/module/battery_saver/parameters/enabled
    else
      apply Y /sys/module/battery_saver/parameters/enabled
    fi
  fi
)
case "$1" in
  "common") common ;;
  "performance") performance_profile ;;
  "balance") balance_profile ;;
  "powersave") powersave_profile ;;
esac