#!/system/bin/sh
exec>/dev/null 2>&1;MODDIR="${0%/*}"
mtask="/storage/emulated/0/Android/media/.sosp/mtask"
sprof="/storage/emulated/0/Android/media/.sosp/sprof"
alias cmd='/system/bin/nice -n -20 /system/bin/cmd'
cmd deviceidle except-idle-whitelist reset
cmd deviceidle sys-whitelist reset
img="file:///storage/emulated/0/Android/media/.sosp/sac.jpg"
refresh()(
  for power_center in $(cmd settings list system|grep power_center|cut -f1 -d=);do
    cmd settings put system "$power_center" -1
  done
  cmd package install $(cmd package path com.miui.securitycenter|cut -f2 -d:)&&sleep 5
  cmd settings get global default_restrict_background_data|grep 1&&cmd netpolicy set restrict-background true
  cmd settings put global low_power_sticky 0 default
  dumpsys content|grep -o settings/.*refresh_rate:|sed "s|settings/|cmd settings put |;s|/| |;s|:| $(dumpsys display|grep -Eo 'fps=[^.]+'|cut -f2 -d=|sort -n|uniq|tail -n1)|"|sh
)
activity_manager()(
  cmd settings delete global activity_manager_constants
  for namekeyval in $(cmd device_config list|grep activity_manager|cut -f1 -d=);do
    cmd device_config delete "${namekeyval%/*}" "${namekeyval#*/}"
  done
  for line in $(dumpsys activity settings|grep _.*=[0-9]);do
    key="${line%%=*}" val="${line#*=}"
    if [[ "$key" == *time* || "$key" == *interval* ]];then
      newval="$val"
    else
      newval="$(echo "$val*$1"|bc)"
      if [[ "$val" == 0.* ]];then
         newval="$(echo "$newval"|sed 's/^\./0./')"
      else
         newval="$(echo "$newval"|cut -f1 -d.)"
      fi
    fi
    keyval="$keyval,$key=$newval"
    cmd device_config put activity_manager "$key" "$newval"&
  done
  cmd settings put global activity_manager_constants "cmd=tweaks$keyval" default
)
performance()(echo "Performance">$sprof
  su -c sh "$MODDIR/root.sh" performance
  for a in $(dumpsys content|grep -o cloud_turbo.*enable.*|cut -f1 -d:);do
    cmd settings put system "$a" true
  done
  cmd settings put global activity_manager_constants max_cached_processes=64,background_settle_time=5000,fgservice_min_shown_time=1000,fgservice_min_report_time=5000,fgservice_screen_on_before_time=5000,fgservice_screen_on_after_time=15000,content_provider_retain_time=240000,gc_timeout=2500,gc_min_interval=30000,full_pss_min_interval=60000,full_pss_lowered_interval=30000,power_check_interval=5000,power_check_max_cpu_1=50,power_check_max_cpu_2=75,power_check_max_cpu_3=100,power_check_max_cpu_4=100,service_usage_interaction_time=10000,usage_stats_interaction_interval=86400000,service_restart_duration=5000,service_reset_run_duration=30000,service_restart_duration_factor=4,service_min_restart_time_between=5000,service_max_inactivity=900000,service_bg_start_timeout=15000,CUR_MAX_CACHED_PROCESSES=48,CUR_MAX_EMPTY_PROCESSES=32,CUR_TRIM_EMPTY_PROCESSES=16,CUR_TRIM_CACHED_PROCESSES=24,max_phantom_processes=64,binder_cpu_max_loops=10,binder_cpu_starvation_threshold=10,binder_cpu_threshold=50,binder_cpu_check_interval=10000,binder_cpu_max_retries=5,binder_cpu_retry_delay=1000,binder_cpu_throttle_delay=1000,binder_cpu_throttle_increment=1000,binder_cpu_throttle_max=10000,binder_cpu_throttle_min=1000,binder_cpu_throttle_period=10000,binder_cpu_throttle_window=10000,binder_cpu_throttle_enabled=false,binder_cpu_throttle_debug=false,binder_cpu_throttle_kill=false,binder_cpu_throttle_kill_delay=10000,binder_cpu_throttle_kill_interval=10000,binder_cpu_throttle_kill_max=10,binder_cpu_throttle_kill_min=1,binder_cpu_throttle_kill_period=10000,binder_cpu_throttle_kill_window=10000
  cmd settings put global app_standby_constants elapsed_threshold_absolute=604800000,elapsed_threshold_interactive=302400000,elapsed_threshold_stable=1209600000,strong_usage_duration=28800000,notification_seen_duration=604800000,system_update_usage_duration=172800000,prediction_timeout=86400000,sync_adapter_duration=600000,exempted_sync_scheduled_nd_duration=300000,exempted_sync_start_duration=600000,system_interaction_duration=300000,initial_foreground_service_start_duration=300000,stable_charging_threshold=60000,role_holder_duration=43200000,trigger_quota_bump_on_notification_seen=true,enable_restricted_bucket=false,restricted_bucket_delay_ms=300000,restricted_bucket_hold_duration_ms=900000,slot_duration=3600000,window_size=10,max_bucket=45,parole_interval=21600000,parole_duration=3600000,notification_duration=30000,system_interaction_logging_duration=300000
  cmd settings put global battery_saver_constants adjust_brightness_factor=1.0,adjust_brightness_disabled=false,datasaver_disabled=true,force_all_apps_standby=false,force_background_check=false,gps_mode=0,job_scheduler_disabled=false,quick_doze_enabled=false,sound_trigger_disabled=false,vibration_disabled=false,fullbackup_deferred=false,keyvaluebackup_deferred=false,gps_disabled=false,launch_boost_disabled=false,optional_sensors_disabled=false,sound_trigger_mode=0,vibration_mode=0
  cmd settings put global device_idle_constants light_after_inactive_to=7200000,light_pre_idle_to=7200000,light_idle_to=3600000,light_idle_factor=2.0,light_max_idle_to=7200000,light_idle_maintenance_min_budget=60000,light_idle_maintenance_max_budget=300000,min_light_maintenance_time=5000,min_deep_maintenance_time=30000,inactive_to=7200000,sensing_to=4000,locating_to=5000,location_accuracy=20.0,motion_inactive_to=60000,idle_after_inactive_to=7200000,idle_to=86400000,wait_for_unlock=true,quick_doze_delay_to=300000,force_idle_delay=600000,light_standby_to=3600000,light_standby_factor=2.0,max_light_standby_to=7200000,light_standby_maintenance_min_budget=60000,light_standby_maintenance_max_budget=300000
  cmd settings put global job_scheduler_constants min_ready_non_active_jobs_count=5,max_non_active_jobs_count=10,min_charging_count=0,min_battery_not_low_count=0,min_storage_not_low_count=0,min_connectivity_count=0,min_content_count=0,min_idle_count=0,min_ready_jobs_count=5,heavy_use_factor=1.0,moderate_use_factor=0.8,fg_job_count=8,bg_normal_job_count=12,bg_moderate_job_count=24,bg_low_job_count=40,bg_critical_job_count=80,max_standard_reschedule_count=5,max_work_reschedule_count=10,min_linear_backoff_time=5000,min_exp_backoff_time=2500,max_backoff_time=18000000,min_backoff_time=5000,max_job_count_per_uid=300,max_job_count_active=200,max_job_count_working=100,max_job_count_failing=10,max_job_count_deferred=50,max_job_count_total=600,job_concurrent_io_cap=16,job_concurrent_network_cap=8,job_concurrent_cpu_cap=4,job_concurrent_compute_cap=2,parallel_runnable_threads=8,max_parallel_jobs_per_app=4,job_start_prefetch_count=2,job_stop_delay_ms=1000,job_expedited_delay_ms=500,job_heartbeat_fg_grace_ms=15000,job_heartbeat_bg_grace_ms=30000
  cmd settings put global job_scheduler_quota_controller_constants in_quota_buffers=5,window_size_ms=3600000,max_execution_time_ms=600000,max_job_count_active=200,max_job_count_working=100,max_job_count_failing=10,max_job_count_deferred=50,top_app_timer_duration_ms=300000,charging_timer_duration_ms=600000,battery_not_low_timer_duration_ms=600000,storage_not_low_timer_duration_ms=600000,connectivity_timer_duration_ms=300000,content_trigger_timer_duration_ms=300000,idle_timer_duration_ms=1800000
  cmd settings put global AudioPowerSaveMode 0 default
  cmd settings put global game_driver_all_apps 1 default
  cmd settings put global low_power 0 default
  cmd settings put global updatable_driver_all_apps 1 default
  cmd settings put global security_center_pc_save_mode_data '{"a":0,"b":-1,"c":-1,"d":-1}' default
  cmd settings put secure miui_optimization 0 default
  cmd settings put system POWER_BALANCED_MODE_OPEN 0
  cmd settings put system POWER_PERFORMANCE_MODE_OPEN 1
  cmd settings put system POWER_SAVE_MODE_OPEN 0
  cmd settings put system POWER_SAVE_PRE_HIDE_MODE performance
  cmd settings put system cloud_schedboost_enable true
  cmd settings put system power_mode_level 0
  cmd settings put system speed_mode 1
  cmd thermalservice override-status 0
  logcat -G 8m
  cmd notification post -t "Performance Profile" -i "$img" -I "$img" sac ''
  su -lp 2000 -c "cmd notification post -t 'Performance Profile' -i '$img' -I '$img' sac ''"
)
balance()(echo "Balanced">$sprof
  su -c sh "$MODDIR/root.sh" balance
  for a in $(dumpsys content|grep -o cloud_turbo.*enable.*|cut -f1 -d:);do
    cmd settings put system "$a" false
  done
  cmd settings put global activity_manager_constants max_cached_processes=16,background_settle_time=10000,fgservice_min_shown_time=2000,fgservice_min_report_time=5000,fgservice_screen_on_before_time=10000,fgservice_screen_on_after_time=30000,content_provider_retain_time=120000,gc_timeout=5000,gc_min_interval=60000,full_pss_min_interval=120000,full_pss_lowered_interval=60000,power_check_interval=15000,power_check_max_cpu_1=25,power_check_max_cpu_2=50,power_check_max_cpu_3=75,power_check_max_cpu_4=100,service_usage_interaction_time=10000,usage_stats_interaction_interval=86400000,service_restart_duration=10000,service_reset_run_duration=60000,service_restart_duration_factor=4,service_min_restart_time_between=10000,service_max_inactivity=1800000,service_bg_start_timeout=30000,CUR_MAX_CACHED_PROCESSES=12,CUR_MAX_EMPTY_PROCESSES=8,CUR_TRIM_EMPTY_PROCESSES=4,CUR_TRIM_CACHED_PROCESSES=8,max_phantom_processes=16,binder_cpu_max_loops=10,binder_cpu_starvation_threshold=10,binder_cpu_threshold=50,binder_cpu_check_interval=10000,binder_cpu_max_retries=5,binder_cpu_retry_delay=1000,binder_cpu_throttle_delay=1000,binder_cpu_throttle_increment=1000,binder_cpu_throttle_max=10000,binder_cpu_throttle_min=1000,binder_cpu_throttle_period=10000,binder_cpu_throttle_window=10000,binder_cpu_throttle_enabled=true,binder_cpu_throttle_debug=false,binder_cpu_throttle_kill=false,binder_cpu_throttle_kill_delay=10000,binder_cpu_throttle_kill_interval=10000,binder_cpu_throttle_kill_max=10,binder_cpu_throttle_kill_min=1,binder_cpu_throttle_kill_period=10000,binder_cpu_throttle_kill_window=10000
  cmd settings put global app_standby_constants elapsed_threshold_absolute=43200000,elapsed_threshold_interactive=21600000,elapsed_threshold_stable=86400000,strong_usage_duration=3600000,notification_seen_duration=43200000,system_update_usage_duration=21600000,prediction_timeout=21600000,sync_adapter_duration=300000,exempted_sync_scheduled_nd_duration=150000,exempted_sync_start_duration=300000,system_interaction_duration=150000,initial_foreground_service_start_duration=150000,stable_charging_threshold=120000,role_holder_duration=21600000,trigger_quota_bump_on_notification_seen=true,enable_restricted_bucket=true,restricted_bucket_delay_ms=600000,restricted_bucket_hold_duration_ms=1800000,slot_duration=7200000,window_size=10,max_bucket=50,parole_interval=172800000,parole_duration=300000,notification_duration=60000,system_interaction_logging_duration=300000
  cmd settings put global battery_saver_constants adjust_brightness_factor=0.7,adjust_brightness_disabled=false,datasaver_disabled=false,force_all_apps_standby=true,force_background_check=true,gps_mode=1,job_scheduler_disabled=true,quick_doze_enabled=true,sound_trigger_disabled=true,vibration_disabled=true,fullbackup_deferred=true,keyvaluebackup_deferred=true,gps_disabled=true,launch_boost_disabled=true,optional_sensors_disabled=true,sound_trigger_mode=1,vibration_mode=1
  cmd settings put global device_idle_constants light_after_inactive_to=120000,light_pre_idle_to=180000,light_idle_to=600000,light_idle_factor=3.0,light_max_idle_to=1800000,light_idle_maintenance_min_budget=120000,light_idle_maintenance_max_budget=600000,min_light_maintenance_time=10000,min_deep_maintenance_time=60000,inactive_to=600000,sensing_to=8000,locating_to=10000,location_accuracy=50.0,motion_inactive_to=120000,idle_after_inactive_to=1800000,idle_to=7200000,wait_for_unlock=true,quick_doze_delay_to=60000,force_idle_delay=30000,light_standby_to=600000,light_standby_factor=3.0,max_light_standby_to=1800000,light_standby_maintenance_min_budget=120000,light_standby_maintenance_max_budget=600000
  cmd settings put global job_scheduler_constants min_ready_non_active_jobs_count=0,max_non_active_jobs_count=2,min_charging_count=1,min_battery_not_low_count=1,min_storage_not_low_count=1,min_connectivity_count=1,min_content_count=1,min_idle_count=1,min_ready_jobs_count=0,heavy_use_factor=0.9,moderate_use_factor=0.5,fg_job_count=2,bg_normal_job_count=4,bg_moderate_job_count=8,bg_low_job_count=12,bg_critical_job_count=20,max_standard_reschedule_count=8,max_work_reschedule_count=15,min_linear_backoff_time=30000,min_exp_backoff_time=15000,max_backoff_time=36000000,min_backoff_time=30000,max_job_count_per_uid=100,max_job_count_active=50,max_job_count_working=25,max_job_count_failing=20,max_job_count_deferred=30,max_job_count_total=150,job_concurrent_io_cap=4,job_concurrent_network_cap=2,job_concurrent_cpu_cap=1,job_concurrent_compute_cap=1,parallel_runnable_threads=2,max_parallel_jobs_per_app=1,job_start_prefetch_count=0,job_stop_delay_ms=5000,job_expedited_delay_ms=2000,job_heartbeat_fg_grace_ms=30000,job_heartbeat_bg_grace_ms=60000
  cmd settings put global job_scheduler_quota_controller_constants in_quota_buffers=2,window_size_ms=7200000,max_execution_time_ms=300000,max_job_count_active=50,max_job_count_working=25,max_job_count_failing=20,max_job_count_deferred=30,top_app_timer_duration_ms=180000,charging_timer_duration_ms=1200000,battery_not_low_timer_duration_ms=1200000,storage_not_low_timer_duration_ms=1200000,connectivity_timer_duration_ms=180000,content_trigger_timer_duration_ms=180000,idle_timer_duration_ms=3600000
  cmd settings put global AudioPowerSaveMode 0 default
  cmd settings put global game_driver_all_apps 0 default
  cmd settings put global low_power 0 default
  cmd settings put global updatable_driver_all_apps 3 default
  cmd settings put global security_center_pc_save_mode_data '{"a":0,"b":-1,"c":0,"d":0}' default
  cmd settings put secure miui_optimization 1 default
  cmd settings put system POWER_BALANCED_MODE_OPEN 1
  cmd settings put system POWER_PERFORMANCE_MODE_OPEN 0
  cmd settings put system POWER_SAVE_MODE_OPEN 0
  cmd settings put system POWER_SAVE_PRE_HIDE_MODE enhance
  cmd settings put system cloud_schedboost_enable false
  cmd settings put system power_mode_level 0
  cmd settings put system speed_mode 0
  cmd thermalservice override-status 1
  logcat -G 1m
  cmd notification post -t "Balanced Profile" -i "$img" -I "$img" sac ''
  su -lp 2000 -c "cmd notification post -t 'Balanced Profile' -i '$img' -I '$img' sac ''"
)
powersave()(echo "Power Saver">$sprof
  su -c sh "$MODDIR/root.sh" powersave
  for a in $(dumpsys content|grep -o cloud_turbo.*enable.*|cut -f1 -d:);do
    cmd settings put system "$a" false
  done
  cmd settings put global activity_manager_constants=max_cached_processes=32,background_settle_time=10000,fgservice_min_shown_time=2000,fgservice_min_report_time=5000,fgservice_screen_on_before_time=10000,fgservice_screen_on_after_time=30000,content_provider_retain_time=120000,gc_timeout=5000,gc_min_interval=60000,full_pss_min_interval=120000,full_pss_lowered_interval=60000,power_check_interval=15000,power_check_max_cpu_1=25,power_check_max_cpu_2=50,power_check_max_cpu_3=75,power_check_max_cpu_4=100,service_usage_interaction_time=10000,usage_stats_interaction_interval=86400000,service_restart_duration=10000,service_reset_run_duration=60000,service_restart_duration_factor=4,service_min_restart_time_between=10000,service_max_inactivity=1800000,service_bg_start_timeout=30000,CUR_MAX_CACHED_PROCESSES=24,CUR_MAX_EMPTY_PROCESSES=16,CUR_TRIM_EMPTY_PROCESSES=8,CUR_TRIM_CACHED_PROCESSES=12,max_phantom_processes=32,binder_cpu_max_loops=10,binder_cpu_starvation_threshold=10,binder_cpu_threshold=50,binder_cpu_check_interval=10000,binder_cpu_max_retries=5,binder_cpu_retry_delay=1000,binder_cpu_throttle_delay=1000,binder_cpu_throttle_increment=1000,binder_cpu_throttle_max=10000,binder_cpu_throttle_min=1000,binder_cpu_throttle_period=10000,binder_cpu_throttle_window=10000,binder_cpu_throttle_enabled=true,binder_cpu_throttle_debug=false,binder_cpu_throttle_kill=false,binder_cpu_throttle_kill_delay=10000,binder_cpu_throttle_kill_interval=10000,binder_cpu_throttle_kill_max=10,binder_cpu_throttle_kill_min=1,binder_cpu_throttle_kill_period=10000,binder_cpu_throttle_kill_window=10000
  cmd settings put global app_standby_constants=elapsed_threshold_absolute=86400000,elapsed_threshold_interactive=43200000,elapsed_threshold_stable=172800000,strong_usage_duration=7200000,notification_seen_duration=86400000,system_update_usage_duration=43200000,prediction_timeout=43200000,sync_adapter_duration=600000,exempted_sync_scheduled_nd_duration=300000,exempted_sync_start_duration=600000,system_interaction_duration=300000,initial_foreground_service_start_duration=300000,stable_charging_threshold=60000,role_holder_duration=43200000,trigger_quota_bump_on notification_seen=true,enable_restricted_bucket=true,restricted_bucket_delay_ms=300000,restricted_bucket_hold_duration_ms=900000,slot_duration=3600000,window_size=10,max_bucket=45,parole_interval=86400000,parole_duration=600000,notification_duration=30000,system_interaction_logging_duration=300000
  cmd settings put global battery_saver_constants=adjust_brightness_factor=0.5,adjust_brightness_disabled=false,datasaver_disabled=false,force_all_apps_standby=false,force_background_check=false,gps_mode=2,job_scheduler_disabled=false,quick_doze_enabled=true,sound_trigger_disabled=false,vibration_disabled=false,fullbackup_deferred=true,keyvaluebackup_deferred=true,gps_disabled=false,launch_boost_disabled=false,optional_sensors_disabled=false,sound_trigger_mode=0,vibration_mode=0
  cmd settings put global device_idle_constants=light_after_inactive_to=300000,light_pre_idle_to=300000,light_idle_to=300000,light_idle_factor=2.0,light_max_idle_to=900000,light_idle_maintenance_min_budget=60000,light_idle_maintenance_max_budget=300000,min_light_maintenance_time=5000,min_deep_maintenance_time=30000,inactive_to=900000,sensing_to=4000,locating_to=5000,location_accuracy=20.0,motion_inactive_to=60000,idle_after_inactive_to=0,idle_to=3600000,wait_for_unlock=true,quick_doze_delay_to=30000,force_idle_delay=10500,light_standby_to=300000,light_standby_factor=2.0,max_light_standby_to=900000,light_standby_maintenance_min_budget=60000,light_standby_maintenance_max_budget=300000
  cmd settings put global job_scheduler_constants=min_ready_non_active_jobs_count=1,max_non_active_jobs_count=5,min_charging_count=1,min_battery_not_low_count=1,min_storage_not_low_count=1,min_connectivity_count=1,min_content_count=1,min_idle_count=1,min_ready_jobs_count=1,heavy_use_factor=0.9,moderate_use_factor=0.5,fg_job_count=4,bg_normal_job_count=6,bg_moderate_job_count=12,bg_low_job_count=20,bg_critical_job_count=40,max_standard_reschedule_count=5,max_work_reschedule_count=10,min_linear_backoff_time=10000,min_exp_backoff_time=5000,max_backoff_time=18000000,min_backoff_time=10000,max_job_count_per_uid=150,max_job_count_active=100,max_job_count_working=50,max_job_count_failing=10,max_job_count_deferred=50,max_job_count_total=300,job_concurrent_io_cap=8,job_concurrent_network_cap=4,job_concurrent_cpu_cap=2,job_concurrent_compute_cap=1,parallel_runnable_threads=4,max_parallel_jobs_per_app=2,job_start_prefetch_count=1,job_stop_delay_ms=2000,job_expedited_delay_ms=1000,job_heartbeat_fg_grace_ms=20000,job_heartbeat_bg_grace_ms=40000
  cmd settings put global job_scheduler_quota_controller_constants=in_quota_buffers=3,window_size_ms=5400000,max_execution_time_ms=450000,max_job_count_active=100,max_job_count_working=50,max_job_count_failing=10,max_job_count_deferred=50,top_app_timer_duration_ms=240000,charging_timer_duration_ms=900000,battery_not_low_timer_duration_ms=900000,storage_not_low_timer_duration_ms=900000,connectivity_timer_duration_ms=240000,content_trigger_timer_duration_ms=240000,idle_timer_duration_ms=2700000
  cmd settings put global AudioPowerSaveMode 1 default
  cmd settings put global game_driver_all_apps 0 default
  cmd settings put global low_power 1 default
  cmd settings put global updatable_driver_all_apps 3 default
  cmd settings put global security_center_pc_save_mode_data '{"a":1,"b":120,"c":0,"d":0}' default
  cmd settings put secure miui_optimization 0 default
  cmd settings put system POWER_BALANCED_MODE_OPEN 0
  cmd settings put system POWER_PERFORMANCE_MODE_OPEN 0
  cmd settings put system POWER_SAVE_MODE_OPEN 1
  cmd settings put system POWER_SAVE_PRE_HIDE_MODE ultimate
  cmd settings put system cloud_schedboost_enable false
  cmd settings put system power_mode_level 1
  cmd settings put system speed_mode 0
  cmd thermalservice override-status 2
  logcat -G 64k
  cmd notification post -t "Power Saver Profile" -i "$img" -I "$img" sac ''
  su -lp 2000 -c "cmd notification post -t 'Power Saver Profile' -i '$img' -I '$img' sac ''"
)
highest()(echo "Highest">$mtask
  activity_manager 1.5
  cmd activity memory-factor set 0
  cmd device_config put activity_manager low_swap_threshold_percent 1.0
)
high()(echo "High">$mtask
  activity_manager 1.25
  cmd activity memory-factor set 0
  cmd device_config put activity_manager low_swap_threshold_percent 0.8
)
medium()(echo "Medium">$mtask
  activity_manager 1
  cmd activity memory-factor set 1
  cmd device_config put activity_manager low_swap_threshold_percent 0.6
)
low()(echo "Low">$mtask
  activity_manager 0.75
  cmd activity memory-factor set 2
  cmd device_config put activity_manager low_swap_threshold_percent 0.4
)
lowest()(echo "Lowest">$mtask
  activity_manager 0.5
  cmd activity memory-factor set 3
  cmd device_config put activity_manager low_swap_threshold_percent 0.2
)
case "$1" in
  performance) performance;refresh ;;
  balance) balance;refresh ;;
  powersave) powersave;refresh ;;
esac
case "$2" in
  highest) highest ;;
  high) high ;;
  medium) medium ;;
  low) low ;;
  lowest) lowest ;;
esac