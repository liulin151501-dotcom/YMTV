#!/system/bin/sh
exec>/dev/null 2>&1;alias cmd='/system/bin/nice -n -20 /system/bin/cmd'
rm /storage/emulated/0/Android/cmd_tweaks.log
cmd notification post un Uninstalling
su -lp 2000 -c "cmd notification post un Uninstalling"
global()(cmd settings delete global "$1")
secure()(cmd settings delete secure "$1")
system()(cmd settings delete system "$1")
# service.sh
for a in com.sonymobile.advancedlogging com.miui.securityinputmethod com.longcheertel.modemlog com.vzw.qualitydatalog com.orange.tdd com.huawei.hms5gkit.agentservice com.motorola.android.nativedropboxagent com.motorola.android.settings.modemdebug com.motorola.systemserver com.samsung.android.galaxycontinuity com.samsung.android.ipsgeofence com.samsung.android.securitylogagent com.samsung.fresco.logging com.sec.android.app.servicemodeapp com.sec.android.RilServiceModeApp com.sec.app.RilErrorNotifier com.sec.hiddenmenu com.sec.imslogger com.sec.mldapchecker com.sec.modem.settings com.android.traceur com.oem.logkitsdservice com.oem.oemlogkit net.oneplus.commonlogtool com.mediatek.mdmlsample com.mediatek.thermalmanager com.mediatek.gnssdebugreport com.qti.diagservices com.qualcomm.qti.biometrics.fingerprint.service com.huaqin.btlogger com.oppo.logkitservice vendor.qti.qesdk.sysservice com.mediatek.bluetooth.dtt com.mediatek.mtklogger.proxy com.mediatek.gnss.nonframeworklbs com.qualcomm.qti.perfdump com.debug.loggerui com.mediatek.mtklogger com.bsp.catchlog com.huaqin.diaglogger com.miui.sysopt com.wt.secret_code_manager com.mi.emapal com.asus.configupdater com.asus.loguploader com.android.huawei.HiMediaEngine com.lge.ims.chatbotinfoprovider com.lge.gnsslogsetting com.lge.imsvt com.lge.lgdataphone com.lge.ims.rcsprovider com.meizu.account com.qualcomm.qti.sva cn.nubia.aftersale com.oneplus.commonoverlay.com.oneplus com.google.android.apps.carrier.log com.alcatel.mcrm com.transsion.kolun.aiservice com.vivo.devicereg com.vivo.findphone com.samsung.gpuwatchapp com.samsung.slsi.audiologging com.samsung.slsi.telephony.silentlogging com.oplus.obrain com.oplus.olc com.oplus.onetrace com.oplus.powermonitor com.oplus.stdsp com.xiaomi.mtb com.transsion.hamal com.oplus.lfeh com.huaqin.clearefs com.samsung.android.sm.provider com.ims.dm com.huawei.searchservice ohos.media.medialibrary com.thundercomm.ar.core com.google.android.grilservice com.huawei.smarthome com.huawei.hwpolicyservice com.vivo.alphacamera com.qualcomm.qti.trustedui com.sec.android.iaft;do
  cmd package install-existing "$a"&
done
for b in /storage/emulated/0/Android/data/com.miHoYo.GenshinImpact/files/hardware_model_config.json /storage/emulated/0/Android/data/com.miHoYo.GenshinImpact/files/vulkan_gpu_list_config.txt /storage/emulated/0/Android/data/com.miHoYo.GenshinImpact/files/vulkan_gpu_list_config_engine.txt;do
  rm -rf "$b"&
done
for c in $(find /storage/emulated/0/Android/data/*/files/dragon2017 -name *record*);do
  rm -rf "$c"&
done
for d in $(cmd package list packages google|cut -f2 -d:|grep -v ia.mo);do
  cmd appops reset "$d"
done
for e in $(dumpsys content|grep -o cloud_turbo.*enable.*|cut -f1 -d:);do
  system "$e"&
done
cmd device_config set_sync_disabled_for_tests none
global activity_starts_logging_enabled
global ble_scan_always_enabled
global multi_cb
secure speed_mode_enable
system miui_app_cache_optimization
# option.sh
"$MODDIR/stellar.sh" --resetting_sys
for a in $(cmd settings list global|grep _constants=|cut -f1 -d=);do
 global "$a"
done
for b in $(cmd device_config list|cut -f1 -d=);do
  cmd device_config delete "${b%/*}" "${b#*/}"&
done
global game_driver_all_apps
global security_center_pc_save_mode_data
global updatable_driver_all_apps
system POWER_BALANCED_MODE_OPEN
system POWER_PERFORMANCE_MODE_OPEN
system POWER_SAVE_MODE_OPEN
system POWER_SAVE_PRE_HIDE_MODE
system cloud_schedboost_enable
system speed_mode
# index.html
cmd deviceidle disable
cmd deviceidle unforce
cmd netpolicy set restrict-background false
cmd package install-existing com.google.android.gms
global default_restrict_background_data
global netstats_enabled
global package_verifier_user_consent
service call sensor_privacy 4 i32 0
service call sensor_privacy 8 i32 0
service call sensor_privacy 9 i32 0
# unreal.sh
for a in $(find /storage/emulated/0/Android/data/*/files/*Game -name Engine.ini|grep -ov /Engine.ini);do
  echo>"$a/DeviceProfiles.ini"&
  echo>"$a/Engine.ini"&
done
# scale.sh
for a in $(dumpsys game|grep -Eo 'package [^ ]+|Name:[^ ]+'|sed 's/.* //;s/Name://');do
  cmd game reset "$a"&
done
# loop.sh
global low_power
global low_power_sticky
system light_speed_app
wait
cmd notification post un Uninstalled,\ Please\ Reboot
su -lp 2000 -c "cmd notification post un Uninstalled,\ Please\ Reboot"