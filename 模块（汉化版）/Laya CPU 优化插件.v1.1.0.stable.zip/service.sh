#!/system/bin/sh
# AxManager 插件服务
# 本脚本运行在 AxManager 的 BusyBox ash 环境中。PATH 已包含 module/system/bin。
[ "$AXERON" != "true" ] && exit 0

BINARY=laya-cpuopt  # 可通过 module/system/bin 在 PATH 中找到

# 优雅地停止现有实例
if command -v pgrep >/dev/null 2>&1; then
    if pgrep -f "$BINARY" >/dev/null 2>&1; then
        pkill -f "$BINARY" || true
        sleep 1
    fi
fi

# 在后台启动优化器（AxManager 的 PATH 包含 module/system/bin）
# 二进制文件本身会尝试 setprop；如果没有权限，它会写入 /sdcard/laya-cpuopt-crash.log
if command -v "$BINARY" >/dev/null 2>&1; then
    "$BINARY" &
else
    # 备用方案：尝试 MODPATH/system/bin 的绝对路径
    if [ -x "${MODPATH}/system/bin/laya-cpuopt" ]; then
        "${MODPATH}/system/bin/laya-cpuopt" &
    fi
fi

# 发送启动通知
if command -v cmd >/dev/null 2>&1; then
    cmd notification post -t "AXManager" "Laya CPU 优化器" "Laya CPU 优化器 v1.1.0 已启动"
fi
