ui_print "Laya CPU 优化器 (Rust) 由 Laynsb 开发"
ui_print "致谢: @Koneko_dev (创意、概念与代码逻辑)"