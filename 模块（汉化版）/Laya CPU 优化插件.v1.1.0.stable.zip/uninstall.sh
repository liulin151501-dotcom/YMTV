#!/system/bin/sh
MODID="laya-cpuopt"
UNINSTALL_LOG=/sdcard/laya-cpuopt-uninstall.log

echo "[卸载] 正在停止 $MODID..." >> "$UNINSTALL_LOG"

# 首先尝试 pkill
if command -v pkill >/dev/null 2>&1; then
    pkill -f "$MODID" 2>/dev/null
fi

# 备用方案：使用 pgrep + kill
if command -v pgrep >/dev/null 2>&1; then
    for pid in $(pgrep -f "$MODID"); do
        kill -9 "$pid" 2>/dev/null
    done
fi

echo "[卸载] 完成。" >> "$UNINSTALL_LOG"
