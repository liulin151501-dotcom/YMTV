#!/system/bin/sh

R="\033[31m"
G="\033[32m"
Y="\033[33m"
B="\033[34m"
P="\033[35m"
C="\033[36m"
W="\033[37m"
N="\033[0m"

line() {
  echo -e "${B}────────────────────────────────────${N}"
}

echo -e "${P}===== 显示与刷新率设置 =====${N}"
echo -e "${C}系统峰值刷新率  : ${W}$(settings get system peak_refresh_rate)${N}"
echo -e "${C}安全峰值刷新率  : ${W}$(settings get secure peak_refresh_rate)${N}"
echo -e "${C}系统最低刷新率  : ${W}$(settings get system min_refresh_rate)${N}"
echo -e "${C}全局锁定刷新率  : ${W}$(settings get global refresh_rate)${N}"

echo
line
echo -e "${P}===== SurfaceFlinger 应用阶段持续时间（纳秒） =====${N}"
echo -e "${G}早期应用渲染时长        : ${W}$(getprop debug.sf.early.app.duration)${N}"
echo -e "${G}晚期应用渲染时长         : ${W}$(getprop debug.sf.late.app.duration)${N}"
echo -e "${G}高帧率模式 - 早期应用时长   : ${W}$(getprop debug.sf.high_fps.early.app.duration)${N}"
echo -e "${G}高帧率模式 - 晚期应用时长   : ${W}$(getprop debug.sf.high_fps.late.app.duration)${N}"

echo
line
echo -e "${P}===== SurfaceFlinger 合成器阶段持续时间（纳秒） =====${N}"
echo -e "${Y}早期合成器时长         : ${W}$(getprop debug.sf.early.sf.duration)${N}"
echo -e "${Y}晚期合成器时长          : ${W}$(getprop debug.sf.late.sf.duration)${N}"
echo -e "${Y}高帧率模式 - 早期合成器时长  : ${W}$(getprop debug.sf.high_fps.early.sf.duration)${N}"
echo -e "${Y}高帧率模式 - 晚期合成器时长  : ${W}$(getprop debug.sf.high_fps.late.sf.duration)${N}"

echo
line
echo -e "${P}===== VSYNC 相位偏移（纳秒） =====${N}"
echo -e "${C}应用早期相位偏移       : ${W}$(getprop debug.sf.early.app.phase_offset_ns)${N}"
echo -e "${C}应用晚期相位偏移        : ${W}$(getprop debug.sf.late.app.phase_offset_ns)${N}"
echo -e "${C}高帧率模式 - 应用早期偏移   : ${W}$(getprop debug.sf.high_fps.early.app.phase_offset_ns)${N}"
echo -e "${C}高帧率模式 - 应用晚期偏移   : ${W}$(getprop debug.sf.high_fps.late.app.phase_offset_ns)${N}"

echo -e "${C}合成器早期相位偏移      : ${W}$(getprop debug.sf.early.sf.phase_offset_ns)${N}"
echo -e "${C}合成器晚期相位偏移       : ${W}$(getprop debug.sf.late.sf.phase_offset_ns)${N}"
echo -e "${C}高帧率模式 - 合成器早期偏移  : ${W}$(getprop debug.sf.high_fps.early.sf.phase_offset_ns)${N}"
echo -e "${C}高帧率模式 - 合成器晚期偏移  : ${W}$(getprop debug.sf.high_fps.late.sf.phase_offset_ns)${N}"

line() {
  echo -e "${B}────────────────────────────────────${N}"
}
