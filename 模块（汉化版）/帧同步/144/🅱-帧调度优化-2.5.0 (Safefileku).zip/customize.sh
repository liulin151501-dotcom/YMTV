#!/system/bin/sh
logcat -G 128K >/dev/null 2>&1

NAME="🅱️-帧调度优化"  # 模块名称改为中文（保持变量名不变）
VERSION="2.5.0 | 帧调度优化"  # 版本描述改为中文
ANDROIDVERSION=$(getprop ro.build.version.release)
DEVICE=$(getprop ro.product.device)
MANUFACTURER=$(getprop ro.product.manufacturer)
DATE=$(date)

echo "==============================="
echo "   $NAME"  # 模块名称（中文）
echo "   版本   : $VERSION"  # "Version" → "版本"
echo "   Android版本 : ${ANDROIDVERSION:-未知}"  # "Android" → "Android版本"，"Unknown" → "未知"
echo "   设备   : ${DEVICE:-未知}"  # "Device" → "设备"，"Unknown" → "未知"
echo "   制造商 : ${MANUFACTURER:-未知}"  # "Maker" → "制造商"，"Unknown" → "未知"
echo "   日期   : $DATE"
echo "==============================="

for part in system vendor data cache metadata odm system_ext product; do
    sm fstrim "/$part" >/dev/null 2>&1
done
for dir in /data/data/*; do
    [ -d "$dir" ] && {
        rm -rf "$dir"/cache/* "$dir"/code_cache/* "$dir"/no_backup/* "$dir"/app_webview/* 2>/dev/null
    }
done

find /data/user_de/*/*/cache/* -delete >/dev/null 2>&1
find /data/user_de/*/*/code_cache/* -delete >/dev/null 2>&1
find /sdcard/Android/data/*/cache/* -delete >/dev/null 2>&1

logcat -c >/dev/null 2>&1
cmd notification post -S bigtext -t '🅱️-帧调度优化' '⚡' "优化已激活"  # "Tweaks Activated" → "优化已激活"

echo "[$NAME] 优化⚡。"  # "Optimization" → "优化"
