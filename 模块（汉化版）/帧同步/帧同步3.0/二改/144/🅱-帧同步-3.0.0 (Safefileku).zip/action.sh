#!/system/bin/sh

R="\033[31m"
G="\033[32m"
Y="\033[33m"
B="\033[34m"
P="\033[35m"
C="\033[36m"
W="\033[37m"
N="\033[0m"

line() {
  echo -e "${B}────────────────────────────────────${N}"
}

echo -e "${P}===== DISPLAY & REFRESH RATE =====${N}"
echo -e "${C}System Peak  : ${W}$(settings get --user 0 system peak_refresh_rate)${N}"
echo -e "${C}System Default  : ${W}$(settings get --user 0 system default_refresh_rate)${N}"
echo -e "${C}System Min   : ${W}$(settings get --user 0 system min_refresh_rate)${N}"
echo -e "${C}System Max  : ${W}$(settings get --user 0 system max_refresh_rate)${N}"

echo
line
echo -e "${P}===== SURFACEFLINGER APP DURATION (ns) =====${N}"
echo -e "${G}Early App        : ${W}$(getprop debug.sf.early.app.duration)${N}"
echo -e "${G}Late App         : ${W}$(getprop debug.sf.late.app.duration)${N}"
echo -e "${G}HFPS Early App   : ${W}$(getprop debug.sf.high_fps.early.app.duration)${N}"
echo -e "${G}HFPS Late App    : ${W}$(getprop debug.sf.high_fps.late.app.duration)${N}"

echo
line
echo -e "${P}===== SURFACEFLINGER SF DURATION (ns) =====${N}"
echo -e "${Y}Early SF         : ${W}$(getprop debug.sf.early.sf.duration)${N}"
echo -e "${Y}Late SF          : ${W}$(getprop debug.sf.late.sf.duration)${N}"
echo -e "${Y}HFPS Early SF    : ${W}$(getprop debug.sf.high_fps.early.sf.duration)${N}"
echo -e "${Y}HFPS Late SF     : ${W}$(getprop debug.sf.high_fps.late.sf.duration)${N}"

echo
line
echo -e "${P}===== VSYNC PHASE OFFSET (ns) =====${N}"
echo -e "${C}App Early Offset : ${W}$(getprop debug.sf.early.app.phase_offset_ns)${N}"
echo -e "${C}App Late Offset  : ${W}$(getprop debug.sf.late.app.phase_offset_ns)${N}"
echo -e "${C}HFPS App Early   : ${W}$(getprop debug.sf.high_fps.early.app.phase_offset_ns)${N}"
echo -e "${C}HFPS App Late    : ${W}$(getprop debug.sf.high_fps.late.app.phase_offset_ns)${N}"

echo -e "${C}SF Early Offset  : ${W}$(getprop debug.sf.early.sf.phase_offset_ns)${N}"
echo -e "${C}SF Late Offset   : ${W}$(getprop debug.sf.late.sf.phase_offset_ns)${N}"
echo -e "${C}HFPS SF Early    : ${W}$(getprop debug.sf.high_fps.early.sf.phase_offset_ns)${N}"
echo -e "${C}HFPS SF Late     : ${W}$(getprop debug.sf.high_fps.late.sf.phase_offset_ns)${N}"

line() {
  echo -e "${B}────────────────────────────────────${N}"
}
