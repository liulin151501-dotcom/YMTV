#!/system/bin/sh

alias SP="setprop"
alias STS="settings"

SP debug.sf.use_phase_offsets_as_durations ""
SP debug.sf.vsync_reactor ""
SP debug.sf.vsync_reactor_apply_phase_offsets ""
SP debug.sf.enable_vsync_immed ""
SP debug.sf.disable_backpressure ""
SP debug.sf.latch_unsignaled ""
SP debug.sf.phase_offset_threshold_for_next_vsync_ns ""

SP debug.sf.early.app.duration ""
SP debug.sf.late.app.duration ""
SP debug.sf.high_fps.early.app.duration ""
SP debug.sf.high_fps.late.app.duration ""

SP debug.sf.early.sf.duration ""
SP debug.sf.late.sf.duration ""
SP debug.sf.high_fps.early.sf.duration ""
SP debug.sf.high_fps.late.sf.duration ""

SP debug.sf.early.app.phase_offset_ns ""
SP debug.sf.late.app.phase_offset_ns ""
SP debug.sf.high_fps.early.app.phase_offset_ns ""
SP debug.sf.high_fps.late.app.phase_offset_ns ""

SP debug.sf.early.sf.phase_offset_ns ""
SP debug.sf.late.sf.phase_offset_ns ""
SP debug.sf.high_fps.early.sf.phase_offset_ns ""
SP debug.sf.high_fps.late.sf.phase_offset_ns ""

SP debug.choreographer.callback ""
SP debug.choreographer.low_latency ""
SP debug.choreographer.zero_jitter ""
SP debug.choreographer.skipwarning ""

SP debug.input.lowlatency ""
SP debug.touchscreen.latency.scale ""
SP debug.sf.default_touch_timer_ms ""
SP debug.sf.set_touch_timer_ms ""

SP debug.hwui.use_buffer_age ""
SP debug.hwui.enable_buffer_queue_pacing ""
SP debug.hwui.skip_empty_damage ""
SP debug.hwui.use_partial_updates ""
SP debug.hwui.disable_vsync ""

SP debug.egl.swapinterval ""
SP debug.gr.swapinterval ""

SP persist.sys.smartfps ""
SP persist.sys.autofps.mode ""
SP persist.sys.fpsctrl.enable ""

SP debug.sf.default_refresh_rate ""
SP debug.sf.refresh_default_rate ""
SP debug.sf.frame_rate_multiple_threshold ""
SP debug.sf.scroll_boost_refreshrate ""
SP debug.sf.touch_boost_refreshrate ""
SP debug.sf.refresh_default_mode ""
SP debug.sf.default_resfresh_mode ""
SP debug.sf.min_refresh_rate ""
SP debug.sf.max_refresh_rate ""
SP debug.sf.peak_refresh_rate ""

SP debug.drm.mode ""
SP debug.drm.mode.force ""

SP sys.display.refresh_rate ""

STS delete system flicker_refresh_rate
STS delete system flicker_refresh_rate_switch
STS delete system auth_optimizer_render_frame_rate
STS delete system preferred_refresh_rate
STS delete system low_power_refresh_rate
STS delete secure user_refresh_rate
STS delete system user_refresh_rate
STS delete system max_refresh_rate
STS delete system peak_refresh_rate
STS delete system min_refresh_rate
STS delete system refresh_default_rate
STS delete system default_refresh_rate
STS delete system min_render_frame_rate
STS delete system peak_render_frame_rate
STS delete system app_request_size
STS delete system app_request_base_mode_refresh_rate
STS delete system display_preferred_size
STS delete system default_refresh_mode
STS delete system refresh_default_mode

cmd notification post -S bigtext -t '🅱️-帧同步' '🛑' " 已停止"