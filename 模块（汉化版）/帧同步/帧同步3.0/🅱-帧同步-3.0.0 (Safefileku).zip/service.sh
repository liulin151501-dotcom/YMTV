#!/system/bin/sh

alias SP="setprop"
alias STS="settings"

FPSI=$(dumpsys display 2>/dev/null | grep -Eo 'refreshRate=[0-9]+(\.[0-9]+)?' | cut -d= -f2 | sort -nr | head -n1)
[ -z "$FPSI" ] && FPSI=60
FPSI=${FPSI%.*}
[ "$FPSI" -lt 60 ] && FPSI=60
[ "$FPSI" -gt 240 ] && FPSI=240

FRAME_NS=$((1000000000 / FPSI))

case $FPSI in
165|170|180) EA=60 LA=82 ES=30 LS=52 ;;
144|150)     EA=59 LA=80 ES=31 LS=53 ;;
120|125)     EA=58 LA=78 ES=32 LS=54 ;;
90|96)       EA=60 LA=76 ES=33 LS=55 ;;
*)           EA=62 LA=74 ES=34 LS=56 ;;
esac

EARLY_APP=$((FRAME_NS * EA / 100))
LATE_APP=$((FRAME_NS * LA / 100))
EARLY_SF=$((FRAME_NS * ES / 100))
LATE_SF=$((FRAME_NS * LS / 100))

OFFSET_EARLY=$((-(FRAME_NS * 35 / 100)))
OFFSET_LATE=$((-(FRAME_NS * 45 / 100)))

SP debug.sf.use_phase_offsets_as_durations 1
SP debug.sf.vsync_reactor 1
SP debug.sf.vsync_reactor_apply_phase_offsets 1
SP debug.sf.enable_vsync_immed 1
SP debug.sf.disable_backpressure 0
SP debug.sf.latch_unsignaled true
SP debug.sf.max_frame_latency 1
SP debug.sf.use_frame_rate_priority 1
SP debug.sf.phase_offset_threshold_for_next_vsync_ns $((FRAME_NS / 4))

SP debug.sf.early.app.duration "$EARLY_APP"
SP debug.sf.late.app.duration "$LATE_APP"
SP debug.sf.high_fps.early.app.duration "$EARLY_APP"
SP debug.sf.high_fps.late.app.duration "$LATE_APP"

SP debug.sf.early.sf.duration "$EARLY_SF"
SP debug.sf.late.sf.duration "$LATE_SF"
SP debug.sf.high_fps.early.sf.duration "$EARLY_SF"
SP debug.sf.high_fps.late.sf.duration "$LATE_SF"

SP debug.sf.early.app.phase_offset_ns "$OFFSET_EARLY"
SP debug.sf.late.app.phase_offset_ns "$OFFSET_LATE"
SP debug.sf.high_fps.early.app.phase_offset_ns "$OFFSET_EARLY"
SP debug.sf.high_fps.late.app.phase_offset_ns "$OFFSET_LATE"

SP debug.sf.early.sf.phase_offset_ns "$OFFSET_EARLY"
SP debug.sf.late.sf.phase_offset_ns "$OFFSET_LATE"
SP debug.sf.high_fps.early.sf.phase_offset_ns "$OFFSET_EARLY"
SP debug.sf.high_fps.late.sf.phase_offset_ns "$OFFSET_LATE"

CALLBACK_US=$((1000000 / FPSI))
SP debug.choreographer.callback "$CALLBACK_US"
SP debug.choreographer.low_latency 1
SP debug.choreographer.zero_jitter 1
SP debug.choreographer.skipwarning "$FPSI"

SP debug.input.lowlatency 1
SP debug.touchscreen.latency.scale 0.0
SP debug.sf.default_touch_timer_ms 0
SP debug.sf.set_touch_timer_ms 0

SP debug.hwui.use_buffer_age 1
SP debug.hwui.enable_buffer_queue_pacing 1
SP debug.hwui.skip_empty_damage 1
SP debug.hwui.use_partial_updates 1
SP debug.hwui.disable_vsync 0

SP debug.egl.swapinterval 1
SP debug.gr.swapinterval 1

SP persist.sys.smartfps 0
SP persist.sys.autofps.mode 0
SP persist.sys.fpsctrl.enable 0

SP debug.sf.default_refresh_rate "$FPSI"
SP debug.sf.refresh_default_rate "$FPSI"
SP debug.sf.frame_rate_multiple_threshold "$FPSI"
SP debug.sf.scroll_boost_refreshrate "$FPSI"
SP debug.sf.touch_boost_refreshrate "$FPSI"
SP debug.sf.refresh_default_mode "$FPSI"
SP debug.sf.default_resfresh_mode "$FPSI"
SP debug.sf.min_refresh_rate "$FPSI"
SP debug.sf.max_refresh_rate "$FPSI"
SP debug.sf.peak_refresh_rate "$FPSI"
STS put --user 0 system flicker_refresh_rate "$FPSI"
STS put --user 0 system flicker_refresh_rate_switch "$FPSI"
STS put --user 0 system auth_optimizer_render_frame_rate "$FPSI"
STS put --user 0 system preferred_refresh_rate "$FPSI"
STS put --user 0 system low_power_refresh_rate "$FPSI"
STS put --user 0 secure user_refresh_rate "$FPSI"
STS put --user 0 system user_refresh_rate "$FPSI"
STS put --user 0 system max_refresh_rate "$FPSI"
STS put --user 0 system peak_refresh_rate "$FPSI".0
STS put --user 0 system min_refresh_rate "$FPSI".0
STS put --user 0 system refresh_default_rate "$FPSI"
STS put --user 0 system default_refresh_rate "$FPSI"
STS put --user 0 system min_render_frame_rate "$FPSI"
STS put --user 0 system peak_render_frame_rate "$FPSI"
STS put --user 0 system app_request_size $(echo $(wm size | awk '{print $3}') | cut -d'x' -f1)x$(echo $(wm size | awk '{print $3}') | cut -d'x' -f2)
STS put --user 0 system app_request_base_mode_refresh_rate "$FPSI"
STS put --user 0 system display_preferred_size $(echo $(wm size | awk '{print $3}') | cut -d'x' -f1)x$(echo $(wm size | awk '{print $3}') | cut -d'x' -f2)
STS put --user 0 system default_refresh_mode "$FPSI"
STS put --user 0 system refresh_default_mode "$FPSI"
cmd display set-user-preferred-display-mode $(echo $(wm size | awk '{print $3}') | cut -d'x' -f1) $(echo $(wm size | awk '{print $3}') | cut -d'x' -f2) "$FPSI".0 0
SP debug.drm.mode $(echo $(wm size | awk '{print $3}') | cut -d'x' -f1)x$(echo $(wm size | awk '{print $3}') | cut -d'x' -f2)@240
SP debug.drm.mode.force $(echo $(wm size | awk '{print $3}') | cut -d'x' -f1)x$(echo $(wm size | awk '{print $3}') | cut -d'x' -f2)@240
inputflinger set-display-mode-fps "$FPSI"

am start -a AxManager.TOAST -e text "🅱️-帧同步 调整正在运行"
