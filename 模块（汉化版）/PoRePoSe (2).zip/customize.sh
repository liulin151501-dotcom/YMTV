# 感谢 @dcx400
MODDIR=${0%/*}
CONF_FILE="$MODDIR/config.txt"
SDK_VER=$(getprop ro.build.version.sdk)

echo "Ay..."
sleep 2
echo "Yo...."
sleep 2
echo "Chill.... 选择 PoRePoSe 模式"
sleep 2
echo "[+] 音量加   : 非 Root 模式 
[-] 音量减 : Root 模式 
"

# 检测并保存 SoC 类型
detect_and_save_soc() {
    local platform=$(getprop ro.board.platform | tr '[:upper:]' '[:lower:]')
    local hardware=$(getprop ro.product.board | tr '[:upper:]' '[:lower:]')
    local soc_info="$platform $hardware"

    if echo "$soc_info" | grep -qE "mt[0-9]|mediatek|helio|dimensity"; then
        SOC=1
    elif echo "$soc_info" | grep -qE "qcom|msm|sdm|sm[0-9]|snapdragon"; then
        SOC=2
    elif echo "$soc_info" | grep -qE "exynos|s5e"; then
        SOC=3
    elif echo "$soc_info" | grep -qE "unisoc|sp98|ums|roc|sc[0-9]"; then
        SOC=4
    elif echo "$soc_info" | grep -qE "gs[0-9]|tensor"; then
        SOC=5
    elif echo "$soc_info" | grep -qE "tegra|nvidia"; then
        SOC=6
    else
        SOC=0
    fi

    echo "SOC=$SOC" > "$CONF_FILE"
    echo "已检测并保存 SoC 类型: $SOC"
}

# 监听音量键选择模式
Volume_key() {
    getevent -l | while read -r line; do
        case "$line" in
            *KEY_VOLUMEUP*) 
                echo "状态: 非 Root 模式"
                pkill getevent
                break 
                ;;
            *KEY_VOLUMEDOWN*) 
                echo "状态: Root 模式"
                detect_and_save_soc
                pkill getevent
                break 
                ;;
        esac
    done
}

# 执行音量键监听
Volume_key

# 根据 Android SDK 版本设置省电参数
if [ "$SDK_VER" -le 30 ]; then
settings put global battery_saver_constants \
advertise_is_enabled=true,\
datasaver_disabled=false,\
enable_night_mode=true,\
launch_boost_disabled=true,\
vibration_disabled=true,\
animation_disabled=true,\
soundtrigger_disabled=true,\
fullbackup_deferred=true,\
keyvaluebackup_deferred=true,\
firewall_disabled=false,\
gps_mode=2,\
adjust_brightness_disabled=false,\
adjust_brightness_factor=0.5,\
force_all_apps_standby=true,\
force_background_check=true,\
optional_sensors_disabled=true,\
aod_disabled=true,\
quick_doze_enabled=true
else
settings put global battery_saver_constants \
advertise_is_enabled=true,\
enable_datasaver=true,\
enable_night_mode=true,\
disable_launch_boost=true,\
disable_vibration=true,\
disable_animation=true,\
soundtrigger_mode=2,\
defer_full_backup=true,\
defer_keyvalue_backup=true,\
enable_firewall=true,\
location_mode=3,\
enable_brightness_adjustment=true,\
adjust_brightness_factor=0.7,\
force_all_apps_standby=true,\
force_background_check=true,\
disable_optional_sensors=true,\
disable_aod=true,\
enable_quick_doze=true
fi

# 针对 Android 11 及以下版本设置设备空闲时间参数
if [ "$SDK_VER" -le 30 ]; then
SEC_MS=1000
MIN_MS=$((60 * SEC_MS))
HOUR_MS=$((60 * MIN_MS))

Inactive_to=$((30 * SEC_MS))
sensing_to=$((0 * SEC_MS))
motion_inactive_to=$((0 * SEC_MS))
idle_after_inactive_to=$((0 * SEC_MS))
idle_pending_to=$((1 * MIN_MS))
max_idle_pending_to=$((2 * MIN_MS))
quick_doze_delay_to=$((10 * SEC_MS))
idle_to=$((60 * MIN_MS))
max_idle_to=$((24 * HOUR_MS))

constants="inactive_to=${Inactive_to},\
sensing_to=${sensing_to},\
motion_inactive_to=${motion_inactive_to},\
idle_after_inactive_to=${idle_after_inactive_to},\
idle_pending_to=${idle_pending_to},\
max_idle_pending_to=${max_idle_pending_to},\
quick_doze_delay_to=${quick_doze_delay_to},\
idle_to=${idle_to},\
max_idle_to=${max_idle_to}"

settings put global device_idle_constants "${constants}"
fi

# 设置 Activity Manager 相关参数
power_interval=$((10 * 60 * 1000))
pss_interval=$((60 * 60 * 1000))
pss_low_interval=$((30 * 60 * 1000))

settings put global activity_manager_constants \
power_check_max_cpu_1=15,\
power_check_max_cpu_2=15,\
power_check_max_cpu_3=5,\
power_check_max_cpu_4=1,\
power_check_interval=$power_interval,\
full_pss_min_interval=$pss_interval,\
full_pss_lowered_interval=$pss_low_interval

# 关闭 Binder 调用统计
settings put global binder_calls_stats detailed_tracking=false,enabled=false,upload_data=false,collect_latency_data=false,track_calling_uid=false

# 根据 SDK 版本设置电池统计参数
if [ "$SDK_VER" -le 33 ]; then
settings put global battery_stats_constants track_cpu_times_by_proc_state=false,track_cpu_active_cluster_time=false,read_binary_cpu_time=false,max_history_files=0,max_history_buffer_kb=0
else
settings put global battery_stats_constants track_cpu_times_by_proc_state=false,track_cpu_active_cluster_time=false,read_binary_cpu_time=false,max_history_files=0,max_history_buffer_kb=0,phone_on_external_stats_collection=false
fi

# 关闭 Wi-Fi 常驻扫描
if [ "$(settings get global wifi_scan_always_enabled)" = "1" ]; then 
settings put global wifi_scan_always_enabled 0
fi

# 关闭蓝牙常驻扫描
if [ "$(settings get global ble_scan_always_enabled)" = "1" ]; then 
settings put global ble_scan_always_enabled 0
fi
