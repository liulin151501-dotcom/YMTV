#!/system/bin/sh

# 定义 kakangkuh 函数：检查文件是否存在，设置权限并写入内容
kakangkuh() {
    [ ! -f "$2" ] && return 1
    chmod 644 "$2" >/dev/null 2>&1
    echo "$1" >"$2" 2>/dev/null
}

# 定义 tweak 函数：如果文件存在，设置权限、写入内容并锁定为只读
tweak() {
    if [ -e "$2" ]; then
        chmod 644 "$2" >/dev/null 2>&1
        echo "$1" > "$2" 2>/dev/null
        chmod 444 "$2" >/dev/null 2>&1
    fi
}

# MediaTek 平台正常模式调整
mediatek_normal() {
    local min_oppfreq

    # 关闭 CPU 频率调节中的省电模式
    tweak 0 /proc/cpufreq/cpufreq_power_mode

    # 如果存在 GPU 频率控制接口 v2
    if [ -d /proc/gpufreqv2 ]; then
        kakangkuh -1 /proc/gpufreqv2/fix_target_opp_index
        if [ -f /proc/gpufreqv2/gpu_working_opp_table ]; then
            min_oppfreq=$(mtk_gpufreq_minfreq_index /proc/gpufreqv2/gpu_working_opp_table)
            tweak "$min_oppfreq" /sys/kernel/ged/hal/custom_boost_gpu_freq
        fi
    # 如果存在旧版 GPU 频率控制接口
    elif [ -d /proc/gpufreq ]; then
        kakangkuh 0 /proc/gpufreq/gpufreq_opp_freq
        if [ -f /proc/gpufreq/gpufreq_opp_dump ]; then
            min_oppfreq=$(mtk_gpufreq_minfreq_index /proc/gpufreq/gpufreq_opp_dump)
            tweak "$min_oppfreq" /sys/kernel/ged/hal/custom_boost_gpu_freq
        fi
    fi
}

# 高通 Snapdragon 平台正常模式调整
snapdragon_normal() {
    local kgsl_path="/sys/class/kgsl/kgsl-3d0/devfreq"
    if [ -d "$kgsl_path" ]; then
        devfreq_unlock "$kgsl_path"
    fi
}

# NVIDIA Tegra 平台正常模式调整
tegra_normal() {
    local gpu_path="/sys/kernel/tegra_gpu"
    if [ -d "$gpu_path" ] && [ -f "$gpu_path/available_frequencies" ]; then
        local max_freq=$(which_maxfreq "$gpu_path/available_frequencies")
        local min_freq=$(which_minfreq "$gpu_path/available_frequencies")
        kakangkuh "$max_freq" "$gpu_path/gpu_cap_rate"
        kakangkuh "$min_freq" "$gpu_path/gpu_floor_rate"
    fi
}

# 三星 Exynos 平台正常模式调整
exynos_normal() {
    local gpu_path="/sys/kernel/gpu"
    if [ -d "$gpu_path" ] && [ -f "$gpu_path/gpu_available_frequencies" ]; then
        local max_freq=$(which_maxfreq "$gpu_path/gpu_available_frequencies")
        local min_freq=$(which_minfreq "$gpu_path/gpu_available_frequencies")
        kakangkuh "$max_freq" "$gpu_path/gpu_max_clock"
        kakangkuh "$min_freq" "$gpu_path/gpu_min_clock"
    fi
}

# 紫光展锐 Unisoc 平台正常模式调整
unisoc_normal() {
    local gpu_path
    gpu_path=$(find /sys/class/devfreq/ -type d -iname "*.gpu" -print -quit 2>/dev/null)
    if [ -n "$gpu_path" ]; then
        devfreq_unlock "$gpu_path"
    fi
}

# Google Tensor 平台正常模式调整
tensor_normal() {
    local gpu_path
    gpu_path=$(find /sys/devices/platform/ -type d -iname "*.mali" -print -quit 2>/dev/null)
    if [ -n "$gpu_path" ] && [ -f "$gpu_path/available_frequencies" ]; then
        local max_freq=$(which_maxfreq "$gpu_path/available_frequencies")
        local min_freq=$(which_minfreq "$gpu_path/available_frequencies")
        kakangkuh "$max_freq" "$gpu_path/scaling_max_freq"
        kakangkuh "$min_freq" "$gpu_path/scaling_min_freq"
    fi
}

# 获取设备 SoC 类型
get_soc_type() {
    local platform=$(getprop ro.board.platform | tr '[:upper:]' '[:lower:]')
    local hardware=$(getprop ro.product.board | tr '[:upper:]' '[:lower:]')
    local cpuinfo=$(grep -i "Hardware" /proc/cpuinfo | tr '[:upper:]' '[:lower:]')
    local soc_info="$platform $hardware $cpuinfo"

    # 根据关键字匹配 SoC 类型
    if echo "$soc_info" | grep -qE "mt[0-9]|mediatek|helio|dimensity"; then
        SOC=1
    elif echo "$soc_info" | grep -qE "qcom|msm|sdm|sm[0-9]|snapdragon"; then
        SOC=2 
    elif echo "$soc_info" | grep -qE "exynos|s5e"; then
        SOC=3 
    elif echo "$soc_info" | grep -qE "unisoc|sp98|ums|roc|sc[0-9]"; then
        SOC=4 
    elif echo "$soc_info" | grep -qE "gs[0-9]|tensor"; then
        SOC=5 
    elif echo "$soc_info" | grep -qE "tegra|nvidia"; then
        SOC=6 
    else
        SOC=0 
    fi
}

# 执行 SoC 类型检测
get_soc_type

# 根据 SoC 类型调用对应的调整函数
case $SOC in
    1)
        mediatek_normal
        ;;
    2)
        snapdragon_normal
        ;;
    3)
        exynos_normal
        ;;
    4)
        unisoc_normal
        ;;
    5)
        tensor_normal
        ;;
    6)
        tegra_normal
        ;;
esac

# 等待进程结束
wait
