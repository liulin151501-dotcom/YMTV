# 来自 Raco 3.0，作者：Kanagawa Yamada
MODDIR=${0%/*}
CONF_FILE="$MODDIR/config.txt"

# 定义 tweak 函数：如果文件存在，设置权限、写入内容并锁定为只读
tweak() {
    if [ -e "$2" ]; then
        chmod 644 "$2" >/dev/null 2>&1
        echo "$1" > "$2" 2>/dev/null
        chmod 444 "$2" >/dev/null 2>&1
    fi
}

# 检查配置文件是否存在
check_config_gate() {
    if [ ! -f "$CONF_FILE" ]; then
        exit 1
    fi
}

# MediaTek 平台省电模式调整
mediatek_powersave() {
    local gpufreq_v2="/proc/gpufreqv2"
    local gpufreq_v1="/proc/gpufreq"
    local min_gpufreq_index
    local gpu_freq

    # 启用 CPU 省电模式
    if [ -f "/proc/cpufreq/cpufreq_power_mode" ]; then
        tweak 1 /proc/cpufreq/cpufreq_power_mode
    fi

    # 如果存在 GPU 频率控制接口 v2
    if [ -d "$gpufreq_v2" ]; then
        if [ -f "$gpufreq_v2/gpu_working_opp_table" ]; then
            min_gpufreq_index=$(mtk_gpufreq_minfreq_index "$gpufreq_v2/gpu_working_opp_table")
            tweak "$min_gpufreq_index" "$gpufreq_v2/fix_target_opp_index"
        fi
    # 如果存在旧版 GPU 频率控制接口
    elif [ -d "$gpufreq_v1" ]; then
        if [ -f "$gpufreq_v1/gpufreq_opp_dump" ]; then
            gpu_freq=$(sed -n 's/.*freq = \([0-9]\{1,\}\).*/\1/p' "$gpufreq_v1/gpufreq_opp_dump" | tail -n 1)
            tweak "$gpu_freq" "$gpufreq_v1/gpufreq_opp_freq"
        fi
    fi
}

# 高通 Snapdragon 平台省电模式调整
snapdragon_powersave() {
    local kgsl_path="/sys/class/kgsl/kgsl-3d0/devfreq"
    if [ -d "$kgsl_path" ]; then
        devfreq_min_perf "$kgsl_path"
    fi
}

# NVIDIA Tegra 平台省电模式调整
tegra_powersave() {
    local gpu_path="/sys/kernel/tegra_gpu"
    local freq

    if [ -d "$gpu_path" ]; then
        if [ -f "$gpu_path/available_frequencies" ]; then
            freq=$(which_minfreq "$gpu_path/available_frequencies")
            tweak "$freq" "$gpu_path/gpu_floor_rate"
            tweak "$freq" "$gpu_path/gpu_cap_rate"
        fi
    fi
}

# 三星 Exynos 平台省电模式调整
exynos_powersave() {
    local gpu_path="/sys/kernel/gpu"
    local freq

    if [ -d "$gpu_path" ]; then
        if [ -f "$gpu_path/gpu_available_frequencies" ]; then
            freq=$(which_minfreq "$gpu_path/gpu_available_frequencies")
            tweak "$freq" "$gpu_path/gpu_min_clock"
            tweak "$freq" "$gpu_path/gpu_max_clock"
        fi
    fi
}

# 紫光展锐 Unisoc 平台省电模式调整
unisoc_powersave() {
    local gpu_path
    gpu_path=$(find /sys/class/devfreq/ -type d -iname "*.gpu" -print -quit 2>/dev/null)

    if [ -n "$gpu_path" ]; then
        devfreq_min_perf "$gpu_path"
    fi
}

# Google Tensor 平台省电模式调整
tensor_powersave() {
    local gpu_path
    local freq
    gpu_path=$(find /sys/devices/platform/ -type d -iname "*.mali" -print -quit 2>/dev/null)

    if [ -n "$gpu_path" ] && [ -f "$gpu_path/available_frequencies" ]; then
        freq=$(which_minfreq "$gpu_path/available_frequencies")
        tweak "$freq" "$gpu_path/scaling_min_freq"
        tweak "$freq" "$gpu_path/scaling_max_freq"
    fi
}

# 加载 SoC 配置
load_soc_config() {
    if [ ! -f "$CONF_FILE" ]; then
        touch "$CONF_FILE"
    fi

    SOC_CFG=$(grep "SOC=" "$CONF_FILE" | cut -d'=' -f2)

    if [ -n "$SOC_CFG" ]; then
        SOC=$SOC_CFG
    fi
}

# 执行 SoC 配置加载
load_soc_config
# 检查配置文件是否存在
check_config_gate

# 根据 SoC 类型调用对应的省电模式函数
case $SOC in
    1)
        mediatek_powersave
        ;;
    2)
        snapdragon_powersave
        ;;
    3)
        exynos_powersave
        ;;
    4)
        unisoc_powersave
        ;;
    5)
        tensor_powersave
        ;;
    6)
        tegra_powersave
        ;;
esac

# 等待进程结束
wait
