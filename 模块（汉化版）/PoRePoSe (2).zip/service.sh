#!/system/bin/sh
MODDIR=${0%/*}

sh $MODDIR/cigarette.sh

while :; do 
    sleep 90

    # 获取屏幕是否亮屏状态
    display=$(nice -n19 cmd deviceidle get screen)
    # 获取充电状态（AC 或 USB 供电）
    charging_status=$(dumpsys battery | awk -F': ' '/AC powered|USB powered/ {if($2=="true") c=1} END{print c?"yes":"no"}')

    # 如果屏幕关闭且未在充电
    if [ "$display" = "false" ] && [ "$charging_status" = "no" ]; then
        # 如果系统版本大于等于 Android 12（API 31）
        if [ "$sdk_version" -ge 31 ]; then
            # 获取当前深度空闲状态
            current_idle=$(cmd deviceidle get deep)
            
            # 如果当前不在深度空闲模式，则逐步进入轻度和深度空闲
            if [ "$current_idle" != "IDLE" ]; then
                cmd deviceidle step light
                cmd deviceidle step deep
            fi
        fi
    fi
done
