#!/system/bin/sh
exec>/dev/null 2>&1
while true;do
  [ "$(dumpsys battery|grep -m1 level|tr -d ' '|cut -f2 -d:)" -gt "95" ]&&cmd settings put secure security_pc_secure_protect_mode_key 2 default||cmd settings delete secure security_pc_secure_protect_mode_key
  sleep 1m
done
