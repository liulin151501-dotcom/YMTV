#!/system/bin/sh
cmd settings delete secure security_pc_secure_protect_mode_key