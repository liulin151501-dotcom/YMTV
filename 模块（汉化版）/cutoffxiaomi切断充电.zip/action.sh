#!/system/bin/sh
MODDIR=PATH
[ $AXERON ]&&a()(sleep 0.01;printf "$@")||a()(sleep 0.01;echo "$@")
PID="$(pgrep -f "sh $MODDIR"|head -n1)" uptime=$(cut -d. -f1 /proc/uptime) memory=$(cat /proc/meminfo|tr -s \ )
a "$MODDIR"
a " "
a "***********************************************"
a "$(grep name= "$MODDIR/module.prop"|cut -f2 -d=) ($(grep version= "$MODDIR/module.prop"|cut -f2 -d=)) by $(grep author= "$MODDIR/module.prop"|cut -f2 -d=)"
a "***********************************************"
a " "
if [ -n "$PID" ];then
  a "- 服务进程 ($PID)"
  a "- CPU 使用率: $(ps -eo %cpu,pid|grep "$PID"|grep -ov "$PID"|tr -d \ )%%"
  a "- 物理内存占用: $(ps -eo res,pid|grep "$PID"|grep -ov "$PID"|tr -d \ )"
  a "- 共享内存占用: $(ps -eo shr,pid|grep "$PID"|grep -ov "$PID"|tr -d \ )"
  a " "
fi
a "· 操作系统: Android $(getprop ro.build.version.release) (SDK $(getprop ro.build.version.sdk))"
a "· 设备型号: $(getprop ro.product.manufacturer) $(getprop ro.product.model)"
a "· 内核版本: $(uname -r|cut -f1,2,3 -d-)"
a "· 运行时长: $((uptime/3600)) 小时, $((uptime%3600/60)) 分钟"
a "· 应用包数: $(cmd package list packages -s --user 0|wc -l) (系统), $(cmd package list packages -3 --user 0|wc -l) (第三方)"
a "· 屏幕分辨率:$(wm size|cut -d: -f2)"
a "· 系统主题: $(getprop ro.build.fingerprint|tr '/' '\n'|grep user|cut -f1 -d:)"
a "· 当前终端: $(cmd activity stack list|grep 0,0.*visible=true|tr -d ' '|cut -f1 -d/|cut -f2 -d:)"
a "· 处理器: $(getprop ro.soc.manufacturer) $(getprop ro.soc.model) ($(grep proc /proc/cpuinfo|wc -l)) @ $(cat /sys/devices/system/cpu/cpufreq/*/cpuinfo_max_freq|tail -n1|awk '{printf("%.3f\n",$1/1000000)}')GHz"
a "· 图形处理器:$(dumpsys SurfaceFlinger|grep GLES:|cut -f2 -d,)"
a "· 内存使用: $((($(echo "$memory"|grep MemTotal|cut -f2 -d\ )-$(echo "$memory"|grep MemAvailable|cut -f2 -d\ ))/1024))MiB / $(($(echo "$memory"|grep MemTotal|cut -f2 -d\ )/1024))MiB"
a " "
