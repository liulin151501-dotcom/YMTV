#!/system/bin/sh

BASE=/sdcard/TianYunGou
GAMELIST=$BASE/gamelist.txt
CONFIG=$BASE/config.prop
BINARY=/sdcard/TianYunGou/bin/Jawa6969fps

PEAK_RATE=120
MIN_RATE=60
SLEEP_INTERVAL=5

if [ ! -f "$GAMELIST" ]; then
    echo "[ERROR] gamelist.txt tidak ditemukan di $BASE"
    exit 1
fi

[ -f "$CONFIG" ] && . "$CONFIG"

get_foreground_package() {
    dumpsys activity activities 2>/dev/null \
        | grep -m1 "mResumedActivity" \
        | sed 's/.*{[^ ]* \([^ /]*\).*/\1/' \
        | cut -d/ -f1
}

GAME_ACTIVE=0

while true; do
    [ -f "$CONFIG" ] && . "$CONFIG"

    FOREGROUND=$(get_foreground_package)
    MATCHED=""

    while IFS= read -r pkg; do
        [ -z "$pkg" ] && continue
        [ "${pkg#\#}" != "$pkg" ] && continue
        if [ "$FOREGROUND" = "$pkg" ]; then
            MATCHED=$pkg
            break
        fi
    done < "$GAMELIST"

    if [ -n "$MATCHED" ]; then
        if [ "$GAME_ACTIVE" = "0" ]; then
            if [ -x "$BINARY" ]; then
                "$BINARY" apply "$PEAK_RATE" "$MIN_RATE" 2>/dev/null
            else
                settings put system peak_refresh_rate "$PEAK_RATE" 2>/dev/null
                settings put system min_refresh_rate "$MIN_RATE" 2>/dev/null
            fi
            GAME_ACTIVE=1
        else
            if [ -x "$BINARY" ]; then
                "$BINARY" boost 2>/dev/null
            fi
        fi
    else
        if [ "$GAME_ACTIVE" = "1" ]; then
            if [ -x "$BINARY" ]; then
                "$BINARY" reset 2>/dev/null
            else
                settings put system peak_refresh_rate 60 2>/dev/null
                settings put system min_refresh_rate 60 2>/dev/null
            fi
            GAME_ACTIVE=0
        fi
    fi

    sleep "$SLEEP_INTERVAL"
done
