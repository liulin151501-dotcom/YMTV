#!/system/bin/sh

SCRIPT_DIR=$(cd "$(dirname "$0")" 2>/dev/null && pwd)

if [ -f "/data/adb/modules/TianYunGou/module.prop" ]; then
    MODDIR=/data/adb/modules/TianYunGou
elif [ -f "$SCRIPT_DIR/module.prop" ]; then
    MODDIR=$SCRIPT_DIR
elif [ -f "/sdcard/TianYunGou/module.prop" ]; then
    MODDIR=/sdcard/TianYunGou
else
    MODDIR=$SCRIPT_DIR
fi

CONFIG=$MODDIR/config.prop
BINARY=$MODDIR/system/bin/Jawa6969fps

PEAK_RATE=120
MIN_RATE=60
[ -f "$CONFIG" ] && . "$CONFIG"

echo "┌─────────────────────────────────────┐"
echo "│         TianYun狗 — Action           │"
echo "└─────────────────────────────────────┘"
echo ""

echo "[ DEVICE INFO ]"
BRAND=$(getprop ro.product.brand 2>/dev/null)
MODEL=$(getprop ro.product.model 2>/dev/null)
ANDROID=$(getprop ro.build.version.release 2>/dev/null)
SDK=$(getprop ro.build.version.sdk 2>/dev/null)
KERNEL=$(uname -r 2>/dev/null)
ABI=$(getprop ro.product.cpu.abi 2>/dev/null)
echo "  Brand   : $BRAND"
echo "  Model   : $MODEL"
echo "  Android : $ANDROID (SDK $SDK)"
echo "  Kernel  : $KERNEL"
echo "  ABI     : $ABI"
echo ""

echo "[ CPU ]"
CPU_CORES=$(nproc 2>/dev/null || grep -c "^processor" /proc/cpuinfo 2>/dev/null)
CPU_HW=$(grep -m1 "Hardware" /proc/cpuinfo 2>/dev/null | cut -d: -f2 | sed 's/^ //')
CPU_LOAD=$(cut -d' ' -f1-3 /proc/loadavg 2>/dev/null)
GOV=$(cat /sys/devices/system/cpu/cpu0/cpufreq/scaling_governor 2>/dev/null)
MAX_FREQ=$(cat /sys/devices/system/cpu/cpu0/cpufreq/cpuinfo_max_freq 2>/dev/null)
CUR_FREQ=$(cat /sys/devices/system/cpu/cpu0/cpufreq/scaling_cur_freq 2>/dev/null)
[ -n "$MAX_FREQ" ] && MAX_FREQ_MHZ=$((MAX_FREQ / 1000)) || MAX_FREQ_MHZ="N/A"
[ -n "$CUR_FREQ" ] && CUR_FREQ_MHZ=$((CUR_FREQ / 1000)) || CUR_FREQ_MHZ="N/A"
echo "  Cores   : ${CPU_CORES:-N/A}"
echo "  Hardware: ${CPU_HW:-N/A}"
echo "  Load    : ${CPU_LOAD:-N/A} (1m 5m 15m)"
echo "  Governor: ${GOV:-N/A}"
echo "  Freq Max: ${MAX_FREQ_MHZ} MHz"
echo "  Freq Now: ${CUR_FREQ_MHZ} MHz"
echo ""

echo "[ RAM ]"
MEM_TOTAL=$(grep "MemTotal" /proc/meminfo 2>/dev/null | awk '{print $2}')
MEM_FREE=$(grep "MemFree" /proc/meminfo 2>/dev/null | awk '{print $2}')
MEM_AVAIL=$(grep "MemAvailable" /proc/meminfo 2>/dev/null | awk '{print $2}')
MEM_CACHED=$(grep "^Cached" /proc/meminfo 2>/dev/null | awk '{print $2}')
MEM_BUFFERS=$(grep "Buffers" /proc/meminfo 2>/dev/null | awk '{print $2}')
MEM_USED=$((MEM_TOTAL - MEM_AVAIL))
MEM_PCT=$((MEM_USED * 100 / MEM_TOTAL))
echo "  Total     : $((MEM_TOTAL / 1024)) MB"
echo "  Used      : $((MEM_USED / 1024)) MB (${MEM_PCT}%)"
echo "  Available : $((MEM_AVAIL / 1024)) MB"
echo "  Free      : $((MEM_FREE / 1024)) MB"
echo "  Cached    : $((MEM_CACHED / 1024)) MB"
echo "  Buffers   : $((MEM_BUFFERS / 1024)) MB"
echo ""

echo "[ SWAP ]"
SWAP_TOTAL=$(grep "SwapTotal" /proc/meminfo 2>/dev/null | awk '{print $2}')
SWAP_FREE=$(grep "SwapFree" /proc/meminfo 2>/dev/null | awk '{print $2}')
if [ "${SWAP_TOTAL:-0}" -gt 0 ]; then
    SWAP_USED=$((SWAP_TOTAL - SWAP_FREE))
    SWAP_PCT=$((SWAP_USED * 100 / SWAP_TOTAL))
    echo "  Total : $((SWAP_TOTAL / 1024)) MB"
    echo "  Used  : $((SWAP_USED / 1024)) MB (${SWAP_PCT}%)"
    echo "  Free  : $((SWAP_FREE / 1024)) MB"
else
    echo "  Swap tidak aktif"
fi
echo ""

echo "[ STORAGE I/O ]"
IO_FOUND=0
for blk_path in /sys/block/*; do
    blk=$(basename "$blk_path")
    sched_file="$blk_path/queue/scheduler"
    ahead_file="$blk_path/queue/read_ahead_kb"
    [ -f "$sched_file" ] || continue
    IO_FOUND=1
    ACTIVE_SCHED=$(cat "$sched_file" 2>/dev/null | tr ' ' '\n' | grep '^\[' | tr -d '[]')
    AHEAD=$(cat "$ahead_file" 2>/dev/null)
    echo "  /dev/$blk -> sched=${ACTIVE_SCHED:-unknown} | read_ahead=${AHEAD:-?}kb"
done
[ "$IO_FOUND" = "0" ] && echo "  Tidak ada block device terdeteksi di /sys/block"
echo ""

echo "[ REFRESH RATE ]"
CURR_PEAK=$(settings get system peak_refresh_rate 2>/dev/null)
CURR_MIN=$(settings get system min_refresh_rate 2>/dev/null)
echo "  Config  : peak=${PEAK_RATE}Hz | min=${MIN_RATE}Hz"
echo "  Current : peak=${CURR_PEAK:-null} | min=${CURR_MIN:-null}"
echo ""

echo "[ BATTERY ]"
BAT_LEVEL=$(cat /sys/class/power_supply/battery/capacity 2>/dev/null)
BAT_STATUS=$(cat /sys/class/power_supply/battery/status 2>/dev/null)
BAT_TEMP_RAW=$(cat /sys/class/power_supply/battery/temp 2>/dev/null)
BAT_VOLT_RAW=$(cat /sys/class/power_supply/battery/voltage_now 2>/dev/null)
if [ -n "$BAT_TEMP_RAW" ] && [ "$BAT_TEMP_RAW" -gt 0 ] 2>/dev/null; then
    BAT_TEMP_INT=$((BAT_TEMP_RAW / 10))
    BAT_TEMP_DEC=$((BAT_TEMP_RAW % 10))
    BAT_TEMP="${BAT_TEMP_INT}.${BAT_TEMP_DEC}°C"
else
    BAT_TEMP="N/A"
fi
[ -n "$BAT_VOLT_RAW" ] && BAT_VOLT="$((BAT_VOLT_RAW / 1000)) mV" || BAT_VOLT="N/A"
echo "  Level   : ${BAT_LEVEL:-N/A}%"
echo "  Status  : ${BAT_STATUS:-N/A}"
echo "  Temp    : $BAT_TEMP"
echo "  Voltage : $BAT_VOLT"
echo ""

echo "[ RUNNING TWEAKS ]"
echo "  Binary  : $BINARY"
if [ -f "$BINARY" ]; then
    chmod +x "$BINARY" 2>/dev/null
    echo "  [*] Memanggil binary apply ${PEAK_RATE} ${MIN_RATE}"
    echo ""
    "$BINARY" apply "$PEAK_RATE" "$MIN_RATE"
else
    echo "  [WARN] Binary tidak ditemukan"
    echo "  [INFO] Menjalankan tweak via shell fallback..."
    echo ""
    settings put system peak_refresh_rate "$PEAK_RATE" 2>/dev/null && \
        echo "  [OK] peak_refresh_rate = $PEAK_RATE" || \
        echo "  [FAIL] peak_refresh_rate"
    settings put system min_refresh_rate "$MIN_RATE" 2>/dev/null && \
        echo "  [OK] min_refresh_rate = $MIN_RATE" || \
        echo "  [FAIL] min_refresh_rate"
    for blk_path in /sys/block/*; do
        sched="$blk_path/queue/scheduler"
        [ -f "$sched" ] || continue
        blk=$(basename "$blk_path")
        AVAIL=$(cat "$sched" 2>/dev/null)
        APPLIED=""
        if echo "$AVAIL" | grep -q "deadline"; then
            echo "deadline" > "$sched" 2>/dev/null && APPLIED="deadline"
        elif echo "$AVAIL" | grep -q "mq-deadline"; then
            echo "mq-deadline" > "$sched" 2>/dev/null && APPLIED="mq-deadline"
        elif echo "$AVAIL" | grep -q "bfq"; then
            echo "bfq" > "$sched" 2>/dev/null && APPLIED="bfq"
        fi
        [ -n "$APPLIED" ] && echo "  [OK] /dev/$blk -> $APPLIED"
    done
fi

echo ""
echo "Done"
