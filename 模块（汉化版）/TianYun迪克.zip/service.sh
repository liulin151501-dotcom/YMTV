#!/system/bin/sh

SCRIPT_DIR=$(cd "$(dirname "$0")" 2>/dev/null && pwd)

if [ -f "/data/adb/modules/TianYunGou/module.prop" ]; then
    MODDIR=/data/adb/modules/TianYunGou
elif [ -f "$SCRIPT_DIR/module.prop" ]; then
    MODDIR=$SCRIPT_DIR
else
    MODDIR=$SCRIPT_DIR
fi

GAMELIST=$MODDIR/gamelist.txt
CONFIG=$MODDIR/config.prop
BINARY=$MODDIR/system/bin/Jawa6969fps

PEAK_RATE=120
MIN_RATE=60
SLEEP_INTERVAL=5
[ -f "$CONFIG" ] && . "$CONFIG"

get_foreground_package() {
    dumpsys activity activities 2>/dev/null \
        | grep -m1 "mResumedActivity" \
        | sed 's/.*{[^ ]* \([^ /]*\).*/\1/' \
        | cut -d/ -f1
}

shell_set_io() {
    for blk_path in /sys/block/*; do
        sched="$blk_path/queue/scheduler"
        ahead="$blk_path/queue/read_ahead_kb"
        [ -f "$sched" ] || continue
        AVAIL=$(cat "$sched" 2>/dev/null)
        if echo "$AVAIL" | grep -q "deadline"; then
            echo "deadline" > "$sched" 2>/dev/null
        elif echo "$AVAIL" | grep -q "mq-deadline"; then
            echo "mq-deadline" > "$sched" 2>/dev/null
        elif echo "$AVAIL" | grep -q "bfq"; then
            echo "bfq" > "$sched" 2>/dev/null
        fi
        [ -f "$ahead" ] && echo 512 > "$ahead" 2>/dev/null
    done
}

shell_reset_io() {
    for blk_path in /sys/block/*; do
        sched="$blk_path/queue/scheduler"
        ahead="$blk_path/queue/read_ahead_kb"
        [ -f "$sched" ] || continue
        AVAIL=$(cat "$sched" 2>/dev/null)
        if echo "$AVAIL" | grep -q "noop"; then
            echo "noop" > "$sched" 2>/dev/null
        elif echo "$AVAIL" | grep -q "none"; then
            echo "none" > "$sched" 2>/dev/null
        fi
        [ -f "$ahead" ] && echo 128 > "$ahead" 2>/dev/null
    done
}

do_boost() {
    if [ -f "$BINARY" ]; then
        chmod +x "$BINARY" 2>/dev/null
        "$BINARY" apply "$PEAK_RATE" "$MIN_RATE" 2>/dev/null
    else
        shell_set_io
        settings put system peak_refresh_rate "$PEAK_RATE" 2>/dev/null
        settings put system min_refresh_rate "$MIN_RATE" 2>/dev/null
    fi
}

do_boost_tick() {
    if [ -f "$BINARY" ]; then
        "$BINARY" boost 2>/dev/null
    fi
}

do_reset() {
    if [ -f "$BINARY" ]; then
        "$BINARY" reset 2>/dev/null
    else
        shell_reset_io
        settings put system peak_refresh_rate 60 2>/dev/null
        settings put system min_refresh_rate 60 2>/dev/null
    fi
}

GAME_ACTIVE=0

while true; do
    [ -f "$CONFIG" ] && . "$CONFIG"

    FOREGROUND=$(get_foreground_package)
    MATCHED=""

    while IFS= read -r pkg; do
        [ -z "$pkg" ] && continue
        [ "${pkg#\#}" != "$pkg" ] && continue
        if [ "$FOREGROUND" = "$pkg" ]; then
            MATCHED=$pkg
            break
        fi
    done < "$GAMELIST"

    if [ -n "$MATCHED" ]; then
        if [ "$GAME_ACTIVE" = "0" ]; then
            do_boost
            GAME_ACTIVE=1
        else
            do_boost_tick
        fi
    else
        if [ "$GAME_ACTIVE" = "1" ]; then
            do_reset
            GAME_ACTIVE=0
        fi
    fi

    sleep "$SLEEP_INTERVAL"
done &
