#!/system/bin/sh
MODPATH=${MODPATH:-/data/adb/modules/zentrix}
logcat -G 128K &>/dev/null

trim_partition () {
  if [ "$(id -u)" -eq 0 ]; then
    for partition in system vendor data cache metadata odm system_ext product;do fstrim -v "/$partition";done >/dev/null 2>&1 &
  else
    for partition in system vendor data cache metadata odm system_ext product;do sm fstrim "/$partition";done >/dev/null 2>&1 &
  fi
    sleep 3
}

delete_trash_logs () {
for DIR in /data/data/*; do
  if [ -d "${DIR}" ]; then
    rm -rf ${DIR}/cache/*
    rm -rf ${DIR}/no_backup/*
    rm -rf ${DIR}/app_webview/*
    rm -rf ${DIR}/code_cache/*
  fi
done

find /data/data/*/cache/* -delete &>/dev/null
find /data/data/*/code_cache/* -delete &>/dev/null
find /data/user_de/*/*/cache/* -delete &>/dev/null
find /data/user_de/*/*/code_cache/* -delete &>/dev/null
find /sdcard/Android/data/*/cache/* -delete &>/dev/null
}

NAME="ＺＥＮＴＲＩＸ⌯⌲"
VERSION="INFINITE"
AUTHOR="ELLIOTH"

ui_print " "
ui_print "======================================"
ui_print " MODULE INFO"
ui_print "======================================"
ui_print " Name    : $NAME"
ui_print " Version : $VERSION"
ui_print " Author  : $AUTHOR"
ui_print " Date    : $(date +'%Y-%m-%d %H:%M')"
ui_print "======================================"
ui_print " "

ANDROID_VER=$(getprop ro.build.version.release)
DEVICE_MODEL=$(getprop ro.product.model)
DEVICE_CODENAME=$(getprop ro.product.device)

ui_print "======================================"
ui_print " DEVICE INFO"
ui_print "======================================"
ui_print " Model   : $DEVICE_MODEL ($DEVICE_CODENAME)"
ui_print " Android : $ANDROID_VER"
ui_print "======================================"
ui_print " "

ui_print "- Cleaning junk and trimming partitions..."
delete_trash_logs
trim_partition
ui_print "- Clean up done."
sleep 1

ui_print "- Installing module files..."
unzip -o "$ZIPFILE" 'system/*' -d $MODPATH >&2
sleep 1

if [ ! -d "$MODPATH" ]; then
  ui_print "! Error: Module path not found!"
  ui_print "! Path: $MODPATH"
else
  ui_print "- Module path detected."
fi

ui_print "- Setting permissions..."

set_perm_recursive $MODPATH 0 0 0755 0644
set_perm_recursive $MODPATH/system/lib 0 0 0755 0644
set_perm $MODPATH/system/bin/app_process32 0 2000 0755 u:object_r:zygote_exec:s0
set_perm $MODPATH/system/bin/dex2oat 0 2000 0755 u:object_r:dex2oat_exec:s0
set_perm $MODPATH/system/lib/libart.so 0 0 0644
set_perm $MODPATH/service.sh 0 0 0755
set_perm $MODPATH/post-fs-data.sh 0 0 0755
set_perm $MODPATH/customize.sh 0 0 0755

if [ -d "$MODPATH/webroot" ]; then
  ui_print "- Configuring WebUI permissions..."
  set_perm_recursive $MODPATH/webroot 0 0 0755 0644
  
  if [ -f "$MODPATH/webroot/config/zentrix.sh" ]; then
      set_perm $MODPATH/webroot/config/zentrix.sh 0 0 0755
  fi
fi

ui_print "- Permissions set successfully."
sleep 1

ui_print "- Opening support channel..."
am start -a android.intent.action.VIEW -d "tg://resolve?domain=Vennec" >/dev/null 2>&1

ui_print " "
ui_print "====================================="
ui_print " INSTALLATION COMPLETE"
ui_print " Reboot to apply changes!"
ui_print "====================================="
ui_print " "

logcat -c &>/dev/null
