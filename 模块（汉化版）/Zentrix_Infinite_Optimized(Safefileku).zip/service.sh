#!/system/bin/sh
MODPATH=${0%/*}

wait_until_login() {
  while [ "$(dumpsys window policy | grep mInputRestricted=true)" != "" ]; do
    sleep 5
  done
  while [ ! -d "/sdcard/Android" ]; do
    sleep 1
  done
}

wait_until_login

ZEN_TAG="zen_$(date +%s)"
su -lp 2000 -c "cmd notification post -S bigtext -t '⌯ＺＥＮＴＲＩＸ' '$ZEN_TAG' 'Ram optimization in progress...'" 2>/dev/null > /dev/null 2>&1 &

write() {
    local file="$1"
    local value="$2"

    if [[ -z "$file" || -z "$value" ]]; then return 1; fi
    if [[ ! -f "$file" ]]; then return 1; fi
    if [[ ! -w "$file" ]]; then
        chmod +w "$file" 2>/dev/null || return 1
    fi
    if ! echo "$value" > "$file" 2>/dev/null; then return 1; fi
    return 0
}

RAM_KB=$(awk '/MemTotal/ {print $2}' /proc/meminfo)
RAM_MB=$((RAM_KB / 1024))
ZRAM_MB=$((RAM_MB * 50 / 100))
CPU_CORES=$(nproc)

swapoff /dev/block/zram0 2>/dev/null
write "/sys/block/zram0/reset" "1"
write "/sys/block/zram0/max_comp_streams" "$CPU_CORES"
write "/sys/block/zram0/disksize" "${ZRAM_MB}M"
mkswap /dev/block/zram0 2>/dev/null
swapon /dev/block/zram0 2>/dev/null

for queue_path in /sys/block/*/queue; do
    block_name=$(echo "$queue_path" | awk -F'/' '{print $4}')
    [ ! -d "$queue_path" ] && continue

    if case "$block_name" in *mmcblk*) true;; *) false;; esac; then
        write "$queue_path/nr_requests" "256"
    elif case "$block_name" in *sd*) true;; *) false;; esac; then
        write "$queue_path/nr_requests" "512"
    else
        write "$queue_path/nr_requests" "256"
    fi

    write "$queue_path/iostats" "0"
    write "$queue_path/rotational" "0"
    write "$queue_path/rq_affinity" "2"
done

write "/proc/sys/kernel/printk" "0 0 0 0"
write "/sys/module/printk/parameters/time" "0"
write "/proc/sys/vm/oom_dump_tasks" "0"

if [ "$RAM_MB" -le 4500 ]; then
    SWAP_RATE=90
    CACHE_PRESS=60
    LMK="18432:0,23040:100,27648:200,32256:250,55296:900,80640:950"
elif [ "$RAM_MB" -le 6500 ]; then
    SWAP_RATE=70
    CACHE_PRESS=80
    LMK="18432:0,23040:100,27648:200,32256:250,46080:900,72000:950"
else
    SWAP_RATE=50
    CACHE_PRESS=100
    LMK="18432:0,23040:100,27648:200,32256:250,46080:900,60480:950"
fi

write "/proc/sys/vm/swappiness" "$SWAP_RATE"
write "/proc/sys/vm/vfs_cache_pressure" "$CACHE_PRESS"
write "/proc/sys/vm/page-cluster" "0"
write "/proc/sys/vm/dirty_background_ratio" "10"
write "/proc/sys/vm/dirty_ratio" "30"

setprop ro.lmk.use_minfree_levels true
setprop sys.lmk.minfree_levels "$LMK"

write "/sys/kernel/mm/transparent_hugepage/enabled" "madvise"
write "/sys/kernel/mm/transparent_hugepage/defrag" "madvise"
write "/proc/sys/vm/watermark_boost_factor" "0"
write "/proc/sys/vm/watermark_scale_factor" "100"

SOC_TYPE=$(getprop ro.board.platform | tr '[:upper:]' '[:lower:]')
HARDWARE=$(getprop ro.hardware | tr '[:upper:]' '[:lower:]')

if echo "$SOC_TYPE $HARDWARE" | grep -qiE "mt[0-9]|heli|dimen"; then
    write "/sys/module/ged/parameters/ged_log_en" "0"
    write "/sys/module/ged/parameters/ged_smart_boost" "1"
elif echo "$SOC_TYPE $HARDWARE" | grep -qiE "exynos|erd"; then
    write "/sys/module/mali_kbase/parameters/mali_debug_level" "0"
elif echo "$SOC_TYPE $HARDWARE" | grep -qiE "gs101|gs201|gs301|zuma"; then
    write "/sys/module/mali_kbase/parameters/mali_debug_level" "0"
    write "/sys/module/f2fs/parameters/disable_ext_identify" "1"
elif echo "$SOC_TYPE $HARDWARE" | grep -qiE "ums|sp9|tiger"; then
    write "/sys/module/sipa_core/parameters/sipa_debug_level" "0"
fi

setprop ro.sys.fw.bg_apps_limit 20
setprop ro.vendor.qti.sys.fw.bg_apps_limit 20
setprop dalvik.vm.heapstartsize 8m
setprop dalvik.vm.heapgrowthlimit 192m
setprop dalvik.vm.heapsize 512m
setprop dalvik.vm.heaptargetutilization 0.75
setprop dalvik.vm.heapminfree 2m
setprop dalvik.vm.heapmaxfree 8m
setprop dalvik.vm.dex2oat-threads 2
setprop dalvik.vm.image-dex2oat-threads 2
setprop ro.hwui.texture_cache_size 48
setprop ro.hwui.layer_cache_size 32
setprop ro.hwui.path_cache_size 16
setprop ro.hwui.drop_shadow_cache_size 4

if [ -e "/sys/kernel/mm/ksm/run" ]; then
    write "/sys/kernel/mm/ksm/pages_to_scan" "100"
    write "/sys/kernel/mm/ksm/sleep_millisecs" "1000"
    write "/sys/kernel/mm/ksm/run" "1"
fi

echo 3 > /proc/sys/vm/drop_caches

su -lp 2000 -c "cmd notification post -S bigtext -t '⌯ＺＥＮＴＲＩＸ' '$ZEN_TAG' 'Dynamic memory management has been implemented. #MoreFreeRam'" 2>/dev/null > /dev/null 2>&1 &

(
  while true; do
    CURRENT_TIME=$(date +%H:%M)

    if [ "$CURRENT_TIME" = "00:00" ]; then
      sm fstrim
      cmd activity idle-maintenance
      sleep 60
    fi
    
    sleep 30 
  done
) &

sync
exit 0
