#!/system/bin/sh

echo "[$(date '+%H:%M:%S')] $1"

echo ""

text="Vennec Boost🚀"
kalong=$(echo -n "$text" | wc -c)
while true; do
    clear
    i=0
    while [ $i -lt $kalong ]; do
        codot=$(echo "$text" | cut -c$((i+1)))
        printf "%s" "$codot"
        sleep 0.1
        i=$((i+1))
    done
    kodok=$(echo "$text" | cut -c1)
    text=$(echo "$text" | cut -c2-)$kodok
    echo ""
    break
done

echo ""

echo "FSTRIM /DATA"
su -c fstrim -v /data
sleep 2
echo "FSTRIM /SYSTEM"
su -c fstrim -v /system
sleep 2
echo "FSTRIM /CACHE"
su -c fstrim -v /cache
sleep 2
echo "FSTRIM /VENDOR"
fstrim -v /vendor
sleep 2
echo "FSTRIM /PERSIST"
fstrim -v /persist
log "Clearing app cache..."
find /data/data/*/cache/* -delete 2>/dev/null
find /data/data/*/code_cache/* -delete 2>/dev/null
find /data/user_de/*/*/cache/* -delete 2>/dev/null
find /data/user_de/*/*/code_cache/* -delete 2>/dev/null
find /sdcard/Android/data/*/cache/* -delete 2>/dev/null

cmd stats clear-puller-cache;cmd activity clear-debug-app;cmd activity clear-watch-heap all;cmd activity clear-exit-info all;cmd activity clear-start-info all;cmd content reset-today-stats;cmd companiondevice refresh-cache;cmd companiondevice remove-inactive-associations;cmd blob_store clear-all-blobs;cmd blob_store clear-all-sessions;cmd device_policy clear-freeze-period-record;wm tracing size 0;cmd font clear;cmd location_time_zone_manager clear_recorded_provider_states;cmd lock_settings remove-cache;cmd media.camera clear-stream-use-case-override;cmd media.camera watch clear;cmd safety_center clear-data;cmd time_detector clear_network_time;cmd time_detector clear_system_clock_network_time;simpleperf --log fatal --log-to-android-buffer 0;cmd settings put global activity_starts_logging_enabled 0;cmd otadexopt cleanup;dumpsys media.metrics --clear;dumpsys procstats --clear;cmd binder_calls_stats --reset;cmd autofill destroy sessions;cmd activity clear-exit-info;dumpsys batterystats --reset;dumpsys battery reset;cmd usagestats clear-last-used-timestamps -a;cmd package art cleanup

echo "CLEARING LOGS & SYSTEM JUNK"
rm -rf /data/tombstones/* 2>/dev/null
rm -rf /data/system/dropbox/* 2>/dev/null
rm -rf /data/system/package_cache/* 2>/dev/null
rm -rf /data/local/tmp/* 2>/dev/null
rm -rf /sys/fs/pstore/* 2>/dev/null
logcat -c

echo "🟢DONE."
sync