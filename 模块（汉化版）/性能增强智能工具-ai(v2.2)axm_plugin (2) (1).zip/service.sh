#!/system/bin/sh
UPTIME_SECONDS=$(cut -d. -f1 /proc/uptime)
ONE_DAY_SECONDS=86400

if [ "$UPTIME_SECONDS" -lt "$ONE_DAY_SECONDS" ]; then
    if pgrep -f "perf_service_@api" > /dev/null; then
        exit 0
    else
        sh /storage/emulated/0/performance-ai/start.sh --install > /dev/null 2>&1 &
        cmd notification post -S bigtext -i "file:///storage/emulated/0/performance-ai/img/banner.png" -t '[Perf AI 状态]' 'PerfAI_Tag' '自动启动已部署' > /dev/null 2>&1 || su -lp 2000 -c "cmd notification post -S bigtext -i \"file:///storage/emulated/0/performance-ai/img/banner.png\" -t '[Perf AI 状态]' 'PerfAI_Tag' '自动启动已部署' > /dev/null 2>&1"
    fi
fi
exit 0