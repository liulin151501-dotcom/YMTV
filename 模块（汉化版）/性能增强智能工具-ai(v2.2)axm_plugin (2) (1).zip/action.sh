#!/system/bin/sh

ram_free() {
    local total_ram available_ram
    total_ram=$(grep MemTotal /proc/meminfo | awk '{print $2}')
    available_ram=$(grep MemAvailable /proc/meminfo | awk '{print $2}')
    echo "总内存: $(echo "scale=2; $total_ram/1024/1024" | bc) GB"
    echo "内存使用率: $(echo "scale=2; ($total_ram-$available_ram)*100/$total_ram" | bc)%"
}

get_system_cpu_usage_percentage() {
    read_cpu_stats() {
        read -r _ user nice system idle iowait irq softirq steal guest guest_nice < /proc/stat
        echo $((user+nice+system+idle+iowait+irq+softirq+steal+guest+guest_nice)) "$idle"
    }
    initial_stats=$(read_cpu_stats)
    sleep 0.2
    final_stats=$(read_cpu_stats)
    initial_total_time=$(echo "$initial_stats" | cut -d' ' -f1)
    initial_idle_time=$(echo "$initial_stats" | cut -d' ' -f2)
    final_total_time=$(echo "$final_stats" | cut -d' ' -f1)
    final_idle_time=$(echo "$final_stats" | cut -d' ' -f2)
    delta_total=$((final_total_time - initial_total_time))
    delta_idle=$((final_idle_time - initial_idle_time))
    if [ "$delta_total" -eq 0 ]; then echo "0.00"; else awk "BEGIN {printf \"%.2f\", (100.0 * ($delta_total - $delta_idle) / $delta_total)}"; fi
}
proc_stat_and_usage() {
    pid=$(pgrep -f "/data/local/tmp/perf_service_@api" | head -n 1)
    if [ -z "$pid" ]; then
        echo "性能服务状态: 已停止"
        echo "----------------------------------------"
        echo "未找到服务"
        return 1
    fi
    echo "性能服务状态: 运行中"
    echo "----------------------------------------"
    if [ -f "/proc/$pid/stat" ]; then
        stats=$(cat "/proc/$pid/stat")
        starttime=$(echo "$stats" | awk '{print $22}')
        uptime_seconds=$(awk '{print $1}' /proc/uptime)
        hz=$(getconf CLK_TCK 2>/dev/null || echo 100)
        runtime_seconds=$(awk "BEGIN {printf \"%.0f\", $uptime_seconds - ($starttime / $hz)}")
        [ "$runtime_seconds" -lt 0 ] && runtime_seconds=0
        days=$((runtime_seconds / 86400)); hours=$(( (runtime_seconds % 86400) / 3600 )); minutes=$(( (runtime_seconds % 3600) / 60 )); seconds=$((runtime_seconds % 60))
        read_process_and_system_stats() {
            process_stats=$(cat "/proc/$pid/stat")
            process_utime=$(echo "$process_stats" | awk '{print $14}')
            process_stime=$(echo "$process_stats" | awk '{print $15}')
            read -r _ user nice system idle iowait irq softirq steal guest guest_nice < /proc/stat
            system_total_time=$((user+nice+system+idle+iowait+irq+softirq+steal+guest+guest_nice))
            echo "$process_utime $process_stime $system_total_time"
        }
        initial_cpu_stats=$(read_process_and_system_stats)
        initial_utime=$(echo "$initial_cpu_stats" | cut -d' ' -f1)
        initial_stime=$(echo "$initial_cpu_stats" | cut -d' ' -f2)
        initial_process_time=$((initial_utime + initial_stime))
        initial_system_total_time=$(echo "$initial_cpu_stats" | cut -d' ' -f3)
        sleep 0.1
        final_cpu_stats=$(read_process_and_system_stats)
        final_utime=$(echo "$final_cpu_stats" | cut -d' ' -f1)
        final_stime=$(echo "$final_cpu_stats" | cut -d' ' -f2)
        final_process_time=$((final_utime + final_stime))
        final_system_total_time=$((final_system_total_time - initial_system_total_time))
        delta_process_time=$((final_process_time - initial_process_time)); delta_system_total_time=$((final_system_total_time - initial_system_total_time))
        if [ "$delta_system_total_time" -eq 0 ]; then process_cpu_percent="0.00"; else process_cpu_percent=$(awk "BEGIN {printf \"%.2f\", (100.0 * $delta_process_time / $delta_system_total_time)}"); fi
        if [ -f "/proc/$pid/io" ]; then
            read_bytes=$(grep "read_bytes:" "/proc/$pid/io" | awk '{print $2}' | tr -d '[:space:]')
            write_bytes=$(grep "write_bytes:" "/proc/$pid/io" | awk '{print $2}' | tr -d '[:space:]')
            format_bytes() {
                awk -v bytes="${1:-0}" 'BEGIN { if (bytes >= 1073741824) printf "%.2f GB", bytes/1073741824; else if (bytes >= 1048576) printf "%.2f MB", bytes/1048576; else if (bytes >= 1024) printf "%.2f KB", bytes/1024; else printf "%d B", bytes; }'
            }
            total_io="读取: $(format_bytes "$read_bytes"), 写入: $(format_bytes "$write_bytes")"
        else
            total_io="读取: 0 B, 写入: 0 B"
        fi
        echo "性能服务 PID: $pid"
        echo "已运行时间: $days 天, $hours 小时, $minutes 分钟, $seconds 秒"
        echo "当前服务 CPU 使用率: $process_cpu_percent%"
        echo "服务总读写量: $total_io"
    else
        echo "性能服务状态: 错误"
        echo "----------------------------------------"
        echo "无法读取 PID $pid 的 /proc 文件"
        return 1
    fi
}
    echo "  ____            __    _      _ "
    echo " |  _ \  ___ _ __/ _|  / \    (_)"
    echo " | |_) |/ _ \ '__| |_  / _ \   | |"
    echo " |  __/|  __/ |  |  _|/ ___ \  | |"
    echo " |_|    \___|_|  |_| /_/   \_\ |_|"
    echo
echo " "
echo "状态 :"
proc_stat_and_usage
echo "-------------------------------------"
echo "系统当前使用情况详情"
echo "当前 CPU 使用率: $(get_system_cpu_usage_percentage)%"
ram_free