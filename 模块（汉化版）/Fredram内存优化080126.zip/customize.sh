#!/system/bin/sh
# 状态文件路径
state="/data/local/tmp/.sc.txt"

# 写入启用 activity compact 标志
echo "compact=1" > "$state"

# 检查设备是否支持 activity compact
if ! cmd activity 2>/dev/null | grep -q "compact"; then
    # 提示该设备不支持 activity compact
    ui_print "此设备不支持 activity compact"
    # 提示仍会安装（仅执行强制停止和杀进程）
    ui_print "仍会安装（仅强制停止和杀进程）"
    # 写入禁用 activity compact 标志
    echo "compact=0" > "$state"
fi

# 提示安装完成
ui_print "安装完成。请享用！"

# 列出用户 0 下符合白名单的包，并保存到文件
cmd package list packages --user 0 | grep -Eo "$(cat $MODDIR/white.txt)" > /data/local/tmp/.wl.txt