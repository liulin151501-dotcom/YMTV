#!/system/bin/sh
# 将标准输出和错误输出重定向到空设备，即不显示任何信息
exec >/dev/null 2>&1

# 将当前 shell 进程的 I/O 调度优先级设置为最低（idle 类，优先级 7）
iorenice $$ 7 idle
# 将当前 shell 进程的调度优先级设置为最低（nice 值 19）
renice -n 19 -p $$

# 状态文件路径
FLAG="/data/local/tmp/.sc.txt"
# 应用白名单文件路径
applist="/data/local/tmp/.wl.txt"

# 包名的正则表达式（常见域名前缀）
pkgvl='^(com|org|app|id|cn)\.[a-z0-9_]+\.[a-z0-9_.]+'
# 白名单关键字（不处理的包名）
whitelist='music|spotify|systemui|launcher|Launcher|inputmethod'

# 默认启用 compaction
compact=1
# 如果状态文件存在，则加载其中的变量
[ -f "$FLAG" ] && . "$FLAG"
# 如果应用列表文件不存在，则创建空文件
[ -f "$applist" ] || touch "$applist"

# 无限循环，持续监控内存并执行相应操作
while :; do

    # 获取总内存大小（KB）
    mem_total=$(awk '/MemTotal/ {print $2}' /proc/meminfo)
    # 获取可用内存大小（KB）
    mem_avail=$(awk '/MemAvailable/ {print $2}' /proc/meminfo)
    # 计算已用内存百分比
    mem_pct=$(( (mem_total - mem_avail) * 100 / mem_total ))

    # 默认休眠时间（秒）
    sleep_time=60

    # 如果内存使用率在 65% 到 72% 之间
    if [ "$mem_pct" -gt 65 ] && [ "$mem_pct" -le 72 ]; then
        mid_done=0

        # 如果启用了 compaction
        if [ "$compact" = "1" ]; then
            # 遍历后台进程的 PID
            for pid in $(ps -o pid,user,pcy | awk '/u0_.*bg/ {print $1}'); do
                # 确保可以读取进程命令行
                [ -r "/proc/$pid/cmdline" ] || continue

                # 获取进程对应的包名
                pkg=$(tr "\0" "\n" < /proc/$pid/cmdline | head -n1)
                # 如果在白名单中则跳过
                grep -qx "$pkg" "$applist" && continue

                # 尝试对进程进行 compaction
                cmd activity compact full "$pid" && mid_done=1
                cmd activity compact native full "$pid" && mid_done=1
            done

            # 对系统进行 compaction
            cmd activity compact system && mid_done=1
        else
            # 列出用户 0 下的第三方应用包名
            cmd package list packages --user 0 -3 | cut -d: -f2 > /tmp/user_pkgs.txt

            # 遍历后台进程并尝试杀掉符合条件的包
            ps -o pid,user,pcy \
            | awk '/u0_.*bg/ {print $1}' \
            | xargs -r -n1 -P4 sh -c '
                pid="$1"
                [ -r "/proc/$pid/cmdline" ] || exit 0

                pkg=$(tr "\0" "\n" < /proc/$pid/cmdline | head -n1)

                grep -qx "$pkg" "'"$applist"'" && exit 0
                grep -qx "$pkg" /tmp/user_pkgs.txt || exit 0

                cmd activity kill --user 0 "$pkg" && echo 1 >> /tmp/kill_flag
            ' _

            # 如果有成功杀掉的包，则延长休眠时间
            [ -f /tmp/kill_flag ] && mid_done=1 && rm -f /tmp/kill_flag
        fi

        # 如果执行了 compaction 或杀进程操作，则休眠 90 秒
        [ "$mid_done" -eq 1 ] && sleep_time=90
    fi

    # 如果内存使用率超过 72%
    if [ "$mem_pct" -gt 72 ]; then
        force_done=0

        # 列出用户 0 下所有已安装和已卸载的包
        cmd package list packages --user 0 -u | cut -d: -f2 > /tmp/user_pkgs.txt

        # 获取前台应用的包名
        fg_pkg=$(cmd activity stack list | awk -F'[/{]' '/0,0.*=true/ {print $3; exit}')

        # 遍历后台进程并尝试强制停止符合条件的包
        ps -o pid,user,pcy \
        | awk '/u0_.*bg/ {print $1}' \
        | xargs -r -n1 -P4 sh -c '
            pid="$1"
            [ -r "/proc/$pid/cmdline" ] || exit 0

            pkg=$(tr "\0" "\n" < /proc/$pid/cmdline | head -n1)

            echo "$pkg" | grep -qE "'"$pkgvl"'" || exit 0
            grep -qx "$pkg" /tmp/user_pkgs.txt || exit 0
            [ -n "'"$fg_pkg"'" ] && [ "$pkg" = "'"$fg_pkg"'" ] && exit 0
            grep -qx "$pkg" "'"$applist"'" && exit 0
            echo "$pkg" | grep -qE "'"$whitelist"'" && exit 0

            cmd activity force-stop "$pkg" && echo 1 >> /tmp/force_flag
        ' _

        # 如果有成功强制停止的包，则延长休眠时间
        [ -f /tmp/force_flag ] && force_done=1 && rm -f /tmp/force_flag
        [ "$force_done" -eq 1 ] && sleep_time=120
    fi

    # 按设定的休眠时间等待
    sleep "$sleep_time"
done