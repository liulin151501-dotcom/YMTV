#!/system/bin/sh
# 获取当前脚本所在目录作为模块目录
MODDIR=${0%/*}
# 列出用户 0 下符合白名单的包，并保存到文件
cmd package list packages --user 0 | grep -Eo "$(cat $MODDIR/white.txt)" > /data/local/tmp/.wl.txt
# 设置系统配置，启用 activity manager 的 compaction 功能
device_config put activity_manager use_compaction true
# 在后台运行 swap.sh 并脱离当前 shell 会话
nohup $MODDIR/other/swap.sh&disown