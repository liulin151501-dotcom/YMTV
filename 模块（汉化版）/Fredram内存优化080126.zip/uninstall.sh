#!/system/bin/sh
# 将标准输出和错误输出重定向到空设备，即不显示任何信息
exec>/dev/null 2>&1
# 强制结束所有包含 "swap.sh" 的进程
pkill -9 -f "swap.sh"
# 状态文件路径
state="/data/local/tmp/.sc.txt"
# 删除状态文件（如果存在）
rm -rf "$state"