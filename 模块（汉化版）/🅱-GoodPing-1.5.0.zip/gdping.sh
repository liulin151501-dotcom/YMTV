#!/system/bin/sh

Z(){ command -v "$1" >/dev/null 2>&1; }

Y(){
  f="$1"; v="$2"
  [ -f "$f" ] || return 0
  c="$(cat "$f" 2>/dev/null | tr -d '\r\n' || true)"
  [ "$c" = "$v" ] && return 0
  chmod +w "$f" 2>/dev/null || true
  printf '%s' "$v" > "$f" 2>/dev/null || true
  chmod -w "$f" 2>/dev/null || true
}

Q(){
  Z getprop && Z setprop || return 0
  c="$(getprop "$1" 2>/dev/null || true)"
  [ "$c" != "$2" ] && setprop "$1" "$2" >/dev/null 2>&1
}

W(){
  Z settings || return 0
  c="$(settings get "$1" "$2" 2>/dev/null || true)"
  [ "$c" != "$3" ] && settings put "$1" "$2" "$3" >/dev/null 2>&1
}

G(){
  [ -r /proc/sys/net/ipv4/tcp_available_congestion_control ] || {
    printf cubic; return
  }
  av="$(cat /proc/sys/net/ipv4/tcp_available_congestion_control 2>/dev/null)"
  case "$av" in
    *bbr*) printf bbr ;;
    *cubic*) printf cubic ;;
    *htcp*) printf htcp ;;
    *) printf cubic ;;
  esac
}

cc="$(G)"
Y /proc/sys/net/ipv4/tcp_congestion_control "$cc"
Y /proc/sys/net/ipv4/tcp_wmem "20480 12582912 25165824"
Y /proc/sys/net/ipv4/tcp_rmem "20480 12582912 25165824"
Y /proc/sys/net/ipv4/tcp_mem "65536 131072 262144"
Y /proc/sys/net/core/netdev_max_backlog "65536"
Y /proc/sys/net/core/somaxconn "1024"
Y /proc/sys/net/ipv4/tcp_fin_timeout "15"
Y /proc/sys/net/ipv4/tcp_keepalive_time "30"
Y /proc/sys/net/ipv4/tcp_tw_reuse "1"
Y /proc/sys/net/ipv4/tcp_max_tw_buckets "1440000"
Y /proc/sys/net/core/rmem_default "25165824"
Y /proc/sys/net/core/wmem_default "25165824"
Y /proc/sys/net/core/rmem_max "25165824"
Y /proc/sys/net/core/wmem_max "25165824"

Q net.tcp.default_init_rwnd "60"

L="
netpolicy_override_enabled
netpolicy_quota_enabled
netpolicy_quota_frac_jobs
netpolicy_quota_frac_multipath
netpolicy_quota_limited
netpolicy_quota_unlimited
netstats_augment_enabled
netstats_combine_subtype_enabled
netstats_dev_bucket_duration
netstats_dev_delete_age
netstats_dev_persist_bytes
netstats_dev_rotate_age
netstats_enabled
netstats_global_alert_bytes
netstats_poll_interval
netstats_sample_enabled
netstats_time_cache_max_age
netstats_uid_bucket_duration
netstats_uid_delete_age
netstats_uid_persist_bytes
netstats_uid_rotate_age
netstats_uid_tag_bucket_duration
netstats_uid_tag_delete_age
netstats_uid_tag_persist_bytes
netstats_uid_tag_rotate_age
network_metered_multipath_preference
network_recommendations_enabled
network_switch_notification_daily_limit
network_switch_notification_rate_limit_millis
network_watchlist_last_report_time
"

for k in $L; do
  W global "$k" "0"
done

W global network_watchlist_enabled ""
W global private_dns_specifier "1dot1dot1dot1.cloudflare-dns.com"
W global private_dns_mode hostname
W global preferred_network_mode "11"
W global data_roaming "0"
W global data_activity_timeout_mobile "0"
W global connectivity_metrics_buffer_size "256"
W global tether_offload_disabled "0"
W global ble_scan_always_enabled "0"
W global enable_cellular_on_boot "1"
W system nearby_scanning_permission_allowed "0"
W system nearby_scanning_enabled "0"

W global data_activity_timeout_wifi "0"
W global wifi_score_params "rssi2=-95:-85:-73:-60,rssi5=-85:-82:-70:-57"
W global wifi_coverage_extend_feature_enabled "0"
W global wifi_networks_available_notification_on "0"
W global wifi_poor_connection_warning "0"
W global wifi_verbose_logging_enabled "0"
W global wifi_suspend_optimizations_enabled "1"
W global wifi_wakeup_enabled "0"
W global wifi_country_code "GB"
W global wifi_framework_scan_interval_ms "0"
W global wifi_supplicant_scan_interval_ms "5000"
W global wifi_watchdog_poor_network_test_enabled "0"
W global wifi_scan_always_enabled "0"
W global wifi_scan_throttle_enabled "0"

Q net.tcp.buffersize.default "4096,87380,6291456,4096,16384,6291456"
Q net.tcp.buffersize.wifi "4096,87380,8388608,4096,16384,8388608"
Q net.tcp.buffersize.lte "4096,87380,12582912,4096,16384,12582912"
Q net.tcp.buffersize.game "4096,87380,2097152,4096,16384,2097152"

Z svc && svc wifi enable >/dev/null 2>&1

Z cmd && {
  cmd wifi set-verbose-logging disabled >/dev/null 2>&1
  cmd wifi force-hi-perf-mode enabled >/dev/null 2>&1
  cmd wifi set-scan-always-available enabled >/dev/null 2>&1
  cmd wifi set-connected-score 60 >/dev/null 2>&1
  cmd connectivity set-chain3-enabled false >/dev/null 2>&1
  cmd phone data enable >/dev/null 2>&1
  cmd phone data set-roaming disabled >/dev/null 2>&1

  cmd netd resolver flushdefaultif >/dev/null 2>&1
  for i in wlan0 rmnet_data0; do cmd netd resolver flushif "$i" >/dev/null 2>&1; done

  SUB="$(cmd phone get-default-data-sub 2>/dev/null || echo 0)"
  for m in 29 24 11 9; do cmd phone set-preferred-network-type "$SUB" "$m" >/dev/null 2>&1 && break; done
  cmd phone enable-modem "$SUB" true >/dev/null 2>&1
}

Z cmd && cmd deviceidle disable >/dev/null 2>&1

Z cmd && Z dumpsys && Z awk && Z cut && {
  GPK="$(dumpsys game 2>/dev/null | awk '/packageName/ {print $NF}' | tr -d '"')"
  for p in $GPK; do
    U="$(cmd package resolve-uid --user 0 "$p" 2>/dev/null | grep -oE '[0-9]+' || true)"
    [ -n "$U" ] && {
      cmd netpolicy remove restrict-background-blacklist "$U" >/dev/null 2>&1
      cmd netpolicy add restrict-background-whitelist "$U" >/dev/null 2>&1
    }
  done
}

Z cmd && {
  for N in $(cmd netpolicy list wifi-networks 2>/dev/null | awk '{print $1}' || true); do
    cmd netpolicy set metered-network "$N" false >/dev/null 2>&1
  done
}

am start -a AxManager.TOAST -e text "🅱️-GoodPing Tweak Active"