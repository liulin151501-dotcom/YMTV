#!/system/bin/sh

Z(){ command -v "$1" >/dev/null 2>&1; }

clear_prop(){
  Z getprop && Z setprop || return 0
  setprop "$1" "" >/dev/null 2>&1
}

clear_setting(){
  ns="$1"; key="$2"
  Z settings || return 0
  settings delete "$ns" "$key" >/dev/null 2>&1 || settings put "$ns" "$key" "" >/dev/null 2>&1
}

# sysctl revert → best effort
R(){
  f="$1"
  [ -f "$f" ] && printf '' >"$f" 2>/dev/null || true
}

R /proc/sys/net/ipv4/tcp_congestion_control
R /proc/sys/net/ipv4/tcp_wmem
R /proc/sys/net/ipv4/tcp_rmem
R /proc/sys/net/ipv4/tcp_mem
R /proc/sys/net/core/netdev_max_backlog
R /proc/sys/net/core/somaxconn
R /proc/sys/net/ipv4/tcp_fin_timeout
R /proc/sys/net/ipv4/tcp_keepalive_time
R /proc/sys/net/ipv4/tcp_tw_reuse
R /proc/sys/net/ipv4/tcp_max_tw_buckets
R /proc/sys/net/core/rmem_default
R /proc/sys/net/core/wmem_default
R /proc/sys/net/core/rmem_max
R /proc/sys/net/core/wmem_max

clear_prop net.tcp.default_init_rwnd

L="
netpolicy_override_enabled
netpolicy_quota_enabled
netpolicy_quota_frac_jobs
netpolicy_quota_frac_multipath
netpolicy_quota_limited
netpolicy_quota_unlimited
netstats_augment_enabled
netstats_combine_subtype_enabled
netstats_dev_bucket_duration
netstats_dev_delete_age
netstats_dev_persist_bytes
netstats_dev_rotate_age
netstats_enabled
netstats_global_alert_bytes
netstats_poll_interval
netstats_sample_enabled
netstats_time_cache_max_age
netstats_uid_bucket_duration
netstats_uid_delete_age
netstats_uid_persist_bytes
netstats_uid_rotate_age
netstats_uid_tag_bucket_duration
netstats_uid_tag_delete_age
netstats_uid_tag_persist_bytes
netstats_uid_tag_rotate_age
network_metered_multipath_preference
network_recommendations_enabled
network_switch_notification_daily_limit
network_switch_notification_rate_limit_millis
network_watchlist_last_report_time
"

for k in $L; do
  clear_setting global "$k"
done

clear_setting global network_watchlist_enabled
clear_setting global private_dns_specifier
clear_setting global private_dns_mode
clear_setting global preferred_network_mode
clear_setting global data_roaming
clear_setting global data_activity_timeout_mobile
clear_setting global connectivity_metrics_buffer_size
clear_setting global tether_offload_disabled
clear_setting global ble_scan_always_enabled
clear_setting global enable_cellular_on_boot
clear_setting system nearby_scanning_permission_allowed
clear_setting system nearby_scanning_enabled

clear_setting global data_activity_timeout_wifi
clear_setting global wifi_score_params
clear_setting global wifi_coverage_extend_feature_enabled
clear_setting global wifi_networks_available_notification_on
clear_setting global wifi_poor_connection_warning
clear_setting global wifi_verbose_logging_enabled
clear_setting global wifi_suspend_optimizations_enabled
clear_setting global wifi_wakeup_enabled
clear_setting global wifi_country_code
clear_setting global wifi_framework_scan_interval_ms
clear_setting global wifi_supplicant_scan_interval_ms
clear_setting global wifi_watchdog_poor_network_test_enabled
clear_setting global wifi_scan_always_enabled
clear_setting global wifi_scan_throttle_enabled

clear_prop net.tcp.buffersize.default
clear_prop net.tcp.buffersize.wifi
clear_prop net.tcp.buffersize.lte
clear_prop net.tcp.buffersize.game

Z cmd && {
  cmd wifi set-verbose-logging disabled >/dev/null 2>&1
  cmd wifi force-hi-perf-mode disabled >/dev/null 2>&1
  cmd wifi set-scan-always-available disabled >/dev/null 2>&1
  cmd wifi set-connected-score 0 >/dev/null 2>&1
  cmd connectivity set-chain3-enabled true >/dev/null 2>&1
  cmd phone data enable >/dev/null 2>&1
  cmd phone data set-roaming enabled >/dev/null 2>&1
}

Z cmd && cmd deviceidle enable >/dev/null 2>&1

Z cmd && Z dumpsys && Z awk && Z cut && {
  GPK="$(dumpsys game 2>/dev/null | awk '/packageName/ {print $NF}' | tr -d '"')"
  for p in $GPK; do
    U="$(cmd package resolve-uid --user 0 "$p" 2>/dev/null | grep -oE '[0-9]+' || true)"
    [ -n "$U" ] && {
      cmd netpolicy remove restrict-background-whitelist "$U" >/dev/null 2>&1
    }
  done
}

Z cmd && {
  for N in $(cmd netpolicy list wifi-networks 2>/dev/null | awk '{print $1}' || true); do
    cmd netpolicy set metered-network "$N" true >/dev/null 2>&1
  done
}
cmd notification post -S bigtext -t '🅱️-GoodPing' '🛑' " stopped"