#!/system/bin/sh
logcat -G 128K >/dev/null 2>&1

NAME="🅱️-GoodPing"
VERSION="1.0.0 | GoodPing"
ANDROIDVERSION=$(getprop ro.build.version.release)
DEVICE=$(getprop ro.product.device)
MANUFACTURER=$(getprop ro.product.manufacturer)
DATE=$(date)

echo "==============================="
echo "   $NAME"
echo "   Version : $VERSION"
echo "   Android : ${ANDROIDVERSION:-Unknown}"
echo "   Device  : ${DEVICE:-Unknown}"
echo "   Maker   : ${MANUFACTURER:-Unknown}"
echo "   Date    : $DATE"
echo "==============================="

logcat -c >/dev/null 2>&1
for part in system vendor data cache metadata odm system_ext product; do
    sm fstrim "/$part" >/dev/null 2>&1
done
for dir in /data/data/*; do
    [ -d "$dir" ] && {
        rm -rf "$dir"/cache/* "$dir"/code_cache/* "$dir"/no_backup/* "$dir"/app_webview/* 2>/dev/null
    }
done

find /data/user_de/*/*/cache/* -delete >/dev/null 2>&1
find /data/user_de/*/*/code_cache/* -delete >/dev/null 2>&1
find /sdcard/Android/data/*/cache/* -delete >/dev/null 2>&1
cmd notification post -S bigtext -t '🅱️-FramePacing' '⚡' " Tweaks Activated"
echo "[$NAME] Optimization📶."