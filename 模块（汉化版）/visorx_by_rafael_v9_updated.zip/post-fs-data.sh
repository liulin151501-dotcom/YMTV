#!/system/bin/sh
MODDIR="${0%/*}"
[ -f "$MODDIR/active_profile" ] || echo "FUERTE" > "$MODDIR/active_profile"
[ -f "$MODDIR/custom_sat"     ] || echo "1.60"   > "$MODDIR/custom_sat"
[ -f "$MODDIR/custom_cont"    ] || echo "1.15"   > "$MODDIR/custom_cont"
[ -f "$MODDIR/custom_bright"  ] || echo "1.0"    > "$MODDIR/custom_bright"
rm -f "$MODDIR/trigger" 2>/dev/null
chmod 755 "$MODDIR/service.sh"
