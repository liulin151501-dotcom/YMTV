<div align="center">

# 🎨 VisorX
### By_Rafael System

**Color & Graphics Engine — Motor de color para tu pantalla**

[![Version](https://img.shields.io/badge/Version-v9.0-purple?style=flat-square)]()
[![Android](https://img.shields.io/badge/Android-8%2B-green?style=flat-square)]()
[![Root](https://img.shields.io/badge/Root-Magisk%20%7C%20KSU%20%7C%20APatch-blue?style=flat-square)]()
[![Author](https://img.shields.io/badge/Author-By__Rafael_System-orange?style=flat-square)]()

</div>

---

## 🌍 Languages / Idiomas
- 🇪🇸 [Español](#español)
- 🇺🇸 [English](#english)
- 🇧🇷 [Português](#português)
- 🇮🇩 [Indonesia](#indonesia)
- 🇷🇺 [Русский](#русский)

---

## 🇪🇸 Español

### ¿Qué es VisorX?
Motor de color y gráficos que mejora la saturación, contraste y brillo de tu pantalla en tiempo real. 6 perfiles predefinidos + modo personalizado completo.

### ✨ Características
- 🟣 **Ultra Suave**: Saturación 1.05 — ajuste casi imperceptible
- 🔵 **Suave**: Saturación 1.15 — colores ligeramente mejorados
- 🟡 **Medio**: Saturación 1.45 — balance visual óptimo
- 🔴 **Fuerte**: Saturación 1.8 — colores vívidos e intensos
- ⚙️ **Custom**: Control total de saturación, contraste y brillo
- ⚪ **Sistema**: Restaura valores originales de fábrica

### 📱 Compatibilidad
| Dispositivo | Compatibilidad | Notas |
|---|---|---|
| Xiaomi / Redmi / POCO | ✅ **Máxima** | Todos los props MIUI/HyperOS activos |
| Samsung | ✅ Buena | Saturación y contraste base |
| OnePlus / OPPO | ✅ Buena | Saturación y contraste base |
| Motorola / Nokia | ✅ Buena | Saturación y contraste base |
| Cualquier Android 8+ | ✅ Base | SurfaceFlinger universal funciona |

### ⚙️ Gestores de Root
| Gestor | Estado |
|---|---|
| Magisk v20.4+ | ✅ Soportado |
| KernelSU | ✅ Soportado |
| APatch | ✅ Soportado |

---

## 🇺🇸 English

### What is VisorX?
Color and graphics engine that improves saturation, contrast and brightness of your screen in real time. 6 predefined profiles + full custom mode.

### ✨ Features
- 🟣 **Ultra Soft**: Saturation 1.05 — almost imperceptible adjustment
- 🔵 **Soft**: Saturation 1.15 — slightly enhanced colors
- 🟡 **Medium**: Saturation 1.45 — optimal visual balance
- 🔴 **Strong**: Saturation 1.8 — vivid and intense colors
- ⚙️ **Custom**: Full control of saturation, contrast and brightness
- ⚪ **System**: Restores original factory values

### 📱 Compatibility
| Device | Compatibility | Notes |
|---|---|---|
| Xiaomi / Redmi / POCO | ✅ **Maximum** | All MIUI/HyperOS props active |
| Samsung | ✅ Good | Base saturation and contrast |
| OnePlus / OPPO | ✅ Good | Base saturation and contrast |
| Any Android 8+ | ✅ Base | Universal SurfaceFlinger works |

---

## 🇧🇷 Português

### O que é VisorX?
Motor de cor e gráficos que melhora a saturação, contraste e brilho da sua tela em tempo real. 6 perfis predefinidos + modo personalizado completo.

### ✨ Funcionalidades
- 🟣 **Ultra Suave**: Saturação 1.05
- 🔵 **Suave**: Saturação 1.15
- 🟡 **Médio**: Saturação 1.45 — equilíbrio visual ideal
- 🔴 **Forte**: Saturação 1.8 — cores vívidas e intensas
- ⚙️ **Custom**: Controle total de saturação, contraste e brilho
- ⚪ **Sistema**: Restaura valores originais de fábrica

### 📱 Compatibilidade
| Dispositivo | Compatibilidade |
|---|---|
| Xiaomi / Redmi / POCO | ✅ Máxima |
| Samsung / OnePlus | ✅ Boa |
| Qualquer Android 8+ | ✅ Base |

---

## 🇮🇩 Indonesia

### Apa itu VisorX?
Mesin warna dan grafis yang meningkatkan saturasi, kontras, dan kecerahan layar Anda secara real time. 6 profil preset + mode kustom lengkap.

### ✨ Fitur
- 🟣 **Ultra Lembut**: Saturasi 1.05
- 🔵 **Lembut**: Saturasi 1.15
- 🟡 **Sedang**: Saturasi 1.45 — keseimbangan visual optimal
- 🔴 **Kuat**: Saturasi 1.8 — warna cerah dan intens
- ⚙️ **Custom**: Kontrol penuh saturasi, kontras, dan kecerahan

### 📱 Kompatibilitas
| Perangkat | Kompatibilitas |
|---|---|
| Xiaomi / Redmi / POCO | ✅ Maksimal |
| Samsung / OnePlus | ✅ Baik |
| Android 8+ manapun | ✅ Dasar |

---

## 🇷🇺 Русский

### Что такое VisorX?
Движок цвета и графики, который улучшает насыщенность, контрастность и яркость экрана в реальном времени. 6 предустановленных профилей + полный пользовательский режим.

### ✨ Возможности
- 🟣 **Ультра мягкий**: Насыщенность 1.05
- 🔵 **Мягкий**: Насыщенность 1.15
- 🟡 **Средний**: Насыщенность 1.45 — оптимальный визуальный баланс
- 🔴 **Сильный**: Насыщенность 1.8 — яркие и насыщенные цвета
- ⚙️ **Custom**: Полный контроль насыщенности, контраста и яркости

### 📱 Совместимость
| Устройство | Совместимость |
|---|---|
| Xiaomi / Redmi / POCO | ✅ Максимальная |
| Samsung / OnePlus | ✅ Хорошая |
| Android 8+ любой | ✅ Базовая |

---

## 📄 License
Apache License 2.0 — By_Rafael System © 2026
