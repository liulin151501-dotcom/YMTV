#!/system/bin/sh
# VISUAL ENHANCER BY_RAFAEL v9.0  By_Rafael System
MODDIR="${0%/*}"
CONFIG="$MODDIR/active_profile"
LOG="$MODDIR/visual_rafael.log"
TRIGGER="$MODDIR/trigger"
CSAT="$MODDIR/custom_sat"
CCONT="$MODDIR/custom_cont"
CBRIGHT="$MODDIR/custom_bright"

until [ "$(getprop sys.boot_completed)" = "1" ]; do sleep 2; done
sleep 10

write_log() {
    {
        echo "=============================="
        echo "Visual Enhancer By_Rafael v9.0"
        echo "By_Rafael System"
        echo "=============================="
        echo "Fecha    : $(date '+%Y-%m-%d %H:%M:%S')"
        echo "Perfil   : $1"
        echo "Saturacion: $2"
        echo "Contraste : $3"
        echo "Brillo    : $4"
        echo "Modelo   : $(getprop ro.product.model)"
        echo "Android  : $(getprop ro.build.version.release)"
        echo "ROM      : $(getprop ro.mi.os.version.name 2>/dev/null || getprop ro.build.flavor 2>/dev/null | cut -d'-' -f1 || getprop ro.custom.build.version 2>/dev/null || getprop ro.build.display.id 2>/dev/null | cut -d' ' -f1 || echo Generic)"
        echo "------------------------------"
        echo "sat real : $(getprop persist.sys.sf.color_saturation)"
        echo "miui mode: $(getprop persist.vendor.display.miui.mode)"
        echo "Estado   : ACTIVO OK"
        echo "=============================="
    } > "$LOG"
    cp "$LOG" "/storage/emulated/0/Download/visual_rafael.log" 2>/dev/null
}

apply_sistema() {
    setprop persist.sys.sf.native_mode 1
    setprop persist.sys.sf.color_saturation 1.0
    setprop persist.sys.sf.force_contrast 1.0
    setprop persist.sys.sf.force_brightness 1.0
    setprop persist.vendor.display.miui.mode 0
    setprop persist.vendor.display.miui.standard_mode 1
    setprop persist.vendor.display.miui.mms.saturation_ratio 100
    setprop persist.vendor.display.miui.mms.saturation_ratio_enhancement 0
    service call SurfaceFlinger 1023 i32 1 2>/dev/null
    service call SurfaceFlinger 1022 f 1.0 2>/dev/null
    setprop debug.sf.hw 0; setprop debug.egl.hw 0
    setprop debug.composition.type default
}

apply_visual() {
    SAT="$1"; CONT="$2"; BRIGHT="$3"
    SAT_INT=$(awk "BEGIN{printf \"%d\", $SAT * 100}")
    setprop persist.vendor.display.miui.standard_mode 0
    setprop persist.vendor.display.miui.mode 1
    service call SurfaceFlinger 1023 i32 0 2>/dev/null
    service call SurfaceFlinger 1022 f "$SAT" 2>/dev/null
    setprop persist.sys.sf.native_mode 0
    setprop persist.sys.sf.color_saturation "$SAT"
    setprop persist.sys.sf.force_contrast "$CONT"
    setprop persist.sys.sf.force_brightness "$BRIGHT"
    setprop persist.sys.sf.color_mode 1
    setprop persist.sys.sf.enable_gl_composition 1
    setprop persist.vendor.display.miui.mms.saturation_ratio "$SAT_INT"
    setprop persist.vendor.display.miui.mms.saturation_ratio_enhancement 1
    setprop debug.sf.hw 1; setprop debug.egl.hw 1; setprop debug.egl.profiler 1
    setprop debug.composition.type gpu
    setprop debug.hwui.renderer skiagl
    setprop debug.hwui.overdraw false
    setprop debug.renderengine.backend skiaglthreaded
    setprop persist.sys.sf.sharpness 0.8 2>/dev/null
    [ -f /sys/class/graphics/fb0/sharpness ] && echo "8" > /sys/class/graphics/fb0/sharpness 2>/dev/null
    [ -f /sys/class/graphics/fb0/hdr_mode  ] && echo "1" > /sys/class/graphics/fb0/hdr_mode  2>/dev/null
    sleep 1
    service call SurfaceFlinger 1023 i32 0 2>/dev/null
    service call SurfaceFlinger 1022 f "$SAT" 2>/dev/null
}

run_profile() {
    P=$(cat "$CONFIG" 2>/dev/null | tr -d '\n\r\t ' | tr '[:lower:]' '[:upper:]')
    [ -z "$P" ] && P="FUERTE"
    case "$P" in
        ULTRASUAVE) apply_visual "1.05" "1.02" "0.98"; write_log "$P" "1.05" "1.02" "0.98" ;;
        SUAVE)      apply_visual "1.15" "1.05" "0.95"; write_log "$P" "1.15" "1.05" "0.95" ;;
        MEDIO)      apply_visual "1.45" "1.12" "1.0" ; write_log "$P" "1.45" "1.12" "1.0"  ;;
        FUERTE)     apply_visual "1.8"  "1.2"  "1.0" ; write_log "$P" "1.8"  "1.2"  "1.0"  ;;
        CUSTOM)
            S=$(cat "$CSAT"    2>/dev/null || echo "1.6")
            C=$(cat "$CCONT"   2>/dev/null || echo "1.15")
            B=$(cat "$CBRIGHT" 2>/dev/null || echo "1.0")
            apply_visual "$S" "$C" "$B"; write_log "CUSTOM" "$S" "$C" "$B" ;;
        SISTEMA)    apply_sistema; write_log "$P" "1.0" "1.0" "1.0" ;;
        *)          apply_visual "1.8" "1.2" "1.0"; write_log "FUERTE" "1.8" "1.2" "1.0" ;;
    esac
}

run_profile

COUNTER=0
while true; do
    sleep 2; COUNTER=$((COUNTER+1))
    if [ -f "$TRIGGER" ]; then
        rm -f "$TRIGGER"
        run_profile
        COUNTER=0
    fi
    [ "$COUNTER" -ge 150 ] && run_profile && COUNTER=0
done
