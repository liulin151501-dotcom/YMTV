#!/system/bin/sh
exec>/dev/null 2>&1
MODDIR="${0%/*}"
alias cmd=/system/bin/cmd
device="$(getprop ro.product.manufacturer | tr '[:upper:]' '[:lower:]')"
cmd package list packages --user 0|grep -Eo "$(cat $MODDIR/other/perflist.txt)">/data/local/tmp/.txt
for a in 1 2 4 8 10 20 40 80 100 200 400 800 1000 2000 4000 8000;do taskset -ap "$a" $$;done
iorenice "$$" 7 idle
renice -n 19 -p "$$"

kntl() {
    local msg="$*"
    cmd notification post -t SACRED \
      -i file:///storage/emulated/0/Android/media/.icon.jpg \
      -I file:///storage/emulated/0/Android/media/.icon.jpg \
      SACRED "$msg" || true
}

while true;do

  
  top_app="$(cmd activity stack list|grep -m1 0,0.*=true|awk -F'[/{]' '{print$3}')"

   
  if [ "$current_app" != "$top_app" ];then current_app="$top_app"

    
    if grep -Fqm1 "$top_app" /data/local/tmp/.txt;then

      
      if [ "$current_mode" != "performance" ];then current_mode="performance"
        for background in $(cmd package list packages --user 0|cut -f2 -d:);do cmd activity kill --user 0 "$background"&done
        cmd thermalservice override-status 0
        sh "$MODDIR/other/option.sh" performance
        
        if echo "$device" | grep -qEi 'xiaomi|redmi|poco'; then
          cmd settings put system light_speed_app "$top_app"
        fi
        
        cmd display set-match-content-frame-rate-pref 2
        logcat -G 8m
        kntl performance
      fi
    else
      if [ "$current_mode" != "powersave" ];then current_mode="powersave"
        cmd activity compact system;cmd activity force-stop com.android.shell
        cmd thermalservice override-status 1
        sh "$MODDIR/other/option.sh" powersave
        if echo "$device" | grep -qEi 'xiaomi|redmi|poco'; then
          cmd settings delete system light_speed_app
        fi
        cmd display set-match-content-frame-rate-pref 1
        logcat -G 64k
        kntl powersave
      fi
      

    fi
    
  fi
  

  
  [ "$current_mode" = "performance" ]&&sleep 30&&continue||sleep 10
  

  
  current_minute="$(date +%M)"
  if [ "$current_minute" != "$minute" ];then minute="$current_minute"
    
    # 强制深度睡眠
    PROP="debug.sacred"
    CUR_STATE="$(cmd deviceidle get screen | awk '{print $NF}')"
    OLD_STATE="$(getprop $PROP)"

    if [ "$CUR_STATE" != "$OLD_STATE" ]; then
      setprop $PROP "$CUR_STATE"

       if [ "$CUR_STATE" = "true" ]; then
          cmd deviceidle enable
          cmd deviceidle unforce
       elif [ "$CUR_STATE" = "false" ]; then
          cmd deviceidle enable
          cmd deviceidle force-idle deep
       fi
    fi
    
    
    
    logcat -P "$(ps -eo %CPU,PID|grep -Ev '%|0.0'|cut -f2 -d.|tr -s ' '|cut -f2 -d' '|sed 's/^/~/g')"
    logcat --wrap
    pkill -f dumpsys logcat
    

    
    ps -eo PID,USER|awk '/u0_/{print$1}'|while read process_id;do
      cmd activity app-logging "$process_id" 0 disable-text
      cmd activity profile stop "$process_id"
      cmd activity set-watch-heap "$process_id" 0
    done

  fi
  
done
