#!/system/bin/sh
rm -rf /data/local/tmp/.txt
rm -rf /storage/emulated/0/Android/media/.icon.jpg
rm -rf /data/data/com.android.shell/AxManager/plugins/kresek