#!/system/bin/sh
#thermal
(
settings put system oplus_settings_hightemp_protect 0
settings put global show_temperature_warning 0
settings put system oplus_settings_hightemp_safety_state 0
setprop debug.gpu.thermal.temp 150
settings put system battery.temp_high 90
settings put global vendor.dfps.enable false
settings put global vendor.smart_dfps.enable false
settings put system virtual_thermal_thermal_zone false 
settings put global thermal_throttling 0
settings put global thermal_pwrlevel 0
) > /dev/null 2>&1

(
# render
setprop debug.choreographer.frametime false
setprop debug.cpurend.vsync true
setprop debug.display.render_frame_rate_is_physical_refresh_rate true
# cpu & gpu
setprop debug.kill_allocating_task 0
# thermal
settings put global persist.sys.smartpower.display_thermal_temp_threshold 70
settings put global ro.vendor.display.hwc_thermal_dimming true
settings put global ro.vendor.fps.switch.thermal true
# thermal
settings put global ro.vendor.thermal.dimming.enable true
settings put global ro.thermal.iec.enable true
settings put global ro.vendor.mi_sf.pq_thermal true
) > /dev/null 2>&1

(
#thermal
setprop debug.init.svc.thermald stopped
setprop debug.init.svc_debug_pid.vendor.thermal-hal-2-0.mtk stopped
setprop debug.init.svc.thermal_manager stopped
setprop debug.init.svc.thermal_mnt_hal_service stopped
setprop debug.init.svc.thermal-engine stopped
setprop debug.init.svc.vendor.thermal-hal-2-0.mtk stopped
setprop debug.init.svc.thermal_core stopped
setprop debug.ro.boottime.thermal_core stopped
setprop debug.ro.boottime.vendor.thermal-hal-2-0.mtk stopped
setprop debug.ro.vendor.mtk_thermal_2_0 stopped
setprop debug.ro.boottime.thermal_core stopped
setprop debug.ro.boottime.thermald stopped
setprop debug.ro.boottime.vendor.thermal-hal-2-0.mtk stopped
setprop debug.ro.vendor.mtk_thermal_2_0 stopped
) > /dev/null 2>&1

(   
#thermal
settings put system bench_mark_mode 1
cmd thermalservice override-status 0
setprop debug.thermal_status 0
setprop debug.performance.tuning 1
setprop debug.thermal.cpu_thermal_throttle.disable 1
setprop debug.thermal.ambient_sensor.disable 0
setprop debug.cooling_name_thermal-devfreq 0
setprop debug.pid.sec-thermal-1-0 stopped
setprop debug.thermal_zone.display_hotplug_control 2
setprop debug.thermal_zone.battery_hotplug_control 2
setprop debug.mediatek.appgamepq_compress 1
setprop debug.mediatek.disp_decompress 1
setprop debug.mtk_tflite.target_nnapi 29
setprop debug.thermal_zone.gpu_threshold_temp 95
setprop debug.thermal_zone.cpu_threshold_temp 90
setprop debug.thermal_zone.display_threshold_temp 80
setprop debug.thermal_zone.camera_hotplug_control 2
setprop debug.thermal_zone.battery_threshold_temp 60
setprop debug.thermal_zone.camera_threshold_temp 85
setprop debug.thermal_zone.cpu_hotplug_control 2
setprop debug.thermal_zone.gpu_hotplug_control 2
setprop debug.power.throttling.disable 1
setprop debug.thermal.gpu_shader_clock_throttle.disable 1
setprop debug.thermal.gpu_core_clock_throttle.disable 1
setprop debug.thermal.gpu_power_throttle.disable 1
setprop debug.thermal.gpu_thermal_throttle.disable 1
setprop debug.thermal.gpu_memory_throttle.disable 1
setprop debug.thermal.gpu_fan_control.disable 1
setprop debug.thermal.gpu_boost.disable 1
setprop debug.thermal.gpu_control.disable 1
setprop debug.thermal.gpu_throttle.disabled 1
setprop debug.thermal.backlight.disabled 1
setprop debug.thermal.boost.disabled 1
setprop debug.thermal.inactive_delay.disabled 1
setprop debug.thermal.throttling.disable 1
setprop debug.thermal.profile.disable 1
setprop debug.thermal.throttle_ratio.disable 1
setprop debug.thermal.turbo_ratio_limit.disable 1
setprop debug.thermal.cooling_device_state.disable 1
setprop debug.thermal.dynamic_scheduling.disable 1
setprop debug.thermal.critical_temp.disable 0
setprop debug.thermal.threshold.disable 1
setprop debug.thermal.overheat_protection.disable 1
setprop debug.thermal.alert.disable 1
setprop debug.thermal.fan.disable 0
setprop debug.thermal.shutdown.disable 1
setprop debug.thermal.balance_algorithm 0
setprop debug.thermal.performance_mode.disable 1
setprop debug.thermal.force_fan_on.disable 0
setprop debug.thermal.critical_trip_point.disable 1
setprop debug.thermal.auto_thermal_disable 1
setprop debug.thermal.zone.disabled 1
setprop debug.thermal.trip_point.disabled 1
setprop debug.thermal.suspend.disabled 0
setprop debug.thermal.thermal_policy.disable 1
setprop debug.thermal.fan_disable 1
setprop debug.thermal.cpu_thermal_throttle.disable 1
setprop debug.thermal.ambient_sensor.disable 0
) > /dev/null 2>&1

#getprop
    getprop | grep thermal

sleep 0.5
echo""
echo " "
sleep 0.5

echo "wait.."
THERMAL_CONFIGS=(
  "/system/vendor/etc/thermal-engine.conf"
  "/vendor/etc/thermal-engine.conf"
  "/system/etc/thermal-engine.conf"
)


#therm
settings put system POWER_PERFORMANCE_MODE_OPEN 1
settings put system POWER_BALANCED_MODE_OPEN 0
settings put system POWER_SAVE_MODE_OPEN 0

# spoof
cmd thermalservice override-status 0

for sensor in cpu0 gpu0 npu0 apu0 dsp0 tpu0 vpu0 isp0 spu0 dpu0 pim0 skin pmic0 ddr0 ufs0 modem0 battery; do
    cmd thermalservice inject-temperature CPU light $sensor 120.000
done

# therm
 disable_another_thermal() {
    thermal_prop=$(getprop | grep init.svc.*thermal* | cut -d: -f1 | sed 's/[][]//g')
 
  for thermal in $thermal_prop; do
    if [ "$(resetprop "$thermal")" = 'running' ] || [ "$(resetprop "$thermal")" = 'restarting' ]; then
      stop "$(echo "$thermal" | sed 's/init.svc.//')"
    fi
  done
  
  # waiting boot finished
while [ "$(getprop sys.boot_completed | tr -d '\r')" != "1" ]; do sleep 3; done

# score
write () {
    local file="$1"
    local value="$2"
    if [[ -z "$file" || -z "$value" || ! -f "$file" ]]; then
        return 1
    fi
    chmod +w "$file" 2>/dev/null
    echo "$value" > "$file" 2>/dev/null && echo "$file → $value" || return 1
    return 0
}

#gpu freq
for gpufreq in /proc/gpufreq; do
    if [ -d "$gpufreq" ]; then
        write $gpufreq/gpufreq_power_limited "0"
        write $gpufreq/gpufreq_limited_thermal_ignore "1"
    fi
done

# therm
for thermsvc in $(getprop | grep init.svc.*thermal* | cut -d: -f1 | sed 's/[][]//g'); do
    resetprop -n "$thermsvc" "stopped"
done

# thermal
for thermsys in $(getprop | grep sys.*thermal* | cut -d: -f1 | sed 's/[][]//g'); do
    resetprop -n "$thermsys" "0"
done

#therm
for thermmode in /sys/devices/virtual/thermal/thermal_zone*/mode; do
    write "$thermmode" "disabled"
done

# gpu throttling
for kgsl in /sys/class/kgsl/kgsl-3d0; do
    if [ -d "$kgsl" ]; then
        write $kgsl/throttling "0"
        write $kgsl/thermal_pwrlevel "0"
    fi
done

# thermal cache
rm -f /data/vendor/thermal/config
rm -f /data/vendor/thermal/thermal.dump
rm -f /data/vendor/thermal/thermal_history.dump

  
# temperature inject
  for THERMAL_ZONE in `ls /sys/class/thermal/thermal_zone*/type`; do
	 if cat $THERMAL_ZONE | grep -E "gpu|ddr" >/dev/null; then
		for TRIP_POINT_TEMP in `ls ${THERMAL_ZONE%/*}/trip_point_*_temp`; do
			if [ "$(cat $TRIP_POINT_TEMP)" -lt "$SET_TRIP_POINT_TEMP_MAX" ]; then
				echo "$SET_TRIP_POINT_TEMP_MAX" > $TRIP_POINT_TEMP
			fi
		done
	 fi
  done

# thermal
  find /sys -name enabled | grep 'msm_thermal' | while IFS= read -r msm_thermal_status; do
    if [ "$(cat "$msm_thermal_status")" = 'Y' ]; then
      echo 'N' > "$msm_thermal_status"
    fi
    if [ "$(cat "$msm_thermal_status")" = '1' ]; then
      echo '0' > "$msm_thermal_status"
    fi
  done

  for thermdevmode in /sys/devices/virtual/thermal/thermal_zone*/mode; do
    chmod -R 644 $thermdevmode
    echo "disabled" > $thermdevmode
  done

  for all_thermal in /sys/devices/virtual/thermal/thermal_zone*; do
    chmod -R 000 $all_thermal
  done

  for all_thermal in /sys/devices/virtual/hwmon/hwmon*; do
    chmod -R 000 $all_thermal
  done

  for all_thermal in /sys/firmware/devicetree/base/soc/qcom,limit_info*; do
    chmod -R 000 $all_thermal
  done
  
  for all_thermal in $(find /sys/firmware/devicetree/base/soc/qcom,msm-thermal/ -name *temp*); do
    chmod 000 $all_thermal
  done
  
  for all_thermal in /sys/firmware/devicetree/base/soc/qcom,msm-thermal/; do
    chmod 000 $all_thermal/name
  done
  
  for all_thermal in $(find /sys/devices/soc/*/kgsl/kgsl-3d0/ -name *temp*); do
    chmod 000 $all_thermal
  done

#thermal
  for sched in /proc/sys/kernel/sched_boost; do
    echo "0" > $sched
  done
  
# props
  if resetprop dalvik.vm.dexopt.thermal-cutoff | grep -q '2'; then
    resetprop -n dalvik.vm.dexopt.thermal-cutoff 0
  fi
  
  if resetprop sys.thermal.enable | grep -q 'true'; then
    resetprop -n sys.thermal.enable false
  fi
  
  if resetprop ro.thermal_warmreset | grep -q 'true'; then
    resetprop -n ro.thermal_warmreset false
  fi
  
#thermal
    cmd thermalservice override-status 0
  
# thermal cache
    rm -f /data/vendor/thermal/config
    rm -f /data/vendor/thermal/thermal.dump
    rm -f /data/vendor/thermal/thermal_history.dump

# log tweak
  disable_logs_debuggers () {
  for exception_trace in $(find /proc/sys/ -name exception-trace); do
    echo "0" > $exception_trace
  done

  for sched_schedstats in $(find /proc/sys/ -name sched_schedstats); do
    echo "0" > $sched_schedstats
  done

  for printk in $(find /proc/sys/ -name printk); do
    echo "0 0 0 0" > $printk
  done

  for printk_devkmsg in $(find /proc/sys/ -name printk_devkmsg); do
    echo "off" > $printk_devkmsg
  done

  for compat_log in $(find /proc/sys/ -name compat-log); do
    echo "0" > $compat_log
  done

  for tracing_on in $(find /proc/sys/ -name tracing_on); do
    echo "0" $tracing_on
  done

  for log_level in $(find /sys/ -name log_level*); do
    echo "0" > $log_level
  done

  for debug_mask in $(find /sys/ -name debug_mask); do
    echo "0" > $debug_mask
  done

  for debug_level in $(find /sys/ -name debug_level); do
    echo "0" > $debug_level
  done

  for log_ue in $(find /sys/ -name *log_ue*); do
    echo "0" > $log_ue
  done

  for log_ce in $(find /sys/ -name *log_ce*); do
    echo "0" > $log_ce
  done

  for edac_mc_log in $(find /sys/ -name edac_mc_log*); do
    echo "0" > $edac_mc_log
  done

  for enable_event_log in $(find /sys/ -name enable_event_log); do
    echo "0" > $enable_event_log
  done

  for log_ecn_error in $(find /sys/ -name log_ecn_error); do
    echo "0" > $log_ecn_error
  done

  for sec_log in $(find /sys/ -name sec_log*); do
    echo "0" > $sec_log
  done

  for snapshot_crashdumper in $(find /sys/ -name snapshot_crashdumper); do
    echo "0" > $snapshot_crashdumper
  done
 }

#config gpu thermal
(
cmd package bg-dexopt-job thermal cutoff
setprop pm.dexopt.disable_bg_dexopt true
cmd device_config put dalvik dexopt disable_bg_dexopt true
pm bg-dexopt-job-disable
cmd device_config put dalvik vm.dexopt thermal_cutoff 0
dumpsys device_config
cmd thermalservice override-status 0
cmd device_config put thermal high_temp_limit 150
cmd device_config put thermal low_temp_limit 150
cmd shortcut reset-throttling
cmd shortcut reset-all-throttling
dumpsys device_config
) >/dev/null 2>&1 &

# gpu thermal
setprop vendor.gpu.thermal.temp 150

# thermal
setprop persist.sys.battery.temp_high 90

# thermal
echo 0 > /sys/class/thermal/thermal_zone*/mode
sleep 1
# thermal
setprop init.svc.thermal stopped
setprop init.svc.thermal-managers stopped
setprop init.svc.thermal_manager stopped
setprop init.svc.thermal_mnt_hal_service stopped
setprop init.svc.thermal-stopped running
setprop init.svc.mi-thermald running 
setprop init.svc.thermalloadalgod stopped
setprop init.svc.thermalservice running
setprop init.svc.thermal-hal running 
setprop init.svc.vendor.thermal-symlinks stoped 
setprop init.svc.android.thermal-hal stopped
setprop init.svc.vendor.thermal-hal running
setprop init.svc.thermal-manager stopped
setprop init.svc.vendor-thermal-hal-1-0 stopped
setprop init.svc.vendor.thermal-hal-1-0 stopped
setprop init.svc.vendor.thermal-hal-2-0 stopped
setprop init.svc.android.thermal-hal stopped
setprop init.svc.thermel-enggine stopped
setprop init.svc.vendor.thermal-enggine stopped
sleep 1
# Thermal Stop Semi-auto Methode
sleep 12
stop logd
sleep 1
stop vendor.thermal-engine
sleep 1
stop vendor.thermal_manager
sleep 1
stop vendor.thermal-manager
sleep 1
stop vendor.thermal-hal-2-0
sleep 1
stop vendor.thermal-symlinks
sleep 1
stop thermal_mnt_hal_service
sleep 1
stop thermal
sleep 1
stop mi_thermald
sleep 1
stop thermald
sleep 1
stop thermalloadalgod
sleep 1
stop thermalservice
sleep 1
stop sec-thermal-1-0
sleep 1
stop debug_pid.sec-thermal-1-0
sleep 1
stop thermal-engine
sleep 1
stop vendor.thermal-hal-1-0
sleep 1
stop android.thermal-hal
sleep 1
stop vendor-thermal-1-0
sleep 1
stop thermal-hal
sleep 1
stop android.thermal-hal

#thermal
echo 0 > /proc/sys/kernel/sched_boost

# thermal throttling
echo 0 > /sys/class/kgsl/kgsl-3d0/max_gpuclk
echo 1 > /sys/class/kgsl/kgsl-3d0/force_clk_on
echo 0 > /sys/class/kgsl/kgsl-3d0/throttling

#thermal conf
rm -f /data/vendor/thermal/config
rm -f /data/vendor/thermal/thermal.dump
rm -f /data/vendor/thermal/thermal_history.dump

#i/o priority
for queue in /sys/block/*/queue; do
    echo "0" > "$queue/iostats"
done

THERMAL_CONFIGS=(
  "/system/vendor/etc/thermal-engine.conf"
  "/vendor/etc/thermal-engine.conf"
  "/system/etc/thermal-engine.conf"
)

# ui tuning
settings put system POWER_PERFORMANCE_MODE_OPEN 1
settings put system POWER_BALANCED_MODE_OPEN 0
settings put system POWER_SAVE_MODE_OPEN 0

# thermspoof
cmd thermalservice override-status 0

for sensor in cpu0 gpu0 npu0 apu0 dsp0 tpu0 vpu0 isp0 spu0 dpu0 pim0 skin pmic0 ddr0 ufs0 modem0 battery; do
    cmd thermalservice inject-temperature CPU light $sensor 120.000
done

# therm
 disable_another_thermal() {
    thermal_prop=$(getprop | grep init.svc.*thermal* | cut -d: -f1 | sed 's/[][]//g')
 
  for thermal in $thermal_prop; do
    if [ "$(resetprop "$thermal")" = 'running' ] || [ "$(resetprop "$thermal")" = 'restarting' ]; then
      stop "$(echo "$thermal" | sed 's/init.svc.//')"
    fi
  done
  
  # wait to finsh booting
while [ "$(getprop sys.boot_completed | tr -d '\r')" != "1" ]; do sleep 3; done

# score
write () {
    local file="$1"
    local value="$2"
    if [[ -z "$file" || -z "$value" || ! -f "$file" ]]; then
        return 1
    fi
    chmod +w "$file" 2>/dev/null
    echo "$value" > "$file" 2>/dev/null && echo "$file → $value" || return 1
    return 0
}

# gpufreqconf
for gpufreq in /proc/gpufreq; do
    if [ -d "$gpufreq" ]; then
        write $gpufreq/gpufreq_power_limited "0"
        write $gpufreq/gpufreq_limited_thermal_ignore "1"
    fi
done

# therm
for thermsvc in $(getprop | grep init.svc.*thermal* | cut -d: -f1 | sed 's/[][]//g'); do
    resetprop -n "$thermsvc" "stopped"
done

# therm
for thermsys in $(getprop | grep sys.*thermal* | cut -d: -f1 | sed 's/[][]//g'); do
    resetprop -n "$thermsys" "0"
done

# therm
for thermmode in /sys/devices/virtual/thermal/thermal_zone*/mode; do
    write "$thermmode" "disabled"
done

# gpu throttling tweal
for kgsl in /sys/class/kgsl/kgsl-3d0; do
    if [ -d "$kgsl" ]; then
        write $kgsl/throttling "0"
        write $kgsl/thermal_pwrlevel "0"
    fi
done

# therm cache clear
rm -f /data/vendor/thermal/config
rm -f /data/vendor/thermal/thermal.dump
rm -f /data/vendor/thermal/thermal_history.dump

  
# temperature tweak
  for THERMAL_ZONE in `ls /sys/class/thermal/thermal_zone*/type`; do
	 if cat $THERMAL_ZONE | grep -E "gpu|ddr" >/dev/null; then
		for TRIP_POINT_TEMP in `ls ${THERMAL_ZONE%/*}/trip_point_*_temp`; do
			if [ "$(cat $TRIP_POINT_TEMP)" -lt "$SET_TRIP_POINT_TEMP_MAX" ]; then
				echo "$SET_TRIP_POINT_TEMP_MAX" > $TRIP_POINT_TEMP
			fi
		done
	 fi
  done

# therm
  find /sys -name enabled | grep 'msm_thermal' | while IFS= read -r msm_thermal_status; do
    if [ "$(cat "$msm_thermal_status")" = 'Y' ]; then
      echo 'N' > "$msm_thermal_status"
    fi
    if [ "$(cat "$msm_thermal_status")" = '1' ]; then
      echo '0' > "$msm_thermal_status"
    fi
  done

  for thermdevmode in /sys/devices/virtual/thermal/thermal_zone*/mode; do
    chmod -R 644 $thermdevmode
    echo "disabled" > $thermdevmode
  done

  for all_thermal in /sys/devices/virtual/thermal/thermal_zone*; do
    chmod -R 000 $all_thermal
  done

  for all_thermal in /sys/devices/virtual/hwmon/hwmon*; do
    chmod -R 000 $all_thermal
  done

  for all_thermal in /sys/firmware/devicetree/base/soc/qcom,limit_info*; do
    chmod -R 000 $all_thermal
  done
  
  for all_thermal in $(find /sys/firmware/devicetree/base/soc/qcom,msm-thermal/ -name *temp*); do
    chmod 000 $all_thermal
  done
  
  for all_thermal in /sys/firmware/devicetree/base/soc/qcom,msm-thermal/; do
    chmod 000 $all_thermal/name
  done
  
  for all_thermal in $(find /sys/devices/soc/*/kgsl/kgsl-3d0/ -name *temp*); do
    chmod 000 $all_thermal
  done

# therm
  for sched in /proc/sys/kernel/sched_boost; do
    echo "0" > $sched
  done
  
# therm props
  if resetprop dalvik.vm.dexopt.thermal-cutoff | grep -q '2'; then
    resetprop -n dalvik.vm.dexopt.thermal-cutoff 0
  fi
  
  if resetprop sys.thermal.enable | grep -q 'true'; then
    resetprop -n sys.thermal.enable false
  fi
  
  if resetprop ro.thermal_warmreset | grep -q 'true'; then
    resetprop -n ro.thermal_warmreset false
  fi
  
# therm
    cmd thermalservice override-status 0
  
# thermal cache removed
    rm -f /data/vendor/thermal/config
    rm -f /data/vendor/thermal/thermal.dump
    rm -f /data/vendor/thermal/thermal_history.dump

# logcat disable
  disable_logs_debuggers () {
  for exception_trace in $(find /proc/sys/ -name exception-trace); do
    echo "0" > $exception_trace
  done

  for sched_schedstats in $(find /proc/sys/ -name sched_schedstats); do
    echo "0" > $sched_schedstats
  done

  for printk in $(find /proc/sys/ -name printk); do
    echo "0 0 0 0" > $printk
  done

  for printk_devkmsg in $(find /proc/sys/ -name printk_devkmsg); do
    echo "off" > $printk_devkmsg
  done

  for compat_log in $(find /proc/sys/ -name compat-log); do
    echo "0" > $compat_log
  done

  for tracing_on in $(find /proc/sys/ -name tracing_on); do
    echo "0" $tracing_on
  done

  for log_level in $(find /sys/ -name log_level*); do
    echo "0" > $log_level
  done

  for debug_mask in $(find /sys/ -name debug_mask); do
    echo "0" > $debug_mask
  done

  for debug_level in $(find /sys/ -name debug_level); do
    echo "0" > $debug_level
  done

  for log_ue in $(find /sys/ -name *log_ue*); do
    echo "0" > $log_ue
  done

  for log_ce in $(find /sys/ -name *log_ce*); do
    echo "0" > $log_ce
  done

  for edac_mc_log in $(find /sys/ -name edac_mc_log*); do
    echo "0" > $edac_mc_log
  done

  for enable_event_log in $(find /sys/ -name enable_event_log); do
    echo "0" > $enable_event_log
  done

  for log_ecn_error in $(find /sys/ -name log_ecn_error); do
    echo "0" > $log_ecn_error
  done

  for sec_log in $(find /sys/ -name sec_log*); do
    echo "0" > $sec_log
  done

  for snapshot_crashdumper in $(find /sys/ -name snapshot_crashdumper); do
    echo "0" > $snapshot_crashdumper
  done
 }

#thermconf
(
cmd package bg-dexopt-job thermal cutoff
setprop pm.dexopt.disable_bg_dexopt true
cmd device_config put dalvik dexopt disable_bg_dexopt true
pm bg-dexopt-job-disable
cmd device_config put dalvik vm.dexopt thermal_cutoff 0
dumpsys device_config
cmd thermalservice override-status 0
cmd device_config put thermal high_temp_limit 150
cmd device_config put thermal low_temp_limit 150
cmd shortcut reset-throttling
cmd shortcut reset-all-throttling
dumpsys device_config
) >/dev/null 2>&1 &

# gpu throttling tweak
setprop vendor.gpu.thermal.temp 150

# battery tweak
setprop persist.sys.battery.temp_high 90

# therm
echo 0 > /sys/class/thermal/thermal_zone*/mode
sleep 1
#therm props
setprop init.svc.thermal stopped
setprop init.svc.thermal-managers stopped
setprop init.svc.thermal_manager stopped
setprop init.svc.thermal_mnt_hal_service stopped
setprop init.svc.thermal-stopped running
setprop init.svc.mi-thermald running 
setprop init.svc.thermalloadalgod stopped
setprop init.svc.thermalservice running
setprop init.svc.thermal-hal running 
setprop init.svc.vendor.thermal-symlinks stoped 
setprop init.svc.android.thermal-hal stopped
setprop init.svc.vendor.thermal-hal running
setprop init.svc.thermal-manager stopped
setprop init.svc.vendor-thermal-hal-1-0 stopped
setprop init.svc.vendor.thermal-hal-1-0 stopped
setprop init.svc.vendor.thermal-hal-2-0 stopped
setprop init.svc.android.thermal-hal stopped
setprop init.svc.thermel-enggine stopped
setprop init.svc.vendor.thermal-enggine stopped
sleep 1
# therm
sleep 12
stop logd
sleep 1
stop vendor.thermal-engine
sleep 1
stop vendor.thermal_manager
sleep 1
stop vendor.thermal-manager
sleep 1
stop vendor.thermal-hal-2-0
sleep 1
stop vendor.thermal-symlinks
sleep 1
stop thermal_mnt_hal_service
sleep 1
stop thermal
sleep 1
stop mi_thermald
sleep 1
stop thermald
sleep 1
stop thermalloadalgod
sleep 1
stop thermalservice
sleep 1
stop sec-thermal-1-0
sleep 1
stop debug_pid.sec-thermal-1-0
sleep 1
stop thermal-engine
sleep 1
stop vendor.thermal-hal-1-0
sleep 1
stop android.thermal-hal
sleep 1
stop vendor-thermal-1-0
sleep 1
stop thermal-hal
sleep 1
stop android.thermal-hal

# therm
echo 0 > /proc/sys/kernel/sched_boost

# thottling tweak
echo 0 > /sys/class/kgsl/kgsl-3d0/max_gpuclk
echo 1 > /sys/class/kgsl/kgsl-3d0/force_clk_on
echo 0 > /sys/class/kgsl/kgsl-3d0/throttling

#therm cache
rm -f /data/vendor/thermal/config
rm -f /data/vendor/thermal/thermal.dump
rm -f /data/vendor/thermal/thermal_history.dump

#i/o priority
for queue in /sys/block/*/queue; do
    echo "0" > "$queue/iostats"
done

exit
sync && echo "温控调整" && exit 0