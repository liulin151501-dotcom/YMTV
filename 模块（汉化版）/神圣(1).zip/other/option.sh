#!/system/bin/sh
exec >/dev/null 2>&1

hz="$(dumpsys display | grep -Eo 'fps=[^.]+' | cut -f2 -d= | sort -n | uniq | tail -n1)"

apply_refresh() {
    target="$1"

    for scope in system global secure; do
        settings list "$scope" | grep -i "refresh" | while IFS='=' read -r key val; do
            if echo "$val" | grep -Eq '^(60|90|120|144)(\.0)?$'; then
                cmd settings put "$scope" "$key" "$target"
            fi
        done
    done
}

case "$1" in
    performance)
        apply_refresh "$hz"
    ;;
    powersave)
        apply_refresh "60"
    ;;
esac
