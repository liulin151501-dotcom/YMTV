#!/system/bin/sh
echo "bulukuduk"
(# main action
cp "$MODPATH/other/icon.jpg" /storage/emulated/0/Android/media/.icon.jpg
MODDIR="$(echo $MODPATH|sed 's/_update//')"
[ $AXERON ]&&sed -i 's|su -c ||g' $MODPATH/webroot/index.html
printf "$(grep -v axeronPlugin $MODPATH/module.prop)">$MODPATH/module.prop
sed -i "s|DIRNAME|$MODDIR|g" $MODPATH/action.sh
sed -i "s|DIRNAME|$MODDIR|g" $MODPATH/webroot/index.html
chmod -R 777 $MODPATH
)>/dev/null 2>&1