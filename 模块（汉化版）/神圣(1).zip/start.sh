#!/system/bin/sh

BH="/data/data/com.android.shell/AxManager/plugins/kresek"
TMP="/data/local/tmp"
LOG="$BH/dinamik.log"
SERVICE="$TMP/dinamikservice"
TOAST_APP="bellavita.toast/.MainActivity"
TOAST_TMP="$TMP/Toast.apk"
OPT="$BH/opt.sh"

log_only() {
    local MSG="$1"
    local TS
    TS="$(date '+%F %T' 2>/dev/null || /system/bin/date '+%F %T')"
    echo "$TS $MSG" >> "$LOG"
}

notify_log() {
    local MSG="$1"
    log_only "$MSG"
    am start -a android.intent.action.MAIN \
        -e toasttext "$MSG" \
        -n "$TOAST_APP" >/dev/null 2>&1
    sleep 1
}

if [ -f "$BH/Toast.apk" ]; then
    if cp -p "$BH/Toast.apk" "$TOAST_TMP"; then
        if pm install -r "$TOAST_TMP" >/dev/null 2>&1; then
            log_only "Toast.apk 安装成功"
        else
            log_only "Toast.apk 已复制但安装失败"
        fi
    else
        log_only "复制 Toast.apk 到 $TMP 失败"
    fi
else
    log_only "在 $BH 中未找到 Toast.apk"
fi

copy_bh() {
    for f in "$SERVICE" "$TMP/opt.sh"; do
        if [ -f "$f" ]; then
            if rm -f "$f"; then
                notify_log "$(basename "$f") 已移除"
            else
                log_only "移除 $(basename "$f") 失败"
            fi
        fi
    done

    if [ -f "$OPT" ]; then
        if cp -p "$OPT" "$TMP/" && chmod 0755 "$TMP/opt.sh"; then
            log_only "opt.sh 已复制并设置权限"
        else
            log_only "复制/设置 opt.sh 权限失败"
        fi
    else
        log_only "在 $BH 中未找到 opt.sh"
    fi

    if [ -f "$BH/batteryhoney_service" ]; then
        if cp -p "$BH/batteryhoney_service" "$TMP/" && chmod 0755 "$SERVICE"; then
            log_only "服务已复制并设置权限"
        else
            log_only "复制/设置 batteryhoney_service 权限失败"
        fi
    else
        log_only "在 $BH 中未找到 batteryhoney_service"
    fi
}

log_only "内存清理完成"

copy_bh

if [ -x "$TMP/opt.sh" ]; then
    "$TMP/opt.sh"
    log_only "优化已应用"
else
    log_only "优化已跳过（opt.sh 缺失或不可执行）"
fi

if pm grant com.android.shell android.permission.WRITE_SECURE_SETTINGS >/dev/null 2>&1; then
    log_only "pm grant 成功"
else
    log_only "pm grant 失败（非 Root 或权限被拒绝）"
fi

if pkill -f batteryhoney_service >/dev/null 2>&1; then
    notify_log "旧服务进程已终止"
else
    log_only "没有旧服务正在运行"
fi
