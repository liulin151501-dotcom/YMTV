How To Install:
1.通过 AxM 安装插件
2.运行 webui
3.享受插件
How to Uninstall:
1.从 AxM 卸载插件
2.重启手机
● 免责声明
• 行了，懒得写，去买曲子吧