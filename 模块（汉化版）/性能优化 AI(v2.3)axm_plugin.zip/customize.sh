#!/system/bin/sh

# 1.1 Magisk 检测逻辑
detect_magisk_path() {
    if [ -n "$MAGISKTMP" ] && [ -d "$MAGISKTMP" ]; then
        echo "$MAGISKTMP"
    else
        echo "/data/adb"
    fi
}

# 1.2 KernelSU 检测逻辑
detect_kernelsu_path() {
    if [ -d "/data/adb/ksu" ]; then
        echo "/data/adb/ksu"
    else
        if command -v ksud >/dev/null 2>&1; then
            dirname "$(command -v ksud)"
        fi
    fi
}

# 1.3 APatch 检测逻辑
detect_apatch_path() {
    if [ -d "/data/adb/ap" ]; then
        echo "/data/adb/ap"
    elif [ -f "/data/adb/ap/bin/busybox" ]; then
        echo "/data/adb/ap"
    elif [ "$APATCH" = "true" ] && [ -d "/data/adb/apd" ]; then
        echo "/data/adb/apd"
    fi
}

# 1.4 AX Manager 检测逻辑
detect_axmanager_path() {
    if [ -n "$AXERONDIR" ] && [ -d "$AXERONDIR" ]; then
        echo "$AXERONDIR"
    else
        echo "/data/user_de/0/com.android.shell/axeron"
    fi
}

check(){
    conflicting_folders="stellar shell_ascend shell_ai cmd_tweaks"

    conflict_found="false"
    error_message=""

    ALL_PATHS=""

    # --- 检测并添加 Magisk 路径 ---
    magisk_base=$(detect_magisk_path)
    if [ -n "$magisk_base" ]; then
        ALL_PATHS="$ALL_PATHS $magisk_base"
        [ -d "/data/adb/modules" ] && ALL_PATHS="$ALL_PATHS /data/adb/modules"
    fi

    # --- 检测并添加 KernelSU 路径 ---
    kernelsu_base=$(detect_kernelsu_path)
    if [ -n "$kernelsu_base" ]; then
        ALL_PATHS="$ALL_PATHS $kernelsu_base"
        [ -d "/data/adb/ksu/modules" ] && ALL_PATHS="$ALL_PATHS /data/adb/ksu/modules"
    fi

    # --- 检测并添加 APatch 路径 ---
    apatch_base=$(detect_apatch_path)
    if [ -n "$apatch_base" ]; then
        ALL_PATHS="$ALL_PATHS $apatch_base"
        [ -d "/data/adb/ap/modules" ] && ALL_PATHS="$ALL_PATHS /data/adb/ap/modules"
    fi

    # --- 检测并添加 AX Manager 路径 ---
    axmanager_base=$(detect_axmanager_path)
    if [ -n "$axmanager_base" ]; then
        axmanager_path="${axmanager_base}/plugins"
        if [ -d "$axmanager_path" ]; then
            ALL_PATHS="$ALL_PATHS $axmanager_path"
        fi
        [ -d "/data/user_de/0/com.android.shell/axeron/plugins" ] && \
            ALL_PATHS="$ALL_PATHS /data/user_de/0/com.android.shell/axeron/plugins"
    fi
    
    for path in $ALL_PATHS; do
        if [ -d "$path" ]; then
            for folder in $conflicting_folders; do
                conflict_dir="$path/$folder"
                if [ -d "$conflict_dir" ]; then
                    conflict_found="true"
                    error_message="$error_message $folder"
                fi
            done
        fi
    done

    if [ "$conflict_found" = "true" ]; then
        echo "无法与以下内容同时使用：$error_message"
        exit 1
    else
        return 0
    fi
}

info() {
    echo "  ____            __    _      _ "
    echo " |  _ \  ___ _ __/ _|  / \    (_)"
    echo " | |_) |/ _ \ '__| |_  / _ \   | |"
    echo " |  __/|  __/ |  |  _|/ ___ \  | |"
    echo " |_|    \___|_|  |_| /_/   \_\ |_|"
    echo
    echo "   Perf-Ai 需要通过 webui 进行配置"
    echo "   点击插件菜单或模块菜单中的 webui 图标即可配置"
    echo
}

send_notification() {
    cmd notification post -S bigtext -t 'Perf AI' 'tag' '正在移动 API 文件，已完成' >/dev/null 2>&1
}

unzip_performance_ai() {
    target_zip="$MODPATH/performance-ai.zip"
    if [ -f "$target_zip" ]; then
        unzip -o "$target_zip" -d "/storage/emulated/0/"
    fi
}

check
unzip_performance_ai
info
send_notification
return 0
