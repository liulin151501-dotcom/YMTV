#!/system/bin/sh
LOG_FILE="/storage/emulated/0/performance-ai/log/refresh.log"

CURRENT_PROCESSOR=$(getprop ro.product.board)
CURRENT_ANDROID=$(getprop ro.build.version.release)
CURRENT_KERNEL=$(uname -r)

LOG_PROCESSOR=$(awk -F': ' '/: Processor/{print $NF}' "$LOG_FILE" | head -1 | tr -d ' ')
LOG_ANDROID=$(awk -F': ' '/: Android Version/{print $NF}' "$LOG_FILE" | head -1 | tr -d ' ')
LOG_KERNEL=$(awk -F': ' '/Kernel Version/{print $NF}' "$LOG_FILE" | head -1 | tr -d ' ')
if [ "$CURRENT_PROCESSOR" != "$LOG_PROCESSOR" ] || [ "$CURRENT_ANDROID" != "$LOG_ANDROID" ] || [ "$CURRENT_KERNEL" != "$LOG_KERNEL" ]; then
    exit 0
fi

if pgrep -f "perf_service_@api" > /dev/null; then
    exit 0
else
    sh /storage/emulated/0/performance-ai/start.sh --install > /dev/null 2>&1 &
    cmd notification post -S bigtext -i "file:///storage/emulated/0/performance-ai/img/banner.png" -t '[性能 AI 状态]' 'PerfAI_Tag' '已部署自动启动' > /dev/null 2>&1 || su -lp 2000 -c "cmd notification post -S bigtext -i "file:///storage/emulated/0/performance-ai/img/banner.png" -t '[性能 AI 状态]' 'PerfAI_Tag' '已部署自动启动' > /dev/null 2>&1"
fi
exit 0
