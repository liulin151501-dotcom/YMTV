#!/system/bin/sh
# core_power.sh - safe hardware writer for target watt/current
# Usage: core_power.sh <target_watt_integer>
# Example: core_power.sh 45

MODDIR=${0%/*}
LOG="$MODDIR/logs/core_power.log"
CONFIG="$MODDIR/config.json"
COMMON="$MODDIR/common"

mkdir -p "$(dirname "$LOG")"
touch "$LOG"

log() {
  echo "$(date '+%Y-%m-%d %H:%M:%S') - $*" >> "$LOG"
}

# default config values (can be changed in config.json)
MIN_W=18
MAX_W=120
TEMP_WARN=40   # deg C
TEMP_CRIT=50   # deg C
SAFE_MODE="true"

# load config.json (very small parser)
if [ -f "$CONFIG" ]; then
  MIN_W=$(grep -oE '"min_w"[[:space:]]*:[[:space:]]*[0-9]+' "$CONFIG" | grep -oE '[0-9]+' || echo $MIN_W)
  MAX_W=$(grep -oE '"max_w"[[:space:]]*:[[:space:]]*[0-9]+' "$CONFIG" | grep -oE '[0-9]+' || echo $MAX_W)
  TEMP_WARN=$(grep -oE '"temp_warn"[[:space:]]*:[[:space:]]*[0-9]+' "$CONFIG" | grep -oE '[0-9]+' || echo $TEMP_WARN)
  TEMP_CRIT=$(grep -oE '"temp_crit"[[:space:]]*:[[:space:]]*[0-9]+' "$CONFIG" | grep -oE '[0-9]+' || echo $TEMP_CRIT)
  SAFE_MODE=$(grep -oE '"safe_mode"[[:space:]]*:[[:space:]]*(true|false)' "$CONFIG" | grep -oE '(true|false)' || echo $SAFE_MODE)
fi

# Candidate sysfs nodes to try writing current / watt values to.
# This list covers common vendor names — may be extended if you know device-specific nodes.
CANDIDATE_CURRENT_NODES="
/sys/class/power_supply/battery/constant_charge_current_max
/sys/class/power_supply/battery/charge_control_limit
/sys/class/power_supply/battery/charging_current
/sys/class/power_supply/charger/charging_current
/sys/class/power_supply/usb/charger_current
/sys/class/power_supply/bms/target_watt
/sys/class/power_supply/bms/charging_enabled
/sys/class/power_supply/battery/current_max
/sys/class/power_supply/battery/input_current_limit
/sys/module/qpnp_charger/parameters/charging_current
/sys/kernel/charging_control/target_watt
/sys/kernel/charge_control/target_watt
/sys/kernel/fastchg/current_max
"

# We'll produce both microamp and milliamp writes depending on file content/units.
# safe_write will attempt a write and return 0 on success
safe_write() {
  node="$1"
  value="$2"
  if [ -z "$node" ] || [ -z "$value" ]; then
    log "safe_write: invalid args"
    return 2
  fi
  if [ ! -e "$node" ]; then
    log "safe_write: node not found $node"
    return 3
  fi
  # check writability
  if [ ! -w "$node" ]; then
    log "safe_write: node not writable $node"
    return 4
  fi
  echo "$value" > "$node" 2>>"$LOG" && return 0 || return 5
}

# find first writable node from the list
detect_current_node() {
  for n in $CANDIDATE_CURRENT_NODES; do
    if [ -e "$n" ]; then
      # test write permission
      if [ -w "$n" ]; then
        echo "$n" && return 0
      fi
      # Some nodes are writable via root-only but test by writing the same value (read/restore)
      # try to read to determine unit
      echo "$n (exists but not writable)"
    fi
  done
  # also look for any file with 'input_current' or 'current_max' in /sys/class/power_supply
  for p in /sys/class/power_supply/*; do
    for f in current_max input_current_limit charging_current constant_charge_current_max; do
      node="$p/$f"
      if [ -e "$node" ] && [ -w "$node" ]; then
        echo "$node" && return 0
      fi
    done
  done
  # nothing found
  echo ""
  return 1
}

# compute microamp needed from watt and voltage in sysfs units
# arguments: watt (W), voltage_uV (int)
compute_current_uA() {
  watt="$1"
  voltage_uV="$2"
  # current_A = watt / voltage_V
  # current_uA = current_A * 1e6 = watt * 1e6 / voltage_uV
  # use awk for safe float math
  cur_uA=$(awk -v w="$watt" -v v="$voltage_uV" 'BEGIN{
    if(v <= 0) { print 0; exit }
    printf("%d", (w * 1000000.0) / v)
  }')
  echo "$cur_uA"
}

# tries to write target current/watt to device nodes; returns 0 on any success
apply_target_watt() {
  target_w="$1"
  log "apply_target_watt: requested ${target_w}W"

  # read battery voltage in microvolts if available
  volt_uV=0
  # try common voltage node
  for p in /sys/class/power_supply/*; do
    if [ -f "$p/voltage_now" ]; then
      volt_uV=$(cat "$p/voltage_now" 2>/dev/null)
      break
    fi
  done

  if [ -z "$volt_uV" ] || [ "$volt_uV" -eq 0 ]; then
    log "apply_target_watt: voltage node not found or zero, will attempt watt nodes only"
  fi

  # compute current in microamps (uA)
  if [ "$volt_uV" -gt 0 ]; then
    cur_uA=$(compute_current_uA "$target_w" "$volt_uV")
  else
    cur_uA=0
  fi

  # We'll try to write either a watt target node, or a current node (uA or mA)
  success=1

  # 1) try direct watt-target nodes
  watt_nodes="/sys/kernel/charging_control/target_watt /sys/kernel/charge_control/target_watt /sys/class/power_supply/bms/target_watt"
  for n in $watt_nodes; do
    if [ -e "$n" ] && [ -w "$n" ]; then
      safe_write "$n" "$target_w"
      if [ $? -eq 0 ]; then
        log "Wrote ${target_w} to $n (watt node)"
        success=0
      fi
    fi
  done

  # 2) try current nodes in microamps or microamp scaling
  # Some nodes expect microamp, others expect mA. We'll try both:
  candidate="$(detect_current_node)"
  if [ -n "$candidate" ]; then
    # try as microamps
    if [ "$cur_uA" -gt 0 ]; then
      safe_write "$candidate" "$cur_uA"
      if [ $? -eq 0 ]; then
        log "Wrote ${cur_uA} (uA) to $candidate"
        success=0
      else
        # try as mA (round)
        cur_mA=$(( (cur_uA + 500) / 1000 ))
        safe_write "$candidate" "$cur_mA"
        if [ $? -eq 0 ]; then
          log "Wrote ${cur_mA} (mA) to $candidate"
          success=0
        fi
      fi
    else
      log "No voltage read -> skipping current writes to $candidate"
    fi
  else
    log "No candidate current node detected"
  fi

  # 3) fallback: try to write to any node in candidate list (even not writable earlier)
  for n in $CANDIDATE_CURRENT_NODES; do
    if [ -e "$n" ] && [ -w "$n" ]; then
      safe_write "$n" "$target_w"
      if [ $? -eq 0 ]; then
        log "Fallback wrote ${target_w} to $n"
        success=0
      fi
    fi
  done

  if [ "$success" -eq 0 ]; then
    return 0
  else
    log "apply_target_watt: failed to write any node for ${target_w}W"
    return 1
  fi
}

# read temperature in Celsius (if present)
read_temp_c() {
  for p in /sys/class/power_supply/*; do
    if [ -f "$p/temp" ]; then
      t=$(cat "$p/temp" 2>/dev/null)
      # often temp is in tenths of a deg
      if [ -n "$t" ]; then
        # if >1000 assume tenths, else assume degC
        if [ "$t" -gt 1000 ]; then
          echo $(( t / 10 ))
        else
          echo "$t"
        fi
        return
      fi
    fi
  done
  echo "0"
}

# Main entrypoint
TARGET_W="$1"
if [ -z "$TARGET_W" ]; then
  echo "Usage: $0 <watt>"
  exit 2
fi

# Enforce bounds:
if [ "$TARGET_W" -lt "$MIN_W" ]; then
  log "Requested $TARGET_W below min $MIN_W. Clamping."
  TARGET_W="$MIN_W"
fi
if [ "$TARGET_W" -gt "$MAX_W" ]; then
  log "Requested $TARGET_W above max $MAX_W. Clamping."
  TARGET_W="$MAX_W"
fi

# Check temp and safe_mode
TEMP_C=$(read_temp_c)
if [ -n "$TEMP_C" ]; then
  log "Current temp: ${TEMP_C}°C (warn ${TEMP_WARN} crit ${TEMP_CRIT})"
  if [ "$TEMP_C" -ge "$TEMP_CRIT" ]; then
    # emergency: set to MIN_W
    log "Temp >= crit ($TEMP_C >= $TEMP_CRIT). Forcing min watt ${MIN_W}"
    TARGET_W="$MIN_W"
  elif [ "$TEMP_C" -gt "$TEMP_WARN" ] && [ "$SAFE_MODE" = "true" ]; then
    # soft reduce proportional
    # example: reduce linearly between warn..crit
    delta=$(( TEMP_C - TEMP_WARN ))
    span=$(( TEMP_CRIT - TEMP_WARN ))
    if [ "$span" -le 0 ]; then
      TARGET_W="$MIN_W"
    else
      reduce=$(( (delta * (TARGET_W - MIN_W)) / span ))
      neww=$(( TARGET_W - reduce ))
      if [ "$neww" -lt "$MIN_W" ]; then neww=$MIN_W; fi
      log "Reducing due to temp: $TARGET_W -> $neww"
      TARGET_W="$neww"
    fi
  fi
fi

# attempt to apply
apply_target_watt "$TARGET_W"
ret=$?
if [ $ret -eq 0 ]; then
  log "apply_target_watt succeeded for ${TARGET_W}W"
  # write current_watt persistent file for service
  echo "$TARGET_W" > "$COMMON/current_watt"
  # post notification if possible
  if [ "$(id -u)" = "0" ]; then
    su -lp 2000 -c "cmd notification post -S bigtext -t ' Atmosphere Battery UI❄️' tag '${TARGET_W} : Running " >/dev/null 2>&1
  fi
  exit 0
else
  log "apply_target_watt failed for ${TARGET_W}W (no writable nodes?)"
  exit 1
fi