Atmosphere Battery UI v5.4.5-Beta - Full ready-to-flash module (MAGISK/KSU)

This full package includes:
- Auto-detecting AI controller, safer defaults, and config.json
- Per-watt mode scripts (18W..120W) that use detected sysfs if available
- Enhanced Web UI with canvas water animation and status
- Simple Python HTTP server (server.py) to serve webroot and provide /api/set_mode
- Notifications via `cmd notification` when present
- Safety reminders: ALWAYS verify the vendor sysfs nodes before enabling writes.

Install notes:
- After flashing, edit /data/adb/modules/AtmosphereBatteryUI/ai_sysfs_candidates.txt if you know your device's real charging sysfs paths.
- If no sysfs is detected, the module will run in log-only mode (no hardware writes).
