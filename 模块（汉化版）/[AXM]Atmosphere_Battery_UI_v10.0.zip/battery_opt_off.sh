#!/system/bin/sh
cmd notification post -S bigtext -t '🌍 Atmosphere Battery UI❄️'🔥 'System' '✅ Optimization Battery OFF' > /dev/null 2>&1 & 

if [ "$(id -u)" = "0" ]; then
    su -lp 2000 -c "cmd notification post -S bigtext -t ' 🌏Atmosphere Battery UI❄️🔥' tag 'System : ✅ Optimization Battery OFF🔥'" >/dev/null 2>&1
fi

BIN_DIR="/data/user_de/0/com.android.shell/axeron/plugins/atmosphere_battery/system/bin"
PID=$(pgrep -f system_optimizer)
if [ -z "$PID" ]; then
    echo "⚠️ System Optimizer not running"
else
    kill -TERM $PID
    echo "🛑 System Optimizer stopped"
fi