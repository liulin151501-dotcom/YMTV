#!/system/bin/sh
#
# All copy and move operations will now abort on failure.
#

check_for_config_changes() {
  local new_config="$1"
  local saved_config="$2"
  
  # This function extracts all configuration keys (e.g., "INCLUDE_ANYA", "SOC")
  # from both files, ignoring comments and section headers. It then compares the lists.
  # If the lists are different in any way (keys added or removed), it returns 0 (true).
  
  get_keys() {
    grep -vE '^#|^\[|^$' "$1" | cut -d'=' -f1
  }

  new_keys=$(get_keys "$new_config")
  saved_keys=$(get_keys "$saved_config")
  
  # diff will be silent and exit with 0 if files are identical.
  # If there is any difference, it will produce output and exit with 1.
  if ! diff <(echo "$new_keys" | sort) <(echo "$saved_keys" | sort) >/dev/null 2>&1; then
    ui_print "- Config file structure has changed."
    return 0 # 0 means true (changes detected)
  fi
  
  return 1 # 1 means false (no changes)
}

LATESTARTSERVICE=true
SOC=0
MODPATH="/data/user_de/0/com.android.shell/axeron/plugins/atmosphere_battery"
TERX_PERSIST_CONFIG="$MODPATH/TerX.txt"

ui_print "------------------------------------"
ui_print " 🌏 ATMOSPHERE BATTERY UI❄️         "
ui_print "------------------------------------"
ui_print " TerX Official        "
ui_print "------------------------------------"
ui_print "------------------------------------"
ui_print " Participating my Friends "
ui_print " @Johnn Davee "
ui_print "------------------------------------"
ui_print " "
sleep 1.5

if [ -f "$TERX_PERSIST_CONFIG" ]; then
  SAVED_SOC=$(grep '^SOC=' "$TERX_PERSIST_CONFIG" | cut -d'=' -f2)
  if [ -n "$SAVED_SOC" ] && [ "$SAVED_SOC" -gt 0 ]; then
    SOC=$SAVED_SOC
  fi
fi

if [ $SOC -eq 0 ]; then
  soc_recognition_extra() {
    [ -d /sys/class/kgsl/kgsl-3d0/devfreq ] && { SOC=2; return 0; }
    [ -d /sys/devices/platform/kgsl-2d0.0/kgsl ] && { SOC=2; return 0; }
    [ -d /sys/kernel/ged/hal ] && { SOC=1; return 0; }
    [ -d /sys/kernel/tegra_gpu ] && { SOC=6; return 0; }
    return 1
  }

  get_soc_getprop() {
    local SOC_PROP="
ro.board.platform
ro.soc.model
ro.hardware
ro.chipname
ro.hardware.chipname
ro.vendor.soc.model.external_name
ro.vendor.qti.soc_name
ro.vendor.soc.model.part_name
ro.vendor.soc.model
"
    for prop in $SOC_PROP; do
      getprop "$prop"
    done
  }

  recognize_soc() {
    case "$1" in
    *mt* | *MT*) SOC=1 ;;
    *sm* | *qcom* | *SM* | *QCOM* | *Qualcomm*) SOC=2 ;;
    *exynos* | *Exynos* | *EXYNOS* | *universal* | *samsung* | *erd* | *s5e*) SOC=3 ;;
    *Unisoc* | *unisoc* | *ums*) SOC=4 ;;
    *gs* | *Tensor* | *tensor*) SOC=5 ;;
    *kirin*) SOC=7 ;;
    esac
    [ $SOC -eq 0 ] && return 1
  }

  ui_print "------------------------------------"
  ui_print "        RECOGNIZING CHIPSET         "
  ui_print "------------------------------------"
  soc_recognition_extra
  [ $SOC -eq 0 ] && recognize_soc "$(get_soc_getprop)"
  [ $SOC -eq 0 ] && recognize_soc "$(grep -E "Hardware|Processor" /proc/cpuinfo | uniq | cut -d ':' -f 2 | sed 's/^[ \t]*//')"
  [ $SOC -eq 0 ] && recognize_soc "$(grep "model\sname" /proc/cpuinfo | uniq | cut -d ':' -f 2 | sed 's/^[ \t]*//')"
  [ $SOC -eq 0 ] && {
    ui_print "! Unable to detect your SoC (Chipset)."
    abort "! Installation cannot continue. Aborting."
  }
fi

ui_print "------------------------------------"
ui_print "      INFORMATION ℹ️            "
ui_print "------------------------------------"
ui_print "Name : 🔋🔥Atmosphere Battery UI⚡❄️"
ui_print "Version : v9.0-Official-Version"
ui_print "Support Update: Up to v20.0.1⬆️"
sleep 1.5

ui_print "      INSTALLING DATA      "
ui_print " "
sleep 1.5

ui_print "- Setting up module files..."
mkdir -p /storage/emulated/0/Atmosphere_TerX

on_install() {
  ui_print " "
  
  unzip -o "$ZIPFILE" 'mode/*' -d $MODPATH >&2
  unzip -o "$ZIPFILE" 'action.sh' -d $MODPATH >&2
  unzip -o "$ZIPFILE" 'battery_extender' -d $MODPATH >&2
  unzip -o "$ZIPFILE" 'UNLOCKER' -d $MODPATH >&2
  unzip -o "$ZIPFILE" 'System/bin/*' -d $MODPATH >&2
  unzip -o "$ZIPFILE" 'system/*' -d $MODPATH >&2
  unzip -o "$ZIPFILE" 'post-fs-data.sh' -d "$MODPATH" >&2
  unzip -o "$ZIPFILE" 'service.sh' -d "$MODPATH" >&2
  unzip -o "$ZIPFILE" 'bin/*' -d "$MODPATH" >&2
  unzip -o "$ZIPFILE" 'webroot/*' -d "$MODPATH" >&2
  unzip -o "$ZIPFILE" 'gamelist.txt' -d "$MODPATH" >&2
  unzip -o "$ZIPFILE" 'OEM/*' -d "$MODPATH" >&2
  unzip -o "$ZIPFILE" 'OEM_KERNEL/*' -d "$MODPATH" >&2

  ui_print " "
}

set_permissions() {
  set_perm_recursive "$MODPATH" 0 0 0755 0755
  set_perm_recursive "$MODPATH/bin" 0 0 0755 0755
  set_perm_revursive "$MODPATH/System/bin" 0 0 0755 0755
  set_perm_recursive $MODPATH 0 0 0755 0755
  set_perm_recursive $MODPATH/mode 0 0 755 0755
  set_perm_recursive $MODPATH/sellscript 0 0 755 0755
  set_perm_recursive $MODPATH/OEM 0 0 755 0755
  set_perm_recursive $MODPATH/OEM_KERNEL 0 0 755 0755
  set_perm_recursive $MODPATH/Battery 0 0 755 0755
  set_perm_recursive $MODPATH/UNLOCKER 0 0 0755 0755
  set_perm_recursive $MODPATH/GameEnhancer 0 0 0755 0755
}

sleep 1.5

choose() {
  while true; do
    /system/bin/getevent -lc 1 2>&1 | /system/bin/grep VOLUME | /system/bin/grep " DOWN" > "$TMPDIR/events"
    if [ -s "$TMPDIR/events" ]; then
      if grep -q "KEY_VOLUMEUP" "$TMPDIR/events"; then
        return 0
      else
        return 1
      fi
    fi
  done
}

TERX_MODULE_CONFIG="$MODPATH/TerX.txt"

ui_print "------------------------------------"
ui_print "      OPTIONAL ADDON SELECTION      "
ui_print "------------------------------------"
ui_print "- Extracting configuration file..."
unzip -o "$ZIPFILE" 'TerX.txt' -d $MODPATH >&2

USE_SAVED_CONFIG=false
if [ -f "$TERX_PERSIST_CONFIG" ]; then
  ui_print " "
  ui_print "- Detecting Save Configuration is not Available."
  ui_print "- This is not a type of Error because the save Configuration available only on Rooted Devices."
  
  # MANDATORY RECONFIGURATION LOGIC
  if check_for_config_changes "$TERX_MODULE_CONFIG" "$TERX_PERSIST_CONFIG"; then
    ui_print " "
    ui_print "! New Entry of Config File Detected."
    ui_print "! Forcing reconfiguration..."
    ui_print " "
    sleep 2
    # No choice is given. USE_SAVED_CONFIG remains false, forcing manual selection.
  else
    # No changes found, ask to use saved config
    ui_print "  Save Configuration is not Available for Ax Manager Choose No"
    ui_print " "
    ui_print "  Vol+ = Yes, use saved config"
    ui_print "  Vol- = No, choose again"
    ui_print " "
    if choose; then
      ui_print "- Using saved configuration."
      ui_print "- Copying TerX.txt..."
      cp "$TERX_PERSIST_CONFIG" "$MODPATH" >/dev/null 2>&1 || abort "! Failed to copy saved configuration"
      USE_SAVED_CONFIG=true
    else
      ui_print "- Re-configuring addons."
    fi
  fi
fi

  ui_print " "
  ui_print "- Balance Core ⚖️"
  ui_print "  n Yes or No"
  ui_print "  Vol+ = Yes  |  Vol- = No"
  if choose; then INCLUDE_BALANCE=1; ui_print "  > Yes"; else INCLUDE_BALANCE=0; ui_print "  > No"; fi
  ui_print " "
  ui_print " " 
  
if [ "$USE_SAVED_CONFIG" = false ]; then
  CHARGING_OPTIONS="18W 20W 25W 30W 33W 40W 45W 50W 55W 60W 65W 70W 75W 80W 85W 90W 95W 100W 105W 110W 115W 120W"

while true; do
  YES_SELECTED=false

  for OPTION in $CHARGING_OPTIONS; do
    VAR_NAME="INCLUDE_${OPTION}"
    ui_print "- ${OPTION} Charging Speed"
    ui_print "Select if Yes or Skip (Vol+ / Vol-)"

    if choose; then
      eval "$VAR_NAME=1"
      ui_print "  > Yes selected"
      YES_SELECTED=true
      break  # Stop the for loop immediately
    else
      eval "$VAR_NAME=0"
      ui_print "  > Skipped"
    fi

    ui_print " "
  done

  if [ "$YES_SELECTED" = true ]; then
    ui_print "- Yes selected. Proceeding with flashing..."
    break  # Exit the while loop completely
  else
    ui_print "! No option selected. You must select at least one charging speed."
    ui_print "Please choose again."
    ui_print " "
  fi
done

  ui_print " "
  ui_print "- Updating module configuration..."
  sed -i "s/^INCLUDE_18W=.*/INCLUDE_18W=$INCLUDE_18W/" "$TERX_MODULE_CONFIG"
  sed -i "s/^INCLUDE_20W=.*/INCLUDE_20W=$INCLUDE_20W/" "$TERX_MODULE_CONFIG"
  sed -i "s/^INCLUDE_25W=.*/INCLUDE_25W=$INCLUDE_25W/"  "$TERX_MODULE_CONFIG"
  sed -i "s/^INCLUDE_BRAIN=.*/INCLUDE_BRAIN=$INCLUDE_BRAIN/" "$TERX_MODULE_CONFIG"
  sed -i "s/^INCLUDE_BALANCE=.*/INCLUDE_BALANCE=$INCLUDE_BALANCE/" "$TERX_MODULE_CONFIG"
  sed -i "s/^INCLUDE_30W=.*/INCLUDE_30W=$INCLUDE_30W/" "$TERX_MODULE_CONFIG"
  sed -i "s/^INCLUDE_33W=.*/INCLUDE_33W=$INCLUDE_33W/" "$TERX_MODULE_CONFIG"
  sed -i "s/^INCLUDE_40W=.*/INCLUDE_40W=$INCLUDE_40W/" "$TERX_MODULE_CONFIG"
  sed -i "s/^INCLUDE_45W=.*/INCLUDE_45W=$INCLUDE_45W/" "$TERX_MODULE_CONFIG"
  sed -i "s/^INCLUDE_50W=.*/INCLUDE_50W=$INCLUDE_50W/" "$TERX_MODULE_CONFIG"
  sed -i "s/^INCLUDE_55W=.*/INCLUDE_55W=$INCLUDE_55W/" "$TERX_MODULE_CONFIG"
  sed -i "s/^INCLUDE_60W=.*/INCLUDE_60W=$INCLUDE_60W/" "$TERX_MODULE_CONFIG"
  sed -i "s/^INCLUDE_65W=.*/INCLUDE_65W=$INCLUDE_65W/" "$TERX_MODULE_CONFIG"
  sed -i "s/^INCLUDE_70W=.*/INCLUDE_70W=$INCLUDE_70W/" "$TERX_MODULE_CONFIG"
  sed -i "s/^INCLUDE_75W=.*/INCLUDE_75W=$INCLUDE_75W/" "$TERX_MODULE_CONFIG"
  sed -i "s/^INCLUDE_80W=.*/INCLUDE_80W=$INCLUDE_80W/" "$TERX_MODULE_CONFIG"
  sed -i "s/^INCLUDE_85W=.*/INCLUDE_85W=$INCLUDE_85W/" "$TERX_MODULE_CONFIG"
  sed -i "s/^INCLUDE_90W=.*/INCLUDE_90W=$INCLUDE_90W/" "$TERX_MODULE_CONFIG"
  sed -i "s/^INCLUDE_95W=.*/INCLUDE_95W=$INCLUDE_95W/" "$TERX_MODULE_CONFIG"
  sed -i "s/^INCLUDE_100W=.*/INCLUDE_100W=$INCLUDE_100W/" "$TERX_MODULE_CONFIG"
  sed -i "s/^INCLUDE_105W=.*/INCLUDE_105W=$INCLUDE_105W/" "$TERX_MODULE_CONFIG"
  sed -i "s/^INCLUDE_110W=.*/INCLUDE_110W=$INCLUDE_110W/" "$TERX_MODULE_CONFIG"
  sed -i "s/^INCLUDE_115W=.*/INCLUDE_115W=$INCLUDE_115W/" "$TERX_MODULE_CONFIG"
  sed -i "s/^INCLUDE_120W=.*/INCLUDE_120W=$INCLUDE_120W/" "$TERX_MODULE_CONFIG"
  ui_print "- Adding SOC Code ($SOC) to module config..."
  sed -i "s/^SOC=.*/SOC=$SOC/" "$TERX_MODULE_CONFIG"

  ui_print " "
  ui_print "- Save these choices for future installations?"
  ui_print "  Vol+ = Yes  |  Vol- = No"
  if choose; then
    ui_print "- Saving configuration for next time."
    ui_print "- Copying TerX.txt..."
    cp "$TERX_MODULE_CONFIG" "/storage/emulated/0/Atmosphere_TerX" >/dev/null 2>&1 || abort "! Failed to save new configuration"
  else
    ui_print "- Choices will not be saved."
    [ -f "$TERX_PERSIST_CONFIG" ] && rm -f "$TERX_PERSIST_CONFIG"
  fi
fi

if [ -f "$TERX_MODULE_CONFIG" ]; then
    ui_print "- Finalizing SOC Code ($SOC) in TerX.txt"
    sed -i "s/^SOC=.*/SOC=$SOC/" "$TERX_MODULE_CONFIG"
fi

ui_print " "
ui_print "   Please Wait Take a Few Second  "
ui_print " "
sleep 0.5
ui_print " Installation Complete ✅"