#!/system/bin/sh
cmd notification post -S bigtext -t '🌍 Atmosphere Battery UI❄️'🔥 'System' '✅ Atmosphere Core On' > /dev/null 2>&1 & 

if [ "$(id -u)" = "0" ]; then
    su -lp 2000 -c "cmd notification post -S bigtext -t ' 🌏Atmosphere Battery UI❄️🔥' tag 'System : ✅ Atmosphere Core On🔥'" >/dev/null 2>&1
fi

exec /data/data/com.android.shell/AxManager/plugins/atmosphere_battery/system/bin/ultimate_battery_daemon

BIN_DIR="/data/user_de/0/com.android.shell/axeron/plugins/atmosphere_battery/system/bin"
cd $BIN_DIR

if pgrep -f ultimate_battery_daemon >/dev/null; then
    echo "✅ Battery Daemon already running"
else
    ./ultimate_battery_daemon &
    echo "⚡ Battery Daemon started"
fi