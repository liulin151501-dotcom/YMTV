const MODULE_PATH = "/data/user_de/0/com.android.shell/axeron/plugins/atmosphere_battery";
const GAME_FILE = `${MODULE_PATH}/gamelist.txt`;
const DAEMON_NAME = "pow-daemon";
const PROP_FILE = `${MODULE_PATH}/module.prop`;

// Safe exec with KernelSU detection
function exec(command) {
  return new Promise((resolve, reject) => {
    // Check if ksu is available
    if (typeof ksu === "undefined") {
      console.log("[SIMULATION] Command:", command);
      // Simulate success for browser testing
      setTimeout(() => resolve("simulated"), 100);
      return;
    }
    
    const cb = `exec_cb_${Date.now()}`;
    window[cb] = (errno, stdout, stderr) => {
      delete window[cb];
      if (errno !== 0) reject(new Error(stderr || stdout || "Exec failed"));
      else resolve(stdout.trim());
    };
    try { 
      ksu.exec(command, `window.${cb}`); 
    }
    catch (e) { 
      reject(e); 
    }
  });
}

// === Helper open link via am start ===
async function openLink(url) {
  try {
    await exec(`am start -a android.intent.action.VIEW -d "${url}"`);
  } catch (err) {
    console.error("openLink failed:", err);
    // Fallback for browser
    window.open(url, '_blank');
  }
}

// === Load System Info ===
async function loadInfo() {
  try {
    const version = await exec(`grep -m1 '^version=' ${PROP_FILE} | cut -d= -f2 || echo Unknown`);
    const kernel = await exec("uname -r || echo N/A");
    const sdk = await exec("getprop ro.build.version.sdk || echo N/A");
    document.getElementById("version").textContent = version;
    document.getElementById("kernel").textContent = kernel;
    document.getElementById("sdk").textContent = sdk;
  } catch (e) {
    console.error("Load info error:", e);
    ["version", "kernel", "sdk"].forEach(id => {
      const el = document.getElementById(id);
      if (el) el.textContent = "-";
    });
  }
}

// === Load PID ===
async function loadPID() {
  try {
    const pid = await exec(`pidof ${DAEMON_NAME} 2>/dev/null || echo -`);
    document.getElementById("pid").textContent = pid;
  } catch (e) {
    console.error("Load PID error:", e);
    const el = document.getElementById("pid");
    if (el) el.textContent = "-";
  }
}

// === Gamelist ===
let allApps = [];
let savedGames = [];

async function loadApps() {
  const listEl = document.getElementById("gamelist");
  const status = document.getElementById("gamelist-status");
  const search = document.getElementById("gamelist-search");
  
  if (!listEl) return;
  
  listEl.innerHTML = `<div class="loading">Connecting to Ley Lines...</div>`;
  
  try {
    const savedRaw = await exec(`[ -f ${GAME_FILE} ] && cat ${GAME_FILE} || echo ""`);
    savedGames = savedRaw.split(/\r?\n/).filter(Boolean);
    
    const pkgsRaw = await exec("pm list packages -3 || true");
    allApps = pkgsRaw.split(/\r?\n/).map(l => l.replace("package:", "").trim()).filter(Boolean);
    
    renderAppList(search ? search.value : "");
    if (status) status.textContent = `${savedGames.length} domains • ${allApps.length} realms`;
  } catch (e) {
    console.error("Load apps failed:", e);
    if (listEl) listEl.innerHTML = `<div class="loading">Ley Lines disrupted - Check Vision connection</div>`;
  }
}

function renderAppList(filter = "") {
  const listEl = document.getElementById("gamelist");
  if (!listEl) return;
  
  const q = filter.toLowerCase();
  listEl.innerHTML = "";
  
  const makeItem = (pkg, isSaved) => {
    const div = document.createElement("div");
    div.className = "gamelist-item" + (isSaved ? " saved" : "");
    div.textContent = (isSaved ? "✦ " : "") + pkg;
    div.onclick = () => saveGame(pkg);
    return div;
  };
  
  // Saved games
  savedGames.forEach(pkg => {
    if (!pkg.toLowerCase().includes(q)) return;
    listEl.appendChild(makeItem(pkg, true));
  });
  
  // Apps lain
  allApps.forEach(pkg => {
    if (savedGames.includes(pkg)) return;
    if (q && !pkg.toLowerCase().includes(q)) return;
    listEl.appendChild(makeItem(pkg, false));
  });
  
  if (!listEl.children.length) {
    listEl.innerHTML = `<div class="loading">No domains found</div>`;
  }
}

async function saveGame(pkg) {
  const status = document.getElementById("gamelist-status");
  if (!pkg) {
    if (status) status.textContent = "No domain selected.";
    return;
  }
  
  try {
    const exists = await exec(`[ -f ${GAME_FILE} ] && grep -qx "${pkg}" ${GAME_FILE} && echo 1 || echo 0`);
    if (exists.trim() === "0") {
      await exec(`echo "${pkg}" >> ${GAME_FILE}`);
      savedGames.push(pkg);
      if (status) status.textContent = `Domain sealed: ${pkg}`;
    } else {
      if (status) status.textContent = `Domain already sealed: ${pkg}`;
    }
    const search = document.getElementById("gamelist-search");
    renderAppList(search ? search.value : "");
  } catch (e) {
    if (status) status.textContent = `Error: ${e.message}`;
  }
}

async function clearSaved() {
  try {
    await exec(`[ -f ${GAME_FILE} ] && rm -f ${GAME_FILE} || true`);
    savedGames = [];
    const search = document.getElementById("gamelist-search");
    renderAppList(search ? search.value : "");
    const status = document.getElementById("gamelist-status");
    if (status) status.textContent = "All domains purged.";
  } catch (e) {
    const status = document.getElementById("gamelist-status");
    if (status) status.textContent = `Error: ${e.message}`;
  }
}

// === Init ===
document.addEventListener("DOMContentLoaded", async () => {
  await Promise.all([loadPID(), loadInfo(), loadApps()]);
  
  const search = document.getElementById("gamelist-search");
  if (search) {
    search.style.display = "block";
    search.placeholder = "🔮 Search domains...";
    search.addEventListener("input", () => renderAppList(search.value));
  }
  
  // Tombol Telegram
  const telegramBtn = document.getElementById("telegram-button");
  if (telegramBtn) {
    telegramBtn.addEventListener("click", () => openLink("https://t.me/terxofficial"));
  }
  
  // Tombol lainnya
  const refreshBtn = document.getElementById("refresh-list");
  const clearBtn = document.getElementById("clear-saved");
  
  if (refreshBtn) refreshBtn.addEventListener("click", loadApps);
  if (clearBtn) clearBtn.addEventListener("click", clearSaved);
});
