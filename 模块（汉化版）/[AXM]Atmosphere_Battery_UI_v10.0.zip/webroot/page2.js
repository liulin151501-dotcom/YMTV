const MODULE_DIR = "/data/user_de/0/com.android.shell/axeron/plugins/atmosphere_battery";

// Elemental Skills Configuration
const elementalSkills = [
    { 
        id: "batteryUI", 
        name: "Electro Vision", 
        desc: "Atmosphere Battery UI",
        on: "atmos_ui_on.sh", 
        off: "atmos_ui_off.sh", 
        icon: "fa-bolt",
        element: "#9333ea",
        color: "electro"
    },
    { 
        id: "batteryOpt", 
        name: "Pyro Resonance", 
        desc: "Battery Optimizer",
        on: "battery_opt_on.sh", 
        off: "battery_opt_off.sh", 
        icon: "fa-fire",
        element: "#dc2626",
        color: "pyro"
    },
    { 
        id: "batteryGuard", 
        name: "Geo Shield", 
        desc: "Atmosphere Battery Guard",
        on: "atmos_guard_on.sh", 
        off: "atmos_guard_off.sh", 
        icon: "fa-shield-alt",
        element: "#d97706",
        color: "geo"
    },
    { 
        id: "fastcharger", 
        name: "Anemo Swift", 
        desc: "Fast Charging System",
        on: "fcs_on.sh", 
        off: "fcs_off.sh", 
        icon: "fa-wind",
        element: "#059669",
        color: "anemo"
    }
];

const listEl = document.getElementById("tweaks-list");
const statusEl = document.getElementById("tweaks-status");
const backBtn = document.getElementById("back-button");
const burstEffect = document.getElementById("burstEffect");
const entryOverlay = document.getElementById("entryOverlay");
const mainContent = document.getElementById("mainContent");

// Safe exec with KernelSU detection
async function execScript(path, skillName) {
    log(`🌟 Channeling ${skillName}...`, 'info');
    
    if (typeof ksu === "undefined") {
        log(`✨ [VISION SIMULATION] ${path}`, 'system');
        await new Promise(res => setTimeout(res, 800));
        log(`✅ ${skillName} resonance complete!`, 'success');
        return "Elemental energy synchronized";
    }
    
    return new Promise((resolve, reject) => {
        ksu.exec(`sh ${path}`, (errno, stdout, stderr) => {
            if (errno !== 0) {
                log(`❌ ${skillName} failed: ${stderr || "Unknown error"}`, 'error');
                reject(stderr || stdout || "Elemental disruption detected");
            } else {
                log(`✅ ${skillName} activated successfully!`, 'success');
                resolve(stdout);
            }
        });
    });
}

// Logger
function log(msg, type = 'info') {
    const time = new Date().toLocaleTimeString();
    const entry = document.createElement('div');
    entry.className = `log-entry ${type}`;
    entry.textContent = `[${time}] ${msg}`;
    statusEl.appendChild(entry);
    statusEl.scrollTop = statusEl.scrollHeight;
    
    while (statusEl.children.length > 20) {
        statusEl.removeChild(statusEl.firstChild);
    }
}

// Elemental burst animation
function elementalBurst(elementColor) {
    burstEffect.style.setProperty('--element-color', elementColor);
    burstEffect.classList.add('active');
    
    if (navigator.vibrate) {
        navigator.vibrate([50, 100, 50, 100, 200, 100, 300]);
    }
    
    setTimeout(() => {
        burstEffect.classList.remove('active');
    }, 1000);
}

// Create floating particles
function createParticles() {
    const container = document.getElementById('particles');
    const symbols = ['⚡', '✦', '◆', '▲', '●', '★'];
    
    setInterval(() => {
        if (document.hidden) return;
        
        const particle = document.createElement('div');
        particle.className = 'particle';
        particle.textContent = symbols[Math.floor(Math.random() * symbols.length)];
        particle.style.left = Math.random() * 100 + '%';
        particle.style.animationDuration = (Math.random() * 3 + 2) + 's';
        particle.style.opacity = Math.random() * 0.5 + 0.2;
        container.appendChild(particle);
        
        setTimeout(() => particle.remove(), 5000);
    }, 400);
}

// Render elemental skill cards
function renderSkills() {
    listEl.innerHTML = "";
    
    elementalSkills.forEach(skill => {
        const saved = localStorage.getItem(skill.id) === "1";
        const card = document.createElement("div");
        card.className = "skill-card" + (saved ? " active" : "");
        card.style.setProperty('--element-color', skill.element);
        
        card.innerHTML = `
            <div class="skill-info">
                <div class="skill-icon" style="background: radial-gradient(circle at 30% 30%, ${skill.element}, transparent); box-shadow: 0 0 15px ${skill.element}">
                    <i class="fas ${skill.icon}"></i>
                </div>
                <div>
                    <div class="skill-name">${skill.name}</div>
                    <div class="skill-desc">${skill.desc}</div>
                </div>
            </div>
            <label class="element-switch">
                <input type="checkbox" ${saved ? "checked" : ""}>
                <span class="switch-slider" style="--element-color: ${skill.element}"></span>
            </label>
        `;
        
        const checkbox = card.querySelector("input");
        const slider = card.querySelector(".switch-slider");
        
        checkbox.addEventListener('change', () => {
            slider.style.setProperty('--element-color', skill.element);
        });
        
        checkbox.addEventListener("change", async () => {
            const isOn = checkbox.checked;
            localStorage.setItem(skill.id, isOn ? "1" : "0");
            
            if (isOn) {
                card.classList.add('active');
            } else {
                card.classList.remove('active');
            }
            
            elementalBurst(skill.element);
            
            const script = isOn ? skill.on : skill.off;
            if (script) {
                try {
                    await execScript(`${MODULE_DIR}/${script}`, skill.name);
                } catch (e) {
                    checkbox.checked = !isOn;
                    localStorage.setItem(skill.id, !isOn ? "1" : "0");
                    if (isOn) card.classList.add('active');
                    else card.classList.remove('active');
                }
            }
        });
        
        listEl.appendChild(card);
    });
}

// UPGRADED Arcade Button
function setupArcadeButton() {
    const arcadeBtn = document.getElementById('arcade-button');
    const arcadeStatus = document.getElementById('arcade-status');
    const screenContent = document.querySelector('.screen-content');
    
    if (!arcadeBtn) return;
    
    // Hover effects
    arcadeBtn.addEventListener('mouseenter', () => {
        if (navigator.vibrate) navigator.vibrate(20);
        arcadeStatus.textContent = "🎮 Press START to enter Golden Apple Archipelago!";
        arcadeStatus.style.color = "#fbbf24";
    });
    
    arcadeBtn.addEventListener('mouseleave', () => {
        arcadeStatus.textContent = "Ready for adventure!";
        arcadeStatus.style.color = "";
    });
    
    // Click handler
    arcadeBtn.addEventListener('click', async () => {
        // Visual feedback
        arcadeBtn.style.transform = "translateY(10px) scale(0.95)";
        screenContent.innerHTML = '<i class="fas fa-spinner fa-spin"></i><span>LOADING...</span>';
        
        // Haptic feedback
        if (navigator.vibrate) {
            navigator.vibrate([100, 50, 100, 50, 200]);
        }
        
        // Burst effect
        elementalBurst("#fbbf24");
        
        arcadeStatus.textContent = "🚀 Launching Arcade Mode...";
        arcadeStatus.style.color = "#4ade80";
        
        // Try to find arcade
        const paths = [
            "arcade/lobby/index.html",
            "./arcade/lobby/index.html",
            "../arcade/lobby/index.html",
            "arcade/index.html",
            "games/index.html"
        ];
        
        setTimeout(() => {
            // Try navigation
            for (const path of paths) {
                try {
                    window.location.href = path;
                    return;
                } catch (e) {
                    continue;
                }
            }
            
            // Fallback
            createFallbackArcade();
        }, 800);
    });
}

// Fallback arcade
function createFallbackArcade() {
    const html = `
<!DOCTYPE html>
<html>
<head>
    <title>🎮 Golden Apple Archipelago</title>
    <style>
        body {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 20px;
            text-align: center;
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        .arcade-container {
            max-width: 500px;
            padding: 40px;
            background: rgba(0,0,0,0.7);
            border-radius: 30px;
            border: 3px solid #fbbf24;
            box-shadow: 0 0 50px rgba(251, 191, 36, 0.3);
        }
        h1 { color: #fbbf24; margin-bottom: 10px; text-shadow: 0 0 20px #fbbf24; }
        .island { font-size: 60px; margin: 20px 0; }
        .game-list { display: flex; flex-direction: column; gap: 15px; margin: 30px 0; }
        .game-btn {
            background: linear-gradient(to right, #ff416c, #ff4b2b);
            color: white;
            border: none;
            padding: 15px;
            border-radius: 15px;
            font-size: 16px;
            cursor: pointer;
            transition: all 0.3s;
            font-weight: bold;
            letter-spacing: 2px;
        }
        .game-btn:hover { transform: scale(1.05); box-shadow: 0 10px 30px rgba(255,75,43,0.4); }
        .back-btn {
            background: transparent;
            color: #fbbf24;
            border: 2px solid #fbbf24;
            padding: 10px 30px;
            border-radius: 25px;
            text-decoration: none;
            display: inline-block;
            margin-top: 20px;
            transition: all 0.3s;
        }
        .back-btn:hover { background: #fbbf24; color: black; }
    </style>
</head>
<body>
    <div class="arcade-container">
        <h1>🏝️ Golden Apple Archipelago</h1>
        <div class="island">🌴🎮🌴</div>
        <p>Welcome to the summer islands!</p>
        
        <div class="game-list">
            <button class="game-btn" onclick="alert('Coming in Version 2.0!')">⚔️ Domain Challenge</button>
            <button class="game-btn" onclick="alert('Coming in Version 2.0!')">🏆 Treasure Hunt</button>
            <button class="game-btn" onclick="alert('Coming in Version 2.0!')">⛵ Boat Racing</button>
        </div>
        
        <a href="page2.html" class="back-btn">🔙 Back to Skills</a>
    </div>
</body>
</html>
    `;
    
    const win = window.open('', '_blank');
    if (win) {
        win.document.write(html);
        win.document.close();
    } else {
        document.open();
        document.write(html);
        document.close();
    }
}

// Back button
if (backBtn) {
    backBtn.onclick = () => {
        elementalBurst('#9333ea');
        log("🌟 Returning to Elemental Nexus...", 'info');
        
        setTimeout(() => {
            window.location.href = "index.html";
        }, 500);
    };
}

// Initialize with entry animation
document.addEventListener("DOMContentLoaded", () => {
    // Show entry animation
    setTimeout(() => {
        entryOverlay.classList.add('hidden');
        mainContent.style.opacity = '1';
        mainContent.style.transform = 'translateY(0)';
    }, 1500);
    
    renderSkills();
    createParticles();
    setupArcadeButton();
    
    log("⚡ Vision System Online", 'system');
    log("🌟 Elemental resonance detected", 'info');
    log("🎮 Golden Apple Archipelago ready!", 'warning');
});
