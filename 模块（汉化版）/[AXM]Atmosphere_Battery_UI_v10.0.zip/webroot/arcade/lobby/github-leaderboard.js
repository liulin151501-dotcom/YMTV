// ============================================
// github-leaderboard.js - GitHub Integration
// Place in: terx-arcade/github-leaderboard.js
// ============================================

console.log('🌐 GitHub Leaderboard System Loading...');

// GitHub Configuration
const GITHUB_CONFIG = {
    // Use GitHub Gists for easy JSON storage
    gistId: '', // Will be generated on first export
    apiUrl: 'https://api.github.com',
    rawUrl: 'https://gist.githubusercontent.com',
    
    // Fallback leaderboard data
    fallbackData: {
        players: [],
        lastUpdated: new Date().toISOString(),
        version: '1.0.0'
    }
};

// Leaderboard Data
let githubLeaderboard = {
    players: [],
    lastUpdated: '',
    totalPlayers: 0,
    totalScore: 0
};

// ============================================
// CORE FUNCTIONS
// ============================================

// Load leaderboard from GitHub
async function loadGitHubLeaderboard() {
    console.log('📥 Loading leaderboard from GitHub...');
    
    try {
        // First check localStorage for cached data
        const cachedData = localStorage.getItem('terx_github_leaderboard');
        if (cachedData) {
            try {
                const parsed = JSON.parse(cachedData);
                if (parsed && parsed.players) {
                    githubLeaderboard = parsed;
                    updateGitHubDisplay();
                    showNotification('Loaded cached leaderboard', 'info');
                }
            } catch (e) {
                console.log('Failed to parse cached data');
            }
        }
        
        // Try to load from GitHub Gist
        const gistId = localStorage.getItem('terx_github_gist_id');
        if (gistId) {
            await loadFromGist(gistId);
        } else {
            // Create initial data
            createInitialLeaderboard();
        }
        
        updateGitHubStatus('success', 'Connected to GitHub');
        
    } catch (error) {
        console.error('Error loading from GitHub:', error);
        updateGitHubStatus('error', 'GitHub Connection Failed');
        createInitialLeaderboard();
    }
}

// Create initial leaderboard data
function createInitialLeaderboard() {
    console.log('🆕 Creating initial leaderboard...');
    
    githubLeaderboard = {
        players: [],
        lastUpdated: new Date().toISOString(),
        totalPlayers: 0,
        totalScore: 0
    };
    
    // Add current player if exists
    const playerName = localStorage.getItem('terx_playerName');
    const playerStats = JSON.parse(localStorage.getItem('terx_playerStats') || '{}');
    
    if (playerName && playerStats.totalScore > 0) {
        githubLeaderboard.players.push({
            name: playerName,
            score: playerStats.totalScore,
            games: playerStats.gamesPlayed || 0,
            playTime: playerStats.totalPlayTime || 0,
            joinDate: playerStats.joinDate || new Date().toISOString(),
            lastPlayed: playerStats.lastPlayed || new Date().toISOString(),
            rank: 1
        });
        
        githubLeaderboard.totalPlayers = 1;
        githubLeaderboard.totalScore = playerStats.totalScore;
    }
    
    updateGitHubDisplay();
    saveLocalLeaderboard();
}

// Update GitHub leaderboard with current player
function updateGitHubLeaderboard() {
    console.log('🔄 Updating GitHub leaderboard...');
    
    const playerName = localStorage.getItem('terx_playerName');
    if (!playerName || playerName === 'Guest Player') return;
    
    const playerStats = JSON.parse(localStorage.getItem('terx_playerStats') || '{}');
    if (playerStats.totalScore === 0) return;
    
    // Find existing player or add new
    const existingIndex = githubLeaderboard.players.findIndex(p => p.name === playerName);
    
    const playerData = {
        name: playerName,
        score: playerStats.totalScore,
        games: playerStats.gamesPlayed || 0,
        playTime: playerStats.totalPlayTime || 0,
        joinDate: playerStats.joinDate || new Date().toISOString(),
        lastPlayed: new Date().toISOString(),
        rank: 0
    };
    
    if (existingIndex >= 0) {
        // Update existing player
        githubLeaderboard.players[existingIndex] = playerData;
    } else {
        // Add new player
        githubLeaderboard.players.push(playerData);
    }
    
    // Sort by score and assign ranks
    githubLeaderboard.players.sort((a, b) => b.score - a.score);
    githubLeaderboard.players.forEach((player, index) => {
        player.rank = index + 1;
    });
    
    // Update totals
    githubLeaderboard.totalPlayers = githubLeaderboard.players.length;
    githubLeaderboard.totalScore = githubLeaderboard.players.reduce((sum, player) => sum + player.score, 0);
    githubLeaderboard.lastUpdated = new Date().toISOString();
    
    // Update display
    updateGitHubDisplay();
    
    // Save locally
    saveLocalLeaderboard();
    
    console.log('✅ GitHub leaderboard updated');
    return true;
}

// Export leaderboard to GitHub Gist
async function exportLeaderboardToGitHub() {
    console.log('🚀 Exporting leaderboard to GitHub...');
    
    showNotification('Exporting to GitHub...', 'info');
    
    try {
        // First update with current data
        updateGitHubLeaderboard();
        
        // Prepare data for export
        const exportData = {
            leaderboard: githubLeaderboard,
            metadata: {
                exportedAt: new Date().toISOString(),
                totalPlayers: githubLeaderboard.totalPlayers,
                totalScore: githubLeaderboard.totalScore,
                version: '1.0.0',
                source: 'TerX Official Arcade'
            }
        };
        
        const dataStr = JSON.stringify(exportData, null, 2);
        
        // Try to save to Gist if we have an ID
        const gistId = localStorage.getItem('terx_github_gist_id');
        
        if (gistId) {
            // Update existing Gist
            const success = await updateGist(gistId, dataStr);
            if (success) {
                showNotification('✅ Leaderboard exported to GitHub!', 'success');
                return true;
            }
        }
        
        // Create new Gist
        const newGistId = await createGist(dataStr);
        if (newGistId) {
            localStorage.setItem('terx_github_gist_id', newGistId);
            showNotification('✅ New GitHub Gist created!', 'success');
            return true;
        }
        
        // Fallback: Download as JSON file
        downloadAsJSON(exportData);
        showNotification('✅ Leaderboard exported as JSON file', 'success');
        return true;
        
    } catch (error) {
        console.error('Export error:', error);
        showNotification('Failed to export to GitHub', 'error');
        
        // Fallback download
        const exportData = {
            leaderboard: githubLeaderboard,
            metadata: { exportedAt: new Date().toISOString() }
        };
        downloadAsJSON(exportData);
        return false;
    }
}

// ============================================
// DISPLAY FUNCTIONS
// ============================================

function updateGitHubDisplay() {
    console.log('🔄 Updating GitHub display...');
    
    // Update stats
    updateElement('totalPlayers', githubLeaderboard.totalPlayers);
    updateElement('totalGamesPlayed', githubLeaderboard.players.reduce((sum, p) => sum + p.games, 0));
    updateElement('avgScore', githubLeaderboard.totalPlayers > 0 ? 
        Math.round(githubLeaderboard.totalScore / githubLeaderboard.totalPlayers) : 0);
    updateElement('lastUpdate', formatTime(githubLeaderboard.lastUpdated));
    
    // Update data size
    const dataSize = JSON.stringify(githubLeaderboard).length;
    updateElement('githubDataSize', `${(dataSize / 1024).toFixed(2)} KB`);
    updateElement('githubLastUpdate', formatTime(githubLeaderboard.lastUpdated));
    
    // Update leaderboard table
    updateLeaderboardTable();
    
    // Update top 3 players
    updateTop3Players();
    
    // Update player's global rank
    updatePlayerGlobalRank();
}

function updateLeaderboardTable() {
    const tableBody = document.getElementById('leaderboardTableBody');
    if (!tableBody) return;
    
    const playersToShow = githubLeaderboard.players.slice(0, 20); // Top 20
    
    if (playersToShow.length === 0) {
        tableBody.innerHTML = `
            <tr>
                <td colspan="5" style="text-align: center; padding: 20px; color: var(--text-secondary);">
                    <i class="fas fa-users"></i>
                    <div style="margin-top: 10px;">No players yet. Be the first!</div>
                </td>
            </tr>
        `;
        return;
    }
    
    tableBody.innerHTML = playersToShow.map(player => {
        const isCurrentPlayer = player.name === localStorage.getItem('terx_playerName');
        
        return `
            <tr class="${isCurrentPlayer ? 'current-player' : ''}">
                <td class="rank">#${player.rank}</td>
                <td class="player">
                    <div class="player-info">
                        <div class="avatar-small">${player.name.charAt(0).toUpperCase()}</div>
                        <div class="player-name">${player.name}</div>
                    </div>
                </td>
                <td class="score">${player.score.toLocaleString()}</td>
                <td class="games">${player.games}</td>
                <td class="joined">${formatDate(player.joinDate)}</td>
            </tr>
        `;
    }).join('');
}

function updateTop3Players() {
    const top3Container = document.getElementById('top3Players');
    if (!top3Container) return;
    
    const top3 = githubLeaderboard.players.slice(0, 3);
    
    if (top3.length === 0) {
        top3Container.innerHTML = `
            <div class="no-top-players">
                <i class="fas fa-trophy"></i>
                <p>No players yet. Be the first!</p>
            </div>
        `;
        return;
    }
    
    top3Container.innerHTML = top3.map((player, index) => {
        const medals = ['🥇', '🥈', '🥉'];
        const colors = ['#FFD700', '#C0C0C0', '#CD7F32'];
        
        return `
            <div class="top3-player rank-${index + 1}" style="border-color: ${colors[index]}">
                <div class="rank-badge" style="background: ${colors[index]}">
                    ${medals[index]}
                </div>
                <div class="player-avatar">
                    ${player.name.charAt(0).toUpperCase()}
                </div>
                <div class="player-details">
                    <div class="player-name">${player.name}</div>
                    <div class="player-score">${player.score.toLocaleString()} pts</div>
                    <div class="player-stats">
                        <span class="stat"><i class="fas fa-gamepad"></i> ${player.games} games</span>
                    </div>
                </div>
            </div>
        `;
    }).join('');
}

function updatePlayerGlobalRank() {
    const playerName = localStorage.getItem('terx_playerName');
    if (!playerName) return;
    
    const player = githubLeaderboard.players.find(p => p.name === playerName);
    const rank = player ? player.rank : githubLeaderboard.players.length + 1;
    
    updateElement('globalRank', `#${rank}`);
}

function updateGitHubStatus(status, message) {
    const statusElement = document.getElementById('githubStatus');
    if (!statusElement) return;
    
    const statusDot = statusElement.querySelector('.status-dot');
    const statusText = statusElement.querySelector('span:last-child');
    
    if (statusDot) {
        statusDot.className = 'status-dot';
        if (status === 'success') {
            statusDot.classList.add('online');
        } else if (status === 'error') {
            statusDot.classList.add('offline');
        }
    }
    
    if (statusText) {
        statusText.textContent = message;
    }
}

// ============================================
// UTILITY FUNCTIONS
// ============================================

function updateElement(id, value) {
    const element = document.getElementById(id);
    if (element) {
        element.textContent = value;
    }
}

function formatTime(dateStr) {
    if (!dateStr) return 'Never';
    
    const date = new Date(dateStr);
    const now = new Date();
    const diffMs = now - date;
    const diffMins = Math.floor(diffMs / 60000);
    
    if (diffMins < 1) return 'Just now';
    if (diffMins < 60) return `${diffMins}m ago`;
    
    const diffHours = Math.floor(diffMins / 60);
    if (diffHours < 24) return `${diffHours}h ago`;
    
    return date.toLocaleDateString();
}

function formatDate(dateStr) {
    if (!dateStr) return '--';
    const date = new Date(dateStr);
    return date.toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' });
}

function saveLocalLeaderboard() {
    localStorage.setItem('terx_github_leaderboard', JSON.stringify(githubLeaderboard));
    localStorage.setItem('terx_github_last_updated', new Date().toISOString());
}

function downloadAsJSON(data) {
    const dataStr = JSON.stringify(data, null, 2);
    const dataUri = 'data:application/json;charset=utf-8,' + encodeURIComponent(dataStr);
    
    const exportFileDefaultName = `terx_leaderboard_${new Date().toISOString().split('T')[0]}.json`;
    
    const linkElement = document.createElement('a');
    linkElement.setAttribute('href', dataUri);
    linkElement.setAttribute('download', exportFileDefaultName);
    linkElement.click();
}

// ============================================
// GITHUB API FUNCTIONS
// ============================================

async function createGist(content) {
    try {
        // For demo purposes - in real implementation, you would use GitHub API
        console.log('📝 Creating new Gist with content:', content.length, 'bytes');
        
        // Generate a random Gist ID for demo
        const demoGistId = 'demo_' + Math.random().toString(36).substr(2, 9);
        
        // Save locally
        localStorage.setItem('terx_github_gist_id', demoGistId);
        localStorage.setItem('terx_github_gist_content', content);
        
        showNotification('Demo: Gist created locally (GitHub API would be used in production)', 'info');
        
        return demoGistId;
    } catch (error) {
        console.error('Gist creation error:', error);
        return null;
    }
}

async function updateGist(gistId, content) {
    try {
        // For demo purposes
        console.log('📝 Updating Gist', gistId);
        
        // Save locally
        localStorage.setItem('terx_github_gist_content', content);
        
        showNotification('Demo: Gist updated locally', 'info');
        return true;
    } catch (error) {
        console.error('Gist update error:', error);
        return false;
    }
}

async function loadFromGist(gistId) {
    try {
        // For demo purposes - load from localStorage
        const content = localStorage.getItem('terx_github_gist_content');
        
        if (content) {
            const data = JSON.parse(content);
            if (data.leaderboard) {
                githubLeaderboard = data.leaderboard;
                updateGitHubDisplay();
                showNotification('Loaded leaderboard from local storage', 'success');
                return true;
            }
        }
        
        return false;
    } catch (error) {
        console.error('Gist load error:', error);
        return false;
    }
}

// ============================================
// PUBLIC API FUNCTIONS
// ============================================

function viewGitHubRawData(type) {
    let dataToShow;
    
    switch(type) {
        case 'players':
            dataToShow = githubLeaderboard.players;
            break;
        case 'scores':
            dataToShow = {
                summary: {
                    totalPlayers: githubLeaderboard.totalPlayers,
                    totalScore: githubLeaderboard.totalScore,
                    lastUpdated: githubLeaderboard.lastUpdated
                },
                topPlayers: githubLeaderboard.players.slice(0, 10)
            };
            break;
        case 'games':
            const gameData = JSON.parse(localStorage.getItem('terx_gameData') || '{}');
            dataToShow = gameData;
            break;
        default:
            dataToShow = githubLeaderboard;
    }
    
    const jsonStr = JSON.stringify(dataToShow, null, 2);
    
    // Create modal to show raw data
    const modalHTML = `
        <div class="raw-data-modal">
            <div class="modal-content">
                <div class="modal-header">
                    <i class="fas fa-code"></i>
                    <h3>GitHub Raw ${type.charAt(0).toUpperCase() + type.slice(1)} Data</h3>
                    <button class="close-btn" onclick="closeRawDataModal()">
                        <i class="fas fa-times"></i>
                    </button>
                </div>
                <div class="modal-body">
                    <pre><code>${jsonStr}</code></pre>
                </div>
                <div class="modal-footer">
                    <button class="btn-primary" onclick="copyRawData('${type}')">
                        <i class="fas fa-copy"></i> Copy JSON
                    </button>
                    <button class="btn-secondary" onclick="closeRawDataModal()">
                        Close
                    </button>
                </div>
            </div>
        </div>
    `;
    
    const modal = document.createElement('div');
    modal.innerHTML = modalHTML;
    document.body.appendChild(modal);
}

function closeRawDataModal() {
    const modal = document.querySelector('.raw-data-modal');
    if (modal) modal.remove();
}

function copyRawData(type) {
    const pre = document.querySelector('.raw-data-modal pre');
    if (pre) {
        navigator.clipboard.writeText(pre.textContent);
        showNotification('JSON copied to clipboard!', 'success');
    }
}

function syncWithGitHub() {
    loadGitHubLeaderboard();
    showNotification('Syncing with GitHub...', 'info');
}

// ============================================
// INITIALIZATION
// ============================================

// Make functions available globally
window.loadGitHubLeaderboard = loadGitHubLeaderboard;
window.updateGitHubLeaderboard = updateGitHubLeaderboard;
window.exportLeaderboardToGitHub = exportLeaderboardToGitHub;
window.viewGitHubRawData = viewGitHubRawData;
window.closeRawDataModal = closeRawDataModal;
window.copyRawData = copyRawData;
window.syncWithGitHub = syncWithGitHub;

console.log('✅ GitHub Leaderboard System Ready!');

// Auto-load leaderboard after a delay
setTimeout(() => {
    if (typeof loadGitHubLeaderboard === 'function') {
        loadGitHubLeaderboard();
    }
}, 1500); and 