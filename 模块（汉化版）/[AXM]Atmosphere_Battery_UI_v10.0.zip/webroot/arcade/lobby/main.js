// ==================== ATMOSPHERE ARCADE - LOCAL FILE VERSION ====================

// Configuration
const ARCADE_DATA = {
    games: {
        snake: { name: "Snake Classic", highScore: 0, lastScore: 0 },
        car: { name: "Highway Rush", highScore: 0, lastScore: 0 },
        battery: { name: "Battery Dash", highScore: 0, lastScore: 0 }
    },
    player: {
        name: '',
        stats: {
            totalScore: 0,
            gamesPlayed: 0,
            bestScore: 0
        }
    }
};

// ==================== INITIALIZATION ====================
function initArcade() {
    console.log('🎮 Arcade Initializing...');
    console.log('📍 Current URL:', window.location.href);
    
    // Load data
    loadData();
    
    // Update UI
    updateUI();
    
    // Check if player needs name
    if (!ARCADE_DATA.player.name) {
        setTimeout(showNameModal, 500);
    }
    
    // Check for returning game
    checkForReturnedScore();
    
    console.log('✅ Arcade ready!');
}

// ==================== DATA MANAGEMENT ====================
function loadData() {
    try {
        // Load player name
        const savedName = localStorage.getItem('arcade_player');
        if (savedName) {
            ARCADE_DATA.player.name = savedName;
        }
        
        // Load game data
        const savedGames = localStorage.getItem('arcade_games');
        if (savedGames) {
            const games = JSON.parse(savedGames);
            Object.keys(ARCADE_DATA.games).forEach(game => {
                if (games[game]) {
                    ARCADE_DATA.games[game] = games[game];
                }
            });
        }
        
        // Load stats
        const savedStats = localStorage.getItem('arcade_stats');
        if (savedStats) {
            ARCADE_DATA.player.stats = JSON.parse(savedStats);
        }
    } catch (e) {
        console.log('⚠️ Starting fresh');
    }
}

function saveData() {
    try {
        // Save player name
        if (ARCADE_DATA.player.name) {
            localStorage.setItem('arcade_player', ARCADE_DATA.player.name);
        }
        
        // Save game data
        localStorage.setItem('arcade_games', JSON.stringify(ARCADE_DATA.games));
        
        // Save stats
        localStorage.setItem('arcade_stats', JSON.stringify(ARCADE_DATA.player.stats));
    } catch (e) {
        console.error('Error saving:', e);
    }
}

// ==================== NAME MODAL ====================
function showNameModal() {
    // Create modal HTML
    const modalHTML = `
        <div id="nameModal" style="
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: rgba(0,0,0,0.95);
            display: flex;
            align-items: center;
            justify-content: center;
            z-index: 10000;
        ">
            <div style="
                background: rgba(28,28,30,0.95);
                border-radius: 20px;
                padding: 30px;
                width: 85%;
                max-width: 400px;
                border: 1px solid rgba(255,255,255,0.1);
                text-align: center;
            ">
                <div style="margin-bottom: 25px;">
                    <div style="
                        width: 80px;
                        height: 80px;
                        background: linear-gradient(135deg, #007AFF, #5856D6);
                        border-radius: 20px;
                        display: flex;
                        align-items: center;
                        justify-content: center;
                        font-size: 36px;
                        margin: 0 auto 15px;
                    ">
                        👤
                    </div>
                    <h2 style="font-size: 24px; font-weight: 700; margin-bottom: 10px;">
                        Welcome to Arcade!
                    </h2>
                    <p style="color: #8E8E93; font-size: 16px;">
                        Enter your name to save scores
                    </p>
                </div>
                
                <div style="margin-bottom: 25px;">
                    <input 
                        type="text" 
                        id="nameInput"
                        placeholder="Your name"
                        style="
                            width: 100%;
                            padding: 15px;
                            background: rgba(44,44,46,0.8);
                            border: 1px solid rgba(255,255,255,0.1);
                            border-radius: 12px;
                            color: white;
                            font-size: 17px;
                            text-align: center;
                            outline: none;
                        "
                        maxlength="15"
                        autocomplete="off"
                    >
                </div>
                
                <div style="display: flex; gap: 10px;">
                    <button onclick="setRandomName()" style="
                        flex: 1;
                        padding: 15px;
                        background: rgba(44,44,46,0.8);
                        color: white;
                        border: 1px solid rgba(255,255,255,0.1);
                        border-radius: 12px;
                        font-size: 16px;
                        font-weight: 500;
                        cursor: pointer;
                    ">
                        Random
                    </button>
                    <button onclick="saveName()" style="
                        flex: 1;
                        padding: 15px;
                        background: #007AFF;
                        color: white;
                        border: none;
                        border-radius: 12px;
                        font-size: 16px;
                        font-weight: 600;
                        cursor: pointer;
                    ">
                        Start
                    </button>
                </div>
            </div>
        </div>
    `;
    
    document.body.insertAdjacentHTML('beforeend', modalHTML);
    
    // Focus input
    setTimeout(() => {
        const input = document.getElementById('nameInput');
        if (input) {
            input.focus();
            input.addEventListener('keypress', (e) => {
                if (e.key === 'Enter') saveName();
            });
        }
    }, 100);
}

function hideNameModal() {
    const modal = document.getElementById('nameModal');
    if (modal) modal.remove();
}

function setRandomName() {
    const names = ['Player', 'Gamer', 'Champion', 'Pro'];
    const input = document.getElementById('nameInput');
    if (input) {
        input.value = names[Math.floor(Math.random() * names.length)];
    }
}

function saveName() {
    const input = document.getElementById('nameInput');
    if (!input) return;
    
    let name = input.value.trim();
    
    if (!name) {
        showNotification('Please enter a name', 'error');
        return;
    }
    
    ARCADE_DATA.player.name = name;
    saveData();
    hideNameModal();
    updateUI();
    showNotification(`Welcome, ${name}!`, 'success');
}

// ==================== GAME LAUNCHING - FIXED FOR LOCAL FILES ====================
function launchGame(gameId) {
    if (!ARCADE_DATA.games[gameId]) {
        showNotification('Game not found', 'error');
        return;
    }
    
    const game = ARCADE_DATA.games[gameId];
    console.log(`🚀 Launching: ${game.name}`);
    
    // Show loading
    const loading = document.getElementById('loadingOverlay');
    const loadingText = document.getElementById('loadingText');
    const loadingSub = document.getElementById('loadingSubtext');
    
    if (loading && loadingText && loadingSub) {
        loadingText.textContent = `Launching ${game.name}`;
        loadingSub.textContent = 'Please wait...';
        loading.classList.add('active');
    }
    
    // Get the CORRECT path based on current location
    const gamePath = getGamePath(gameId);
    console.log(`📍 Game path: ${gamePath}`);
    
    // Save session info
    localStorage.setItem('arcade_current_game', gameId);
    localStorage.setItem('arcade_return_path', window.location.href);
    
    // Try to launch game with timeout
    setTimeout(() => {
        console.log(`🔄 Attempting to navigate to: ${gamePath}`);
        
        // Method 1: Direct navigation
        try {
            // For local files, we need to use relative paths
            window.location.href = gamePath;
        } catch (error) {
            console.error('Navigation error:', error);
            
            // Method 2: Create iframe
            loadGameInIframe(gamePath);
        }
    }, 500);
}

// FIXED PATH FUNCTION - This is the key fix!
function getGamePath(gameId) {
    const currentUrl = window.location.href;
    console.log('🔍 Current URL:', currentUrl);
    
    // Check where we are and construct correct path
    if (currentUrl.includes('ax://plugin.local')) {
        // We're coming from battery tweaks via ax:// protocol
        // Games are in: /data/user_de/0/com.android.shell/axeron/plugins/atmosphere_battery/webroot/arcade/
        // So we need to go to the game subdirectory
        return `arcade/${gameId}/index.html`;
    } else if (currentUrl.includes('/arcade/')) {
        // We're already in arcade directory
        return `${gameId}/index.html`;
    } else if (currentUrl.includes('file://')) {
        // We're loading from local file system
        return `${gameId}/index.html`;
    } else {
        // Default fallback
        return `${gameId}/index.html`;
    }
}

function loadGameInIframe(path) {
    // Create fullscreen container
    const container = document.createElement('div');
    container.style.cssText = `
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background: black;
        z-index: 9998;
    `;
    
    // Create iframe
    const iframe = document.createElement('iframe');
    iframe.style.cssText = `
        width: 100%;
        height: 100%;
        border: none;
    `;
    iframe.src = path;
    
    // Create close button
    const closeBtn = document.createElement('button');
    closeBtn.innerHTML = '✕ Close Game';
    closeBtn.style.cssText = `
        position: fixed;
        top: 20px;
        right: 20px;
        z-index: 9999;
        background: rgba(0,0,0,0.7);
        color: white;
        border: 1px solid rgba(255,255,255,0.3);
        border-radius: 20px;
        padding: 10px 20px;
        font-size: 14px;
        cursor: pointer;
    `;
    closeBtn.onclick = function() {
        document.body.removeChild(container);
        document.body.removeChild(closeBtn);
        
        // Hide loading
        const loading = document.getElementById('loadingOverlay');
        if (loading) loading.classList.remove('active');
        
        // Check for score
        setTimeout(checkForReturnedScore, 500);
    };
    
    // Add to page
    container.appendChild(iframe);
    document.body.appendChild(container);
    document.body.appendChild(closeBtn);
}

// ==================== SCORE MANAGEMENT ====================
function checkForReturnedScore() {
    console.log('🔍 Checking for returned score...');
    
    // Check URL parameters
    const urlParams = new URLSearchParams(window.location.search);
    const game = urlParams.get('game');
    const score = urlParams.get('score');
    
    if (game && score) {
        console.log(`🎯 Found score in URL: ${game} = ${score}`);
        processScore(game, parseInt(score));
        
        // Clean URL
        window.history.replaceState({}, '', window.location.pathname);
        return;
    }
    
    // Check localStorage
    const pending = localStorage.getItem('arcade_pending_score');
    if (pending) {
        try {
            const data = JSON.parse(pending);
            if (data.game && data.score) {
                console.log(`📥 Found pending score: ${data.game} = ${data.score}`);
                processScore(data.game, data.score);
                localStorage.removeItem('arcade_pending_score');
            }
        } catch (e) {
            localStorage.removeItem('arcade_pending_score');
        }
    }
}

function processScore(gameId, score) {
    if (!ARCADE_DATA.games[gameId] || !score || score < 0) return;
    
    const game = ARCADE_DATA.games[gameId];
    
    // Update game stats
    game.lastScore = score;
    
    // Check for high score
    if (score > game.highScore) {
        game.highScore = score;
        showNotification(`🎉 NEW HIGH SCORE! ${score}`, 'success');
    } else {
        showNotification(`Score: ${score}`, 'info');
    }
    
    // Update player stats
    ARCADE_DATA.player.stats.totalScore += score;
    ARCADE_DATA.player.stats.gamesPlayed++;
    
    if (score > ARCADE_DATA.player.stats.bestScore) {
        ARCADE_DATA.player.stats.bestScore = score;
    }
    
    // Save data
    saveData();
    
    // Update UI
    updateUI();
    
    console.log(`✅ Score processed: ${score} in ${game.name}`);
}

// ==================== UI UPDATES ====================
function updateUI() {
    // Player info
    document.getElementById('playerName').textContent = ARCADE_DATA.player.name || 'Guest Player';
    
    // Update status
    const statusEl = document.getElementById('playerStatus');
    if (statusEl) {
        statusEl.textContent = ARCADE_DATA.player.name ? 
            `Total: ${ARCADE_DATA.player.stats.totalScore}` : 
            'Tap profile to set name';
    }
    
    // Update stats
    document.getElementById('totalScore').textContent = ARCADE_DATA.player.stats.totalScore.toLocaleString();
    document.getElementById('gamesPlayed').textContent = ARCADE_DATA.player.stats.gamesPlayed;
    document.getElementById('highScore').textContent = ARCADE_DATA.player.stats.bestScore.toLocaleString();
    document.getElementById('playTime').textContent = '0m'; // Placeholder
    
    // Update game stats
    document.getElementById('snakeHighScore').textContent = ARCADE_DATA.games.snake.highScore.toLocaleString();
    document.getElementById('snakeLastScore').textContent = ARCADE_DATA.games.snake.lastScore.toLocaleString();
    document.getElementById('carHighScore').textContent = ARCADE_DATA.games.car.highScore.toLocaleString();
    document.getElementById('carLastScore').textContent = ARCADE_DATA.games.car.lastScore.toLocaleString();
    document.getElementById('batteryHighScore').textContent = ARCADE_DATA.games.battery.highScore.toLocaleString();
    document.getElementById('batteryLastScore').textContent = ARCADE_DATA.games.battery.lastScore.toLocaleString();
}

// ==================== NOTIFICATION ====================
function showNotification(message, type = 'info') {
    // Remove existing
    document.querySelectorAll('.notification').forEach(n => n.remove());
    
    // Create notification
    const notification = document.createElement('div');
    notification.className = `notification ${type}`;
    
    const icons = {
        success: '✅',
        error: '❌',
        info: 'ℹ️',
        warning: '⚠️'
    };
    
    notification.innerHTML = `
        <div class="notification-icon">${icons[type] || icons.info}</div>
        <div class="notification-text">${message}</div>
    `;
    
    document.body.appendChild(notification);
    
    // Auto-remove
    setTimeout(() => {
        if (notification.parentNode) {
            notification.remove();
        }
    }, 3000);
}

// ==================== START ARCADE ====================
document.addEventListener('DOMContentLoaded', function() {
    // Enable scrolling
    document.body.style.overflow = 'auto';
    
    // Initialize
    setTimeout(initArcade, 100);
});

// ==================== GLOBAL FUNCTIONS ====================
window.launchGame = launchGame;
window.saveName = saveName;
window.setRandomName = setRandomName;
window.showNotification = showNotification;