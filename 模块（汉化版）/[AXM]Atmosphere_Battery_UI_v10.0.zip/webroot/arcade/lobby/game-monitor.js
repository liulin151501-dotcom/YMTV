// ============================================
// game-monitor.js - Auto Score Detection System
// ============================================

console.log('📡 Game Monitor - Auto Score Detection');

class GameMonitor {
    constructor() {
        this.currentGame = null;
        this.lastScores = {};
        this.detectedScores = [];
        this.monitoringInterval = null;
        
        this.init();
    }
    
    init() {
        console.log('🎯 Initializing auto-score detection...');
        this.startMonitoring();
        this.setupGameListeners();
    }
    
    // Start monitoring for game scores
    startMonitoring() {
        // Check every 2 seconds for game activity
        this.monitoringInterval = setInterval(() => {
            this.checkForGameActivity();
            this.saveDetectedScores();
        }, 2000);
        
        console.log('✅ Auto-score monitoring started');
    }
    
    // Setup game event listeners
    setupGameListeners() {
        // Listen for game iframe messages
        window.addEventListener('message', (event) => {
            this.handleGameMessage(event);
        });
        
        // Listen for storage changes (games saving scores)
        window.addEventListener('storage', (event) => {
            if (event.key === 'terx_game_score') {
                this.handleStorageScore(event.newValue);
            }
        });
        
        // Listen for page visibility changes (game closed)
        document.addEventListener('visibilitychange', () => {
            if (document.hidden) {
                this.checkForFinalScore();
            }
        });
    }
    
    // Handle game messages
    handleGameMessage(event) {
        try {
            const data = event.data;
            if (data && data.type === 'game_score') {
                console.log('📨 Game score received:', data);
                this.processScore(data.game, data.score);
            }
        } catch (e) {
            console.log('Message error:', e);
        }
    }
    
    // Handle storage scores
    handleStorageScore(scoreData) {
        try {
            const data = JSON.parse(scoreData);
            if (data.game && data.score) {
                console.log('💾 Storage score detected:', data);
                this.processScore(data.game, data.score);
                localStorage.removeItem('terx_game_score');
            }
        } catch (e) {
            localStorage.removeItem('terx_game_score');
        }
    }
    
    // Check for game activity
    checkForGameActivity() {
        // Check URL for game parameters
        const params = new URLSearchParams(window.location.search);
        const game = params.get('game');
        const score = params.get('score');
        
        if (game && score) {
            console.log(`🔗 URL score detected: ${game} = ${score}`);
            this.processScore(game, parseInt(score));
            
            // Clean URL
            window.history.replaceState({}, document.title, window.location.pathname);
        }
        
        // Check for game windows
        this.checkGameWindows();
    }
    
    // Check game windows/iframes
    checkGameWindows() {
        const iframes = document.getElementsByTagName('iframe');
        
        for (let iframe of iframes) {
            try {
                // Try to access iframe content
                const iframeDoc = iframe.contentDocument || iframe.contentWindow.document;
                
                // Look for score elements
                const scoreElements = iframeDoc.querySelectorAll('[id*="score"], [class*="score"], #points, .points, #currentScore');
                
                scoreElements.forEach(element => {
                    const text = element.textContent || element.value || '';
                    const match = text.match(/\d+/);
                    
                    if (match) {
                        const score = parseInt(match[0]);
                        const gameId = this.detectGameFromIframe(iframe);
                        
                        if (gameId && score > 0) {
                            this.recordScore(gameId, score);
                        }
                    }
                });
                
                // Check for game over screens
                const gameOverElements = iframeDoc.querySelectorAll('#gameOver, .game-over, #endScreen, .end-screen');
                if (gameOverElements.length > 0) {
                    this.checkForFinalScore();
                }
                
            } catch (e) {
                // Cross-origin error, try postMessage
                iframe.contentWindow.postMessage({ type: 'request_score' }, '*');
            }
        }
    }
    
    // Detect game from iframe
    detectGameFromIframe(iframe) {
        const src = iframe.src || '';
        
        if (src.includes('snake')) return 'snake';
        if (src.includes('car')) return 'car';
        if (src.includes('battery')) return 'battery';
        
        return null;
    }
    
    // Record score
    recordScore(gameId, score) {
        if (!gameId || !score || score <= 0) return;
        
        // Check if this is a new high score for this session
        const lastScore = this.lastScores[gameId] || 0;
        
        if (score > lastScore) {
            this.lastScores[gameId] = score;
            
            // Add to detected scores
            this.detectedScores.push({
                game: gameId,
                score: score,
                time: Date.now(),
                source: 'auto-detection'
            });
            
            console.log(`🎯 Score recorded: ${gameId} = ${score}`);
        }
    }
    
    // Process score
    processScore(gameId, score) {
        if (!gameId || !score || score <= 0) return false;
        
        // Save to localStorage for main arcade to pick up
        const scoreData = {
            game: gameId,
            score: score,
            time: Date.now(),
            detected: true
        };
        
        // Save in multiple ways for reliability
        localStorage.setItem('terx_pendingScore', JSON.stringify(scoreData));
        
        // Also save to auto scores array
        let autoScores = JSON.parse(localStorage.getItem('terx_auto_scores') || '[]');
        autoScores.push(scoreData);
        localStorage.setItem('terx_auto_scores', JSON.stringify(autoScores));
        
        console.log(`✅ Score saved for processing: ${gameId} = ${score}`);
        return true;
    }
    
    // Check for final score when game closes
    checkForFinalScore() {
        const currentGame = localStorage.getItem('terx_currentGame');
        const highestScore = this.lastScores[currentGame];
        
        if (currentGame && highestScore && highestScore > 0) {
            console.log(`🏁 Final score detected for ${currentGame}: ${highestScore}`);
            this.processScore(currentGame, highestScore);
            
            // Clear session data
            this.lastScores[currentGame] = 0;
            localStorage.removeItem('terx_currentGame');
        }
    }
    
    // Save detected scores
    saveDetectedScores() {
        if (this.detectedScores.length > 0) {
            // Save to localStorage
            localStorage.setItem('terx_detected_scores', JSON.stringify(this.detectedScores));
            
            // Clear old scores (keep only last 10 minutes)
            const tenMinutesAgo = Date.now() - 600000;
            this.detectedScores = this.detectedScores.filter(score => score.time > tenMinutesAgo);
        }
    }
    
    // Get detected scores
    getDetectedScores() {
        return this.detectedScores;
    }
    
    // Stop monitoring
    stopMonitoring() {
        if (this.monitoringInterval) {
            clearInterval(this.monitoringInterval);
            this.monitoringInterval = null;
        }
    }
}

// Create global instance
window.GameMonitor = new GameMonitor();

// Helper function for games to send scores easily
function sendAutoScore(gameId,)