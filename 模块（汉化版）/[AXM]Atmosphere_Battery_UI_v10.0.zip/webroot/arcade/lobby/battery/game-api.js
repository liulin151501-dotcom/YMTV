// game-api.js - Atmosphere Arcade Game API
// Place this in the same folder as index.html

class AtmosphereGameAPI {
    constructor(gameId, gameName) {
        this.gameId = gameId;
        this.gameName = gameName;
        this.parentWindow = window.parent;
        this.isInArcade = window.location !== window.parent.location;
        this.apiReady = false;
        this.score = 0;
        
        this.init();
    }
    
    init() {
        // Check if we're in the arcade
        if (this.isInArcade) {
            console.log(`🎮 Atmosphere API: ${this.gameName} initialized in arcade`);
            
            // Listen for messages from arcade
            window.addEventListener('message', this.handleMessage.bind(this));
            
            // Send ready signal to arcade
            this.sendMessage({
                type: 'API_READY',
                gameId: this.gameId,
                gameName: this.gameName,
                timestamp: new Date().toISOString()
            });
            
            this.apiReady = true;
            
        } else {
            console.log('🔧 Atmosphere API: Running outside arcade - scores will not be saved');
        }
    }
    
    handleMessage(event) {
        // Handle messages from parent (arcade)
        if (event.data && typeof event.data === 'object') {
            console.log('Arcade message received:', event.data);
            
            switch (event.data.type) {
                case 'SCORE_RECEIVED':
                    console.log('✅ Arcade confirmed score received:', event.data);
                    if (this.onScoreReceived) {
                        this.onScoreReceived(event.data);
                    }
                    break;
                    
                case 'GAME_CLOSING':
                    console.log('🔙 Arcade is closing the game');
                    if (this.onGameClosing) {
                        this.onGameClosing();
                    }
                    break;
                    
                case 'GAME_PAUSED':
                    console.log('⏸️ Game paused by arcade');
                    if (this.onGamePaused) {
                        this.onGamePaused();
                    }
                    break;
                    
                case 'GAME_RESUMED':
                    console.log('▶️ Game resumed by arcade');
                    if (this.onGameResumed) {
                        this.onGameResumed();
                    }
                    break;
            }
        }
    }
    
    sendMessage(data) {
        if (this.isInArcade && this.parentWindow) {
            const message = {
                ...data,
                gameId: this.gameId,
                gameName: this.gameName,
                timestamp: new Date().toISOString(),
                version: '1.0'
            };
            
            try {
                this.parentWindow.postMessage(message, '*');
                console.log('📤 API Message sent:', message);
            } catch (error) {
                console.error('❌ Failed to send message:', error);
            }
        } else {
            console.log('📤 API Message (outside arcade):', data);
        }
    }
    
    // PUBLIC API METHODS - Games should use these
    
    // Report current score
    reportScore(score, additionalData = {}) {
        this.score = score;
        
        this.sendMessage({
            type: 'SCORE_UPDATE',
            score: score,
            ...additionalData
        });
        
        console.log(`📊 Score reported: ${score}`);
    }
    
    // Report game start
    reportGameStart(initialData = {}) {
        this.sendMessage({
            type: 'GAME_START',
            ...initialData
        });
    }
    
    // Report game over with final score
    reportGameOver(score, additionalData = {}) {
        this.reportScore(score, {
            ...additionalData,
            event: 'GAME_OVER',
            isFinal: true
        });
        
        this.sendMessage({
            type: 'GAME_OVER',
            score: score,
            ...additionalData
        });
    }
    
    // Report game pause
    reportGamePause() {
        this.sendMessage({
            type: 'GAME_PAUSE'
        });
    }
    
    // Report game resume
    reportGameResume() {
        this.sendMessage({
            type: 'GAME_RESUME'
        });
    }
    
    // Report level completion
    reportLevelComplete(level, score, time) {
        this.sendMessage({
            type: 'LEVEL_COMPLETE',
            level: level,
            score: score,
            time: time
        });
    }
    
    // Report achievement unlocked
    reportAchievement(achievementId, achievementName, scoreBonus = 0) {
        this.sendMessage({
            type: 'ACHIEVEMENT_UNLOCKED',
            achievementId: achievementId,
            achievementName: achievementName,
            scoreBonus: scoreBonus
        });
    }
    
    // Get current score
    getCurrentScore() {
        return this.score;
    }
    
    // Check if API is available
    isApiAvailable() {
        return this.isInArcade && this.apiReady;
    }
    
    // Get game info
    getGameInfo() {
        return {
            gameId: this.gameId,
            gameName: this.gameName,
            inArcade: this.isInArcade,
            apiReady: this.apiReady
        };
    }
    
    // Callbacks - Games can set these
    onScoreReceived = null;
    onGameClosing = null;
    onGamePaused = null;
    onGameResumed = null;
}

// Auto-initialize if game ID is detected in URL
(function() {
    const urlParams = new URLSearchParams(window.location.search);
    const gameId = urlParams.get('game_id');
    const arcadeApi = urlParams.get('arcade_api');
    
    if (gameId && arcadeApi === 'true' && window !== window.parent) {
        // Auto-create global API instance
        window.AtmosphereAPI = new AtmosphereGameAPI(
            gameId,
            document.title.replace('Atmosphere Arcade - ', '').replace(' | Game', '') || 'Unknown Game'
        );
        
        // Auto-report game start after a short delay
        setTimeout(() => {
            if (window.AtmosphereAPI.isApiAvailable()) {
                window.AtmosphereAPI.reportGameStart();
            }
        }, 1000);
    }
})();

// Export for module systems
if (typeof module !== 'undefined' && module.exports) {
    module.exports = AtmosphereGameAPI;
}

// Global helper function for quick score reporting
window.reportArcadeScore = function(score, data = {}) {
    if (window.AtmosphereAPI && window.AtmosphereAPI.isApiAvailable()) {
        window.AtmosphereAPI.reportScore(score, data);
        return true;
    }
    return false;
};