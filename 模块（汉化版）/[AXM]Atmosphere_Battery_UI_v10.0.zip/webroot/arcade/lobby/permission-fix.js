// ============================================
// permission-fix.js - Android Permission Helper
// ============================================

console.log('🔧 Android Permission Fix Loaded');

// Check if we can access files
function checkFileAccess(path) {
    return new Promise((resolve) => {
        const xhr = new XMLHttpRequest();
        xhr.open('HEAD', path, true);
        xhr.onreadystatechange = function() {
            if (xhr.readyState === 4) {
                resolve(xhr.status === 200 || xhr.status === 0);
            }
        };
        xhr.onerror = function() {
            resolve(false);
        };
        setTimeout(() => resolve(false), 1000);
        xhr.send();
    });
}

// Fix game paths for Android
function fixGamePaths() {
    console.log('🔧 Fixing game paths for Android...');
    
    const games = ['snake', 'car', 'battery'];
    const basePath = window.location.pathname.replace(/\/[^\/]*$/, '/');
    
    games.forEach(async (game) => {
        const gamePath = `${basePath}${game}/index.html`;
        const canAccess = await checkFileAccess(gamePath);
        
        console.log(`📁 ${game}: ${canAccess ? 'Accessible' : 'Restricted'}`);
        
        if (!canAccess) {
            // Create a workaround
            createGameWorkaround(game);
        }
    });
}

// Create workaround for restricted games
function createGameWorkaround(gameId) {
    console.log(`🛠️ Creating workaround for ${gameId}`);
    
    // Create an iframe wrapper
    const wrapper = document.createElement('div');
    wrapper.id = `game-wrapper-${gameId}`;
    wrapper.style.display = 'none';
    wrapper.style.position = 'fixed';
    wrapper.style.top = '0';
    wrapper.style.left = '0';
    wrapper.style.width = '100%';
    wrapper.style.height = '100%';
    wrapper.style.zIndex = '9999';
    wrapper.style.background = '#000';
    document.body.appendChild(wrapper);
    
    // Add close button
    const closeBtn = document.createElement('button');
    closeBtn.innerHTML = '✕ Close Game';
    closeBtn.style.position = 'absolute';
    closeBtn.style.top = '10px';
    closeBtn.style.right = '10px';
    closeBtn.style.zIndex = '10000';
    closeBtn.style.padding = '10px 20px';
    closeBtn.style.background = '#ff6b6b';
    closeBtn.style.color = 'white';
    closeBtn.style.border = 'none';
    closeBtn.style.borderRadius = '5px';
    closeBtn.style.cursor = 'pointer';
    closeBtn.onclick = function() {
        wrapper.style.display = 'none';
    };
    wrapper.appendChild(closeBtn);
    
    console.log(`✅ Workaround created for ${gameId}`);
}

// Initialize
document.addEventListener('DOMContentLoaded', function() {
    setTimeout(fixGamePaths, 1000);
});

console.log('✅ Permission Fix Ready');