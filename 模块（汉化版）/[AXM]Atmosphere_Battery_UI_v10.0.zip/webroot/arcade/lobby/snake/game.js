// ==================== SIMPLE GAME API ====================
// Place this in your game folder and include it in your game HTML

// Function to submit score
function submitScore(gameId, score) {
    console.log(`🎮 [Game] Submitting score: ${gameId} = ${score}`);
    
    // Method 1: Try to call parent function
    try {
        if (window.parent && window.parent.submitGameScore) {
            window.parent.submitGameScore(gameId, score);
            return true;
        }
    } catch (e) {
        console.log('Parent call failed:', e);
    }
    
    // Method 2: Use localStorage
    try {
        localStorage.setItem('arcade_pending_score', JSON.stringify({
            game: gameId,
            score: score,
            timestamp: Date.now()
        }));
        
        // Also save as auto score
        localStorage.setItem('arcade_auto_score', JSON.stringify({
            game: gameId,
            score: score
        }));
    } catch (e) {
        console.log('localStorage failed:', e);
    }
    
    // Method 3: Post message
    try {
        if (window.parent) {
            window.parent.postMessage({
                type: 'gameScore',
                gameId: gameId,
                score: score
            }, '*');
        }
    } catch (e) {
        console.log('postMessage failed:', e);
    }
    
    // Show game over screen
    showSimpleGameOver(score);
    
    return true;
}

function showSimpleGameOver(score) {
    // Remove existing screen
    const existing = document.getElementById('simpleGameOver');
    if (existing) existing.remove();
    
    const screenHTML = `
        <div id="simpleGameOver" style="
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0,0,0,0.95);
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            z-index: 9999;
            color: white;
            text-align: center;
            padding: 20px;
        ">
            <div style="font-size: 60px; margin-bottom: 20px;">🏆</div>
            <h1 style="font-size: 32px; margin-bottom: 10px;">GAME OVER</h1>
            <div style="font-size: 48px; font-weight: bold; color: #FFD60A; margin-bottom: 30px;">
                ${score}
            </div>
            
            <div style="display: flex; flex-direction: column; gap: 15px; width: 100%; max-width: 300px;">
                <button onclick="returnToLobby()" style="
                    padding: 15px;
                    background: #007AFF;
                    color: white;
                    border: none;
                    border-radius: 12px;
                    font-size: 18px;
                    font-weight: 600;
                    cursor: pointer;
                ">
                    🏆 SUBMIT & EXIT
                </button>
                
                <button onclick="playAgain()" style="
                    padding: 15px;
                    background: rgba(255,255,255,0.1);
                    color: white;
                    border: 1px solid rgba(255,255,255,0.2);
                    border-radius: 12px;
                    font-size: 18px;
                    cursor: pointer;
                ">
                    🔄 PLAY AGAIN
                </button>
            </div>
        </div>
    `;
    
    document.body.insertAdjacentHTML('beforeend', screenHTML);
}

function returnToLobby() {
    console.log('🔄 Returning to lobby...');
    
    // Try multiple methods to return
    try {
        // Method 1: Parent navigation
        if (window.parent && window.parent.closeGame) {
            window.parent.closeGame();
            return;
        }
    } catch (e) {}
    
    try {
        // Method 2: History back
        window.history.back();
    } catch (e) {}
    
    try {
        // Method 3: Navigate to lobby
        setTimeout(() => {
            window.location.href = '../index.html';
        }, 500);
    } catch (e) {}
}

function playAgain() {
    window.location.reload();
}

// Auto-detect game ID from URL
function getGameId() {
    const path = window.location.pathname;
    if (path.includes('/snake/')) return 'snake';
    if (path.includes('/car/')) return 'car';
    if (path.includes('/battery/')) return 'battery';
    return 'unknown';
}

// Make functions globally available
window.submitScore = submitScore;
window.showSimpleGameOver = showSimpleGameOver;
window.returnToLobby = returnToLobby;
window.playAgain = playAgain;
window.getGameId = getGameId;

console.log('🎮 Game API loaded. Game ID:', getGameId());