// send-score.js para sa Snake Game
// Ilagay sa: terx-arcade/snake/send-score.js

function sendSnakeScore(score) {
    console.log('🐍 Snake Game Score:', score);
    
    // Call the main bridge function
    if (window.sendScoreToArcade) {
        window.sendScoreToArcade('snake', score);
    } else {
        // Fallback
        localStorage.setItem('terx_pendingScore', JSON.stringify({
            game: 'snake',
            score: score,
            time: Date.now()
        }));
        
        setTimeout(() => {
            window.location.href = '../index.html?game=snake&score=' + score;
        }, 2000);
    }
}

// Make available globally
window.sendSnakeScore = sendSnakeScore;
console.log('✅ Snake Score Sender Ready!');