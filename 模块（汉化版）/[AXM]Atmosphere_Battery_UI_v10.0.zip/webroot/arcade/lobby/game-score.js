// ============================================
// GAME SCORE SUBMISSION SYSTEM
// Include this in your game HTML files
// ============================================

// Function to submit score back to arcade
function submitGameScore(gameId, score) {
    console.log(`🎮 Submitting score: ${gameId} = ${score}`);
    
    // Try multiple methods to send score back
    
    // Method 1: Save to localStorage for auto-detection
    localStorage.setItem('arcade_auto_score', JSON.stringify({
        game: gameId,
        score: score,
        timestamp: Date.now()
    }));
    
    // Method 2: Save as pending score
    localStorage.setItem('arcade_pending_score', JSON.stringify({
        game: gameId,
        score: score
    }));
    
    // Method 3: Try to navigate back with URL parameters
    try {
        const returnUrl = localStorage.getItem('arcade_return_url') || '../index.html';
        const newUrl = `${returnUrl}?game=${encodeURIComponent(gameId)}&score=${encodeURIComponent(score)}`;
        console.log(`🔄 Returning to: ${newUrl}`);
        
        // Try navigation
        setTimeout(() => {
            window.location.href = newUrl;
        }, 500);
    } catch (e) {
        console.error('Navigation error:', e);
    }
    
    // Show message to player
    alert(`Score submitted: ${score}\nReturning to arcade...`);
}

// Function for games to call when game ends
function gameOver(gameId, finalScore) {
    console.log(`🎮 Game over: ${gameId} - Score: ${finalScore}`);
    
    // Create game over screen
    const gameOverHTML = `
        <div style="
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.9);
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            z-index: 9999;
            color: white;
            text-align: center;
            padding: 20px;
        ">
            <h1 style="font-size: 3em; color: #ff6b6b; margin-bottom: 10px;">GAME OVER</h1>
            <h2 style="font-size: 2em; margin-bottom: 20px;">Score: ${finalScore}</h2>
            
            <div style="margin-bottom: 30px;">
                <button onclick="submitGameScore('${gameId}', ${finalScore})" style="
                    padding: 15px 30px;
                    background: linear-gradient(90deg, #ff6b6b, #6b6bff);
                    color: white;
                    border: none;
                    border-radius: 10px;
                    font-size: 1.2em;
                    font-weight: bold;
                    cursor: pointer;
                    margin: 10px;
                ">
                    🏆 SUBMIT SCORE
                </button>
                
                <button onclick="window.location.reload()" style="
                    padding: 15px 30px;
                    background: rgba(255, 255, 255, 0.1);
                    color: white;
                    border: 1px solid rgba(255, 255, 255, 0.3);
                    border-radius: 10px;
                    font-size: 1.2em;
                    cursor: pointer;
                    margin: 10px;
                ">
                    🔄 PLAY AGAIN
                </button>
            </div>
            
            <p style="color: #aaa; max-width: 400px;">
                Your score will be saved to the arcade leaderboard
            </p>
        </div>
    `;
    
    // Add to page
    document.body.insertAdjacentHTML('beforeend', gameOverHTML);
}

// Make functions available globally
window.submitGameScore = submitGameScore;
window.gameOver = gameOver;