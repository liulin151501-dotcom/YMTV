// game-api.js - FIXED: No Duplicate, All Games Working
// Place in: /arcade/lobby/game-api.js

console.log('🎮 Atmosphere Arcade API Loaded');

// Check if already loaded to prevent duplicates
if (window.AtmosphereAPI) {
    console.log('⚠️ API already loaded, skipping...');
} else {

// Universal API for ALL games
window.AtmosphereAPI = {
    
    // Send score to arcade
    sendScore: function(score, gameName = null) {
        console.log(`📤 Sending score: ${score} (Game: ${gameName || 'auto'})`);
        
        // Auto-detect game
        if (!gameName) {
            gameName = this.detectGame();
        }
        
        // VALIDATE game name
        if (!this.isValidGame(gameName)) {
            console.error(`❌ Invalid game name: ${gameName}`);
            gameName = this.detectGame(); // Try to auto-detect again
        }
        
        // Send to parent (arcade lobby) - ONLY ONE FORMAT
        try {
            if (window.parent && window.parent !== window) {
                // SEND ONLY ONE FORMAT to prevent duplicates
                window.parent.postMessage({
                    type: 'GAME_SCORE',
                    game: gameName,
                    gameId: gameName,
                    score: parseInt(score),
                    timestamp: Date.now(),
                    source: 'game-api'
                }, '*');
                
                console.log(`✅ Score ${score} sent for ${gameName}`);
                return true;
            }
        } catch (e) {
            console.log('⚠️ Cannot send to parent:', e);
        }
        
        // Save to localStorage as backup
        try {
            localStorage.setItem(`arcade_last_score_${gameName}`, score);
            localStorage.setItem(`arcade_last_time`, Date.now());
            return true;
        } catch (e) {
            return false;
        }
    },
    
    // Detect which game this is - FIXED DETECTION
    detectGame: function() {
        // Get current path
        const path = window.location.pathname;
        console.log('Current path:', path);
        
        // Check path for game names
        if (path.includes('/snake/') || path.includes('snake')) {
            return 'snake';
        }
        if (path.includes('/car/') || path.includes('car')) {
            return 'car';
        }
        if (path.includes('/battery/') || path.includes('battery')) {
            return 'battery';
        }
        
        // Check page title
        const title = document.title.toLowerCase();
        if (title.includes('snake')) return 'snake';
        if (title.includes('car') || title.includes('rush')) return 'car';
        if (title.includes('battery') || title.includes('energy')) return 'battery';
        
        // Default to folder name
        const pathParts = path.split('/');
        for (let i = pathParts.length - 1; i >= 0; i--) {
            const part = pathParts[i].toLowerCase();
            if (part === 'snake' || part === 'car' || part === 'battery') {
                return part;
            }
        }
        
        console.warn('⚠️ Could not detect game, using "unknown"');
        return 'unknown';
    },
    
    // Validate game name
    isValidGame: function(gameName) {
        const validGames = ['snake', 'car', 'battery', 'demo'];
        return validGames.includes(gameName.toLowerCase());
    },
    
    // Game over with final score
    gameOver: function(score, gameName = null) {
        if (!gameName) {
            gameName = this.detectGame();
        }
        
        return this.sendScore(score, gameName);
    }
};

// Auto-initialize for games
window.addEventListener('DOMContentLoaded', function() {
    // Detect game
    const gameName = window.AtmosphereAPI.detectGame();
    console.log(`🎮 Detected game: ${gameName}`);
    
    // Set global variables
    window.currentGame = gameName;
    
    // Create simple global functions
    window.submitScore = function(score) {
        return window.AtmosphereAPI.sendScore(score, gameName);
    };
    
    window.gameOver = function(score) {
        return window.AtmosphereAPI.sendScore(score, gameName);
    };
    
    window.sendToArcade = function(score) {
        return window.submitScore(score);
    };
    
    // Send ready message after delay
    setTimeout(() => {
        if (window.AtmosphereAPI.sendScore) {
            window.AtmosphereAPI.sendScore(0, gameName);
        }
    }, 1000);
});

} // End of duplicate prevention