// send-score.js para sa Battery Dash
// Ilagay sa: terx-arcade/battery/send-score.js

function sendBatteryScore(score) {
    console.log('🔋 Battery Dash Score:', score);
    
    if (window.sendScoreToArcade) {
        window.sendScoreToArcade('battery', score);
    } else {
        localStorage.setItem('terx_pendingScore', JSON.stringify({
            game: 'battery',
            score: score,
            time: Date.now()
        }));
        
        setTimeout(() => {
            window.location.href = '../index.html?game=battery&score=' + score;
        }, 2000);
    }
}

window.sendBatteryScore = sendBatteryScore;
console.log('✅ Battery Score Sender Ready!');