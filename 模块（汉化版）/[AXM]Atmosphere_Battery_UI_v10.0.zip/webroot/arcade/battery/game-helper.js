// game-helper.js - For individual games to send scores back

function sendScoreToArcade(gameId, score) {
    console.log(`🎮 Game ${gameId} completed with score: ${score}`);
    
    // Store score in localStorage for main arcade to pick up
    localStorage.setItem('terx_pendingScore', JSON.stringify({
        game: gameId,
        score: score,
        timestamp: Date.now()
    }));
    
    // Also try to call the update function directly if available
    if (window.parent && window.parent.updateGameScore) {
        try {
            window.parent.updateGameScore(gameId, score);
            console.log('✅ Score sent to parent window');
        } catch (e) {
            console.log('Parent window function not accessible');
        }
    }
    
    // Redirect back to arcade with score in URL
    setTimeout(() => {
        const returnUrl = localStorage.getItem('terx_returnTo') || '../index.html';
        window.location.href = `${returnUrl}?game=${gameId}&score=${score}&t=${Date.now()}`;
    }, 1500);
    
    return true;
}

// Example usage in Snake game when game ends:
// if (gameOver) {
//   sendScoreToArcade('snake', finalScore);
// }

// Example usage in Highway Rush game:
// if (gameOver) {
//   sendScoreToArcade('highway', finalScore);
// }

// Example usage in Battery Dash game:
// if (gameOver) {
//   sendScoreToArcade('battery', finalScore);
// }