// Add to end of battery game
function endBatteryGame(finalScore) {
    console.log('🔋 Battery Dash Game Over! Score:', finalScore);
    
    // Your existing game over code...
    
    setTimeout(() => {
        if (window.sendBatteryScore) {
            sendBatteryScore(finalScore);
        } else if (window.sendGameScore) {
            sendGameScore('battery', finalScore);
        } else {
            localStorage.setItem('terx_pendingScore', JSON.stringify({
                game: 'battery',
                score: finalScore,
                time: Date.now()
            }));
            window.location.href = '../index.html?game=battery&score=' + finalScore;
        }
    }, 1500);
}