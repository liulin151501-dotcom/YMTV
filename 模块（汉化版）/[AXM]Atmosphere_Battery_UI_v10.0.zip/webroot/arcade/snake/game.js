const canvas = document.getElementById("game");
const ctx = canvas.getContext("2d");

function resize() {
  canvas.width = window.innerWidth;
  canvas.height = window.innerHeight;
}
resize();
window.addEventListener("resize", resize);

const segmentSize = 25;
const BORDER = 64;

let score = 0;
let bestScore = localStorage.getItem("bestScore") || 0;
let speed = 120;
let isPaused = false;
let shake = 0;
let gameOverFlag = false;

const scoreEl = document.getElementById("score");
const pauseScreen = document.getElementById("pauseScreen");
const gameOverScreen = document.getElementById("gameOverScreen");
const finalScore = document.getElementById("finalScore");
const bombNotification = document.getElementById("bombNotification");

let snake = [{
  x: Math.floor(canvas.width/2/segmentSize)*segmentSize,
  y: Math.floor(canvas.height/2/segmentSize)*segmentSize
}];

let vx = 0, vy = -segmentSize;
let grow = 0;

let food = {};
let bombs = [];
let bombNotified = false;

// ---------------- UTIL ----------------
function randX() { return Math.floor(Math.random()*((canvas.width-BORDER*2)/segmentSize))*segmentSize+BORDER; }
function randY() { return Math.floor(Math.random()*((canvas.height-BORDER*2)/segmentSize))*segmentSize+BORDER; }

// ---------------- FOOD ----------------
function spawnFood() { food.x = randX(); food.y = randY(); }
spawnFood();

// ---------------- LEVEL SYSTEM ----------------
function bombLimit() {
  if(score >= 10000) return 200;
  if(score >= 5000) return 150;
  if(score >= 1500) return 100;
  if(score >= 500) return 50;
  if(score >= 100) return 10;
  return 0;
}
function explodeTime() { return 20000; }

// ---------------- IMAGES ----------------
const imgs = {};
["snake_head","snake_body","food","bomb","tree","stadium_bg"].forEach(n=>{
  const i = new Image();
  i.src = `assets/${n}.png`;
  imgs[n]=i;
});

// ---------------- IMAGE LOAD CHECK ----------------
let loadedCount = 0;
Object.values(imgs).forEach(img=>{
  img.onload = ()=>{ loadedCount++; startLoopIfReady(); };
  img.onerror = ()=>{ console.error("FAILED TO LOAD:", img.src); loadedCount++; startLoopIfReady(); };
});
function startLoopIfReady() {
  if (loadedCount === Object.keys(imgs).length) requestAnimationFrame(loop);
}

// ---------------- PAUSE ----------------
function pauseGame() { 
  if(gameOverFlag) return; 
  isPaused = true; 
  pauseScreen.style.display="flex"; 
  vx=0; vy=0; 
}
function resumeGame() { 
  if(gameOverFlag) return; 
  isPaused = false; 
  pauseScreen.style.display="none"; 
  requestAnimationFrame(loop); 
}
document.getElementById("pauseBtn").onclick = pauseGame;
document.getElementById("continueBtn").onclick = resumeGame;
document.getElementById("exitPauseBtn").onclick = ()=>location.href="../lobby/index.html";
document.addEventListener("visibilitychange",()=>{ if(document.hidden) pauseGame(); });

// ---------------- CONTROLS ----------------
document.addEventListener("keydown",e=>{
  if(isPaused || gameOverFlag) return;
  if(e.key==="ArrowUp" && vy===0){vx=0;vy=-segmentSize;}
  if(e.key==="ArrowDown" && vy===0){vx=0;vy=segmentSize;}
  if(e.key==="ArrowLeft" && vx===0){vx=-segmentSize;vy=0;}
  if(e.key==="ArrowRight" && vx===0){vx=segmentSize;vy=0;}
});

// ---------------- TOUCH / SWIPE ----------------
let touchStartX=0,touchStartY=0;
canvas.addEventListener("touchstart",e=>{
  const t=e.touches[0]; touchStartX=t.clientX; touchStartY=t.clientY;
});
canvas.addEventListener("touchend",e=>{
  if(isPaused || gameOverFlag) return;
  const t=e.changedTouches[0]; const dx=t.clientX-touchStartX; const dy=t.clientY-touchStartY;
  if(Math.abs(dx)>Math.abs(dy)){
    if(dx>0 && vx===0){vx=segmentSize;vy=0;}
    if(dx<0 && vx===0){vx=-segmentSize;vy=0;}
  } else {
    if(dy>0 && vy===0){vx=0;vy=segmentSize;}
    if(dy<0 && vy===0){vx=0;vy=-segmentSize;}
  }
});

// ---------------- DRAW ----------------
function drawTrees(){
  for(let x=0;x<canvas.width;x+=64){
    ctx.drawImage(imgs.tree,x,0,64,64);
    ctx.drawImage(imgs.tree,x,canvas.height-64,64,64);
  }
  for(let y=64;y<canvas.height-64;y+=64){
    ctx.drawImage(imgs.tree,0,y,64,64);
    ctx.drawImage(imgs.tree,canvas.width-64,y,64,64);
  }
}
function drawBombs(){
  const now=Date.now();
  bombs.forEach(b=>{
    const blink = (now-b.plantedAt>explodeTime()-3000)?Math.sin(now/100)*5:0;
    ctx.save();
    ctx.shadowColor="red";
    ctx.shadowBlur=10+blink;
    ctx.drawImage(imgs.bomb,b.x,b.y,segmentSize,segmentSize);
    ctx.restore();
    // Draw countdown above bomb
    const timeLeft = Math.max(0, explodeTime() - (now - b.plantedAt));
    ctx.fillStyle="white";
    ctx.font="12px Arial";
    ctx.fillText(Math.ceil(timeLeft/1000), b.x, b.y - 2);
  });
}

// ---------------- GAME LOGIC ----------------
function spawnBombs(){
  const limit=bombLimit();
  if(limit===0) return;
  if(!bombNotified){
    bombNotification.style.display="block";
    setTimeout(()=>bombNotification.style.display="none",2000);
    bombNotified=true;
  }
  while(bombs.length<limit){
    bombs.push({x:randX(),y:randY(),plantedAt:Date.now(),exploded:false});
  }
}

function updateBombs(){
  const now=Date.now();
  bombs.forEach(b=>{
    if(!b.exploded && now-b.plantedAt>=explodeTime()){
      b.exploded=true;
      shake=10;
      if(navigator.vibrate) navigator.vibrate([200,100,200]);
      // FIX: Only trigger game over if head is on bomb
      if(Math.abs(snake[0].x-b.x)<=segmentSize && Math.abs(snake[0].y-b.y)<=segmentSize) gameOver();
    }
  });
  bombs=bombs.filter(b=>!b.exploded);
}

function moveSnake(){
  if(isPaused || gameOverFlag) return;
  const h=snake[0]; let nx=h.x+vx; let ny=h.y+vy;
  if(nx<BORDER) nx=canvas.width-BORDER-segmentSize;
  if(nx>=canvas.width-BORDER) nx=BORDER;
  if(ny<BORDER) ny=canvas.height-BORDER-segmentSize;
  if(ny>=canvas.height-BORDER) ny=BORDER;
  if((vx||vy) && snake.some((s,i)=>i>0 && s.x===nx && s.y===ny)) return gameOver();
  snake.unshift({x:nx,y:ny});

  // FIX FOOD COLLISION
  if(Math.abs(nx-food.x)<segmentSize && Math.abs(ny-food.y)<segmentSize){
    score+=10;
    grow++;
    spawnFood();
    scoreEl.innerText=`Score: ${score} | Best: ${bestScore}`;
    if(score>bestScore){bestScore=score; localStorage.setItem("bestScore",bestScore);}
  }

  if(grow>0) grow--;
  else snake.pop();
}

// ---------------- LOOP ----------------
function loop(){
  if(isPaused || gameOverFlag) return;
  ctx.setTransform(1,0,0,1,shake?Math.random()*shake-shake/2:0,shake?Math.random()*shake-shake/2:0);
  if(shake>0) shake--;
  ctx.clearRect(0,0,canvas.width,canvas.height);
  ctx.drawImage(imgs.stadium_bg,0,0,canvas.width,canvas.height);
  drawTrees();
  ctx.drawImage(imgs.food,food.x,food.y,segmentSize,segmentSize);
  drawBombs();
  snake.forEach((s,i)=>{ctx.drawImage(i?imgs.snake_body:imgs.snake_head,s.x,s.y,segmentSize,segmentSize);});
  spawnBombs(); updateBombs(); moveSnake();
  if(score>=5000) speed=80;
  if(score>=10000) speed=50;
  setTimeout(()=>requestAnimationFrame(loop),speed);
}

// ---------------- GAME OVER ----------------
function gameOver(){
  if(gameOverFlag) return;
  gameOverFlag=true;
  finalScore.innerText=`Score: ${score} | Best: ${bestScore}`;
  gameOverScreen.style.display="flex";
}

// Retry / Exit
document.getElementById("retryBtn").onclick = ()=>{
  gameOverScreen.style.display="none";
  gameOverFlag=false;
  snake=[{x:Math.floor(canvas.width/2/segmentSize)*segmentSize,y:Math.floor(canvas.height/2/segmentSize)*segmentSize}];
  score=0; grow=0; bombs=[]; bombNotified=false; vx=0; vy=-segmentSize; speed=120;
  spawnFood();
  requestAnimationFrame(loop);
};
document.getElementById("exitBtn").onclick = ()=>location.href="../lobby/index.html";

// Add this to the END of your snake game file
function endSnakeGame(finalScore) {
    console.log('🐍 Snake Game Over! Score:', finalScore);
    
    // Show game over screen
    // ... your existing game over code ...
    
    // Send score to arcade after 1.5 seconds
    setTimeout(() => {
        if (window.sendSnakeScore) {
            sendSnakeScore(finalScore);
        } else if (window.sendGameScore) {
            sendGameScore('snake', finalScore);
        } else {
            // Fallback
            localStorage.setItem('terx_pendingScore', JSON.stringify({
                game: 'snake',
                score: finalScore,
                time: Date.now()
            }));
            window.location.href = '../index.html?game=snake&score=' + finalScore;
        }
    }, 1500);
}