// send-score.js para sa Highway Rush
// Ilagay sa: terx-arcade/car/send-score.js

function sendCarScore(score) {
    console.log('🚗 Highway Rush Score:', score);
    
    if (window.sendScoreToArcade) {
        window.sendScoreToArcade('highway', score);
    } else {
        localStorage.setItem('terx_pendingScore', JSON.stringify({
            game: 'highway',
            score: score,
            time: Date.now()
        }));
        
        setTimeout(() => {
            window.location.href = '../index.html?game=highway&score=' + score;
        }, 2000);
    }
}

window.sendCarScore = sendCarScore;
console.log('✅ Car Score Sender Ready!');