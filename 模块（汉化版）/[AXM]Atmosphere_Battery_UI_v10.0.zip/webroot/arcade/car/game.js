// Add to end of car game
function endCarGame(finalScore) {
    console.log('🚗 Highway Rush Game Over! Score:', finalScore);
    
    // Your existing game over code...
    
    setTimeout(() => {
        if (window.sendCarScore) {
            sendCarScore(finalScore);
        } else if (window.sendGameScore) {
            sendGameScore('highway', finalScore);
        } else {
            localStorage.setItem('terx_pendingScore', JSON.stringify({
                game: 'highway',
                score: finalScore,
                time: Date.now()
            }));
            window.location.href = '../index.html?game=highway&score=' + finalScore;
        }
    }, 1500);
}