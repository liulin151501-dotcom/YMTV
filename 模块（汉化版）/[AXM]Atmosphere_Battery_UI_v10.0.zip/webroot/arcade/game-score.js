// game-score.js - Universal Score Bridge for TerX Arcade Games
// ============================================================

const GAME_SCORE_BRIDGE = {
    
    // Game Configuration
    GAME_CONFIGS: {
        snake: {
            name: "Snake Classic",
            folder: "../snake/",
            scoreElement: "score",
            highScoreElement: "highScore",
            gameOverFunction: "gameOver"
        },
        car: {
            name: "Highway Rush",
            folder: "../car/",
            scoreElement: "score",
            highScoreElement: "highScore",
            gameOverFunction: "gameOver"
        },
        highway: { // Alias for car
            name: "Highway Rush",
            folder: "../car/",
            scoreElement: "score",
            highScoreElement: "highScore",
            gameOverFunction: "gameOver"
        },
        battery: {
            name: "Battery Dash",
            folder: "../battery/",
            scoreElement: "score",
            highScoreElement: "highScore",
            gameOverFunction: "gameOver"
        }
    },
    
    // Send score to main arcade
    sendScore: function(gameId, score) {
        console.log(`🎯 [GAME-SCORE] Sending score: ${gameId} = ${score}`);
        
        if (!gameId || !score || score < 0) {
            console.error('Invalid score data');
            return false;
        }
        
        try {
            // Store in localStorage for main arcade
            localStorage.setItem('terx_pendingScore', JSON.stringify({
                game: gameId,
                score: parseInt(score),
                timestamp: Date.now(),
                player: localStorage.getItem('terx_playerName') || 'Guest',
                source: 'game-score-bridge'
            }));
            
            console.log(`✅ Score stored for ${gameId}: ${score}`);
            
            // Also update main arcade directly if available
            if (window.opener && window.opener.updateGameScore) {
                window.opener.updateGameScore(gameId, score);
                console.log('✅ Score sent to opener window');
            }
            
            // Try to update parent
            if (window.parent && window.parent !== window) {
                try {
                    if (window.parent.updateGameScore) {
                        window.parent.updateGameScore(gameId, score);
                        console.log('✅ Score sent to parent window');
                    }
                } catch (e) {
                    console.log('Parent window not accessible');
                }
            }
            
            // Redirect back to arcade
            setTimeout(() => {
                this.redirectToArcade(gameId, score);
            }, 2000);
            
            return true;
            
        } catch (error) {
            console.error('Error sending score:', error);
            return false;
        }
    },
    
    // Redirect back to arcade
    redirectToArcade: function(gameId, score) {
        const returnUrl = localStorage.getItem('terx_returnTo') || '../index.html';
        const redirectUrl = `${returnUrl}?game=${gameId}&score=${score}&returned=true&t=${Date.now()}`;
        
        console.log(`🔄 Redirecting to: ${redirectUrl}`);
        
        // Add a confirmation message
        alert(`🎮 Game Over!\nYour Score: ${score}\n\nReturning to Arcade...`);
        
        // Redirect
        window.location.href = redirectUrl;
    },
    
    // Initialize game with score tracking
    initGame: function(gameId) {
        console.log(`🎮 Initializing game: ${gameId}`);
        
        const config = this.GAME_CONFIGS[gameId];
        if (!config) {
            console.error(`Game config not found: ${gameId}`);
            return false;
        }
        
        // Save game session
        localStorage.setItem('terx_currentGame', gameId);
        localStorage.setItem('terx_gameStartTime', Date.now().toString());
        localStorage.setItem('terx_returnTo', document.referrer || '../index.html');
        
        // Override window.onbeforeunload to save score on refresh/close
        window.onbeforeunload = function() {
            const score = this.getCurrentScore(gameId);
            if (score > 0) {
                localStorage.setItem('terx_autosave_score', JSON.stringify({
                    game: gameId,
                    score: score,
                    time: Date.now()
                }));
            }
        }.bind(this);
        
        console.log(`✅ Game ${gameId} initialized with score tracking`);
        return true;
    },
    
    // Get current score from game
    getCurrentScore: function(gameId) {
        const config = this.GAME_CONFIGS[gameId];
        if (!config) return 0;
        
        try {
            // Try different methods to get score
            let score = 0;
            
            // Method 1: Global variable
            if (window[config.scoreElement]) {
                score = parseInt(window[config.scoreElement]) || 0;
            }
            
            // Method 2: DOM element
            const scoreElement = document.getElementById(config.scoreElement);
            if (scoreElement) {
                score = parseInt(scoreElement.textContent) || 0;
            }
            
            // Method 3: Check localStorage
            const savedScore = localStorage.getItem(`terx_${gameId}_currentScore`);
            if (savedScore) {
                score = Math.max(score, parseInt(savedScore));
            }
            
            return score;
            
        } catch (error) {
            console.error('Error getting score:', error);
            return 0;
        }
    },
    
    // Setup game over handler
    setupGameOverHandler: function(gameId) {
        const config = this.GAME_CONFIGS[gameId];
        if (!config) return;
        
        console.log(`🎮 Setting up game over handler for ${gameId}`);
        
        // Override the game's game over function
        const originalGameOver = window[config.gameOverFunction];
        
        if (originalGameOver && typeof originalGameOver === 'function') {
            window[config.gameOverFunction] = function() {
                console.log(`🎮 Game Over detected for ${gameId}`);
                
                // Get final score
                const finalScore = GAME_SCORE_BRIDGE.getCurrentScore(gameId);
                
                // Call original game over function
                originalGameOver();
                
                // Send score to arcade
                setTimeout(() => {
                    GAME_SCORE_BRIDGE.sendScore(gameId, finalScore);
                }, 1500);
            };
            
            console.log(`✅ Game over handler installed for ${gameId}`);
        }
    },
    
    // Auto-save score periodically
    startAutoSave: function(gameId) {
        setInterval(() => {
            const currentScore = this.getCurrentScore(gameId);
            if (currentScore > 0) {
                localStorage.setItem(`terx_${gameId}_currentScore`, currentScore.toString());
            }
        }, 5000); // Save every 5 seconds
    }
};

// Make it globally available
window.GAME_SCORE_BRIDGE = GAME_SCORE_BRIDGE;
window.sendScoreToArcade = GAME_SCORE_BRIDGE.sendScore.bind(GAME_SCORE_BRIDGE);
window.initGameWithTracking = GAME_SCORE_BRIDGE.initGame.bind(GAME_SCORE_BRIDGE);