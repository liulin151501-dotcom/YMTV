#!/system/bin/sh
cmd notification post -S bigtext -t '🌍 Atmosphere Battery UI❄️'🔥 'System' '✅ Optimization Battery ON' > /dev/null 2>&1 & 

if [ "$(id -u)" = "0" ]; then
    su -lp 2000 -c "cmd notification post -S bigtext -t ' 🌏Atmosphere Battery UI❄️🔥' tag 'System : ✅ Optimization Battery ON🔥'" >/dev/null 2>&1
fi
exec /data/data/com.android.shell/AxManager/plugins/atmosphere_battery/system/bin/system_optimizer

BIN_DIR="/data/user_de/0/com.android.shell/axeron/plugins/atmosphere_battery/system/bin"
cd $BIN_DIR

if pgrep -f system_optimizer >/dev/null; then
    echo "✅ System Optimizer already running"
else
    ./system_optimizer &
    echo "⚡ System Optimizer started"
fi