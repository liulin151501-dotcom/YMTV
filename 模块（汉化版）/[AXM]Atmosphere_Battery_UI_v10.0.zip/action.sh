#!/system/bin/sh
MODPATH="${0%/*}"
TARGET_DIR="$MODPATH"
CONFIG_FILE="/data/user_de/0/com.android.shell/axeron/plugins/atmosphere_battery/TerX.txt"
chmod 755 $MODPATH/sellscript
chmod 755 /sys/class/power_supply/*
chmod 755 //sys/devices/system/cpu/cpu4/cpufreq/*
chmod 755 /sys/devices/system/cpu/cpu7/cpufreq/scaling_governor

# Run 18WW.sh then only if both INCLUDE_18WW and 18WW are set to 1
if grep -q "INCLUDE_18W=1" "$CONFIG_FILE" && grep -q "18W=1" "$CONFIG_FILE"; then
    sh "$MODPATH/mode/18W.sh"      
fi

# Run 20W.sh then only if both INCLUDE_20W and 20W are set to 1
if grep -q "INCLUDE_20W=1" "$CONFIG_FILE" && grep -q "20W=1" "$CONFIG_FILE"; then
    sh "$MODPATH/mode/20W.sh  "   
fi

# Run 25W.sh then only if both INCLUDE_25W and 25W are set to 1
if grep -q "INCLUDE_25W=1" "$CONFIG_FILE" && grep -q "25W=1" "$CONFIG_FILE"; then
    sh "$MODPATH/mode/25W.sh "          
fi

# Run 30W.sh then only if both INCLUDE_30W and 30W are set to 1
if grep -q "INCLUDE_30W=1" "$CONFIG_FILE" && grep -q "30W=1" "$CONFIG_FILE"; then
    sh "$MODPATH/mode/30W.sh  " 
       
fi

# Run 33W.sh then only if both INCLUDE_33W and 33W are set to 1
if grep -q "INCLUDE_33W=1" "$CONFIG_FILE" && grep -q "33W=1" "$CONFIG_FILE"; then
    sh "$MODPATH/mode/33W.sh  " 
fi

# Run 40W.sh then only if both INCLUDE_40W and 40W are set to 1
if grep -q "INCLUDE_40W=1" "$CONFIG_FILE" && grep -q "40W=1" "$CONFIG_FILE"; then
    sh "$MODPATH/mode/40W.sh  " 
fi

# Run 45W.sh then only if both INCLUDE_45W and 45W are set to 1
if grep -q "INCLUDE_45W=1" "$CONFIG_FILE" && grep -q "45W=1" "$CONFIG_FILE"; then
    sh "$MODPATH/mode/45W.sh  " 
fi

# Run 50W.sh then only if both INCLUDE_50W and 50W are set to 1
if grep -q "INCLUDE_50W=1" "$CONFIG_FILE" && grep -q "50W=1" "$CONFIG_FILE"; then
    sh "$MODPATH/mode/50W.sh " 
fi

# Run 55W.sh then only if both INCLUDE_55W and 55W are set to 1
if grep -q "INCLUDE_55W=1" "$CONFIG_FILE" && grep -q "55W=1" "$CONFIG_FILE"; then
    sh "$MODPATH/mode/55W.sh "   
fi

# Run 60W.sh then only if both INCLUDE_60W and 60W are set to 1
if grep -q "INCLUDE_60W=1" "$CONFIG_FILE" && grep -q "60W=1" "$CONFIG_FILE"; then
    sh "$MODPATH/mode/60W.sh   " 
fi

# Run 18W.sh then only if both INCLUDE_18W and 18W are set to 1
if grep -q "INCLUDE_65W=1" "$CONFIG_FILE" && grep -q "65W=1" "$CONFIG_FILE"; then
    sh "$MODPATH/mode/65W.sh"   
fi

# Run 70W.sh then only if both INCLUDE_70W and 70W are set to 1
if grep -q "INCLUDE_70W=1" "$CONFIG_FILE" && grep -q "70W=1" "$CONFIG_FILE"; then
    sh "$MODPATH/mode/70W.sh "  
fi

# Run 75W.sh then only if both INCLUDE_75W and 75W are set to 1
if grep -q "INCLUDE_75W=1" "$CONFIG_FILE" && grep -q "75W=1" "$CONFIG_FILE"; then
    sh "$MODPATH/mode/75W.sh"
fi

# Run 85W.sh then only if both INCLUDE_85W and 85W are set to 1
if grep -q "INCLUDE_85W=1" "$CONFIG_FILE" && grep -q "85W=1" "$CONFIG_FILE"; then
    sh "$MODPATH/mode/85W.sh  " 
fi

# Run 90W.sh then only if both INCLUDE_90W and 90W are set to 1
if grep -q "INCLUDE_90W=1" "$CONFIG_FILE" && grep -q "90W=1" "$CONFIG_FILE"; then
    sh "$MODPATH/mode/90W.sh "  
fi

# Run 95W.sh then only if both INCLUDE_95W and 95W are set to 1
if grep -q "INCLUDE_95W=1" "$CONFIG_FILE" && grep -q "95W=1" "$CONFIG_FILE"; then
    sh "$MODPATH/mode/95W.sh   " 
fi

# Run 100W.sh then only if both INCLUDE_100W and 100W are set to 1
if grep -q "INCLUDE_100W=1" "$CONFIG_FILE" && grep -q "100W=1" "$CONFIG_FILE"; then
    sh "$MODPATH/mode/100W.sh  "
fi

# Run 105W.sh then only if both INCLUDE_105W and 105W are set to 1
if grep -q "INCLUDE_105W=1" "$CONFIG_FILE" && grep -q "105W=1" "$CONFIG_FILE"; then
    sh "$MODPATH/mode/105W.sh   " 
fi

# Run 110W.sh then only if both INCLUDE_110W and 110W are set to 1
if grep -q "INCLUDE_110W=1" "$CONFIG_FILE" && grep -q "110W=1" "$CONFIG_FILE"; then
    sh "$MODPATH/mode/110W.sh  " 
fi

# Run 115W.sh then only if both INCLUDE_115W and 115W are set to 1
if grep -q "INCLUDE_115W=1" "$CONFIG_FILE" && grep -q "115W=1" "$CONFIG_FILE"; then
    sh "$MODPATH/mode/115W.sh  "  
fi

# Run 120W.sh then only if both INCLUDE_120W and 120W are set to 1
if grep -q "INCLUDE_120W=1" "$CONFIG_FILE" && grep -q "120W=1" "$CONFIG_FILE"; then
    sh "$MODPATH/mode/120W.sh  " 
fi

sleep 0.5
$MODPATH/sellscript
# notification
if [ "$(id -u)" = "0" ]; then
    su -lp 2000 -c "cmd notification post -S bigtext -t '🌏 Atmosphere Battery UI❄️' 'TerX Official' 'Successfully✅'" > /dev/null 2>&1
fi
# WebUI X
if pm path com.dergoogler.mmrl.wx >/dev/null 2>&1; then
    echo "[*] Start Open WebUI X.."
    am start -n "com.dergoogler.mmrl.wx/.ui.activity.webui.WebUIActivity" -e id "stellar" > /dev/null 2>&1
    exit 0 
fi
    
#KSU WebUI
if pm path io.github.a13e300.ksuwebui >/dev/null 2>&1; then
    echo "[*] Start Open WebUI on KSU Webui Standanlone.."
    am start -n "io.github.a13e300.ksuwebui/.WebUIActivity" -e id "stellar" > /dev/null 2>&1
    exit 0
fi  	
    
# MMRL 
if pm path com.dergoogler.mmrl >/dev/null 2>&1; then
    echo "[*] Starting WebUI through MMRL..."
    am start -n "com.dergoogler.mmrl/.ui.activity.webui.WebUIActivity" -e MOD_ID "stellar" > /dev/null 2>&1
    exit 0
fi
# === FOOTER ===
#!/system/bin/sh
#
# This script configures LIFE in Kamui.txt using volume keys.
# It uses getevent to capture key presses.
MODULE_DIR="$MODPATH"
CONFIG_FILE="$MODULE_DIR/tree.txt"

ui_print() {
  echo "$1"
}

# Read the current LIFE setting to display its status
if [ -f "$CONFIG_FILE" ]; then
    CURRENT_LIFE=$(grep '^LIFE=' "$CONFIG_FILE" | cut -d'=' -f2)
else
    # Default to 0 (Disabled) if the file doesn't exist yet
    CURRENT_LIFE=0
fi

# Set the status string for the UI based on the current value
if [ "$CURRENT_LIFE" -eq 1 ]; then
    STATUS_STRING="Enabled"
else
    STATUS_STRING="Disabled"
fi

ui_print " "
ui_print "LIFE Mode: Halfing Max CPU Freq for battery"
ui_print "Conservation in exchange of reduced performance"
ui_print " "
ui_print "Please use the volume keys to make a selection."
ui_print " "
ui_print "  Volume UP   = Set Enable LIFE Mode"
ui_print "  Volume DOWN = Set Disable LIFE Mode"
ui_print "  Current: LIFE Mode $STATUS_STRING"
ui_print " "
ui_print "Note: No need to reboot, effective immediately"
ui_print " "

# Wait for a volume key press using getevent
while true; do
  # Capture a single key press event. We look for 'DOWN' state to avoid double triggers.
  EVENT=$(getevent -lqc 1)

  if echo "$EVENT" | grep -q "KEY_VOLUMEUP.*DOWN"; then
    ui_print "LIFE Mode enabled"
    echo "LIFE=1" > "$CONFIG_FILE"
    break
  elif echo "$EVENT" | grep -q "KEY_VOLUMEDOWN.*DOWN"; then
    ui_print "LIFE Mode disabled"
    echo "LIFE=0" > "$CONFIG_FILE"
    break
  fi
done

# Apply the new settings immediately
sh "$MODPATH/Battery/Balanced.sh"

# Display the resulting max frequencies
ui_print " "
ui_print "Max Freq is:"
for policy in /sys/devices/system/cpu/cpufreq/policy*; do
  cat "$policy/scaling_max_freq"
done
ui_print " "

exit 0

echo "======= TerX Official ======="

su -lp 2000 -c "cmd notification post -S bigtext -t ' 🌏Atmosphere Battery UI❄️🔥' tag 'Power : SELECTION HAS BEEN ACTIVATED✅'" >/dev/null 2>&1