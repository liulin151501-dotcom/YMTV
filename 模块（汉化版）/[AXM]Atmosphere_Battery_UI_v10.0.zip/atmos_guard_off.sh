#!/system/bin/sh

if [ "$(id -u)" = "0" ]; then
    su -lp 2000 -c "cmd notification post -S bigtext -t ' 🌏Atmosphere Battery UI❄️🔥' tag 'System : ✅ Atmosphere Guard OFF🔥'" >/dev/null 2>&1
fi

#!/system/bin/sh
####################################################
# Atmosphere Battery OFF script - FINAL FIX
####################################################

BASE_DIR="/data/user_de/0/com.android.shell/axeron/plugins/atmosphere_battery"
WATCHDOG="$BASE_DIR/system/bin/battery_guard"

# Remove ON flag
echo OFF > /data/adb/modules/atmosphere_battery/system/bin/battery_enabled

# Kill running daemon safely
pkill -f "$WATCHDOG" >/dev/null 2>&1

# Remove notify flag so next ON will trigger notification
[ -f "$BASE_DIR/system/bin/notify_sent" ] && rm -f "$BASE_DIR/system/bin/notify_sent"

echo "Atmosphere Battery Watchdog STOPPED"