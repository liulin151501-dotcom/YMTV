#!/system/bin/sh

cmd notification post -S bigtext -t '🌍 Atmosphere Battery UI❄️'🔥 'System' '✅ Fast Charging System ON' > /dev/null 2>&1 & 

if [ "$(id -u)" = "0" ]; then
    su -lp 2000 -c "cmd notification post -S bigtext -t ' 🌏Atmosphere Battery UI❄️🔥' tag 'System : ✅ Fast Charging System ON🔥'" >/dev/null 2>&1
fi

MODPATH="/data/user_de/0/com.android.shell/axeron/plugins/atmosphere_battery"

chmod 0666 "$MODPATH/Scripts/fcs.sh"

sh "$MODPATH/scripts/fcs.sh"