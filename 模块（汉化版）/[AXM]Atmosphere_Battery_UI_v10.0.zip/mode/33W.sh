#!/system/bin/sh
MODPATH="/data/adb/modules/atmosphere_battery"
MODDIR="/sys/class/power_supply"

# 33W Fast Charging Mode - Aggressive
if [ "$(id -u)" = "0" ]; then
    su -lp 2000 -c "cmd notification post -S bigtext -t ' 🌏Atmosphere Battery UI❄️🔥' tag 'System : ✅Successfully Selected 33W🔥'" >/dev/null 2>&1
fi


# Main Fast Charging System Upragdes 
# =========================================
# AOSP FAST CHARGE – COMBINED FILE
# Works ONLY if kernel supports high current
# =========================================

permission() {
    if [ -e "$2" ]; then
        chmod 0666 "$2" >/dev/null 2>&1
        echo "$1" > "$2" 2>/dev/null
        chmod 0444 "$2" >/dev/null 2>&1
    fi
}

chmod 0666 /sys/class/power_supply/charger/constant_charge_current 
chmod 0666 /sys/class/power_supply/charger/input_current_limit

chmod 0666 /sys/class/power_supply/battery/constant_charge_voltage 
chmod 0666 /sys/class/power_supply/battery/voltage_now
chmod 0666 /sys/class/power_supply/battery/charge_full
chmod 0666 /sys/class/power_supply/battery/charge_full_design
chmod 0666 sys/class/power_supply/charger/voltage_max

chmod 0666 /sys/class/power_supply/mtk-master-charger/constant_charge_current_max
chmod 0666 /sys/class/power_supply/mtk-master-charger/voltage_max
chmod 0666 /sys/class/power_supply/mtk-slave-charger/constant_charge_current_max
 
# ---------- AOSP PROPS ----------
resetprop -n persist.sys.fast_charge 1
resetprop -n persist.sys.usb.fastcharge 1
resetprop -n ro.config.fast_charge true
resetprop -n ro.config.usb_fastcharge true
resetprop -n persist.sys.powerctl.fastcharge 1

# Disable charging throttles (AOSP)
resetprop -n persist.sys.thermal.limit false
resetprop -n ro.thermal.charging false

# ---------- CURRENT LIMITS ----------
# USB input
permission 3300000 > /sys/class/power_supply/charger/current_max 2>/dev/null
permission 3300000 > /sys/class/power_supply/charger/input_current_limit 2>/dev/null

echo 3300000 > /sys/class/power_supply/charger/current_max 2>/dev/null
echo 3300000 > /sys/class/power_supply/charger/input_current_limit 2>/dev/null


permission 3300000 > /sys/class/power_supply/mtk-master-charger/constant_charge_current_max
permission 3300000 > /sys/class/power_supply/mtk-slave-charger/constant_charge_current_max

echo 3300000 > /sys/class/power_supply/mtk-master-charger/constant_charge_current_max
echo 3300000 > /sys/class/power_supply/mtk-slave-charger/constant_charge_current_max
echo 0 > /sys/class/power_supply/mtk-master-charger/voltage_max
# Battery charging current
permission 3300000 > /sys/class/power_supply/battery/constant_charge_voltage 2>/dev/null
permission 3300000 > /sys/class/power_supply/battery/voltage_now 2>/dev/null
permission 3300000 > /sys/class/power_supply/battery/charge_full
permission 3300000 > /sys/class/power_supply/battery/charge_full_design

echo 3300000 > /sys/class/power_supply/battery/constant_charge_voltage 2>/dev/null
echo 3300000 > /sys/class/power_supply/battery/voltage_now 2>/dev/null
echo 3300000 > /sys/class/power_supply/battery/charge_full
echo 3300000 > /sys/class/power_supply/battery/charge_full_design

chmod 755 $MODPATH 2>/dev/null
chmod 755 $MODDIR/* 2>/dev/null

sh "$MODPATH/scripts/safe_access.sh"
sh "$MODPATH/helpers.sh"

#For Mediatek
echo 3300000 > $MODDIR/charger/constant_charge_current
echo 3300000 > $MODDIR/charger/constant_charge_voltage
echo 3300000 > $MODDIR/charger/input_current_limit
echo 3300000 > $MODDIR/charger/input_voltage_limit

#For Snapdragon 
echo 3300000 > $MODDIR/battery/constant_charge_current_max
echo 3300000 > $MODDIR/battery/constant_charge_current
echo 3300000 > $MODDIR/battery/input_current_limited
echo 3300000 > $MODDIR/battery/voltage_max
echo 3300000 > $MODDIR/battery/charge_control_limit
echo 3300000 > $MODDIR/battery/charge_control_limit_max

#For UnisocT 
echo 3300000 > $MODDIR/charger/input_current_limit
echo 3300000 > $MODDIR/charger/constant_charge_current