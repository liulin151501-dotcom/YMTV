###############################
# DEFINE CONFIG
###############################

# Config file path
MODDIR=${0%/*}
TERX_CONFIG="$MODDIR/TerX.txt"

# Format: 1=MTK, 2=SD, 3=Exynos, 4=Unisoc, 5=Tensor, 6=Tegra, 7=Kirin
SOC=$(grep '^SOC=' "$TERX_CONFIG" | cut -d'=' -f2)

DEFAULT_CPU_GOV=$(grep '^GOV=' "$TERX_CONFIG" | cut -d'=' -f2)
if [ -z "$DEFAULT_CPU_GOV" ]; then
    if [ -e /sys/devices/system/cpu/cpu0/cpufreq/scaling_available_governors ] && grep -q "schedhorizon" /sys/devices/system/cpu/cpu0/cpufreq/scaling_available_governors; then
        DEFAULT_CPU_GOV="schedhorizon"
    else
        DEFAULT_CPU_GOV="schedutil"
    fi
fi

DEVICE_MITIGATION=$(grep '^DEVICE_MITIGATION=' "$TERX_CONFIG" | cut -d'=' -f2)
DND=$(grep '^DND=' "$TERX_CONFIG" | cut -d'=' -f2)

##############################
# Path Variable
##############################
ipv4="/proc/sys/net/ipv4"

##############################
# ADDED: Source External Script
##############################
MODE_PATH="$MODDIR/mode"
MODULE_PATH="$MODDIR"

##############################
# Begin Functions
##############################

18WATT() {
    if [ "$18WATT" = "1" ] && [ "$18WATT" = "1" ]; then
        sh $MODDIR/mode/18WATT.sh
    fi
}

20WATT() {
    if [ "$20WATT" = "1" ] && [ "$20WATT" = "1" ]; then
        sh $MODDIR/mode/20WATT.sh
    fi
}

25WATT() {
    if [ "$25WATT" = "1" ] && [ "$25WATT" = "1" ]; then
        sh $MODDIR/mode/25WATT.sh
    fi
}

30WATT() {
    if [ "$30WATT" = "1" ] && [ "$30WATT" = "1" ]; then
        sh $MODDIR/mode/30WATT.sh
    fi
}

33WATT() {
    if [ "$33WATT" = "1" ] && [ "$33WATT" = "1" ]; then
        sh $MODDIR/mode/33WATT.sh
    fi
}

40WATT() {
    if [ "$40WATT" = "1" ] && [ "$40WATT" = "1" ]; then
        sh $MODDIR/mode/40WATT.sh
    fi
}

45WATT() {
    if [ "$45WATT" = "1" ] && [ "$45WATT" = "1" ]; then
        sh $MODDIR/mode/45WATT.sh
    fi
}

50WATT() {
    if [ "$50WATT" = "1" ] && [ "$50WATT" = "1" ]; then
        sh $MODDIR/mode/50WATT.sh
    fi
}

55WATT() {
    if [ "$55WATT" = "1" ] && [ "$55WATT" = "1" ]; then
        sh $MODDIR/mode/55WATT.sh
    fi
}

60WATT() {
    if [ "$60WATT" = "1" ] && [ "$60WATT" = "1" ]; then
        sh $MODDIR/mode/60WATT.sh
    fi
}

65WATT() {
    if [ "$65WATT" = "1" ] && [ "$65WATT" = "1" ]; then
        sh $MODDIR/mode/65WATT.sh
    fi
}

70WATT() {
    if [ "$70WATT" = "1" ] && [ "$70WATT" = "1" ]; then
        sh $MODDIR/mode/70WATT.sh
    fi
}

75WATT() {
    if [ "$75WATT" = "1" ] && [ "$75WATT" = "1" ]; then
        sh $MODDIR/mode/75WATT.sh
    fi
}

80WATT() {
    if [ "$80WATT" = "1" ] && [ "$80WATT" = "1" ]; then
        sh $MODDIR/mode/80WATT.sh
    fi
}

85WATT() {
    if [ "$85WATT" = "1" ] && [ "$85WATT" = "1" ]; then
        sh $MODDIR/mode/85WATT.sh
    fi
}

90WATT() {
    if [ "$90WATT" = "1" ] && [ "$90WATT" = "1" ]; then
        sh $MODDIR/mode/90WATT.sh
    fi
}

95WATT() {
    if [ "$95WATT" = "1" ] && [ "$95WATT" = "1" ]; then
        sh $MODDIR/mode/95WATT.sh
    fi
}

100WATT() {
    if [ "$100WATT" = "1" ] && [ "$100WATT" = "1" ]; then
        sh $MODDIR/mode/100WATT.sh
    fi
}

105WATT() {
    if [ "$105WATT" = "1" ] && [ "$105WATT" = "1" ]; then
        sh $MODDIR/mode/105WATT.sh
    fi
}

110WATT() {
    if [ "$110WATT" = "1" ] && [ "$110WATT" = "1" ]; then
        sh $MODDIR/mode/110WATT.sh
    fi
}

115WATT() {
    if [ "$115WATT" = "1" ] && [ "$115WATT" = "1" ]; then
        sh $MODDIR/mode/115WATT.sh
    fi
}

120WATT() {
    if [ "$120WATT" = "1" ] && [ "$120WATT" = "1" ]; then
        sh $MODDIR/mode/120WATT.sh
    fi
}

tweak() {
    if [ -e "$2" ]; then
        chmod 644 "$2" >/dev/null 2>&1
        echo "$1" > "$2" 2>/dev/null
        chmod 444 "$2" >/dev/null 2>&1
    fi
}

kill_all() {
	for pkg in $(pm list packages -3 | cut -f 2 -d ":"); do
    if [ "$pkg" != "com.google.android.inputmethod.latin" ]; then
        am force-stop $pkg
    fi
done

echo 3 > /proc/sys/vm/drop_caches
am kill-all
}

# This is also external

notification() {
    local TITLE="🌏 Atmosphere Battery UI❄️"
    local MESSAGE="$1"
    
    su -lp 2000 -c "cmd notification post -S bigtext -t '$TITLE' $MESSAGE'"
}

###################################
##########################################
# MAIN EXECUTION LOGIC
##########################################
exit 0