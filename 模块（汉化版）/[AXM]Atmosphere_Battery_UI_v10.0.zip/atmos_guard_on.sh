#!/system/bin/sh

if [ "$(id -u)" = "0" ]; then
    su -lp 2000 -c "cmd notification post -S bigtext -t ' 🌏Atmosphere Battery UI❄️🔥' tag 'System : ✅ Atmosphere Guard ON🔥'" >/dev/null 2>&1
fi

BASE_DIR="/data/user_de/0/com.android.shell/axeron/plugins/atmosphere_battery"
BIN="$BASE_DIR/system/bin/battery_guard"

# STOP old instances
pkill -f battery_guard.

# Create flag
touch "$BASE_DIR/system/bin/battery_enabled"
chmod 666 "$BASE_DIR/system/bin/battery_enabled"
echo ON > /data/adb/modules/atmosphere_battery/system/bin/battery_enabled

# START daemon
sh "$BIN" >/dev/null 2>&1 &