#!/system/bin/sh

# Atmosphere Battery - Unified startup tweaks
while [ "$(getprop sys.boot_completed)" != "1" ]; do
    sleep 5
done

MODULE_DIR="${0%/*}"
BIN="$MODULE_DIR/bin"

if [ -f "$BIN/pow-daemon" ]; then
    chmod 0755 "$BIN/pow-daemon" 2>/dev/null
    [ -f "$BIN/pow" ] && chmod 0755 "$BIN/pow" 2>/dev/null
    nohup "$BIN/pow-daemon" >/dev/null 2>&1 &
fi

#permission 
chmod 0777 "$MODULE_DIR/System/bin/battery_extender"
chmod 0777 "$MODULE_DIR/mode"
chmod 0777 "$MODULE_DIR/common"
chmod 0777 "$MODULE_DIR/sellscript"
chmod 0777 "$MODULE_DIR/action.sh"
chmod 0777 "$MODULE_DIR/TerX.sh"
chmod 0777 "$MODULE_DIR/scripts"
chmod 0777 /sys/class/power_supply/battery/*
chmod 0777 "$MODULE_DIR/scripts"
chmod 0777 "$MODULE_DIR/common"
chmod 0777 "$MODULE_DIR/common/detector.sh"
chmod 0777 "$MODULE_DIR/system/bin/Atmosphere"
chmod 0755 "$MODULE_DIR/system/bin/system_optimizer"
chmod 0755 "$MODULE_DIR/system/bin/ultimate_battery_daemon"
chmod 0755 "$MODULE_DIR/system/bin/main_power_ui"
chmod 0755 "$MODULE_DIR/system/bin/atmosphere_battery_ui"

/data/user_de/0/com.android.shell/axeron/plugins/atmosphere_battery/system/bin/main_power_ui

#Execute the scripts & common inside the folder 📂 
CONFIG_FILE="/data/user_de/0/com.android.shell/axeron/plugins/atmosphere_battery/TerX.txt"
MODDIR="$MODULE_DIR"
MODPATH="$MODULE_DIR"
LIMIT=39 
BAT_TEMP="/sys/class/power_supply/battery/temperature"
DETECTOR="$MODULE_DIR/common/detector.sh"
MODEDIR="${MODPATH}/mode"

# --- helper functions ---
tweak() {
    # usage: tweak <file> <value>
    if [ -e "$1" ]; then
        echo "$2" > "$1" 2>/dev/null
    fi
}

write_val() {
    # usage: write_val <file> <value>
    local file="$1"
    local value="$2"
    if [ -e "$file" ]; then
        chmod 644 "$file" 2>/dev/null || true
        echo "$value" > "$file" 2>/dev/null && return 0 || return 1
    fi
    return 1
}

mask_val() {
    # write and bind-mount mask to keep value persistent if possible
    # usage: mask_val <value> <file>
    local val="$1"
    local p="$2"
    if [ -f "$p" ]; then
        chmod 644 "$p" 2>/dev/null || true
        echo "$val" > "$p" 2>/dev/null || true
    fi
}

change_cpu_gov() {
    # usage: change_cpu_gov <governor>
    for f in /sys/devices/system/cpu/cpu*/cpufreq/scaling_governor; do
        if [ -e "$f" ]; then
            chmod 644 "$f" 2>/dev/null || true
            echo "$1" > "$f" 2>/dev/null || true
            chmod 444 "$f" 2>/dev/null || true
        fi
    done
}

# --- Mali scheduler tweaks (MiAzami) ---
mali_sched_dir=$(ls -d /sys/devices/platform/soc/*mali*/scheduling 2>/dev/null | head -n1)
mali_root_dir=$(ls -d /sys/devices/platform/soc/*mali* 2>/dev/null | head -n1)

if [ -n "$mali_sched_dir" ]; then
    write_val "$mali_sched_dir/serialize_jobs" "full"
fi

if [ -n "$mali_root_dir" ]; then
    write_val "$mali_root_dir/js_ctx_scheduling_mode" "1"
fi

# fix mistaken calls from original: ensure correct order (file then value)
tweak /proc/sys/kernel/panic 0
tweak /proc/sys/kernel/panic_on_oops 0
tweak /proc/sys/kernel/panic_on_warn 0
tweak /proc/sys/kernel/softlockup_panic 0

# Run 18WW.sh then only if both INCLUDE_18WW and 18WW are set to 1
if grep -q "INCLUDE_18W=1" "$CONFIG_FILE" && grep -q "18W=1" "$CONFIG_FILE"; then
    sh $MODULE_DIR/mode/18W.sh    
fi

# Run 20W.sh then only if both INCLUDE_20W and 20W are set to 1
if grep -q "INCLUDE_20W=1" "$CONFIG_FILE" && grep -q "20W=1" "$CONFIG_FILE"; then
    sh $MODULE_DIR/mode/20W.sh
fi

# Run 25W.sh then only if both INCLUDE_25W and 25W are set to 1
if grep -q "INCLUDE_25W=1" "$CONFIG_FILE" && grep -q "25W=1" "$CONFIG_FILE"; then
    sh $MODULE_DIR/mode/25W.sh          
fi

# Run 30W.sh then only if both INCLUDE_30W and 30W are set to 1
if grep -q "INCLUDE_30W=1" "$CONFIG_FILE" && grep -q "30W=1" "$CONFIG_FILE"; then
    sh $MODULE_DIR/mode/30W.sh      
fi

# Run 33W.sh then only if both INCLUDE_33W and 33W are set to 1
if grep -q "INCLUDE_33W=1" "$CONFIG_FILE" && grep -q "33W=1" "$CONFIG_FILE"; then
    sh $MODULE_DIR/mode/33W.sh
fi

# Run 40W.sh then only if both INCLUDE_40W and 40W are set to 1
if grep -q "INCLUDE_40W=1" "$CONFIG_FILE" && grep -q "40W=1" "$CONFIG_FILE"; then
    sh $MODULE_DIR/mode/40W.sh
fi

# Run 45W.sh then only if both INCLUDE_45W and 45W are set to 1
if grep -q "INCLUDE_45W=1" "$CONFIG_FILE" && grep -q "45W=1" "$CONFIG_FILE"; then
    sh $MODULE_DIR/mode/45W.sh
fi

# Run 50W.sh then only if both INCLUDE_50W and 50W are set to 1
if grep -q "INCLUDE_50W=1" "$CONFIG_FILE" && grep -q "50W=1" "$CONFIG_FILE"; then
    sh $MODULE_DIR/mode/50W.sh
fi

# Run 55W.sh then only if both INCLUDE_55W and 55W are set to 1
if grep -q "INCLUDE_55W=1" "$CONFIG_FILE" && grep -q "55W=1" "$CONFIG_FILE"; then
    sh $MODULE_DIR/mode/55W.sh
fi

# Run 60W.sh then only if both INCLUDE_60W and 60W are set to 1
if grep -q "INCLUDE_60W=1" "$CONFIG_FILE" && grep -q "60W=1" "$CONFIG_FILE"; then
    sh $MODULE_DIR/mode/60W.sh
fi

# Run 18W.sh then only if both INCLUDE_18W and 18W are set to 1
if grep -q "INCLUDE_65W=1" "$CONFIG_FILE" && grep -q "65W=1" "$CONFIG_FILE"; then
    sh $MODULE_DIR/mode/65W.sh
fi

# Run 70W.sh then only if both INCLUDE_70W and 70W are set to 1
if grep -q "INCLUDE_70W=1" "$CONFIG_FILE" && grep -q "70W=1" "$CONFIG_FILE"; then
    sh $MODULE_DIR/mode/70W.sh
fi

# Run 75W.sh then only if both INCLUDE_75W and 75W are set to 1
if grep -q "INCLUDE_75W=1" "$CONFIG_FILE" && grep -q "75W=1" "$CONFIG_FILE"; then
    sh $MODULE_DIR/mode/75W.sh
fi

# Run 85W.sh then only if both INCLUDE_85W and 85W are set to 1
if grep -q "INCLUDE_85W=1" "$CONFIG_FILE" && grep -q "85W=1" "$CONFIG_FILE"; then
    sh $MODULE_DIR/mode/85W.sh
fi

# Run 90W.sh then only if both INCLUDE_90W and 90W are set to 1
if grep -q "INCLUDE_90W=1" "$CONFIG_FILE" && grep -q "90W=1" "$CONFIG_FILE"; then
    sh $MODULE_DIR/mode/90W.sh
fi

# Run 95W.sh then only if both INCLUDE_95W and 95W are set to 1
if grep -q "INCLUDE_95W=1" "$CONFIG_FILE" && grep -q "95W=1" "$CONFIG_FILE"; then
    sh $MODULE_DIR/mode/95W.sh    
fi

# Run 100W.sh then only if both INCLUDE_100W and 100W are set to 1
if grep -q "INCLUDE_100W=1" "$CONFIG_FILE" && grep -q "100W=1" "$CONFIG_FILE"; then
    sh $MODULE_DIR/mode/100W.sh 
fi

# Run 105W.sh then only if both INCLUDE_105W and 105W are set to 1
if grep -q "INCLUDE_105W=1" "$CONFIG_FILE" && grep -q "105W=1" "$CONFIG_FILE"; then
    sh $MODULE_DIR/mode/105W.sh  
fi

# Run 110W.sh then only if both INCLUDE_110W and 110W are set to 1
if grep -q "INCLUDE_110W=1" "$CONFIG_FILE" && grep -q "110W=1" "$CONFIG_FILE"; then
    sh $MODULE_DIR/mode/110W.sh   
fi

# Run 115W.sh then only if both INCLUDE_115W and 115W are set to 1
if grep -q "INCLUDE_115W=1" "$CONFIG_FILE" && grep -q "115W=1" "$CONFIG_FILE"; then
    sh $MODULE_DIR/mode/115W.sh   
fi

# Run 120W.sh then only if both INCLUDE_120W and 120W are set to 1
if grep -q "INCLUDE_120W=1" "$CONFIG_FILE" && grep -q "120W=1" "$CONFIG_FILE"; then
    sh $MODULE_DIR/mode/120W.sh 
fi

# Run 120W.sh then only if both INCLUDE_120W and 120W are set to 1
if grep -q "INCLUDE_BALANCE=1" "$CONFIG_FILE" && grep -q "BALANCE=1" "$CONFIG_FILE"; then
    sh $MODULE_DIR/mode/core_balance.sh 
fi

# ---------------------------
# Carlotta Render (surfaceflinger tuning)
# ---------------------------
# Get refresh rate (best-effort)
refresh_rate=""
# try method 1
if command -v cmd >/dev/null 2>&1; then
    refresh_rate=$(cmd display dump 2>/dev/null | grep -Eo 'fps=[0-9.]+' | cut -f2 -d= | awk '{printf "%.0f\n", $1}' | sort -nr | head -n1 || true)
fi

# fallback method 2
if [ -z "$refresh_rate" ] || [ "$refresh_rate" -lt 1 ]; then
    refresh_rate=$(dumpsys display 2>/dev/null | grep -E 'mRefreshRate|frameRate|mDefaultPeak' | grep -Eo '[0-9.]+' | head -n1 | awk '{printf "%.0f\n",$1}' 2>/dev/null || true)
fi

# default
if [ -z "$refresh_rate" ] || [ "$refresh_rate" -lt 1 ]; then
    refresh_rate=60
fi

# compute frame duration in ns (use bc if available)
if command -v bc >/dev/null 2>&1; then
    frame_duration_ns=$(echo "scale=0; 1000000000 / $refresh_rate" | bc)
else
    # integer fallback
    frame_duration_ns=$((1000000000 / refresh_rate))
fi

# pick ratios based on refresh_rate
if [ "$refresh_rate" -ge 120 ]; then
    app_phase_ratio=0.72
    sf_phase_ratio=0.85
    app_duration_ratio=0.58
    sf_duration_ratio=0.32
elif [ "$refresh_rate" -ge 90 ]; then
    app_phase_ratio=0.70
    sf_phase_ratio=0.82
    app_duration_ratio=0.62
    sf_duration_ratio=0.30
elif [ "$refresh_rate" -ge 75 ]; then
    app_phase_ratio=0.68
    sf_phase_ratio=0.80
    app_duration_ratio=0.65
    sf_duration_ratio=0.28
else
    app_phase_ratio=0.65
    sf_phase_ratio=0.75
    app_duration_ratio=0.68
    sf_duration_ratio=0.25
fi

# compute offsets/durations (use bc when available)
if command -v bc >/dev/null 2>&1; then
    app_phase_offset_ns=$(echo "scale=0; (-$frame_duration_ns * $app_phase_ratio)/1" | bc)
    sf_phase_offset_ns=$(echo "scale=0; (-$frame_duration_ns * $sf_phase_ratio)/1" | bc)
    app_duration=$(echo "scale=0; ($frame_duration_ns * $app_duration_ratio)/1" | bc)
    sf_duration=$(echo "scale=0; ($frame_duration_ns * $sf_duration_ratio)/1" | bc)
else
    # integer math fallback (approx)
    app_phase_offset_ns=$(( - (frame_duration_ns * app_phase_ratio) ))
    sf_phase_offset_ns=$(( - (frame_duration_ns * sf_phase_ratio) ))
    app_duration=$(( frame_duration_ns * app_duration_ratio ))
    sf_duration=$(( frame_duration_ns * sf_duration_ratio ))
fi

# ensure minimum margins and durations
if command -v bc >/dev/null 2>&1; then
    min_margin=$(echo "scale=0; $frame_duration_ns * 0.08 / 1" | bc)
    dead_time=$(echo "scale=0; -($app_duration + $sf_phase_offset_ns)" | bc)
    if [ "$(echo "$dead_time < $min_margin" | bc)" -eq 1 ]; then
        adjustment=$(echo "scale=0; $min_margin - $dead_time" | bc)
        app_duration=$(echo "scale=0; $app_duration - $adjustment" | bc)
    fi
    min_phase_duration=$(echo "scale=0; $frame_duration_ns * 0.12 / 1" | bc)
    if [ "$(echo "$app_duration < $min_phase_duration" | bc)" -eq 1 ]; then
        app_duration=$min_phase_duration
    fi
    if [ "$(echo "$sf_duration < $min_phase_duration" | bc)" -eq 1 ]; then
        sf_duration=$min_phase_duration
    fi
fi

# rounding to integer (printf)
app_duration=$(printf "%.0f" "$app_duration")
sf_duration=$(printf "%.0f" "$sf_duration")
app_phase_offset_ns=$(printf "%.0f" "$app_phase_offset_ns")
sf_phase_offset_ns=$(printf "%.0f" "$sf_phase_offset_ns")

# apply surfaceflinger props
setprop debug.sf.early.app.duration "$app_duration" 2>/dev/null || true
setprop debug.sf.earlyGl.app.duration "$app_duration" 2>/dev/null || true
setprop debug.sf.late.app.duration "$app_duration" 2>/dev/null || true

setprop debug.sf.early.sf.duration "$sf_duration" 2>/dev/null || true
setprop debug.sf.earlyGl.sf.duration "$sf_duration" 2>/dev/null || true
setprop debug.sf.late.sf.duration "$sf_duration" 2>/dev/null || true

setprop debug.sf.early_app_phase_offset_ns "$app_phase_offset_ns" 2>/dev/null || true
setprop debug.sf.high_fps_early_app_phase_offset_ns "$app_phase_offset_ns" 2>/dev/null || true
setprop debug.sf.high_fps_late_app_phase_offset_ns "$app_phase_offset_ns" 2>/dev/null || true
setprop debug.sf.early_phase_offset_ns "$sf_phase_offset_ns" 2>/dev/null || true
setprop debug.sf.high_fps_early_phase_offset_ns "$sf_phase_offset_ns" 2>/dev/null || true
setprop debug.sf.high_fps_late_sf_phase_offset_ns "$sf_phase_offset_ns" 2>/dev/null || true

# threshold ratio -> compute threshold ns
if command -v bc >/dev/null 2>&1; then
    if [ "$refresh_rate" -ge 120 ]; then
        threshold_ratio=0.28
    elif [ "$refresh_rate" -ge 90 ]; then
        threshold_ratio=0.32
    elif [ "$refresh_rate" -ge 75 ]; then
        threshold_ratio=0.35
    else
        threshold_ratio=0.38
    fi
    phase_offset_threshold_ns=$(echo "scale=0; ($frame_duration_ns * $threshold_ratio) / 1" | bc)
    max_threshold=$(echo "scale=0; $frame_duration_ns * 0.45 / 1" | bc)
    min_threshold=$(echo "scale=0; $frame_duration_ns * 0.22 / 1" | bc)

    if [ "$(echo "$phase_offset_threshold_ns > $max_threshold" | bc)" -eq 1 ]; then
        phase_offset_threshold_ns=$max_threshold
    elif [ "$(echo "$phase_offset_threshold_ns < $min_threshold" | bc)" -eq 1 ]; then
        phase_offset_threshold_ns=$min_threshold
    fi
    phase_offset_threshold_ns=$(printf "%.0f" "$phase_offset_threshold_ns")
    setprop debug.sf.phase_offset_thresh_for_next_vsync_ns "$phase_offset_threshold_ns" 2>/dev/null || true
fi

# set various sf/debug props (safe defaults)
setprop debug.sf.enable_advanced_sf_phase_offset 1 2>/dev/null || true
setprop debug.sf.enable_cached_set_render_scheduling true 2>/dev/null || true
setprop debug.sf.enable_egl_image_tracker false 2>/dev/null || true
setprop debug.sf.enable_transaction_tracing false 2>/dev/null || true
setprop debug.sf.layer_caching_highlight false 2>/dev/null || true
setprop debug.sf.trace_hint_sessions false 2>/dev/null || true
setprop debug.sf.vsp_trace false 2>/dev/null || true
setprop debug.sf.layer_history_trace false 2>/dev/null || true
setprop debug.sf.kernel_idle_timer_update_overlay false 2>/dev/null || true
setprop debug.sf.enable_layer_caching 1 2>/dev/null || true
setprop debug.sf.predict_hwc_composition_strategy 1 2>/dev/null || true
setprop debug.sf.disable_client_composition_cache 0 2>/dev/null || true
setprop debug.sf.luma_sampling 0 2>/dev/null || true
setprop debug.sf.show_predicted_vsync false 2>/dev/null || true
setprop debug.sf.treat_170m_as_sRGB 0 2>/dev/null || true
setprop debug.sf.use_phase_offsets_as_durations 0 2>/dev/null || true
setprop debug.sf.enable_hwc_vds 0 2>/dev/null || true
setprop debug.vulkan.enable_callback false 2>/dev/null || true
setprop debug.renderengine.vulkan false 2>/dev/null || true
setprop debug.renderengine.backend skiaglthreaded 2>/dev/null || true
setprop debug.stagefright.renderengine.backend skiaglthreaded 2>/dev/null || true
setprop debug.hwui.initialize_gl_always true 2>/dev/null || true
setprop debug.hwui.early_preload_gl_context true 2>/dev/null || true

# layer caching timeout heuristics
fps_int=$(printf "%.0f" "$refresh_rate" 2>/dev/null || echo 60)
if [ "$fps_int" -ge 120 ]; then
    timeout=42
elif [ "$fps_int" -ge 90 ]; then
    timeout=67
else
    timeout=133
fi
# clamp
if [ "$timeout" -lt 16 ]; then
    timeout=16
elif [ "$timeout" -gt 1000 ]; then
    timeout=1000
fi
setprop debug.sf.layer_caching_active_layer_timeout_ms "$timeout" 2>/dev/null || true

# ---------------------------
# ---------------------------
MODDIR=${0%/*}
MALI_PATH="/proc/mali"
GPUF_PATH="/proc/gpufreq"
GPUF_PATH2="/proc/gpufreqv2"
GED_PATH2="/sys/kernel/debug/ged/hal"
ADRENO_PATH="/sys/class/kgsl/kgsl-3d0"
GED_PATH="/sys/module/ged/parameters"
PVR_PATH2="/sys/kernel/debug/pvr/apphint"
PVR_PATH="/sys/module/pvrsrvkm/parameters"
PLATFORM_GPU_PATH="/sys/devices/platform/gpu"
ADRENO_PATH3="/sys/module/adreno_idler/parameters"
KERNEL_FPSGO_PATH="/sys/kernel/debug/fpsgo/common"
ADRENO_PATH2="/sys/kernel/debug/kgsl/kgsl-3d0/profiling"
GPUFREQ_TRACING_PATH="/sys/kernel/debug/tracing/events/mtk_events"

# helper: log to stdout (kept minimal)
log() { echo "$1"; }

# optimize GPU thermal thresholds (MediaTek / general)
optimize_gpu_temperature() {
    for THERMAL in /sys/class/thermal/thermal_zone*/type; do
        if [ -f "$THERMAL" ]; then
            if grep -E "gpu|ddr" "$THERMAL" >/dev/null 2>&1; then
                for ZONE in "${THERMAL%/*}"/trip_point_*_temp; do
                    if [ -f "$ZONE" ]; then
                        CURRENT_TEMP=$(cat "$ZONE" 2>/dev/null || echo 0)
                        if [ "$CURRENT_TEMP" -lt 90000 ]; then
                            write_val "$ZONE" "95000"
                        fi
                    fi
                done
            fi
        fi
    done

    # disable Adreno thermal nodes (best-effort)
    for all_thermal in $(find /sys/devices/soc -path '*/kgsl/*' -name '*temp*' 2>/dev/null); do
        if [ -f "$all_thermal" ]; then
            chmod 000 "$all_thermal" 2>/dev/null || true
        fi
    done
}

additional_gpu_settings() {
    if [ -d "$GED_PATH" ]; then
        write_val "$GED_PATH/gpu_cust_boost_freq" "2000000"
        write_val "$GED_PATH/gpu_cust_upbound_freq" "2000000"
        write_val "$GED_PATH/ged_smart_boost" "1000"
        write_val "$GED_PATH/gpu_bottom_freq" "800000"
        write_val "$GED_PATH/boost_upper_bound" "100"
        write_val "$GED_PATH/gx_dfps" "$fps_int"
        write_val "$GED_PATH/g_gpu_timer_based_emu" "1"
        write_val "$GED_PATH/boost_gpu_enable" "1"
        write_val "$GED_PATH/ged_boost_enable" "1"
        write_val "$GED_PATH/enable_gpu_boost" "1"
        write_val "$GED_PATH/gx_game_mode" "1"
        write_val "$GED_PATH/gx_boost_on" "1"
        write_val "$GED_PATH/boost_amp" "1"
        write_val "$GED_PATH/gx_3D_benchmark_on" "1"
        write_val "$GED_PATH/is_GED_KPI_enabled" "1"
        write_val "$GED_PATH/gpu_dvfs_enable" "1"
    else
        log "GED_PATH not found, skipping GED optimizations"
    fi

    if [ -d "$GED_PATH2" ]; then
        write_val "$GED_PATH2/gpu_boost_level" "2"
        write_val "$GED_PATH2/custom_upbound_gpu_freq" "1"
    else
        log "GED_PATH2 not found, skipping"
    fi

    if [ -d "$PLATFORM_GPU_PATH" ]; then
        write_val "$PLATFORM_GPU_PATH/dvfs_enable" "1"
        write_val "$PLATFORM_GPU_PATH/gpu_busy" "1"
    else
        log "PLATFORM_GPU_PATH not found, skipping"
    fi
}

optimize_gpu_frequency() {
    if [ -d "$GPUF_PATH" ] && [ -f "$GPUF_PATH/gpufreq_opp_dump" ]; then
        gpu_freq=$(cat "$GPUF_PATH/gpufreq_opp_dump" 2>/dev/null | grep -o 'freq = [0-9]*' | sed 's/freq = //' | sort -nr | head -n1 || true)
        [ -n "$gpu_freq" ] && write_val "$GPUF_PATH/gpufreq_opp_freq" "$gpu_freq"
        for i in $(seq 0 8); do
            write_val "$GPUF_PATH/limit_table" "$i 0 0"
        done
        write_val "$GPUF_PATH/limit_table" "1 1 1"
        write_val "$GPUF_PATH/gpufreq_limited_thermal_ignore" "1"
        write_val "$GPUF_PATH/gpufreq_limited_oc_ignore" "1"
        write_val "$GPUF_PATH/gpufreq_limited_low_batt_volume_ignore" "1"
        write_val "$GPUF_PATH/gpufreq_limited_low_batt_volt_ignore" "1"
        write_val "$GPUF_PATH/gpufreq_fixed_freq_volt" "0"
        write_val "$GPUF_PATH/gpufreq_opp_stress_test" "0"
        write_val "$GPUF_PATH/gpufreq_power_dump" "0"
        write_val "$GPUF_PATH/gpufreq_power_limited" "0"
    else
        log "GPUF_PATH not found, skipping GPUF optimizations"
    fi

    if [ -d "$GPUF_PATH2" ] && [ -f "$GPUF_PATH2/gpu_working_opp_table" ]; then
        gpu_freq2=$(cat "$GPUF_PATH2/gpu_working_opp_table" 2>/dev/null | awk '{print $3}' | sed 's/,//g' | sort -nr | head -n1 || true)
        if [ -n "$gpu_freq2" ]; then
            # try to extract corresponding volt (best-effort)
            gpu_volt=$(awk -v gf="$gpu_freq2" '$0 ~ gf {gsub(/.*, volt: /,""); gsub(/,.*/,""); print}' "$GPUF_PATH2/gpu_working_opp_table" 2>/dev/null | head -n1 || true)
            if [ -n "$gpu_volt" ]; then
                write_val "$GPUF_PATH2/fix_custom_freq_volt" "${gpu_freq2} ${gpu_volt}"
            fi
        fi
        for i in $(seq 0 10); do
            write_val "$GPUF_PATH2/limit_table" "$i 0 0"
        done
        # enable only levels 1..3 (if present)
        write_val "$GPUF_PATH2/limit_table" "1 1 1"
        write_val "$GPUF_PATH2/limit_table" "2 1 1" || true
        write_val "$GPUF_PATH2/aging_mode" "disable"
    else
        log "GPUF_PATH2 not found or missing table, skipping"
    fi
}

optimize_pvr_settings() {
    if [ -d "$PVR_PATH" ]; then
        write_val "$PVR_PATH/gpu_power" "2"
        write_val "$PVR_PATH/HTBufferSizeInKB" "512"
        write_val "$PVR_PATH/DisableClockGating" "1"
        write_val "$PVR_PATH/EmuMaxFreq" "2"
        write_val "$PVR_PATH/EnableFWContextSwitch" "1"
        write_val "$PVR_PATH/gPVRDebugLevel" "0"
        write_val "$PVR_PATH/gpu_dvfs_enable" "1"
    else
        log "PVR_PATH not found, skipping"
    fi

    if [ -d "$PVR_PATH2" ]; then
        write_val "$PVR_PATH2/CacheOpConfig" "1"
        write_val "$PVR_PATH2/CacheOpUMKMThreshSize" "512" 2>/dev/null || true
        write_val "$PVR_PATH2/EnableFTraceGPU" "0"
        write_val "$PVR_PATH2/HTBOperationMode" "2"
        write_val "$PVR_PATH2/TimeCorrClock" "1"
        write_val "$PVR_PATH2/0/DisableFEDLogging" "1"
        write_val "$PVR_PATH2/0/EnableAPM" "0"
    else
        log "PVR_PATH2 not found, skipping"
    fi
}

optimize_adreno_driver() {
    if [ -d "$ADRENO_PATH" ]; then
        if [ -f "$ADRENO_PATH/num_pwrlevels" ]; then
            PWRLVL=$(($(cat "$ADRENO_PATH/num_pwrlevels" 2>/dev/null) - 1))
            mask_val "$PWRLVL" "$ADRENO_PATH/default_pwrlevel"
            mask_val "$PWRLVL" "$ADRENO_PATH/min_pwrlevel"
        fi
        mask_val "0" "$ADRENO_PATH/max_pwrlevel"
        mask_val "1" "$ADRENO_PATH/bus_split"
        mask_val "1" "$ADRENO_PATH/force_clk_on"
        mask_val "1" "$ADRENO_PATH/force_no_nap"
        mask_val "1" "$ADRENO_PATH/force_rail_on"
        mask_val "0" "$ADRENO_PATH/force_bus_on"
        mask_val "0" "$ADRENO_PATH/thermal_pwrlevel"
        mask_val "0" "$ADRENO_PATH/perfcounter"
        mask_val "0" "$ADRENO_PATH/throttling"
        mask_val "0" "$ADRENO_PATH/fsync_enable"
        mask_val "0" "$ADRENO_PATH/vsync_enable"
    else
        log "ADRENO_PATH not found, skipping"
    fi

    mask_val "1114800000" "$ADRENO_PATH/max_gpuclk" 2>/dev/null || true
    mask_val "1114800000" "$ADRENO_PATH/gpuclk" 2>/dev/null || true
    mask_val "1114" "$ADRENO_PATH/max_clock_mhz" 2>/dev/null || true
    mask_val "1114" "$ADRENO_PATH/gpuclk_mhz" 2>/dev/null || true

    write_val "$ADRENO_PATH/devfreq/adrenoboost" "0"
    write_val "$ADRENO_PATH2/enable" "0"
    write_val "$ADRENO_PATH3/adreno_idler_active" "0"
    write_val "/sys/module/msm_performance/parameters/touchboost" "1"
}

optimize_mali_driver() {
    if [ -d "$MALI_PATH" ]; then
        write_val "$MALI_PATH/dvfs_enable" "1"
        write_val "$MALI_PATH/max_clock" "550000"
        write_val "$MALI_PATH/min_clock" "100000"
    else
        log "MALI_PATH not found, skipping"
    fi

    # also try earlier discovered mali dirs (if present)
    if [ -n "$mali_sched_dir" ]; then
        write_val "$mali_sched_dir/serialize_jobs" "full"
    fi
    if [ -n "$mali_root_dir" ]; then
        write_val "$mali_root_dir/js_ctx_scheduling_mode" "1"
    fi
}

optimize_task_cgroup_nice() {
    # ps list snapshot
    ps_ret="$(ps -Ao pid,args 2>/dev/null || ps -A -o pid,args 2>/dev/null || true)"

    change_task_cgroup() {
        # $1: pattern, $2: cgroup name, $3: "cpuset" or "stune"
        local patt="$1"; local cg="$2"; local ctl="$3"
        for temp_pid in $(echo "$ps_ret" | grep -i -E "$patt" | grep -v "PID" | awk '{print $1}' 2>/dev/null); do
            for temp_tid in $(ls "/proc/$temp_pid/task/" 2>/dev/null); do
                if [ -f "/proc/$temp_pid/task/$temp_tid/comm" ]; then
                    # write to tasks if path exists
                    if [ -w "/dev/$ctl/$cg/tasks" ]; then
                        echo "$temp_tid" > "/dev/$ctl/$cg/tasks" 2>/dev/null || true
                    fi
                fi
            done
        done
    }

    # apply recommended changes (best-effort)
    change_task_cgroup "surfaceflinger" "" "cpuset"
    change_task_cgroup "system_server" "foreground" "cpuset"
    change_task_cgroup "netd|allocator" "foreground" "cpuset"
    change_task_cgroup "hardware.media.c2|vendor.mediatek.hardware" "background" "cpuset"
}

final_optimize_gpu() {
    if [ -d "$KERNEL_FPSGO_PATH" ]; then
        if [ -f "$KERNEL_FPSGO_PATH/gpu_block_boost" ]; then
            current_val=$(cat "$KERNEL_FPSGO_PATH/gpu_block_boost" 2>/dev/null || echo "")
            num_fields=$(echo "$current_val" | awk '{print NF}' 2>/dev/null || echo 0)
            if [ "$num_fields" -eq 1 ]; then
                write_val "$KERNEL_FPSGO_PATH/gpu_block_boost" "100"
            elif [ "$num_fields" -eq 3 ]; then
                write_val "$KERNEL_FPSGO_PATH/gpu_block_boost" "60 120 1"
            else
                log "gpu_block_boost unknown format: $current_val"
            fi
        else
            log "gpu_block_boost node not found"
        fi
    else
        log "KERNEL_FPSGO_PATH not found"
    fi

    # disable some tracing nodes (best-effort)
    for pvrtracing in $(find /sys/kernel/debug/tracing/events/pvr_fence -name 'enable' 2>/dev/null); do
        write_val "$pvrtracing" "0"
    done

    write_val "$GPUFREQ_TRACING_PATH/enable" "0" 2>/dev/null || true
    write_val "/proc/gpufreq/gpufreq_aging_enable" "0" 2>/dev/null || true

    # cpuset configuration (best-effort; adapt to your cpu topology)
    write_val "/dev/cpuset/foreground/cpus" "0-3,4-7" 2>/dev/null || true
    write_val "/dev/cpuset/foreground/boost/cpus" "4-7" 2>/dev/null || true
    write_val "/dev/cpuset/top-app/cpus" "0-7" 2>/dev/null || true
}

cleanup_memory() {
    write_val "/proc/sys/vm/drop_caches" "3" 2>/dev/null || true
    write_val "/proc/sys/vm/compact_memory" "1" 2>/dev/null || true
}

# main GPU/render optimization sequence
main_render_optimizations() {
    optimize_gpu_temperature
    additional_gpu_settings
    optimize_gpu_frequency
    optimize_pvr_settings
    optimize_adreno_driver
    optimize_mali_driver
    optimize_task_cgroup_nice
    final_optimize_gpu
    cleanup_memory
}

main_render_optimizations

if [ -f "$MODULE_DIR/TerX.sh" ] && [ "$(readlink -f "$0")" != "$MODULE_DIR/TerX.sh" ]; then
    sh $MODULE_DIR/TerX.sh 2>/dev/null || true
fi

# Post notification 
# notification
# 18W Fast Charging Mode - Aggressive
if [ "$(id -u)" = "0" ]; then
    su -lp 2000 -c "cmd notification post -S bigtext -t ' 🌏Atmosphere Battery UI❄️🔥' tag 'Active : ✅Service Running🔥'" >/dev/null 2>&1
fi

sh "$MODULE_DIR/scripts/Fast_Charger_System.sh"
sh "$MODULE_DIR/scripts/safe_access.sh"
sh "$MODULE_DIR/Touch_Enchancer.sh"
sh "$MODULE_DIR/Battery/TerX.sh"
sh "$MODULE_DIR/Battery/Powersave.sh"
sh "$MODULE_DIR/scripts/terx.sh"

# Late Starting this service

/data/user_de/0/com.android.shell/axeron/plugins/atmosphere_battery/system/bin/atmosphere_battery_ui