#!/system/bin/sh

MODDIR="${0%/*}"
SERVICE="$MODDIR/service.sh"

chmod 0755 "$SERVICE"

chmod 0755 /data/user_de/0/com.android.shell/axeron/plugins/atmosphere_battery/system/bin/main_power_ui

/data/user_de/0/com.android.shell/axeron/plugins/atmosphere_battery/system/bin/main_power_ui

