#!/system/bin/sh

# Copyright (C) 2024-2025 Kanao
# Licensed under the Apache License, Version 2.0
# See http://www.apache.org/licenses/LICENSE-2.0

SKIPMOUNT=false
PROPFILE=true
POSTFSDATA=true
LATESTARTSERVICE=true

TOAST_PKG="bellavita.toast"
BASEDIR="/data/adb/.config/stellar"

ENVIRONMENT=""
ROOT_METHOD=""
USE_SKIPMOUNT=false
CHIPSET_ID=0

BINS="stellars vmt stellar_helper"

ui_print() {
    echo "- $1"
    sleep 0.1
}

abort_clean() {
    echo " "
    echo "******************************************** "
    echo "! ERROR: $1"
    echo "! Installation failed! $2" 
    echo "******************************************** "
    echo " "
    exit 1
}

set_perm_simple() {
    local file="$1"
    local uid="$2"
    local gid="$3"
    local mode="$4"
    chown $uid:$gid "$file" 2>/dev/null
    chmod $mode "$file" 2>/dev/null
}

set_perm_recursive() {
    local dir="$1"
    local uid="$2"
    local gid="$3"
    local dirmode="$4"
    local filemode="$5"
    chown -R $uid:$gid "$dir" 2>/dev/null
    find "$dir" -type d -exec chmod $dirmode {} \; 2>/dev/null
    find "$dir" -type f -exec chmod $filemode {} \; 2>/dev/null
}

abort() {
    echo "! ABORT: $1"
    exit 1
}

safe_extract() {
    local file_pattern="$1"
    local dest="$2"
    ui_print "- Extracting $file_pattern..."
    if ! unzip -qo "$ZIPFILE" "$file_pattern" -d "$dest"; then
        abort_clean "Failed to extract $file_pattern"
    fi
}

detect_environment() {
    ui_print "- Detecting environment..."
    
    if [ -n "$AXERON" ] && [ "$AXERON" = "true" ]; then
        ENVIRONMENT="AXERON"
        BASEDIR="/data/data/com.android.shell/AxManager/plugins/stellar/.config"
        USE_SKIPMOUNT=true
        ui_print "Axeron environment detected (Non-root)"
        return
    fi
    
    if [ "$(id | grep -c root)" -gt 0 ] || [ "$(whoami)" = "root" ]; then
        if [ -d "/data/adb/ksu" ]; then
            ENVIRONMENT="KSU"
            USE_SKIPMOUNT=true
            ui_print "KernelSU detected"
            return
        fi
        
        if [ -d "/data/adb/ap" ]; then
            ENVIRONMENT="APATCH"
            USE_SKIPMOUNT=true
            ui_print "Apatch detected"
            return
        fi
        
        ENVIRONMENT="ROOT"
        ui_print "Root environment detected"
        return
    fi
    
    abort_clean "No environment detected" "Ensure you have root or Axeron environment"
}

apply_skipmount() {
    if $USE_SKIPMOUNT; then
        ui_print "Applying skip_mount for $ENVIRONMENT"
        touch "$MODPATH/skip_mount"
        if [ -f "$MODPATH/action.sh" ]; then
            rm "$MODPATH/action.sh"
            ui_print "Removed action.sh"
        fi
    fi
}

install_toast_apk() {
    ui_print "Installing Bellavita Toast"
    pm uninstall bellavita.toast >/dev/null 2>&1
    if [ -f "$MODPATH/toast.apk" ]; then
        pm install -r "$MODPATH/toast.apk" >/dev/null
        ui_print "Toast APK installed"
    else
        ui_print "Warning: toast.apk not found"
    fi
}

setup_directories_and_configs() {
    ui_print "Setting up directories..."
    
    mkdir -p "$BASEDIR" || abort_clean "Failed to create directory"
    touch "$BASEDIR/lock" || abort_clean "Failed to create lock"
    touch "$BASEDIR/soc" || abort_clean "Failed to create soc"
    
    cat > "$BASEDIR/config.json" <<EOF
{
  "utility_tool": {
    "gms_auto": false,
    "clear_ram": false
  },
  "cpu_governors": {
    "normal": "interactive",
    "game": "performance",
    "powersave": "interactive"
  },
  "scheduler_io": {
    "normal": "",
    "game": "",
    "powersave": ""
  },
  "battery_saving": {
    "disable_network": false,
    "ultra_saving": false,
    "bypass_charging": false
  },
  "advanced_dvfs": {
    "cpu_limit": 100,
    "gpu_limit": 100
  },
  "downscaling": {
    "scale": 1.0
  },
  "devmode": {
    "debug_logging": false
  },
  "ai_configuration": {
    "master_enabled": false
  }
}
EOF
    ui_print "Config created at $BASEDIR/config.json"
}

identify_chipset() {
    ui_print "Identifying chipset..."
    
    if [ -d /sys/kernel/ged/hal ]; then CHIPSET_ID=1
    elif [ -d /sys/class/kgsl/kgsl-3d0/devfreq ] || [ -d /sys/devices/platform/kgsl-2d0.0/kgsl ]; then CHIPSET_ID=2
    elif [ -d /sys/kernel/tegra_gpu ]; then CHIPSET_ID=7
    fi
    
    if [ $CHIPSET_ID -eq 0 ]; then
        local SOC_INFO=""
        SOC_INFO="$SOC_INFO $(getprop ro.board.platform 2>/dev/null)"
        SOC_INFO="$SOC_INFO $(getprop ro.soc.model 2>/dev/null)"
        SOC_INFO="$SOC_INFO $(getprop ro.hardware 2>/dev/null)"
        
        case "$SOC_INFO" in
            *mt*|*MT*) CHIPSET_ID=1 ;;
            *sm*|*qcom*|*SM*|*QCOM*|*Qualcomm*) CHIPSET_ID=2 ;;
            *exynos*|*Exynos*|*EXYNOS*) CHIPSET_ID=3 ;;
            *unisoc*|*UNISOC*|*ums*) CHIPSET_ID=4 ;;
            *tensor*|*Tensor*|*gs*) CHIPSET_ID=5 ;;
            *intel*|*Intel*) CHIPSET_ID=6 ;;
            *kirin*|*Kirin*) CHIPSET_ID=8 ;;
        esac
    fi
    
    case "$CHIPSET_ID" in
        1) ui_print "MediaTek" ;;
        2) ui_print "Snapdragon" ;;
        3) ui_print "Exynos" ;;
        4) ui_print "Unisoc" ;;
        5) ui_print "Google Tensor" ;;
        6) ui_print "Intel" ;;
        7) ui_print "Nvidia Tegra" ;;
        8) ui_print "Kirin" ;;
        *) ui_print "Universal" ;;
    esac
    
    echo "$CHIPSET_ID" > "$BASEDIR/soc"
    ui_print "Chipset ID: $CHIPSET_ID saved to soc file"
}

copy_binaries() {
    ui_print "Copying binaries..."
    
    local SRC_BIN="$MODPATH/system/bin"
    
    case $ENVIRONMENT in
        "AXERON")
            DEST_BIN="/data/data/com.android.shell/AxManager/bin"
            mkdir -p "$DEST_BIN"
            ;;
        "KSU")
            DEST_BIN="/data/adb/ksu/bin"
            mkdir -p "$DEST_BIN"
            ;;
        "APATCH")
            DEST_BIN="/data/adb/ap/bin"
            mkdir -p "$DEST_BIN"
            ;;
        "ROOT")
            return
            ;;
    esac
    
    if [ -n "$DEST_BIN" ] && [ -d "$SRC_BIN" ]; then
        for bin in $BINS; do
            if [ -f "$SRC_BIN/$bin" ]; then
                rm -f "$DEST_BIN/$bin"
                cp "$SRC_BIN/$bin" "$DEST_BIN/$bin"
                chmod 777 "$DEST_BIN/$bin"
                ui_print "Copied: $bin → $DEST_BIN"
            else
                ui_print "Warning: $bin not found in $SRC_BIN"
            fi
        done
    else
        ui_print "Warning: Source binaries directory not found"
    fi
}

set_permissions() {
    ui_print "Setting permissions..."
    
    if [ -d "$MODPATH" ]; then
        set_perm_recursive "$MODPATH" 0 0 0755 0644
        if [ -d "$MODPATH/system/bin" ]; then
            set_perm_recursive "$MODPATH/system/bin" 0 2000 0755 0755
        fi
    fi
}

finalize_installation() {
    RAND_MSG=$((RANDOM % 8 + 1))
    case $RAND_MSG in
        1) ui_print "Fall star from heaven -stellar" ;;
        2) ui_print "Void Feeling The Negative Effect." ;;
        3) ui_print "Against The Law, Dont Soft." ;;
        4) ui_print "Emotion Anger From Stellar." ;;
        5) ui_print "Feed Me Donate Wen." ;;
        6) ui_print "Try Be Honest, May Can Safe You (?)" ;;
        7) ui_print "Anyone Would Seen This?!" ;;
        8) ui_print "Premium Vvip Gaming 6969?!" ;;
    esac
    
    ui_print "Join our channel for updates!"
    sleep 1

    am start -a android.intent.action.VIEW -d "https://t.me/hosshi_prjkt" >/dev/null 2>&1
}

detect_environment
apply_skipmount
install_toast_apk
setup_directories_and_configs
identify_chipset
copy_binaries
set_permissions
finalize_installation