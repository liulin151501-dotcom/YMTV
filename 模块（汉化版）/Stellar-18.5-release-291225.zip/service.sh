#!/system/bin/sh

# Copyright (C) 2024-2025 Kanao
# Licensed under the Apache License, Version 2.0
# See http://www.apache.org/licenses/LICENSE-2.0

# Wait when it's done
while [ "$(getprop sys.boot_completed | tr -d '\r')" != "1" ]; do sleep 10; done

# Be ready
sleep 20

# Pushy pushy !
while true; do
    if ! pgrep -x stellars; then
        stellars
    else
        exit 0
    fi
    sleep 5
done