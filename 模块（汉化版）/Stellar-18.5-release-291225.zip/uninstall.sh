#!/bin/sh

# Copyright (C) 2024-2025 Kanao
# Licensed under the Apache License, Version 2.0
# See http://www.apache.org/licenses/LICENSE-2.0

# Resetting Default Value
cmd settings reset global
cmd settings reset secure
cmd settings reset system

# Resetting Fully
stellar_helper --resetting_sys

# Old binary
BINS="stellars vmt stellar_helper"
for DIR in /data/adb/*/bin; do
    [ -d "$DIR" ] && for BIN in $BINS; do
        rm -f "$DIR/$BIN"
    done
done