#!/system/bin/sh
# Celestial-Priority-UFW by Kazuyoo  
# Copyright (c) 2026 Kazuyoo
# Licensed under the Apache License, Version 2.0
# http://www.apache.org/licenses/LICENSE-2.0
# Open-source powered — with appreciation to GL-DP and all contributors.
MODDIR=${0%/*};[ "${AXERON:-false}" = "true" ] && [ ! -f "$AXERONXBIN/RC" ] && cp -f "$MODDIR/system/bin/RC" "$AXERONXBIN/RC"

# ----------------- HELPER FUNCTIONS -----------------
wait_until_boot_completed() {
    # Wait sys.boot_completed
    while [ "$(getprop sys.boot_completed)" != "1" ]; do
        sleep 2
    done

    # Wait for storage to mount
    until [ -d "/sdcard/Android" ] || [ -d "/storage/emulated/0/Android" ]; do
        sleep 1
    done
}
  
send_notification() {
    # Notify user of optimization completion
    if command -v su >/dev/null 2>&1; then
        su -lp 2000 -c "cmd notification post -S bigtext -t 'Ram-Compaction' tag 'Status :  Optimization Completed!'" >/dev/null 2>&1
    else
        cmd notification post -S bigtext -t 'Ram-Compaction' 'tag' 'Status :  Optimization Completed!' >/dev/null 2>&1
    fi
}
wait_until_boot_completed

# Main Execution & Exit script successfully
RC --execute;send_notification;exit 0