#!/system/bin/sh
# Celestial-Flinger-Flux by Kazuyoo
# Copyright (c) 2026 Kazuyoo
# Licensed under the Apache License, Version 2.0
# http://www.apache.org/licenses/LICENSE-2.0
# Open-source powered — with appreciation to GL-DP and all contributors.
# Set logcat buffer size @Dcx400 
a=$(awk '/MemTotal/ {printf"%.0f\n",$2/1024/1024}' /proc/meminfo);logcat -G "$a"m

# === PRINT FUNCTION SELECTION ===
if [ "$AXERON" == "true" ]; then
    PRINT="printf"
else
    PRINT="ui_print"
fi

# === PRINT FUNCTION WRAPPER ===
print_msg() {
    case "$PRINT" in
        ui_print) ui_print "$1" ;;
        printf) printf "$1" ;;
    esac
}

# === LINE SEPARATOR ===
print_line() {
    ui_print "***************************************"
}

# === TRIM PARTITION ===
trim_partition() {
    if command -v su >/dev/null; then
        for partition in data cache metadata storage;do fstrim -v "/$partition";done
    else
        for partition in data cache metadata storage;do sm fstrim "/$partition";done
    fi
}

# === CHECK COMPACT FEATURE AVAILABILITY ===
if ! cmd activity | grep -q "compact" 2>/dev/null; then
    echo "    [ERROR]: 'cmd activity compact' not found on this device."
    echo "⚠️  This feature is only available on devices"
    echo "    with Android 13+ or specific vendor frameworks."
    rm -rf "$MODPATH"
    exit 1
fi

# === DEVICE INFO ===
ANDROIDVERSION=$(getprop ro.build.version.release)
DEVICES=$(getprop ro.product.board)
MANUFACTURER=$(getprop ro.product.manufacturer)
API=$(getprop ro.build.version.sdk)
ABI=$(getprop ro.product.cpu.abi)
NAME="Ram-Compaction | Kzyo"
VERSION="1.5 | Efficient"
DATE=$(date)

# === STARTER ===
if [ -z "$ABI" ];then ABI=$(getprop ro.product.cpu.abi);fi
[[ "$ABI" == *64* ]] && arch="64" || arch="32";mv -f "$MODPATH/system/bin/RC${arch}" "$MODPATH/system/bin/RC"

# === DISPLAY BANNER ===
print_msg "░█▀▀█ ── ░█▀▀█ ░█▀▄▀█ ░█▀▀█ ▀▀█▀▀ 
░█▄▄▀ ▀▀ ░█─── ░█░█░█ ░█▄▄█ ─░█── 
░█─░█ ── ░█▄▄█ ░█──░█ ░█─── ─░█──"
ui_print ""
sleep 0.5
print_msg "         reduce ram usage."
sleep 0.2
ui_print ""
print_line
print_msg "- Name            : ${NAME}"
sleep 0.2
print_msg "- Version         : ${VERSION}"
sleep 0.2
print_msg "- Android Version : ${ANDROIDVERSION:-Unknown}"
sleep 0.2
print_msg "- Current Date    : ${DATE}"
sleep 0.2
print_line
print_msg "- Devices         : ${DEVICES:-Unknown}"
sleep 0.2
print_msg "- Manufacturer    : ${MANUFACTURER:-Unknown}"
sleep 0.2
print_line
print_msg "- Architecture ${arch}-bit detected."
sleep 0.2
print_msg "- Trimming up Partitions"
trim_partition>/dev/null 2>&1 &
sleep 2

# === SET PERMISSIONS ===
if command -v su >/dev/null; then ui_print "- Setting permissions";set_perm_recursive $MODPATH/system/bin 0 0 0755 0755;fi

# === CLEANUP ===
logcat -c &>/dev/null