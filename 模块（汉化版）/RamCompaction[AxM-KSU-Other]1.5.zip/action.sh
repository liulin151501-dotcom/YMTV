# ====== CHECK IF service.sh IS RUNNING ======
check_service_status() {
    if pgrep RC &>/dev/null; then
        echo "[ACTIVE] PID : $(pgrep RC) | Service is already running."
        return 0
    else
        echo "[INACTIVE] Service is not running."
        return 1
    fi
}
check_service_status