# =========================================== #

#!/system/bin/sh
# === 恢复性能模式默认设置 ===

# 电源设置（恢复正常）
cmd power set-fixed-performance-mode-enabled false
cmd power set-adaptive-power-saver-enabled true
cmd power set-mode 1  # balanced

# 热控恢复
cmd thermalservice override-status reset

# 删除自定义 power_check 配置
settings delete global power_check_max_cpu_1
settings delete global power_check_max_cpu_2
settings delete global power_check_max_cpu_3
settings delete global power_check_max_cpu_4

# HWUI 和 EGL 默认设置
setprop debug.hwui.target_power_time_percent 0
setprop debug.hwui.trace_gpu_resources true
setprop debug.egl.force_msaa true
setprop debug.hwui.use_hint_manager 0
setprop debug.hwui.disable_vsync false
setprop debug.hwui.disable_scissor_opt false

# 禁用性能调整
setprop debug.performance.tuning 0
setprop debug.composition.type gpu

# 渲染器默认设置（OpenGL）
setprop debug.hwui.renderer opengl
setprop debug.renderengine.backend skiagl

# 禁用自定义 vsync 调整
setprop debug.cpurend.vsync true

# 重新激活 ZRAM
settings put global zram_enabled 1

# 卡顿监控恢复
device_config delete interaction_jank_monitor enabled
device_config delete interaction_jank_monitor sampling_interval
device_config delete interaction_jank_monitor trace_threshold_frame_time_millis
device_config delete interaction_jank_monitor trace_threshold_missed_frames
device_config delete activity_manager disable_app_profiler_pss_profiling

# 动态系统恢复
cmd settings delete system air_motion_engine
cmd settings delete system master_motion
cmd settings delete system motion_engine

# 恢复 CPU power hint
setprop debug.cluster_little-set_his_speed ""
setprop debug.cluster_big-set_his_speed ""
setprop debug.powehint.cluster_little-set_his_speed ""
setprop debug.powehint.cluster_big-set_his_speed ""

# 清除 debug 标志
cmd activity clear-debug-app
cmd activity clear-exit-info

echo "✅ 系统已恢复到默认模式（移除模式成功）"
