async function safeExec(cmd) {
    try {
        if (window.webuix?.send) return await window.webuix.send(cmd);
        if (window.ksu?.exec) {
            const r = await window.ksu.exec(cmd);
            return r.stdout ?? r;
        }
    } catch (e) {
        console.error(e);
    }
    return "";
}

if (window.ksu && typeof window.ksu.fullScreen === 'function') {
    window.ksu.fullScreen(true);
}

window.runCmd = safeExec;
window.openLink = async (url) => {
    await safeExec(`cmd activity start -a android.intent.action.VIEW -d "${url}"`);
};

const SAVED_PKG_PATH = "/data/local/tmp/kyroos_selected_apps.list";
let savedPackagesSet = new Set();

async function loadSavedPackagesList() {
    try {
        await safeExec(`touch ${SAVED_PKG_PATH}`);
        const content = await safeExec(`cat ${SAVED_PKG_PATH}`);
        if (content) {
            savedPackagesSet = new Set(content.split('\n').map(s => s.trim()).filter(Boolean));
        } else {
            savedPackagesSet.clear();
        }
    } catch (e) {
        savedPackagesSet.clear();
    }
}

window.toggleAppSelection = async (pkg, checkbox) => {
    if (checkbox.checked) {
        savedPackagesSet.add(pkg);
        await safeExec(`echo "${pkg}" >> ${SAVED_PKG_PATH}`);
    } else {
        savedPackagesSet.delete(pkg);
        if (savedPackagesSet.size === 0) {
            await safeExec(`rm -rf ${SAVED_PKG_PATH}`);
        } else {
            const safePkg = pkg.replace(/\./g, '\\.');
            await safeExec(`sed -i "/^${safePkg}$/d" ${SAVED_PKG_PATH}`);
        }
    }
};

const REFRESH_RATE_MAP = { 0: 60, 1: 90, 2: 120, 3: 144, 4: -1 };
const REFRESH_RATE_TEXT = {
    '60': '60 Hz', '90': '90 Hz', '120': '120 Hz', '144': '144 Hz',
    '-1': 'Max (Stock/Auto)', '0': 'Max (Stock/Auto)'
};

function updateText(id, text, isSkeleton = false) {
    const el = document.getElementById(id);
    if (!el) return;
    if (el.textContent !== text) el.textContent = text;
    el.classList.toggle('skeleton', isSkeleton);
}

window.toggleDescription = (cardId, descriptionId) => {
    const card = document.getElementById(cardId);
    const desc = document.getElementById(descriptionId);
    if (!card || !desc) return;

    document.querySelectorAll('.hidden-desc.expanded').forEach(d => {
        if (d.id !== descriptionId) {
            d.classList.remove('expanded');
            d.previousElementSibling?.classList.remove('is-open');
        }
    });

    const isExpanded = desc.classList.toggle('expanded');
    card.classList.toggle('is-open', isExpanded);
};

(function initTheme() {
    const currentTheme = localStorage.getItem('theme');
    const themeIcon = document.getElementById('theme-icon');
    if (currentTheme) {
        document.documentElement.setAttribute('data-theme', currentTheme);
        if (currentTheme === 'dark' && themeIcon) themeIcon.textContent = 'light_mode';
    }
})();

window.toggleTheme = () => {
    const html = document.documentElement;
    const icon = document.getElementById('theme-icon');
    const isDark = html.getAttribute('data-theme') === 'dark';
    const newTheme = isDark ? 'light' : 'dark';
    
    html.setAttribute('data-theme', newTheme);
    localStorage.setItem('theme', newTheme);
    if (icon) icon.textContent = isDark ? 'dark_mode' : 'light_mode';
};

function setStatusVisuals(kyroosActive, perfActive, nupidActive) {
    const img = document.getElementById('status-image');
    const title = document.getElementById('status-title');
    const pid = document.getElementById('status-pid');
    const thresholdCard = document.getElementById('threshold-card');

    if (!img || !title || !pid) return;

    const activeCount = [kyroosActive, perfActive, nupidActive].filter(Boolean).length;

    let config = {
        src: 'status_stopped.png',
        text: 'Services Stopped',
        color: 'var(--text-main)',
        pidHtml: '<span class="material-symbols-rounded" style="font-size:16px;">power_settings_new</span> Inactive',
        pidBorder: 'var(--outline)',
        pidColor: 'var(--text-sub)',
        pidBg: 'var(--surface-container)',
        showThreshold: true
    };

    if (activeCount >= 2) {
        let activeNames = [];
        if (kyroosActive) activeNames.push("SunDae");
        if (perfActive) activeNames.push("Sigma");
        if (nupidActive) activeNames.push("Nupid");
        
        const labelStr = activeCount === 3 ? "All Engines" : activeNames.join(" + ");

        config = {
            src: 'status_working.png', 
            text: 'Hybrid Active',
            color: '#9C27B0', 
            pidHtml: `<span class="material-symbols-rounded" style="font-size:16px; color:#9C27B0;">hub</span> ${labelStr}`,
            pidBorder: '#9C27B0', 
            pidColor: '#9C27B0', 
            pidBg: 'rgba(156, 39, 176, 0.1)',
            showThreshold: kyroosActive 
        };
    } else if (perfActive) {
        config = {
            src: 'status_working.png', 
            text: 'Performance',
            color: '#C2185B',
            pidHtml: '<span class="material-symbols-rounded" style="font-size:16px; color:#C2185B;">rocket_launch</span> Active',
            pidBorder: '#C2185B', pidColor: '#C2185B', pidBg: 'rgba(194, 24, 91, 0.1)',
            showThreshold: false
        };
    } else if (nupidActive) {
        config = {
            src: 'status_working.png', 
            text: 'Nupid Stiggers',
            color: '#0041FA',
            pidHtml: '<span class="material-symbols-rounded" style="font-size:16px; color:#0041FA;">auto_awesome</span> Active',
            pidBorder: '#0041FA', 
            pidColor: '#0041FA', 
            pidBg: 'rgba(98, 0, 234, 0.1)',
            showThreshold: false 
        };
    } else if (kyroosActive) {
        config = {
            src: 'status_working.png', 
            text: 'SunDae',
            color: 'var(--primary-color)',
            pidHtml: '<span class="material-symbols-rounded" style="font-size:16px; color:var(--primary-color);">check_circle</span> Active',
            pidBorder: 'var(--primary-color)', pidColor: 'var(--primary-color)', pidBg: 'var(--primary-container)',
            showThreshold: true
        };
    }

    if (img.src !== config.src) img.src = config.src;
    title.textContent = config.text;
    title.style.color = config.color;
    pid.innerHTML = config.pidHtml;
    pid.style.borderColor = config.pidBorder;
    pid.style.color = config.pidColor;
    pid.style.background = config.pidBg;
    
    if (thresholdCard) {
        thresholdCard.style.display = config.showThreshold ? 'flex' : 'none';
    }
}

async function loadSystemInfo() {
    const [pidSigmaRaw, sPsRaw, pidGorrRaw, gPsRaw, pidNupidRaw, nPsRaw] = await Promise.all([
        safeExec('pgrep sigma'),
        safeExec('ps -A | grep sigma | grep -v grep'),
        safeExec('pgrep gorrfu'),
        safeExec('ps -A | grep gorrfu | grep -v grep'),
        safeExec('pgrep nupid'),
        safeExec('ps -A | grep nupid | grep -v grep')
    ]);

    const isKyroosActive = (pidSigmaRaw && /^\d+$/.test(pidSigmaRaw.trim())) || (sPsRaw && /(\d+)/.test(sPsRaw));
    const isPerfActive = (pidGorrRaw && /^\d+$/.test(pidGorrRaw.trim())) || (gPsRaw && /(\d+)/.test(gPsRaw));
    const isNupidActive = (pidNupidRaw && /^\d+$/.test(pidNupidRaw.trim())) || (nPsRaw && /(\d+)/.test(nPsRaw));

    setStatusVisuals(isKyroosActive, isPerfActive, isNupidActive);

    const updateSwitch = (id, textId, active, activeText, activeColor, activeWeight) => {
        const sw = document.getElementById(id);
        const txt = document.getElementById(textId);
        if (sw && txt) {
            sw.checked = active;
            txt.textContent = active ? activeText : "Inactive";
            txt.style.color = active ? activeColor : "var(--text-sub)";
            txt.style.fontWeight = active ? activeWeight : "500";
        }
    };

    updateSwitch('daemon-switch', 'daemon-state-text', isKyroosActive, "SunDae Active", "var(--primary-color)", "600");
    updateSwitch('perf-switch', 'perf-state-text', isPerfActive, "Performance Active", "#C2185B", "700");
    updateSwitch('nupid-switch', 'nupid-state-text', isNupidActive, "Nupid Active", "#6200EA", "700");

    const relValEl = document.getElementById('release-val');
    if (relValEl?.classList.contains('skeleton')) {
        const [rel, kern, chipRaw, ndkRaw] = await Promise.all([
            safeExec('getprop ro.build.version.release'),
            safeExec('uname -r'),
            safeExec('getprop ro.board.platform'),
            safeExec('getprop ro.build.version.sdk')
        ]);

        const androidVersion = rel.trim() || 'Unknown';
        const ndkValue = ndkRaw.trim();
        updateText('release-val', ndkValue && ndkValue !== 'Unknown' ? `${androidVersion} (SDK ${ndkValue})` : androidVersion);
        updateText('kernel-val', kern.trim() || 'Unknown');
        
        let chip = chipRaw.trim();
        if (/sm|sdm/i.test(chip)) chip = `Snapdragon ${chip}`;
        updateText('chipset-val', chip || 'Unknown');
    }

    const memEl = document.getElementById('memory-total-val');
    if (memEl?.textContent === '...') updateText('memory-total-val', '...', true);

    if (isKyroosActive) updateText('threshold-status-text', 'Reading...', false);

    const [memInfoRaw, thresholdRaw] = await Promise.all([
        safeExec("cat /proc/meminfo"),
        isKyroosActive ? safeExec("cat /data/local/tmp/utensil/battery_learning.dat") : Promise.resolve('')
    ]);

    const memMatch = (memInfoRaw || "").match(/MemTotal:\s+(\d+)/);
    const memRaw = memMatch ? memMatch[1] : null;

    const kb = parseInt(memRaw, 10);
    updateText('memory-total-val', !isNaN(kb) ? (kb / 1024 / 1024).toFixed(1) + ' GB' : 'N/A', false);

    const thresholdPct = (thresholdRaw && /^\d+$/.test(thresholdRaw.trim())) ? thresholdRaw.trim() : '';
    let summaryMsg = "Service Stopped", fullMsg = "Daemon is currently sleeping.";

    const activeCount = [isKyroosActive, isPerfActive, isNupidActive].filter(Boolean).length;

    if (activeCount >= 2) {
        fullMsg = (thresholdPct && isKyroosActive) ? `Hybrid Mode Active. Threshold: ${thresholdPct}%` : "Multi-Engine Mode Active";
        summaryMsg = (thresholdPct && isKyroosActive) ? `Hybrid • ${thresholdPct}%` : "Hybrid Active";
    } else if (isPerfActive) {
        fullMsg = "Performance engine is running."; summaryMsg = "Gaming Mode";
    } else if (isNupidActive) {
        fullMsg = "Memory optimizer is running."; summaryMsg = "Optimizer Active";
    } else if (isKyroosActive) {
        fullMsg = thresholdPct ? `Battery saver triggers at ${thresholdPct}%` : "Please charge to calibrate data";
        summaryMsg = thresholdPct ? `Trigger at ${thresholdPct}%` : "Calibrating...";
    }

    updateText('threshold-summary-msg', summaryMsg);
    updateText('threshold-status-text', fullMsg);
}

async function loadConfigData() {
    updateText('current-renderer-val', 'Checking...', true);
    let r = await safeExec('getprop debug.hwui.renderer') || await safeExec('getprop ro.hwui.renderer');
    r = r ? r.trim().toLowerCase() : 'Default';
    if (r === 'skiagl') r = 'OpenGL';
    else if (r === 'skiavk') r = 'Vulkan';
    else r = r.charAt(0).toUpperCase() + r.slice(1);
    updateText('current-renderer-val', r);

    updateText('current-driver-val', 'Checking...', true);
    const d = (await safeExec('settings get global updatable_driver_all_apps')).trim();
    const dMap = { '0': 'Default (0)', '1': 'Game (1)', '2': 'Dev (2)', '3': 'Off (3)' };
    updateText('current-driver-val', dMap[d] || `Unknown (${d})`);

    updateText('current-refresh-rate-val', 'Reading...', true);
    let rate = (await safeExec('settings get system peak_refresh_rate')).trim();
    let rateVal = parseInt(rate);
    let sliderIdx = 4;

    if (!isNaN(rateVal) && rateVal > 0) {
        const found = Object.entries(REFRESH_RATE_MAP).find(([k, v]) => v === rateVal);
        sliderIdx = found ? parseInt(found[0]) : -1;
    }
    
    const slider = document.getElementById('refresh-rate-slider');
    if (slider && sliderIdx >= 0) slider.value = sliderIdx;
    
    const displayTxt = (sliderIdx === -1) ? `${rateVal} Hz (Custom)` : REFRESH_RATE_TEXT[rateVal] || REFRESH_RATE_TEXT['-1'];
    updateText('current-refresh-rate-val', displayTxt);

    document.querySelectorAll('#refresh-rate-labels span').forEach((label, i) => {
        const isCurrent = i === sliderIdx;
        label.style.color = isCurrent ? 'var(--primary-color)' : 'var(--text-sub)';
        label.style.fontWeight = isCurrent ? '700' : '500';
        label.style.transform = isCurrent ? 'scale(1.1)' : 'none';
        if (isCurrent && i > 0 && i < 4) label.style.transform += ' translateX(-50%)';
        else if (i > 0 && i < 4) label.style.transform = 'translateX(-50%)';
    });
}

let allPackages = [];
const PLACEHOLDER_ICON = 'data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHZpZXdCb3g9IjAgMCAyNCAyNCIgZmlsbD0iIzU1NSI+PHBhdGggZD0iTTEyIDJDNi41IDIgMiA2LjUgMiAxMnM0LjUgMTAgMTAgMTAgMTAtNC41IDEwLTEwUzE3LjUgMiAxMiAyeiIvPjwvc3ZnPg==';

const infoCache = {};
let fetchQueue = new Set();
let isFetching = false;
let observer = null;

function safeJSONParse(str) {
    if (!str) return [];
    try { return JSON.parse(str); } catch { return []; }
}

async function fetchPackages() {
    try {
        if (window.ksu?.listAllPackages) {
            const res = window.ksu.listAllPackages();
            return typeof res === 'string' ? safeJSONParse(res) : res;
        }
        const raw = await safeExec("pm list packages -u");
        const regex = /package:([^\s]+)/g;
        const matches = [];
        let match;
        while ((match = regex.exec(raw)) !== null) {
            matches.push(match[1]);
        }
        return matches;
    } catch (err) {
        console.error(err);
        return [];
    }
}

async function processFetchQueue() {
    if (isFetching || fetchQueue.size === 0) return;

    if (!window.ksu || (!window.ksu.getPackagesInfo && !window.ksu.getPackagesIcons)) {
        fetchQueue.clear();
        return;
    }

    isFetching = true;

    const queueArray = Array.from(fetchQueue);
    const batch = queueArray.slice(0, 30);
    
    batch.forEach(pkg => fetchQueue.delete(pkg));

    try {
        const batchJson = JSON.stringify(batch);
        const pInfo = window.ksu.getPackagesInfo ? window.ksu.getPackagesInfo(batchJson) : "[]";
        const pIcon = window.ksu.getPackagesIcons ? window.ksu.getPackagesIcons(batchJson, 100) : "[]";

        const [infoRaw, iconsRaw] = await Promise.all([pInfo, pIcon]);
        const infos = safeJSONParse(infoRaw);
        const icons = safeJSONParse(iconsRaw);

        const iconMap = {};
        icons.forEach(item => iconMap[item.packageName] = item.icon);

        const infoMap = {};
        infos.forEach(item => infoMap[item.packageName] = item.appLabel);

        batch.forEach(pkg => {
            if (!infoCache[pkg]) infoCache[pkg] = {};
            if (infoMap[pkg]) infoCache[pkg].label = infoMap[pkg];
            if (iconMap[pkg]) infoCache[pkg].icon = iconMap[pkg];

            const el = document.getElementById(`app-${pkg}`);
            if (el) {
                const imgEl = el.querySelector('.app-card-icon');
                const titleEl = el.querySelector('.app-card-title');
                if (imgEl && iconMap[pkg]) {
                    imgEl.src = iconMap[pkg];
                    imgEl.style.opacity = '1';
                }
                if (titleEl && infoMap[pkg]) {
                    titleEl.textContent = infoMap[pkg];
                }
                el.removeAttribute('data-observe');
                if (observer) observer.unobserve(el);
            }
        });

    } catch (e) {
        console.error(e);
    } finally {
        isFetching = false;
        if (fetchQueue.size > 0) {
            setTimeout(processFetchQueue, 10);
        }
    }
}

function initObserver() {
    if (observer) observer.disconnect();
    observer = new IntersectionObserver((entries) => {
        let needsFetch = false;
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                const pkg = entry.target.dataset.pkg;
                if (pkg && (!infoCache[pkg]?.icon || !infoCache[pkg]?.label)) {
                    fetchQueue.add(pkg);
                    needsFetch = true;
                }
                observer.unobserve(entry.target);
            }
        });
        if (needsFetch) processFetchQueue();
    }, {
        root: document.getElementById('app-list-target').parentNode,
        rootMargin: '100px',
        threshold: 0.1
    });
}

function renderAppList(filter = '') {
    const container = document.getElementById('app-list-target');
    const countInfo = document.getElementById('app-count-info');
    const filterLower = filter.toLowerCase();

    if (observer) {
        observer.disconnect();
        fetchQueue.clear();
    }
    initObserver();

    const filtered = allPackages.filter(pkg => 
        pkg.toLowerCase().includes(filterLower) || 
        (infoCache[pkg]?.label || '').toLowerCase().includes(filterLower)
    );

    filtered.sort();

    if (countInfo) {
        countInfo.textContent = `${filtered.length} apps`;
        countInfo.style.display = 'block';
    }

    if (filtered.length === 0) {
        container.innerHTML = `
            <div class="empty-state" style="padding:40px 0; text-align:center;">
                <span class="material-symbols-rounded" style="font-size: 40px; opacity: 0.3;">search_off</span>
                <div style="opacity: 0.6; font-size:13px; margin-top:8px;">No apps found</div>
            </div>`;
        return;
    }

    const fragment = document.createDocumentFragment();
    const limit = 200;
    const shown = filtered.slice(0, limit);

    shown.forEach(pkg => {
        const cached = infoCache[pkg];
        const label = cached?.label || pkg;
        const icon = cached?.icon || PLACEHOLDER_ICON;
        const isChecked = savedPackagesSet.has(pkg) ? 'checked' : '';
        const isLoaded = !!cached?.icon;

        const div = document.createElement('div');
        div.className = 'app-card-item';
        div.id = `app-${pkg}`;
        div.dataset.pkg = pkg;
        div.setAttribute('onclick', `openAppDetails('${pkg}')`);

        if (!isLoaded) {
            div.setAttribute('data-observe', 'true');
        }

        div.innerHTML = `
            <img src="${icon}" class="app-card-icon" loading="lazy" style="transition: opacity 0.3s; opacity: ${isLoaded ? 1 : 0.5}">
            <div class="app-card-info">
                <div class="app-card-title">${label}</div>
                <div class="app-card-pkg">${pkg}</div>
            </div>
            <div class="app-card-actions">
                <label class="mini-switch" onclick="event.stopPropagation()">
                    <input type="checkbox" onchange="toggleAppSelection('${pkg}', this)" ${isChecked}>
                    <span class="mini-slider"></span>
                </label>
            </div>
        `;

        fragment.appendChild(div);
        if (!isLoaded) observer.observe(div);
    });

    container.innerHTML = '';
    container.appendChild(fragment);

    if (filtered.length > limit) {
        const moreDiv = document.createElement('div');
        moreDiv.style.cssText = "text-align:center; padding:20px; font-size:11px; opacity:0.5;";
        moreDiv.textContent = `+${filtered.length - limit} more apps (use search)`;
        container.appendChild(moreDiv);
    }
}

async function loadAppManager() {
    const container = document.getElementById('app-list-target');
    const loading = document.getElementById('app-list-loading');
    const scanBtn = document.getElementById('btn-scan-apps');
    const notice = document.getElementById('app-manager-notice');
    const searchInput = document.getElementById('app-search-input');

    if (scanBtn) scanBtn.style.display = 'none';
    if (notice) notice.style.display = 'flex';
    if (loading) loading.style.display = 'block';
    
    if (container) container.innerHTML = '';

    await loadSavedPackagesList();
    allPackages = await fetchPackages();

    if (loading) loading.style.display = 'none';
    if (notice) notice.style.display = 'none';
    if (scanBtn) scanBtn.style.display = 'flex';

    if (allPackages.length > 0) {
        renderAppList(searchInput ? searchInput.value : '');
    } else {
        container.innerHTML = `<div class="empty-state">Failed to list packages.<br>Check Root/KSU access.</div>`;
    }
}

function debounce(func, delay) {
    let timeout;
    return (...args) => {
        clearTimeout(timeout);
        timeout = setTimeout(() => func.apply(this, args), delay);
    };
}

const debouncedRenderAppList = debounce((value) => {
    if (allPackages.length > 0) renderAppList(value);
}, 300);

document.getElementById('app-search-input')?.addEventListener('input', (e) => {
    debouncedRenderAppList(e.target.value);
});

document.getElementById('btn-scan-apps').onclick = loadAppManager;

let isNavigating = false;

function switchTab(targetId) {
    if (isNavigating) return;
    
    const current = document.querySelector('.content-section.active-section');
    const target = document.getElementById(targetId);
    
    if (current === target) return;

    if (targetId === 'modules-content') {
        document.getElementById('app-detail-content').classList.remove('active-subpage');
        document.getElementById('modules-content').style.display = 'flex';
        document.getElementById('main-nav').classList.remove('nav-hidden');
    }

    isNavigating = true;

    document.querySelectorAll('.nav-item').forEach(n => n.classList.remove('active'));
    document.getElementById(`nav-${targetId.replace('-content', '')}`)?.classList.add('active');

    const titleEl = document.getElementById('page-title');
    const headerConfig = {
        'home-content': { icon: '', text: 'KyrooS', action: () => loadSystemInfo() },
        'configuration-content': { icon: 'tune', text: 'Config', action: () => loadConfigData() },
        'modules-content': { icon: 'apps', text: 'App Manager', action: null },
        'settings-content': { icon: 'settings', text: 'Settings', action: null }
    };

    const conf = headerConfig[targetId] || { icon: 'circle', text: 'KyrooS' };
    
    const iconHtml = conf.icon ? `<span class="material-symbols-rounded filled-icon" style="font-size:32px; color:var(--primary-color); vertical-align:middle; margin-right:4px;">${conf.icon}</span>` : '';
    titleEl.innerHTML = `${iconHtml} ${conf.text}`;

    if (current) {
        current.style.display = 'none';
        current.classList.remove('active-section');
        current.style.opacity = '0';
    }

    target.style.display = 'flex';
    
    requestAnimationFrame(() => {
        target.classList.add('active-section');
        target.style.opacity = '1';
        setTimeout(() => {
            isNavigating = false;
        }, 300); 
    });

    if (conf.action) {
        setTimeout(() => {
            if (window.requestIdleCallback) {
                window.requestIdleCallback(() => conf.action());
            } else {
                conf.action();
            }
        }, 400);
    } else {
        isNavigating = false;
    }
}

['home', 'configuration', 'modules', 'settings'].forEach(tab => {
    document.getElementById(`nav-${tab}`).onclick = () => switchTab(`${tab}-content`);
});

const APP_OPS_INFO = [
    { code: "WAKE_LOCK", label: "Wake Lock", icon: "visibility", desc: "Keep device awake." },
    { code: "RUN_IN_BACKGROUND", label: "Run in Background", icon: "background_replace", desc: "Allow execution in background." },
    { code: "START_FOREGROUND", label: "Start Foreground", icon: "notification_important", desc: "Start foreground services." },
    { code: "MONITOR_LOCATION", label: "Monitor Location", icon: "location_on", desc: "Access location in background." },
    { code: "ACTIVITY_RECOGNITION", label: "Activity Recognition", icon: "directions_walk", desc: "Detect physical activity." },
    { code: "GET_ACCOUNTS", label: "Get Accounts", icon: "manage_accounts", desc: "Read registered accounts." },
    { code: "SYSTEM_EXEMPT_FROM_HIBERNATION", label: "Exempt Hibernation", icon: "battery_saver", desc: "Avoid app hibernation." },
    { code: "RUN_ANY_IN_BACKGROUND", label: "Run Any BG", icon: "motion_photos_on", desc: "Force background running." },
    { code: "INSTANT_APP_START_FOREGROUND", label: "Instant App FG", icon: "rocket", desc: "Start FG service in instant app." },
    { code: "INTERACT_ACROSS_PROFILES", label: "Cross Profile", icon: "supervisor_account", desc: "Interact across users." },
    { code: "LOADER_USAGE_STATS", label: "Loader Usage", icon: "data_usage", desc: "Track data loader usage." },
    { code: "ACTIVITY_RECOGNITION_SOURCE", label: "Activity Source", icon: "sensors", desc: "Access sensor data." },
    { code: "FOREGROUND_SERVICE_SPECIAL_USE", label: "Special Service", icon: "medical_services", desc: "Special use FG service." },
    { code: "SYSTEM_EXEMPT_FROM_POWER_RESTRICTIONS", label: "Power Exempt", icon: "power", desc: "Ignore power restrictions." }
];

const COMPILE_MODES_INFO = [
    { id: "speed", icon: "rocket_launch", title: "Speed", desc: "Maximize runtime performance." },
    { id: "everything", icon: "all_inclusive", title: "Everything", desc: "Compile all. Slowest build." },
    { id: "speed-profile", icon: "offline_bolt", title: "Speed Profile", desc: "Optimize hot methods." },
    { id: "quicken", icon: "bolt", title: "Quicken", desc: "Fast optimization." },
    { id: "space-profile", icon: "save", title: "Space Profile", desc: "Prioritize storage space." },
    { id: "space", icon: "compress", title: "Space", desc: "Maximize storage saving." },
    { id: "verify", icon: "verified_user", title: "Verify", desc: "Only verify classes." },
    { id: "assume-verified", icon: "fact_check", title: "Assume Verified", desc: "Skip verification (Risky)." },
    { id: "extract", icon: "unarchive", title: "Extract", desc: "No optimization." }
];

let currentAppPkg = '', currentSelectedOpCode = '', currentSubView = null, currentCompileMode = '';

window.openAppDetails = (pkg) => {
    currentAppPkg = pkg;
    currentSubView = null;
    
    const info = infoCache[pkg];
    document.getElementById('detail-app-name').textContent = info ? info.label : pkg;
    document.getElementById('detail-app-pkg').textContent = pkg;
    document.getElementById('detail-app-icon').src = info ? info.icon : PLACEHOLDER_ICON;

    document.getElementById('app-dashboard-menu').style.display = 'grid';
    ['view-ops', 'view-compile', 'view-uninstall'].forEach(id => document.getElementById(id).style.display = 'none');

    document.getElementById('modules-content').style.display = 'none';
    document.getElementById('main-header').style.display = 'none';
    document.getElementById('main-nav').classList.add('nav-hidden');
    document.getElementById('app-detail-content').classList.add('active-subpage');
    window.scrollTo(0, 0);
};

window.openSubFeature = (featureName) => {
    document.getElementById('app-dashboard-menu').style.display = 'none';
    currentSubView = featureName;

    if (featureName === 'ops') {
        const container = document.getElementById('ops-list-target');
        container.innerHTML = APP_OPS_INFO.map(op => `
            <div class="modern-list-item" onclick="openOpDialog('${op.code}', '${op.label}')">
                <div class="modern-icon-box" style="background: var(--surface-container); color: var(--primary-color);">
                    <span class="material-symbols-rounded">${op.icon}</span>
                </div>
                <div class="modern-text">
                    <span class="modern-title">${op.label}</span>
                    <span class="modern-desc">${op.desc}</span>
                </div>
                <div class="action-indicator"><span class="material-symbols-rounded">arrow_forward</span></div>
            </div>
        `).join('');
        document.getElementById('view-ops').style.display = 'flex';
    } else if (featureName === 'compile') {
        const container = document.getElementById('compile-list-target');
        if (container) {
            container.innerHTML = COMPILE_MODES_INFO.map(mode => `
                <div class="modern-list-item" onclick="openCompileDialog('${mode.id}')">
                    <div class="modern-icon-box" style="background: var(--surface-container); color: var(--text-sub);">
                        <span class="material-symbols-rounded">${mode.icon}</span>
                    </div>
                    <div class="modern-text">
                        <span class="modern-title">${mode.title}</span>
                        <span class="modern-desc">${mode.desc}</span>
                    </div>
                    <div class="action-indicator"><span class="material-symbols-rounded">play_arrow</span></div>
                </div>
            `).join('');
        }
        document.getElementById('view-compile').style.display = 'flex';
    } else if (featureName === 'uninstall') {
        document.getElementById('view-uninstall').style.display = 'flex';
    }
};

window.handleBackNavigation = () => {
    if (currentSubView !== null) {
        ['view-ops', 'view-compile', 'view-uninstall'].forEach(id => document.getElementById(id).style.display = 'none');
        document.getElementById('app-dashboard-menu').style.display = 'grid';
        currentSubView = null;
    } else {
        closeAppDetails();
    }
};

document.getElementById('btn-back-ops').onclick = window.handleBackNavigation;

window.closeAppDetails = () => {
    document.getElementById('app-detail-content').classList.remove('active-subpage');
    setTimeout(() => {
        document.getElementById('modules-content').style.display = 'flex';
        document.getElementById('main-header').style.display = 'flex';
        document.getElementById('main-nav').classList.remove('nav-hidden');
    }, 150);
};

window.openCompileDialog = (mode) => {
    currentCompileMode = mode;
    document.getElementById('compile-dialog-mode').textContent = mode;
    document.getElementById('compile-dialog').classList.add('show');
    const btn = document.getElementById('btn-confirm-compile');
    btn.innerHTML = `<span class="material-symbols-rounded">play_arrow</span> Start Compile`;
    btn.disabled = false;
    btn.style.opacity = '1';
};

window.closeCompileDialog = () => document.getElementById('compile-dialog').classList.remove('show');

window.confirmCompile = async () => {
    if (!currentAppPkg || !currentCompileMode) return;
    const btn = document.getElementById('btn-confirm-compile');
    btn.innerHTML = `<span class="material-symbols-rounded fa-spin">refresh</span> Compiling...`;
    btn.disabled = true;
    try {
        await safeExec(`pm compile -m ${currentCompileMode} ${currentAppPkg}`);
        setTimeout(() => window.closeCompileDialog(), 800);
    } catch {
        btn.innerHTML = `<span class="material-symbols-rounded">error</span> Failed`;
        setTimeout(() => window.closeCompileDialog(), 1500);
    }
};

window.openUninstallConfirmation = () => {
    if (!currentAppPkg) return;
    document.getElementById('uninstall-pkg-name').textContent = currentAppPkg;
    const dialog = document.getElementById('uninstall-dialog');
    dialog.classList.add('show');
    document.getElementById('uninstall-logs').style.display = 'none';
    const btn = document.getElementById('btn-confirm-uninstall');
    btn.innerHTML = `<span class="material-symbols-rounded">delete</span> Yes, Uninstall`;
    btn.disabled = false;
    btn.style.opacity = '1';
};

window.closeUninstallDialog = () => document.getElementById('uninstall-dialog').classList.remove('show');

window.confirmUninstall = async () => {
    if (!currentAppPkg) return;
    const btn = document.getElementById('btn-confirm-uninstall');
    const logDiv = document.getElementById('uninstall-logs');
    
    btn.innerHTML = `<span class="material-symbols-rounded fa-spin">refresh</span> Cleaning...`;
    btn.disabled = true;
    logDiv.style.display = 'block';
    logDiv.innerHTML = '';

    const cmds = [
        `pm uninstall-system-updates ${currentAppPkg}`,
        `pm clear ${currentAppPkg}`,
        `pm uninstall --user 0 ${currentAppPkg}`,
        `pm uninstall -k --user 0 ${currentAppPkg}`,
        `cmd package uninstall --user 0 ${currentAppPkg}`,
        `am force-stop ${currentAppPkg}`
    ];

    for (const cmd of cmds) {
        logDiv.innerHTML += `> ${cmd}\n`;
        logDiv.scrollTop = logDiv.scrollHeight;
        await safeExec(cmd);
    }

    logDiv.innerHTML += `> DONE.\n`;
    btn.innerHTML = `<span class="material-symbols-rounded">check</span> Completed`;
    setTimeout(() => {
        window.closeUninstallDialog();
        window.handleBackNavigation();
        loadAppManager();
    }, 1500);
};

window.openOpDialog = (opCode, opLabel) => {
    currentSelectedOpCode = opCode;
    document.getElementById('op-dialog-title').textContent = opLabel || opCode;
    document.getElementById('op-mode-dialog').classList.add('show');
};

window.closeOpDialog = () => document.getElementById('op-mode-dialog').classList.remove('show');

window.executeOp = async (mode) => {
    if (currentAppPkg && currentSelectedOpCode) {
        window.closeOpDialog();
        await safeExec(`appops set ${currentAppPkg} ${currentSelectedOpCode} ${mode}`);
    }
};

document.getElementById('daemon-switch').onchange = async (e) => {
    const isChecked = e.target.checked;
    const stateText = document.getElementById('daemon-state-text');
    if (stateText) stateText.textContent = "Processing...";
    e.target.disabled = true;
    
    if (isChecked) await safeExec('sigma >/dev/null 2>&1 &');
    else {
        await safeExec('pkill -9 -f sigma');
        await safeExec('killall -9 sigma'); 
    }
    setTimeout(() => { loadSystemInfo(); e.target.disabled = false; }, 1200);
};

document.getElementById('perf-switch').onchange = async (e) => {
    const isChecked = e.target.checked;
    const stateText = document.getElementById('perf-state-text');
    if (stateText) stateText.textContent = "Processing...";
    e.target.disabled = true;

    if (isChecked) await safeExec('gorrfu &');
    else {
        await safeExec('pkill -9 -f gorrfu');
        await safeExec('killall -9 gorrfu'); 
    }
    setTimeout(() => { loadSystemInfo(); e.target.disabled = false; }, 1200);
};

document.getElementById('nupid-switch').onchange = async (e) => {
    const isChecked = e.target.checked;
    const stateText = document.getElementById('nupid-state-text');
    if (stateText) stateText.textContent = "Processing...";
    e.target.disabled = true;

    if (isChecked) {
        await safeExec('nupid >/dev/null 2>&1 &'); 
    } else {
        await safeExec('pkill -9 -f nupid');
        await safeExec('killall -9 nupid'); 
    }
    setTimeout(() => { loadSystemInfo(); e.target.disabled = false; }, 1200);
};

document.getElementById('btn-trim-cache').onclick = async function() {
    const gb = document.getElementById('cache-mb-input').value;
    const orig = this.innerHTML;
    this.innerHTML = `<span class="material-symbols-rounded fa-spin">refresh</span>`;
    await safeExec(`pm trim-caches ${gb}G`);
    this.innerHTML = `<span class="material-symbols-rounded">check</span>`;
    setTimeout(() => this.innerHTML = orig, 1500);
};

document.querySelectorAll('.btn-m3[data-renderer]').forEach(btn => {
    btn.onclick = async () => {
        const orig = btn.innerHTML;
        btn.innerHTML = `<span class="material-symbols-rounded fa-spin">refresh</span>`;
        await safeExec(`setprop debug.hwui.renderer ${btn.dataset.renderer}`);
        setTimeout(() => { btn.innerHTML = orig; loadConfigData(); }, 1500);
    };
});

document.querySelectorAll('.btn-m3[data-driver-val]').forEach(btn => {
    btn.onclick = async () => {
        const v = btn.dataset.driverVal;
        const orig = btn.innerHTML;
        btn.innerHTML = `<span class="material-symbols-rounded fa-spin">refresh</span>`;
        await safeExec(`settings put global updatable_driver_all_apps ${v}`);
        await safeExec(`settings put global game_driver_all_apps ${v === '1' ? '1' : '0'}`);
        setTimeout(() => { btn.innerHTML = orig; loadConfigData(); }, 1500);
    };
});

document.getElementById('refresh-rate-slider').oninput = async function() {
    const rateValue = REFRESH_RATE_MAP[this.value];
    updateText('current-refresh-rate-val', `${REFRESH_RATE_TEXT[rateValue]} (Applying...)`);
    
    await Promise.all([
        safeExec(`settings put system peak_refresh_rate ${rateValue === -1 ? '0' : rateValue}`),
        safeExec(`settings put system min_refresh_rate ${rateValue === -1 ? '0' : `${rateValue}.0`}`)
    ]);
    loadConfigData();
};

document.querySelectorAll('#refresh-rate-labels span').forEach((label, index) => {
    label.onclick = () => {
        const s = document.getElementById('refresh-rate-slider');
        if (s) { s.value = index; s.dispatchEvent(new Event('input')); }
    };
});

document.getElementById('silent-login-btn').onclick = async function() {
    const orig = this.innerHTML;
    this.innerHTML = `<span class="material-symbols-rounded fa-spin">refresh</span> Stealthing...`;
    await safeExec('silent-trace');
    this.innerHTML = `<span class="material-symbols-rounded">check</span> Active`;
    setTimeout(() => this.innerHTML = orig, 2000);
};

async function stopApps(type, btnId) {
    const btn = document.getElementById(btnId);
    const orig = btn.innerHTML;
    btn.innerHTML = `<span class="material-symbols-rounded fa-spin">refresh</span> Stopping...`;
    const flag = type === 'user' ? '-u' : type === 'system' ? '-s' : '-a';
    await safeExec(`app-stopper ${flag}`);
    btn.innerHTML = `<span class="material-symbols-rounded">check</span> Done`;
    setTimeout(() => btn.innerHTML = orig, 2000);
}

document.getElementById('btn-kill-user').onclick = () => stopApps('user', 'btn-kill-user');
document.getElementById('btn-kill-sys').onclick = () => stopApps('system', 'btn-kill-sys');
document.getElementById('btn-kill-all').onclick = () => stopApps('all', 'btn-kill-all');

document.getElementById('reset-data-btn').onclick = async () => {
    if (confirm("Reset Data & Reboot?")) {
        await safeExec('rm -rf /data/local/tmp/battery_threshold.dat');
        await safeExec('reboot');
    }
};

document.getElementById('get-log-btn').onclick = async () => {
    const btn = document.getElementById('get-log-btn');
    const orig = btn.innerHTML;
    btn.innerHTML = "Saving...";
    await safeExec('logcat -d > /sdcard/StarFlow_Log.txt');
    alert('Log Saved to Internal Storage: /sdcard/StarFlow_Log.txt');
    btn.innerHTML = orig;
};

const btnManual = document.getElementById('btn-manual-book');
const btnBackManual = document.getElementById('btn-back-manual');

if (btnManual) {
    btnManual.onclick = () => {
        document.getElementById('main-header').style.display = 'none';
        document.getElementById('main-nav').classList.add('nav-hidden');
        
        const settings = document.getElementById('settings-content');
        settings.classList.remove('active-section');
        settings.style.display = 'none';

        const manual = document.getElementById('manual-book-content');
        manual.style.display = 'flex';
        requestAnimationFrame(() => {
            manual.classList.add('active-section');
            manual.style.opacity = '1';
        });
        window.scrollTo(0, 0);
    };
}

if (btnBackManual) {
    btnBackManual.onclick = () => {
        const manual = document.getElementById('manual-book-content');
        manual.classList.remove('active-section');
        manual.style.display = 'none';

        document.getElementById('main-header').style.display = 'flex';
        document.getElementById('main-nav').classList.remove('nav-hidden');

        const settings = document.getElementById('settings-content');
        settings.style.display = 'flex';
        requestAnimationFrame(() => {
            settings.classList.add('active-section');
            settings.style.opacity = '1';
        });
    };
}

window.addEventListener('load', function() {
    window.history.pushState({ page: 1 }, "", "");
});

window.addEventListener('popstate', function(event) {
    window.history.pushState({ page: 1 }, "", "");

    if (document.getElementById('op-mode-dialog')?.classList.contains('show')) {
        closeOpDialog(); return;
    }
    if (document.getElementById('compile-dialog')?.classList.contains('show')) {
        closeCompileDialog(); return;
    }
    if (document.getElementById('uninstall-dialog')?.classList.contains('show')) {
        closeUninstallDialog(); return;
    }

    const manualPage = document.getElementById('manual-book-content');
    if (manualPage && manualPage.style.display !== 'none') {
        document.getElementById('btn-back-manual').click();
        return;
    }

    if (typeof currentSubView !== 'undefined' && currentSubView !== null) {
        window.handleBackNavigation();
        return;
    }

    const appDetail = document.getElementById('app-detail-content');
    if (appDetail && appDetail.classList.contains('active-subpage')) {
        closeAppDetails();
        return;
    }

    const homeNav = document.getElementById('nav-home');
    if (homeNav && !homeNav.classList.contains('active')) {
        switchTab('home-content');
        return;
    }
});

document.addEventListener('DOMContentLoaded', () => {
    switchTab('home-content');
    setTimeout(loadSystemInfo, 300);
});
