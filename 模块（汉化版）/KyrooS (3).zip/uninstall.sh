#!/system/bin/sh

# 版权所有 2024 Dcx400
#
# 根据 Apache 许可证 2.0 版本（"许可证"）授权；
# 除非遵守许可证，否则不得使用此文件。
# 您可以在以下网址获取许可证副本：
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# 除非适用法律要求或书面同意，否则按"原样"分发软件，
# 没有任何明示或暗示的保证或条件。
# 有关权限的详细信息，请参阅许可证。

# 定义工具路径
utensil="/data/local/tmp/utensil"

# 删除配置文件
rm $utensil/battery_learning.dat
rm $utensil/battery_threshold.dat
rm $utensil/sensorconfiguration
rm $utensil/airplaneconfiguration
rm $utensil/charglogconfiguration
rm $utensil/notificationconfiguration
rm $utensil/dndconfiguration
rm $utensil/watchdogconfiguration
rm $utensil/watchdog.db
rm /sdcard/fileconfig.txt
rm /sdcard/chargelog.txt
rm /storage/emulated/0/Android/media/.kyroos_icon.jpg
rm /data/local/tmp/kyroos_selected_apps.list

# 关闭请勿打扰模式
cmd notification set_dnd off

# 删除所有常量设置
settings delete global battery_saver_constants
settings put global battery_stats_constants track_cpu_times_by_proc_state=false
settings delete global binder_calls_stats
settings delete global activity_manager_constants
# 删除所有常量设置

# 切换WiFi和蓝牙扫描
if [ "$(settings get global wifi_scan_always_enabled)" = 0 ]; then settings put global wifi_scan_always_enabled 1;fi
if [ "$(settings get global ble_scan_always_enabled)" = 0 ]; then settings put global ble_scan_always_enabled 1;fi
# 切换WiFi和蓝牙扫描

# 回退到默认设置 / 来自循环的配置

datasaveconfig="$utensil/datasaverconfiguration"
if [ -f "$datasaveconfig" ]; then
cmd netpolicy set restrict-background false
rm $datasaveconfig
fi


cmd power set-mode 0
cmd power set-adaptive-power-saver-enabled false
settings put global low_power 0
if [ "$(getprop ro.product.manufacturer)" = "Xiaomi" ]; then settings put system POWER_SAVE_MODE_OPEN 0;fi
# 回退到默认设置 / 来自循环的配置

backup="$utensil/batteryconfiguration.dat"

if [ -f "$backup" ]; then
    . "$backup"
    [ -n "$low_power_sticky" ] && settings put global low_power_sticky "$low_power_sticky"
    rm -f "$backup"
fi

# 开启传感器
dumpsys sensorservice enable

# 关闭飞行模式
cmd connectivity airplane-mode disable

# 内存压缩配置
compactconfig="$utensil/compactionconfiguration"

if [ -f "$compactconfig" ]; then
compactionstate=$(dumpsys activity settings | grep 'use_compaction=' | head -n1 | cut -d= -f2)
if [ "$compactionstate" != "false" ]; then device_config put activity_manager use_compaction false;fi
fi
rm $compactconfig

backupcompact="$utensil/savestatcompact"

if [ -f "$backupcompact" ];then
device_config put activity_manager use_compaction true
fi
rm $backupcompact

# 屏幕超时设置
timeoutfile="$utensil/screentimeout.dat"
modifiedtimeout="$utensil/screentimeoutconfiguration"

if [ -f "$timeoutfile" ]; then
	settings put system screen_off_timeout $(cat $timeoutfile)
	rm $timeoutfile
	rm $modifiedtimeout
fi

thermalconfig="$utensil/thermalserviceconfiguration"
if [ -f "$thermalconfig" ];then 
cmd thermalservice override-status 0
rm $thermalconfig
fi
