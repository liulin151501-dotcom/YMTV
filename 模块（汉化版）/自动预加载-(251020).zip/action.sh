#!/system/bin/sh
MODDIR=DIRNAME
[ $AXERON ]&&a()(sleep 0.01;printf "$@")||a()(sleep 0.01;echo "$@")
PID="$(pgrep -f "sh $MODDIR"|head -n1)" uptime=$(cut -d. -f1 /proc/uptime) memory=$(cat /proc/meminfo|tr -s \ )
a "$MODDIR"
a " "
a "***********************************************"
a "$(grep name= "$MODDIR/module.prop"|cut -f2 -d=) ($(grep version= "$MODDIR/module.prop"|cut -f2 -d=)) by $(grep author= "$MODDIR/module.prop"|cut -f2 -d=)"
a "***********************************************"
a " "
if [ -n "$PID" ];then
  a "- 服务进程 ($PID)"
  a "- CPU 使用率: $(ps -eo %cpu,pid|grep "$PID"|grep -ov "$PID"|tr -d \ )%%"
  a "- 常驻内存使用: $(ps -eo res,pid|grep "$PID"|grep -ov "$PID"|tr -d \ )"
  a "- 共享内存使用: $(ps -eo shr,pid|grep "$PID"|grep -ov "$PID"|tr -d \ )"
  a " "
fi
a "· 操作系统: Android $(getprop ro.build.version.release)"
a "· 型号: $(getprop ro.product.manufacturer) $(getprop ro.product.model)"
a "· 内核: $(uname -r|cut -f1,2,3 -d-)"
a "· 运行时间: $((uptime/3600)) 小时, $((uptime%3600/60)) 分钟"
a "· 应用数量: $(cmd package list packages -s --user 0|wc -l) (系统), $(cmd package list packages -3 --user 0|wc -l) (第三方)"
a "· 分辨率:$(wm size|cut -d: -f2)"
a "· 主题: $(getprop ro.build.fingerprint|tr '/' '\n'|grep user|cut -f1 -d:)"
a "· 终端: $(cmd activity stack list|grep 0,0.*visible=true|tr -d ' '|cut -f1 -d/|cut -f2 -d:)"
a "· CPU: $(getprop ro.soc.manufacturer) $(getprop ro.soc.model) ($(grep proc /proc/cpuinfo|wc -l)) @ $(cat /sys/devices/system/cpu/cpufreq/*/cpuinfo_max_freq|tail -n1|awk '{printf("%.3f\n",$1/1000000)}')GHz"
a "· GPU:$(dumpsys SurfaceFlinger|grep GLES:|cut -f2 -d,)"
a "· 内存: $((($(echo "$memory"|grep MemTotal|cut -f2 -d\ )-$(echo "$memory"|grep MemAvailable|cut -f2 -d\ ))/1024))MiB / $(($(echo "$memory"|grep MemTotal|cut -f2 -d\ )/1024))MiB"
a " "
if $AXERON;then
  echo "[-] 点击模块卡片以打开 WebUI。"
elif [ -d /data/adb/ksu ];then
  echo "[-] 点击模块卡片以打开 WebUI。"
elif cmd package path io.github.a13e300.ksuwebui>/dev/null 2>&1;then
  echo "[*] 正在启动 KSU WebUI 独立版.."
  sleep 1
  cmd activity start -n "io.github.a13e300.ksuwebui/.WebUIActivity" -e id "$(grep id= "$MODDIR/module.prop"|cut -f2 -d=)">/dev/null 2>&1
else
  echo "[!] 请安装 KsuWebUI 以访问 WebUI"
  sleep 3
  am start -a android.intent.action.VIEW -d "https://github.com/5ec1cff/KsuWebUIStandalone/releases">/dev/null 2>&1
fi
