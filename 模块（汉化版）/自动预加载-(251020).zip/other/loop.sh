#!/system/bin/sh
exec>/dev/null 2>&1
MODDIR=${0%/*}
alias cmd=/system/bin/cmd
cmd package list packages --user 0|grep -Eo "$(cat $MODDIR/perflist.txt)">/storage/emulated/0/Android/perflist.txt
file_limit="$(($(grep MemTotal /proc/meminfo|awk '{print$2}')/(64*513)))"
for a in 1 2 4 8 10 20 40 80 100 200 400 800 1000 2000 4000 8000;do taskset -ap "$a" $$;done
iorenice $$ 7 idle
renice -n 19 -p $$
while :;do

  # 检测前台应用
  top_app="$(cmd activity stack list|grep -m1 0,0.*=true|awk -F'[/{]' '{print $3}')"

  # 检测当前应用
  if [ "$current_app" != "$top_app" ];then current_app="$top_app"

    # 检测是否在玩游戏
    if grep -Fqm1 "$top_app" /storage/emulated/0/Android/perflist.txt;then

      # 自动预加载
      cmd notification post -t 正在预加载 -i file:///storage/emulated/0/Android/media/.apl.jpg -I file:///storage/emulated/0/Android/media/.apl.jpg apl $top_app
      su -lp 2000 -c "/system/bin/cmd notification post -t 正在预加载 -i file:///storage/emulated/0/Android/media/.apl.jpg -I file:///storage/emulated/0/Android/media/.apl.jpg apl $top_app"
      for package_assets in $(find "/data/user/0/$top_app" "/storage/emulated/0/Android/data/$top_app" "$(dumpsys package "$top_app"|grep -o codePath=.*|sed 's/codePath=//')" -type f -exec du -b {} +|sort -n|tail -n$file_limit|awk '{$1="";sub(/^/,"");print}');do
        dd if="$package_assets" of=/dev/null bs=1M
      done
      cmd notification post -t 预加载完成 -i file:///storage/emulated/0/Android/media/.apl.jpg -I file:///storage/emulated/0/Android/media/.apl.jpg apl $top_app
      su -lp 2000 -c "/system/bin/cmd notification post -t 预加载完成 -i file:///storage/emulated/0/Android/media/.apl.jpg -I file:///storage/emulated/0/Android/media/.apl.jpg apl $top_app"
      # 自动预加载

      # 自动模式
      current_mode="performance"
    else
      if [ "$current_mode" != "battery" ];then current_mode="battery"
        cmd activity force-stop com.android.shell
      fi
      # 自动模式

    fi
    # 检测是否在玩游戏

  fi
  # 检测当前应用

  # 降低循环 CPU 负载
  if [ "$current_mode" = "performance" ];then
    sleep 1m
    continue
  else
    sleep 10
  fi
  # 降低循环 CPU 负载

done
