#!/system/bin/sh
uptime=$(cut -d. -f1 /proc/uptime) memory=$(cat /proc/meminfo|tr -s \ )
[ $AXERON ]&&a()(sleep 0.01;printf "$@")||a()(sleep 0.01;echo "$@")
a "· 操作系统: Android $(getprop ro.build.version.release)"
a "· 型号: $(getprop ro.product.manufacturer) $(getprop ro.product.model)"
a "· 内核: $(uname -r|cut -f1,2,3 -d-)"
a "· 运行时间: $((uptime/3600)) 小时, $((uptime%3600/60)) 分钟"
a "· 应用数量: $(cmd package list packages -s --user 0|wc -l) (系统), $(cmd package list packages -3 --user 0|wc -l) (第三方)"
a "· 分辨率:$(wm size|cut -d: -f2)"
a "· 主题: $(getprop ro.build.fingerprint|tr '/' '\n'|grep user|cut -f1 -d:)"
a "· 终端: $(cmd activity stack list|grep 0,0.*visible=true|tr -d ' '|cut -f1 -d/|cut -f2 -d:)"
a "· CPU: $(getprop ro.soc.manufacturer) $(getprop ro.soc.model) ($(grep proc /proc/cpuinfo|wc -l)) @ $(cat /sys/devices/system/cpu/cpufreq/*/cpuinfo_max_freq|tail -n1|awk '{printf("%.3f\n",$1/1000000)}')GHz"
a "· GPU:$(dumpsys SurfaceFlinger|grep GLES:|cut -f2 -d,)"
a "· 内存: $((($(echo "$memory"|grep MemTotal|cut -f2 -d\ )-$(echo "$memory"|grep MemAvailable|cut -f2 -d\ ))/1024))MiB / $(($(echo "$memory"|grep MemTotal|cut -f2 -d\ )/1024))MiB"
a " "
(# 主要操作
rm -rf /data/local/tmp/toolkit
MODDIR="$(echo $MODPATH|sed 's/_update//')"
[ $AXERON ]&&sed -i 's|su -c ||g' $MODPATH/webroot/index.html
cp $MODPATH/other/image/apl.jpg /storage/emulated/0/Android/media/.apl.jpg
printf "$(grep -v axeronPlugin $MODPATH/module.prop)">$MODPATH/module.prop
sed -i "s|DIRNAME|$MODDIR|g" $MODPATH/action.sh
sed -i "s|DIRNAME|$MODDIR|g" $MODPATH/webroot/index.html
rm -rf $MODPATH/other/image
chmod -R 777 $MODPATH
)>/dev/null 2>&1
(# 加入我的频道
cmd activity start -a android.intent.action.VIEW -d 'https://t.me/S_O_S_P'
if [ ! -f /storage/emulated/0/Android/perflist.txt ];then
  sleep 3
  for tap in $(seq 50);do sleep
    if [ "$(cmd settings get secure navigation_mode)" = 0 ];then
      input tap 200 $(($(cmd window size|tail -n1|cut -f2 -dx)*90/100))
    else
      input tap 200 $(($(cmd window size|tail -n1|cut -f2 -dx)*95/100))
    fi
  done
fi)>/dev/null 2>&1&
