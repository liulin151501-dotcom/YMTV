#!/system/bin/sh
exec>/dev/null 2>&1;[ $AXERON ]||sleep 1m;while [ $(getprop sys.boot_completed) != 1 ];do sleep 5;done
for a in /proc/sys/kernel/*panic*;do echo 0>"$a";done;MODDIR=${0%/*};alias cmd=/system/bin/cmd
exec $MODDIR/other/loop.sh