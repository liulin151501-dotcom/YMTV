# Don't modify anything after this
rm -f /data/local/tmp/rc_server*;pkill -9 -f "RC"