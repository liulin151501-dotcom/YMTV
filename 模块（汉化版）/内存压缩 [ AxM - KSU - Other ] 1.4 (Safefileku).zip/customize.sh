#!/system/bin/sh
# Celestial-Flinger-Flux by Kazuyoo
# Copyright (c) 2026 Kazuyoo
# Licensed under the Apache License, Version 2.0
# http://www.apache.org/licenses/LICENSE-2.0
# 开源项目 — 感谢 GL-DP 及所有贡献者。
# 设置 logcat 缓冲区大小 @Dcx400 
a=$(awk '/MemTotal/ {printf"%.0f\n",$2/1024/1024}' /proc/meminfo);logcat -G "$a"m

# === 打印函数选择 ===
if [ "$AXERON" == "true" ]; then
    PRINT="printf"
else
    PRINT="ui_print"
fi

# === 打印函数包装器 ===
print_msg() {
    case "$PRINT" in
        ui_print) ui_print "$1" ;;
        printf) printf "$1" ;;
    esac
}

# === 分割线 ===
print_line() {
    ui_print "***************************************"
}

# === 修剪分区 ===
trim_partition() {
    if command -v su >/dev/null; then
        for partition in data cache metadata storage;do fstrim -v "/$partition";done
    else
        for partition in data cache metadata storage;do sm fstrim "/$partition";done
    fi
}

# === 检查压缩功能是否可用 ===
if ! cmd activity | grep -q "compact" 2>/dev/null; then
    echo "    [错误]: 此设备未找到 'cmd activity compact'。"
    echo "⚠️  此功能仅在 Android 13+ 或特定厂商框架的设备上可用。"
    rm -rf "$MODPATH"
    exit 1
fi

# === 设备信息 ===
ANDROIDVERSION=$(getprop ro.build.version.release)
DEVICES=$(getprop ro.product.board)
MANUFACTURER=$(getprop ro.product.manufacturer)
API=$(getprop ro.build.version.sdk)
ABI=$(getprop ro.product.cpu.abi)
NAME="内存压缩 | Kzyo"
VERSION="1.4 | 高效版"
DATE=$(date)

# === 启动器 ===
if [ -z "$ABI" ];then ABI=$(getprop ro.product.cpu.abi);fi
[[ "$ABI" == *64* ]] && arch="64" || arch="32";mv -f "$MODPATH/system/bin/RC${arch}" "$MODPATH/system/bin/RC"

# === 显示横幅 ===
print_msg "░█▀▀█ ── ░█▀▀█ ░█▀▄▀█ ░█▀▀█ ▀▀█▀▀ 
░█▄▄▀ ▀▀ ░█─── ░█░█░█ ░█▄▄█ ─░█── 
░█─░█ ── ░█▄▄█ ░█──░█ ░█─── ─░█──"
ui_print ""
sleep 0.5
print_msg "         减少内存使用量。"
sleep 0.2
ui_print ""
print_line
print_msg "- 名称            : ${NAME}"
sleep 0.2
print_msg "- 版本            : ${VERSION}"
sleep 0.2
print_msg "- Android 版本    : ${ANDROIDVERSION:-未知}"
sleep 0.2
print_msg "- 当前日期        : ${DATE}"
sleep 0.2
print_line
print_msg "- 设备代号        : ${DEVICES:-未知}"
sleep 0.2
print_msg "- 制造商          : ${MANUFACTURER:-未知}"
sleep 0.2
print_line
print_msg "- 检测到 ${arch} 位架构。"
sleep 0.2
print_msg "- 正在修剪分区"
trim_partition>/dev/null 2>&1 &
sleep 2

# === 设置权限 ===
if command -v su >/dev/null; then ui_print "- 正在设置权限";set_perm_recursive $MODPATH/system/bin 0 0 0755 0755;fi

# === 清理 ===
logcat -c &>/dev/null
