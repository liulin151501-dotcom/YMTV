# ====== 检查 service.sh 是否正在运行 ======
check_service_status() {
    if pgrep RC &>/dev/null; then
        echo "[活跃] PID : $(pgrep RC) | 服务正在运行。"
        return 0
    else
        echo "[未活跃] 服务未运行。"
        return 1
    fi
}
check_service_status
