#!/system/bin/sh

# Copyright 2024 Dcx400
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

monilith="/sdcard/monilith"

volume_key() {
    getevent -l | while read -r line; do
        case "$line" in
            *KEY_VOLUMEUP*) echo UP; break;;
            *KEY_VOLUMEDOWN*) echo DOWN; break;;
        esac
    done
}




echo "Do you want to save log each time this plugin is run ?"
echo "
[+] Volume Up   : Enable log
[-] Volume Down : Skip"


value=$(volume_key)


if [ "$value" = "UP" ]; then
	mkdir -p "$monilith"
	echo hi > "$monilith/logconfig"
	echo Saved
		else
	echo Skipped
fi