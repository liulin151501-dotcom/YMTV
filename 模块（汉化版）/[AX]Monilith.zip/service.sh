#!/system/bin/sh

# Copyright 2024 Dcx400
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.


#monilith folder
monilith="/sdcard/monilith"
logfile="$monilith/logfile.txt"
logging() {
    rc=$?
    [ -f "$monilith/logconfig" ] || return
    ts="$(date '+%F %T')"

    if [ "$rc" -eq 0 ]; then
        echo "$ts | stable | $*" >> "$logfile"
    else
        echo "$ts | error($rc) | $*" >> "$logfile"
    fi
}


if [ -f "$monilith/logconfig" ]; then echo "============================================" >> $logfile;fi

trim_c() {
disksize=$(df -k /data | awk 'NR==2 {print int($2/1024/1024)}')

#math
diskmath=$((disksize + 32))
pm trim-caches ${diskmath}G
logging "trimmed ${diskmath}G"
}

appcache_clearonsize() {

# we're only clear cache if the size is 32mb> || formula -> limit = 32 * 1024
limitsize=$((32 * 1024))


pm list packages -3 -e | cut -d: -f2 | while read -r a; do
    cache="/sdcard/Android/data/$a/cache"
    [ -d "$cache" ] || continue

size=$(du -sk "$cache" | awk '{print $1}')
[ -z "$size" ] && continue
          #for testing purpose
          #echo $size

    if [ "$size" -gt "$limitsize" ]; then
      rm -rf "$cache"/*
      logging "cleared | $a | ${size}KB"
        else
     if [ -f "$monilith/logconfig" ]; then echo "$(date '+%F %T') | skipped | $a | ${size}KB" >> "$logfile";fi
    fi
done
}

trimlog() {
if [ -f "$logfile" ]; then

	buffer=$(cat "$logfile" | wc -l)
		if [ "$buffer" -ge 500 ]; then
			> '$logfile'
		fi

fi
}

#call function
appcache_clearonsize 
trim_c ; sleep 15 ; sm fstrim ; trimlog