#!/system/bin/sh
# service.sh — Magisk service (runs on boot)
# Storage policy: ALL module runtime files live ONLY inside the module directory.
# Path layout:
#   $MODDIR/bps_config.conf
#   $MODDIR/bps_apps.db
#   $MODDIR/bps_charge_state
#   $MODDIR/bps_daemon_state
#   $MODDIR/bps_daemon.pid
# Binaries:
#   $MODDIR/system/bin/bpsd

MODDIR="${0%/*}"
DAEMON_BIN="$MODDIR/system/bin/bpsd"

CONFIG="$MODDIR/bps_config.conf"
DB_FILE="$MODDIR/bps_apps.db"
STATE_FILE="$MODDIR/bps_charge_state"
DAEMON_STATE="$MODDIR/bps_daemon_state"
PID_FILE="$MODDIR/bps_daemon.pid"
LOG_FILE="$MODDIR/bpsd.log"

cfg_get() { # key default
  KEY="$1"; DEF="$2"
  VAL="$(grep -m1 -E "^${KEY}=" "$CONFIG" 2>/dev/null | cut -d= -f2-)"
  [ -z "$VAL" ] && VAL="$DEF"
  echo "$VAL"
}

is_running() {
  if [ -f "$PID_FILE" ]; then
    PID="$(cat "$PID_FILE" 2>/dev/null)"
    [ -n "$PID" ] && kill -0 "$PID" 2>/dev/null && return 0
  fi
  return 1
}

# Wait for boot complete (helps cmd/dumpsys inside daemon)
for _ in 1 2 3 4 5 6 7 8 9 10; do
  getprop sys.boot_completed | grep -q "1" && break
  sleep 2
done

# ---- Create/seed module runtime files (ONLY in $MODDIR) ----
# Config
if [ ! -f "$CONFIG" ]; then
  cat > "$CONFIG" <<EOF
# Bypass Charging MTK config
# interval_sec: poll interval for daemon (1..60)
# daemon_enabled: 1/0
# auto_bypass: 1/0  (enable bypass for apps in DB; disable outside)
# manual_bypass: 1/0 (set to 1 when user manually enables bypass; daemon must do nothing)
interval_sec=2
daemon_enabled=1
auto_bypass=1
manual_bypass=0
EOF
fi

# App DB
if [ ! -f "$DB_FILE" ]; then
  cat > "$DB_FILE" <<EOF
# One package name per line (examples):
# com.tencent.ig
# com.pubg.imobile
EOF
fi

# States
[ ! -f "$STATE_FILE" ] && echo "normal" > "$STATE_FILE"
[ ! -f "$DAEMON_STATE" ] && echo "stopped" > "$DAEMON_STATE"

# Permissions (module dir is writable; keep sane perms)
chmod 0644 "$CONFIG" "$DB_FILE" "$STATE_FILE" "$DAEMON_STATE" 2>/dev/null

# ---- Start daemon if enabled ----
EN="$(cfg_get daemon_enabled 1)"
if [ "$EN" != "1" ]; then
  echo "stopped" > "$DAEMON_STATE"
  exit 0
fi

if [ ! -x "$DAEMON_BIN" ]; then
  # Not compiled/packed yet — OK.
  echo "stopped" > "$DAEMON_STATE"
  exit 0
fi

# Avoid double start
if is_running; then
  echo "running" > "$DAEMON_STATE"
  exit 0
fi

# Clear stale pid if any
rm -f "$PID_FILE" 2>/dev/null

# Start in background (&). Daemon itself will write PID + state.
"$DAEMON_BIN" >>"$LOG_FILE" 2>&1 &

sleep 1
if is_running; then
  echo "running" > "$DAEMON_STATE"
else
  echo "stopped" > "$DAEMON_STATE"
fi

exit 0
