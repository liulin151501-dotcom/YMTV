# Bypass Charger MediaTek

A Magisk module for MediaTek-based Android devices that implements **bypass charging** with an intelligent, event-driven daemon.

This project is designed for users who want fine‑grained control over how their device charges during intensive usage such as gaming, emulation, benchmarking, or long performance sessions — without constantly cycling the battery.

It supports **Android 9 through Android 16** and is built around a simple idea:

> The battery should not be charged when the device is already powered and under heavy load.

Instead, the device can be powered **directly from the charger**, while the battery remains electrically idle.

---

## What is Bypass Charging?

Most MediaTek kernels expose a special control interface:

```
/proc/mtk_battery_cmd/current_cmd
```

This interface allows two important commands:

- `0 1` — Enable bypass mode (power is routed directly to the device, battery is not charged)
- `0 0` — Normal charging behavior

In bypass mode, the charger powers the system **without stressing the battery**.  
This significantly reduces heat, battery wear, and unnecessary charge cycles during long gaming or performance sessions.

Bypass charging is particularly useful when:

- Playing games while plugged in
- Running emulators for extended periods
- Performing benchmarks or stress tests
- Using the device as a performance platform while charging

---

## How This Module Works

This module combines three components into a cohesive system:

### 1. Service (boot-time initializer)

At boot, `service.sh` prepares all runtime files inside the module directory:

- Configuration file
- Applications database
- State files
- Daemon state and PID tracking

All runtime data lives strictly inside the module directory:

```
/data/adb/modules/<module_id>/
```

No temporary paths, no external dependencies.

---

### 2. Interactive Menu & CLI (`bps` / `bpsmtk`)

The menu allows you to:

- Manually enable or disable bypass charging
- Start or stop the daemon
- Adjust daemon behavior through configuration
- Add or remove applications from the database
- Enable **automatic mode** for games and heavy apps

The menu does **not** create any files.  
It only edits configuration prepared by the service.

---

### 3. Intelligent C++ Daemon (`bpsd`)

The daemon is the core of the system.

It runs in the background and:

- Detects the current foreground application
- Compares it with the database (`bps_apps.db`)
- Enables bypass when a target app is active
- Disables bypass when leaving the app
- Reacts only to **actual foreground changes** (no spamming writes)
- Reloads configuration and database on the fly (no restart required)

If you manually enable bypass, the daemon automatically steps aside and does nothing until manual mode is disabled.

---

## Automatic Mode (Game Mode)

When enabled:

- `daemon_enabled=1`
- `auto_bypass=1`
- `manual_bypass=0`

The behavior becomes:

| Situation | Result |
|-----------|--------|
| Game/app from DB is active | Bypass ON |
| Any other app | Bypass OFF |

This ensures the battery is protected only when it matters.

---

## Configuration File

Located at:

```
/data/adb/modules/<module_id>/bps_config.conf
```

Example:

```
interval_sec=2
daemon_enabled=1
auto_bypass=1
manual_bypass=0
```

- `interval_sec` — daemon polling interval
- `daemon_enabled` — whether daemon is allowed to run
- `auto_bypass` — automatic game/app mode
- `manual_bypass` — set by menu when bypass is manually enabled

The daemon reads this file continuously and adapts in real time.

---

## Applications Database

Located at:

```
/data/adb/modules/<module_id>/bps_apps.db
```

One package name per line:

```
com.tencent.ig
com.pubg.imobile
org.ppsspp.ppsspp
```

You can edit this file through the menu without restarting anything.

---

## Usage

After installation and reboot:

```
su -c bps
```

CLI examples:

```
su -c bps -on
su -c bps -off
su -c bps -start
su -c bps -stop
```

---

## Design Principles

This module was built with the following goals:

- No unnecessary writes to kernel interfaces
- Event-driven behavior instead of constant polling actions
- Clear separation of responsibilities (service, menu, daemon)
- All data contained inside the module directory
- Stability across Android 9 to 16
- Simple, readable shell + efficient native daemon

---

## Why This Matters

Frequent charging while gaming is one of the fastest ways to degrade battery health due to:

- Heat buildup
- Constant charge cycles
- Electrical stress under load

Bypass charging removes the battery from the equation when it is not needed.

This module automates that process in a safe, transparent, and configurable way.

---

## Requirements

- MediaTek device with `/proc/mtk_battery_cmd/current_cmd`
- Root with Magisk
- Android 9–16

---

## Disclaimer

Bypass charging relies on kernel support provided by MediaTek implementations.  
If your kernel does not expose the required interface, the module will not function.

Use responsibly and verify compatibility with your device.
