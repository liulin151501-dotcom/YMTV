#!/system/bin/sh
# Magisk module installer script (customize.sh)

MODDIR="${MODPATH:-${0%/*}}"
BIN_DIR="$MODDIR/system/bin"
PROC_IF="/proc/mtk_battery_cmd/current_cmd"

ui_print " "
ui_print "========================================"
ui_print "  MTK Bypass Charging Controller"
ui_print "           Installer"
ui_print "========================================"
ui_print " "
sleep 2
# Определение архитектуры
get_arch() {
    case "$(uname -m)" in
        armv7*|armv8l) echo "32BIT" ;;
        aarch64|arm64*) echo "64BIT" ;;
        x86_64) echo "64BIT" ;;
        x86|i686) echo "32BIT" ;;
        *) echo "UNKNOWN" ;;
    esac
}

ARCH=$(get_arch)

ui_print "[*] Detected architecture: $ARCH"
ui_print " "
sleep 2
# Проверка MTK интерфейса
ui_print "[*] Checking MTK bypass support..."
ui_print "    Path: $PROC_IF"

if [ ! -e "$PROC_IF" ]; then
    ui_print "[✗] ERROR: MTK interface not found!"
    ui_print "    Required: /proc/mtk_battery_cmd/current_cmd"
    ui_print "    Your device may not be supported."
    ui_print " "
    abort 1
fi
sleep 1
ui_print "[*] Testing write permissions..."

TEST_CMD="echo \"0 0\" > \"$PROC_IF\""
if ! eval "$TEST_CMD" 2>/dev/null; then
    ui_print "[✗] ERROR: Cannot write to interface!"
    ui_print "    Root or kernel restriction detected."
    ui_print "    Make sure you have root access."
    ui_print " "
    abort 1
fi

ui_print "[✓] MTK bypass interface verified"
ui_print " "
sleep 2
# Распаковка нужного архива
ui_print "[*] Setting up binaries for $ARCH..."
sleep 1
ARCHIVE="$MODDIR/${ARCH}.tar.gz"

if [ -f "$ARCHIVE" ]; then
    ui_print "[*] Extracting $ARCH binaries..."
    
    # Создаем директорию если нет
    mkdir -p "$BIN_DIR"
    
    # Распаковываем архив
    if tar -xzf "$ARCHIVE" -C "$BIN_DIR" 2>/dev/null; then
        ui_print "[✓] Successfully extracted $ARCH binaries"
        
        # Список файлов после распаковки
        ui_print "[*] Files in $BIN_DIR after extraction:"
        ls -la "$BIN_DIR/" | while read line; do
            ui_print "    $line"
        done
    else
        ui_print "[!] WARNING: Failed to extract $ARCHIVE"
        ui_print "    Trying to use existing binaries..."
    fi
else
    ui_print "[!] WARNING: $ARCH archive not found!"
    ui_print "    Using existing binaries if available..."
fi

ui_print " "
sleep 1
ui_print "[*] Setting permissions..."
sleep 2

if [ ! -d "$BIN_DIR" ]; then
    mkdir -p "$BIN_DIR"
    chmod 0755 "$BIN_DIR"
    ui_print "[✓] Created system/bin directory"
fi

if [ -f "$MODDIR/service.sh" ]; then
    chmod 0755 "$MODDIR/service.sh"
    ui_print "[✓] service.sh (0755)"
fi

for binary in "$BIN_DIR"/*; do
    if [ -f "$binary" ]; then
        chmod 0755 "$binary"
        ui_print "[✓] $(basename "$binary") (0755)"
    fi
done

CONFIG_FILES="bpsmtk_config.conf bpsmtk_apps.db bpsmtk_charge_state bpsmtk_daemon_state"
for file in $CONFIG_FILES; do
    if [ -f "$MODDIR/$file" ]; then
        chmod 0644 "$MODDIR/$file"
        ui_print "[✓] $file (0644)"
    fi
done

find "$MODDIR" -type d -exec chmod 0755 {} \; 2>/dev/null
ui_print " "

ui_print "[*] Verifying installation..."
sleep 1
EXEC_COUNT=0
for binary in "$BIN_DIR"/*; do
    if [ -x "$binary" ]; then
        EXEC_COUNT=$((EXEC_COUNT + 1))
    fi
done

if [ -x "$MODDIR/service.sh" ]; then
    EXEC_COUNT=$((EXEC_COUNT + 1))
fi

ui_print "[✓] $EXEC_COUNT executable files ready"
ui_print " "

ui_print "[*] Checking required files:"
sleep 2
REQUIRED_FILES=0
if [ -f "$BIN_DIR/bpsmtk" ]; then
    ui_print "[✓] bpsmtk found"
    REQUIRED_FILES=$((REQUIRED_FILES + 1))
else
    ui_print "[!] bpsmtk NOT found (main binary)"
fi

if [ -f "$BIN_DIR/bpsd" ]; then
    ui_print "[✓] bpsd found"
    REQUIRED_FILES=$((REQUIRED_FILES + 1))
else
    ui_print "[i] bpsd not found (optional daemon)"
fi

ui_print " "

sleep 2
ui_print "========================================"
ui_print "  INSTALLATION COMPLETE"
ui_print "========================================"
ui_print " "
ui_print "Available commands after reboot:"
ui_print " "
if [ -f "$BIN_DIR/bpsmtk" ]; then
    ui_print "  • su -c bpsmtk     (main menu)"
    ui_print "  • su -c bpsmtk -on (enable bypass)"
    ui_print "  • su -c bpsmtk -off (disable)"
    if [ -f "$BIN_DIR/bpsd" ]; then
        ui_print "  • su -c bpsmtk -start (daemon)"
        ui_print "  • su -c bpsmtk -stop (daemon)"
    fi
else
    ui_print "  [!] Main binary not installed!"
    ui_print "  Check if $ARCH.tar.gz contains bpsmtk"
fi
ui_print " "
sleep 1
ui_print "[*] Cleaning up archive files..."
sleep 1
if [ -f "$MODDIR/32BIT.tar.gz" ]; then
    rm -f "$MODDIR/32BIT.tar.gz"
    ui_print "[✓] Removed 32BIT.tar.gz"
fi

if [ -f "$MODDIR/64BIT.tar.gz" ]; then
    rm -f "$MODDIR/64BIT.tar.gz"
    ui_print "[✓] Removed 64BIT.tar.gz"
fi

if [ -f "$MODDIR/customize.sh" ]; then
    rm -f "$MODDIR/customize.sh"
    ui_print "[✓] Removed old installer"
fi
sleep 1
ui_print "[✓] Cleanup completed"
ui_print " "
sleep 1
ui_print "Module directory:"
ui_print "$MODDIR"
ui_print " "
ui_print "Telegram: @opensourcemagiskmodule"
sleep 2
am start -a android.intent.action.VIEW -d "https://t.me/opensourcemagiskmodule" >/dev/null 2>&1
ui_print "🔁 Reboot recommended."
exit 0