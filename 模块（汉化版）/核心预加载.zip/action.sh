#!/system/bin/sh

p() { awk -v k="$1" -v v="$2" 'BEGIN {
  w=18
  l=length(k)
  if(l<w){ for(i=1;i<=w-l;i++) k=k" " }
  print k " : " v
}'; }

pretty_name() {
  case "$1" in
    Cached) echo "缓存内存" ;;
    ActiveFile) echo "活跃的文件页" ;;
    InactiveFile) echo "非活跃的文件页" ;;
    Dirty) echo "脏页" ;;
    Writeback) echo "回写页" ;;
    SwapCached) echo "交换缓存" ;;
    pgpgin) echo "页缓存读取次数" ;;
    pgpgout) echo "页缓存写入次数" ;;
    pgfault) echo "轻微页错误" ;;
    pgmajfault) echo "严重页错误" ;;
    minflt) echo "轻微缺页错误" ;;
    pgsteal) echo "页面回收" ;;
    pgscan) echo "页面扫描" ;;
    compact) echo "内存压缩" ;;
    compact_fail) echo "压缩失败次数" ;;
    compact_daemon*) echo "压缩守护进程" ;;
    MemPressure10) echo "内存压力 (10秒)" ;;
    MemPressure60) echo "内存压力 (60秒)" ;;
    MemPressure300) echo "内存压力 (300秒)" ;;
    IOPressure10) echo "I/O 压力 (10秒)" ;;
    ZRAMmemUsed) echo "ZRAM 已用字节数" ;;
    SwapUsed) echo "已用交换空间" ;;
    *) echo "$1" ;;
  esac
}

get_mem() {
  awk '
    $1=="Cached:"          {print "Cached="$2}
    $1=="Active(file):"    {print "ActiveFile="$2}
    $1=="Inactive(file):"  {print "InactiveFile="$2}
    $1=="Dirty:"           {print "Dirty="$2}
    $1=="Writeback:"       {print "Writeback="$2}
    $1=="SwapCached:"      {print "SwapCached="$2}
  ' /proc/meminfo
}

# Aggregate vmstat entries that share the same logical metric (pgsteal*, pgscan*, compact_*, etc.)
get_vm() {
  awk '/pgpgin|pgpgout|pgfault|pgmajfault|minflt|pgsteal|pgscan|compact/ {
    k=$1; v=$2;
    # normalize keys that appear with suffixes
    if (k ~ /^pgsteal/) base="pgsteal";
    else if (k ~ /^pgscan/) base="pgscan";
    else if (k ~ /^compact_/) base="compact";
    else base=k;
    agg[base]+=v
  }
  END {
    for (i in agg) print i"="agg[i]
  }' /proc/vmstat
}

get_mem_pressure() {
  awk '/full/ {
    if (match($0,/avg10=([0-9.]+)/,a)) print "MemPressure10="a[1]
    if (match($0,/avg60=([0-9.]+)/,b)) print "MemPressure60="b[1]
    if (match($0,/avg300=([0-9.]+)/,c)) print "MemPressure300="c[1]
  }' /proc/pressure/memory 2>/dev/null
}

get_io_pressure() {
  awk '/full/ {
    if (match($0,/avg10=([0-9.]+)/,a)) print "IOPressure10="a[1]
  }' /proc/pressure/io 2>/dev/null
}

echo "预加载指标 ~"

for kv in $(get_mem); do
  k="${kv%%=*}"
  v="${kv#*=}"
  echo "$(p "$(pretty_name "$k")" "$v")"
done

# get_vm now emits unique, aggregated keys
for kv in $(get_vm); do
  raw="${kv%%=*}"
  val="${kv#*=}"
  echo "$(p "$(pretty_name "$raw")" "$val")"
done

for kv in $(get_mem_pressure); do
  raw="${kv%%=*}"
  val="${kv#*=}"
  echo "$(p "$(pretty_name "$raw")" "$val")"
done

for kv in $(get_io_pressure); do
  raw="${kv%%=*}"
  val="${kv#*=}"
  echo "$(p "$(pretty_name "$raw")" "$val")"
done

if [ -r /proc/swaps ]; then
  swap=$(awk '/zram/ {print $3"/"$4}' /proc/swaps)
  [ -n "$swap" ] && echo "$(p "$(pretty_name "SwapUsed")" "$swap")"
fi

if [ -r /sys/block/zram0/mem_used_total ]; then
  echo "$(p "$(pretty_name "ZRAMmemUsed")" "$(cat /sys/block/zram0/mem_used_total)")"
fi

echo
