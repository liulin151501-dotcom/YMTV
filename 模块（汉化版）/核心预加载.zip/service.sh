#!/system/bin/sh
while [ "$(getprop sys.boot_completed)" != "1" ]; do
  sleep 2
done
while ! pidof com.android.systemui >/dev/null; do
  sleep 2
done
am start -a AxManager.TOAST -e text "核心切换预加载器正在运行中"
bin=$(
  find /data/adb/modules /data/data/com.android.shell/AxManager/plugins \
    -type d -name coremana -path '*/modules/*' -o \
    -type d -name coremana -path '*/AxManager/*' 2>/dev/null | head -n1
)

[ -n "$bin" ] && BIN="$bin/system/bin"
pkgs=$(pm list packages -3 | cut -d: -f2)
home=$(cmd package resolve-activity -a android.intent.action.MAIN -c android.intent.category.HOME | awk -F= '/packageName=/{print $2; exit}')

prev_fg=""

while true; do
  fg=$(cmd activity stack list | awk -F'[/{]' '/0,.*true/{print $3; exit}')

  if [ "$fg" = "$home" ] && [ "$fg" != "$prev_fg" ]; then
    printf '%s\n' "$pkgs" | xargs -r -n1 -P4 -I% "$BIN/kasane" -a % -m n -t 4
  fi

  prev_fg="$fg"
  sleep 2
done
