#!/system/bin/sh

# CoreShift Vulkan
# 一次性强制启用 Vulkan 渲染路径

# 强制使用 Vulkan 渲染路径
/system/bin/setprop debug.hwui.renderer skiavk
/system/bin/setprop debug.renderengine.backend skiavkthreaded
/system/bin/setprop debug.renderengine.vulkan true
/system/bin/setprop debug.stagefright.renderengine.backend threaded

# 允许属性生效
sleep 3


exit 0
