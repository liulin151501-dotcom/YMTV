#!/system/bin/sh
[ "$(id -u 2>/dev/null)" = "0" ] || [ ! -d /data/data/com.android.shell/AxManager ] && exit 0
while ! pidof com.android.systemui >/dev/null 2>&1; do
    sleep 2
done
sleep 15

if [ ! -e /system/lib/libvulkan.so ] \
   && [ ! -e /system/lib64/libvulkan.so ] \
   && ! ls /vendor/lib*/hw/vulkan*.so >/dev/null 2>&1; then
    exit 0
fi

PID_FILE=/data/local/tmp/.sf_pid

sf_pid="$(pidof surfaceflinger 2>/dev/null)"
[ -z "$sf_pid" ] && exit 0

render.sh

echo "$sf_pid" > "$PID_FILE"

exit 0