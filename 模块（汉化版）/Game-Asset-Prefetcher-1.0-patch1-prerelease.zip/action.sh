#!/system/bin/sh
# Game-Asset-Prefetcher by Kazuyoo
# Copyright (c) 2026 Kazuyoo
# Licensed under the GNU General Public License v3.0 or later.
# See LICENSE file for details.
# Open-source powered — with appreciation to GL-DP and all contributors.
cat /sdcard/kzyo_preload.log