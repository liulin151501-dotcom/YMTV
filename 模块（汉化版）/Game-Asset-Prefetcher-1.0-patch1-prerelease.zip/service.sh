#!/system/bin/sh
# Game-Asset-Prefetcher by Kazuyoo
# Copyright (c) 2026 Kazuyoo
# Licensed under the GNU General Public License v3.0 or later.
# See LICENSE file for details.
# Open-source powered — with appreciation to GL-DP and all contributors.
MODDIR=${0%/*};[ "${AXERON:-false}" = "true" ] && [ ! -f "$AXERONXBIN/GAP" ] && cp -f "$MODDIR/system/bin/GAP" "$AXERONXBIN/GAP"
VERSION="$(getprop ro.build.version.release)"

# ----------------- HELPER FUNCTIONS -----------------
wait_until_boot_completed() {
    # Wait sys.boot_completed
    while [ "$(getprop sys.boot_completed)" != "1" ]; do
        sleep 2
    done

    # Wait for storage to mount
    until [ -d "/sdcard/Android" ] || [ -d "/storage/emulated/0/Android" ]; do
        sleep 1
    done
}
  
send_notification() {
    # Notify user of optimization completion
    if command -v su >/dev/null 2>&1; then
        su -lp 2000 -c "cmd notification post -S bigtext -t 'Game-Asset-Prefetcher' tag 'Status :  Optimization Completed!'" >/dev/null 2>&1
    else
        cmd notification post -S bigtext -t 'Game-Asset-Prefetcher' 'tag' 'Status :  Optimization Completed!' >/dev/null 2>&1
    fi
}
wait_until_boot_completed

build_game_list() {
    local out="/data/local/tmp/gamelist.txt"
    local tmp="/data/local/tmp/gamelist_raw.txt"
    local pkg

    : > "$out"
    : > "$tmp"

    VERSION=$(getprop ro.build.version.release | cut -d. -f1)

    if [ "$VERSION" -ge 12 ]; then
        dumpsys game 2>/dev/null | \
        grep -Eo 'com\.[a-zA-Z0-9._]+' | \
        sort -u > "$tmp"
    else
        pm list packages -3 | sed 's/package://' > "$tmp"
    fi

    while read -r pkg; do
        case "$pkg" in
            ""|\
            *chrome*|*youtube*|*browser*|*webview*|*music*|*video*|*gallery*|*maps*|*gmail*|*drive*)
                continue
            ;;
        esac
        echo "$pkg"
    done < "$tmp" | sort -u > "$out"

    rm -f "$tmp"
}

# Main Execution & Exit script successfully
  build_game_list
  GAP --execute;send_notification;exit 0