#!/system/bin/sh
# Game-Asset-Prefetcher by Kazuyoo
# Copyright (c) 2026 Kazuyoo
# Licensed under the GNU General Public License v3.0 or later.
# See LICENSE file for details.
# Open-source powered — with appreciation to GL-DP and all contributors.

# Variable
DATE=$(date)
VERSION="1.0"
NAME="Game-Asset-Prefetcher | Kzyo"
API=$(getprop ro.build.version.sdk)
DEVICES=$(getprop ro.product.board)
MANUFACTURER=$(getprop ro.product.manufacturer)
ANDROIDVERSION=$(getprop ro.build.version.release)
OFFICIAL_REPO="https://github.com/Kazuyoo-stuff"

# Set logcat buffer size @Dcx400
a=$(awk '/MemTotal/ {printf"%.0f\n",$2/1024/1024}' /proc/meminfo)
logcat -G "$a"m

if [ "$AXERON" == "true" ]; then
  PRINT="printf"
else
  PRINT="ui_print"
fi

# PRINT FUNCTION WRAPPER
print_msg() {
  case "$PRINT" in
    ui_print) ui_print "$1" ;;
    printf)   printf "$1" ;;
  esac
}

# LINE SEPARATOR
print_line() {
  ui_print "***************************************"
}

cleanup_abort() {
  ui_print "! $1"
  rm -rf "$MODPATH"
  abort "! Installation Failed."
}

verify_file() {
  file="$1"
  hash_file="$2"

  [ -f "$file" ] || cleanup_abort "Missing file: $file"
  [ -f "$hash_file" ] || cleanup_abort "Missing checksum: $file"

  expected="$(cat "$hash_file" | tr -d '\r\n')"
  actual="$(sha256sum "$file" | awk '{print $1}')"

  [ "$expected" = "$actual" ] || cleanup_abort "Checksum mismatch: $(basename "$file")"
}

# Auto verify
while IFS= read -r hashfile; do
  file="${hashfile%.sha256}"
  verify_file "$file" "$hashfile"
done < <(find "$MODPATH" -type f -name "*.sha256")

check_official_repo() {
  local SRC="${OFFICIAL_REPO:-}"
  RELEASE="Unofficial"
  case "$SRC" in
    *"github.com/Kazuyoo-stuff"*) RELEASE="Official" ;;
  esac
}
check_official_repo

# TRIM PARTITION
trim_partition() {
  setsid sh -c '
    for partition in data cache metadata storage; do
      if command -v su >/dev/null; then
        fstrim -v "/$partition"
      else
        sm fstrim "/$partition"
      fi
    done
  ' >/dev/null 2>&1 &
}

# Starter
[ -z "$ABI" ] && ABI=$(getprop ro.product.cpu.abi);if [[ "$ABI" == *64* ]];then arch=64;rm -f "$MODPATH/system/bin/GAP32";else arch=32;rm -f "$MODPATH/system/bin/GAP64";fi;[ -f "$MODPATH/system/bin/GAP$arch" ] && mv -f "$MODPATH/system/bin/GAP$arch" "$MODPATH/system/bin/GAP"

print_msg "░█▀▀█ ─█▀▀█ ░█▀▄▀█ ░█▀▀▀ ── ─█▀▀█ ░█▀▀█ 
░█─▄▄ ░█▄▄█ ░█░█░█ ░█▀▀▀ ▀▀ ░█▄▄█ ░█▄▄█ 
░█▄▄█ ░█─░█ ░█──░█ ░█▄▄▄ ── ░█─░█ ░█───"
ui_print ""
sleep 0.5
print_msg "   Preload for better launch game."
sleep 0.2
ui_print ""
print_line
print_msg "- Name            : ${NAME}"
sleep 0.2
print_msg "- Version         : ${VERSION} | ${RELEASE}"
sleep 0.2
print_msg "- Android Version : ${ANDROIDVERSION:-Unknown}"
sleep 0.2
print_msg "- Current Date    : ${DATE}"
sleep 0.2
print_line
print_msg "- Devices         : ${DEVICES:-Unknown}"
sleep 0.2
print_msg "- Manufacturer    : ${MANUFACTURER:-Unknown}"
sleep 0.2
print_line

print_msg "- Architecture ${arch}-bit detected."
sleep 0.2

print_msg "- Trimming up Partitions"
trim_partition
sleep 2

# SET PERMISSIONS
if command -v su >/dev/null; then
  print_msg "- Setting permissions"
  set_perm_recursive "$MODPATH" 0 0 0755 0755
fi

# closing or peak completion of the flash module
logcat -c