#!/system/bin/sh
exec>/dev/null 2>&1
pkill -9 -f "swap.sh"
state="/data/local/tmp/.sc.txt"
rm -rf "$state"