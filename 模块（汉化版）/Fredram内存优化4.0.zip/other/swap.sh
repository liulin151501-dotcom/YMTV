#!/system/bin/sh
exec >/dev/null 2>&1

iorenice $$ 7 idle
renice -n 19 -p $$

FLAG="/data/local/tmp/.sc.txt"
applist="/data/local/tmp/.wl.txt"

pkgvl='^(com|org|app|id|cn)\.[a-z0-9_]+\.[a-z0-9_.]+'
whitelist='music|spotify|systemui|launcher|Launcher|inputmethod'

compact=1
[ -f "$FLAG" ] && . "$FLAG"
[ -f "$applist" ] || touch "$applist"

while :; do
    mem_total=$(awk '/MemTotal/ {print $2}' /proc/meminfo)
    mem_avail=$(awk '/MemAvailable/ {print $2}' /proc/meminfo)
    mem_pct=$(( (mem_total - mem_avail) * 100 / mem_total ))

    sleep_time=60
    fg_pkg=$(cmd activity stack list | awk -F'[/{]' '/0,0.*=true/ {print $3; exit}')
    [ -z "$fg_pkg" ] && fg_pkg="__NO_FG__"

    if [ "$mem_pct" -gt 72 ]; then
        RAM_THRESHOLD_KB=$(( mem_total / 80 ))   # 约 1.25%
    else
        RAM_THRESHOLD_KB=$(( mem_total / 50 ))   # 约 2%
    fi

    pid_list=$(ps -o pid,user,pcy | awk '/u0_.*bg/ {print $1}')

    if [ "$mem_pct" -gt 65 ] && [ "$mem_pct" -le 72 ]; then
        mid_done=0

        if [ "$compact" = "1" ]; then
            for pid in $pid_list; do
                [ -r "/proc/$pid/status" ] || continue
                rss_kb=$(awk '/VmRSS/ {print $2}' /proc/$pid/status 2>/dev/null)
                [ -z "$rss_kb" ] || [ "$rss_kb" -lt "$RAM_THRESHOLD_KB" ] && continue

                [ -r "/proc/$pid/cmdline" ] || continue
                pkg=$(tr '\0' '\n' < /proc/$pid/cmdline | head -n1)

                grep -qx "$pkg" "$applist" && continue

                cmd activity compact full "$pid" && mid_done=1
                cmd activity compact native full "$pid" && mid_done=1
            done

            cmd activity compact system && mid_done=1
        else
            user_pkgs=$(cmd package list packages --user 0 -3 | cut -d: -f2)

            for pid in $pid_list; do
                [ -r "/proc/$pid/status" ] || continue
                rss_kb=$(awk '/VmRSS/ {print $2}' /proc/$pid/status 2>/dev/null)
                [ -z "$rss_kb" ] || [ "$rss_kb" -lt "$RAM_THRESHOLD_KB" ] && continue

                [ -r "/proc/$pid/cmdline" ] || continue
                pkg=$(tr '\0' '\n' < /proc/$pid/cmdline | head -n1)

                echo "$user_pkgs" | grep -qx "$pkg" || continue
                grep -qx "$pkg" "$applist" && continue

                cmd activity kill --user 0 "$pkg" && mid_done=1
            done
        fi

        [ "$mid_done" -eq 1 ] && sleep_time=90
    fi

    if [ "$mem_pct" -gt 72 ]; then
        force_done=0
        user_pkgs=$(cmd package list packages --user 0 -u | cut -d: -f2)

        for pid in $pid_list; do
            [ -r "/proc/$pid/status" ] || continue
            rss_kb=$(awk '/VmRSS/ {print $2}' /proc/$pid/status 2>/dev/null)
            [ -z "$rss_kb" ] || [ "$rss_kb" -lt "$RAM_THRESHOLD_KB" ] && continue

            [ -r "/proc/$pid/cmdline" ] || continue
            pkg=$(tr '\0' '\n' < /proc/$pid/cmdline | head -n1)

            echo "$pkg" | grep -qE "$pkgvl" || continue
            echo "$user_pkgs" | grep -qx "$pkg" || continue
            [ "$pkg" = "$fg_pkg" ] && continue
            grep -qx "$pkg" "$applist" && continue
            echo "$pkg" | grep -qE "$whitelist" && continue

            cmd activity force-stop "$pkg" && force_done=1
        done

        [ "$force_done" -eq 1 ] && sleep_time=120
    fi

    sleep "$sleep_time"
done
