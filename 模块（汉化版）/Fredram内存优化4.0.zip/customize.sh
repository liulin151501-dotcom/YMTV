#!/system/bin/sh
state="/data/local/tmp/.sc.txt"

echo "compact=1" > "$state"

# 检查是否支持 activity compact
if ! cmd activity 2>/dev/null | grep -q "compact"; then
    ui_print "该设备不支持 activity compact"
    ui_print "仍然安装（仅执行强制停止和杀进程）"
    echo "compact=0" > "$state"
fi

ui_print "安装完成。请享用！"

cmd package list packages --user 0 | grep -Eo "$(cat $MODDIR/white.txt)" > /data/local/tmp/.wl.txt