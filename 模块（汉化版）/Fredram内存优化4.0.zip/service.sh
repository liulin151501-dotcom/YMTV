#!/system/bin/sh
MODDIR=${0%/*}
cmd package list packages --user 0 | grep -Eo "$(cat $MODDIR/white.txt)" > /data/local/tmp/.wl.txt
device_config put activity_manager use_compaction true
nohup $MODDIR/other/swap.sh&disown