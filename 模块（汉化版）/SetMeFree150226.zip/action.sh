#!/system/bin/sh

# ===============================
#  Monitor Specter(C) Loop
# ===============================

# Path tempat binary specter
SPECTER_PATH="/data/user_de/0/com.android.shell/axeron/plugins/SetmeFree/sfrz"
MODULE_PROP="/data/user_de/0/com.android.shell/axeron/plugins/SetmeFree/module.prop"
Setme="/data/user_de/0/com.android.shell/axeron/plugins/SetmeFree"
# Ambil PID
PIDS="$(pidof $(basename "$SPECTER_PATH"))"

if echo "${0%/*}" | grep -q Ax; then
  a() { sleep 0.01; printf "%s\n" "$*"; }
else
  a() { sleep 0.01; echo "$*"; }
fi >/dev/null

# Header
a "***********************************************"
a "SetMeFree Monitor"
a "***********************************************"

HZ=100

if [ -n "$PIDS" ]; then
    if [ -f "$MODULE_PROP" ]; then
        ORIG_DESC=$(grep '^description=' "$MODULE_PROP" | cut -d= -f2-)

        if ! echo "$ORIG_DESC" | grep -q "SetMeFree($PIDS)"; then
            NEW_DESC=$(echo "$ORIG_DESC" | sed 's/ - SetMeFree([0-9]\+)//g')
            sed -i "s|^description=.*|description=$NEW_DESC - SetMeFree($PIDS)|" "$MODULE_PROP"
        fi
    fi
    else
    if [ -f "$MODULE_PROP" ]; then
        rm -rf "$Setme"
    fi
    a "SetMeFree not running please report to @sxSoleum"
fi

if [ -n "$PIDS" ]; then
  COUNT=$(echo "$PIDS" | wc -w)
  a "- $COUNT SetmeFree running"
  a "PID     CPU%   RES    SHR    UPTIME    CMDLINE"
  a "-----------------------------------------------------------------------"

  for PID in $PIDS; do
    CPU="$(ps -eo %cpu,pid | awk -v id=$PID '$2==id {print $1}')"
    RES="$(ps -eo res,pid  | awk -v id=$PID '$2==id {print $1}')"
    SHR="$(ps -eo shr,pid  | awk -v id=$PID '$2==id {print $1}')"
    CMDLINE="$(tr -d '\0' < /proc/$PID/cmdline 2>/dev/null)"

    START_TICKS="$(awk '{print $22}' /proc/$PID/stat 2>/dev/null)"
    SYS_UPTIME="$(cut -d. -f1 /proc/uptime)"
    if [ -n "$START_TICKS" ]; then
      PROC_START_SEC=$((START_TICKS / HZ))
      PROC_UPTIME=$((SYS_UPTIME - PROC_START_SEC))
    else
      PROC_UPTIME=0
    fi
    UP_H=$((PROC_UPTIME / 3600))
    UP_M=$((PROC_UPTIME % 3600 / 60))
    UP_S=$((PROC_UPTIME % 60))
    UPTIME_FMT=$(printf "%02d:%02d:%02d" "$UP_H" "$UP_M" "$UP_S")

    a "$(printf "%-6s %-5s %-6s %-6s %-8s %s" \
        "$PID" "${CPU:-0}" "${RES:-0}" "${SHR:-0}" "$UPTIME_FMT" "$CMDLINE")"
  done
else
  a "- No funct"
fi
