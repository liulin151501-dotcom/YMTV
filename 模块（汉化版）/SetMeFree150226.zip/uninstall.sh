#!/system/bin/sh
exec>/dev/null 2>&1
kill -9 $(pidof sfrz)