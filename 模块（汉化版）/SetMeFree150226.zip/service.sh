#!/system/bin/sh
exec>/dev/null 2>&1;while [ "$(getprop sys.boot_completed)" != 1 ];do sleep 5;done
MODDIR="${0%/*}";alias cmd=/system/bin/cmd;for a in /proc/sys/kernel/*panic*;do echo 0>"$a";done
cmd package list packages --user 0 | grep -Eo "$(cat $MODDIR/perflist.txt)" > /data/local/tmp/.sfrz.txt

#Some cmd from cmd-tweaks by @HoyoSlave
for a in $(dumpsys thermalservice|grep -Eo 'mName[^,]+'|cut -f2 -d=);do
  cmd thermalservice inject-temperature "$a" none "$a" 10
done

kill -9 $(pidof sfrz)
sleep 1
nohup sfrz&disown
exit 0