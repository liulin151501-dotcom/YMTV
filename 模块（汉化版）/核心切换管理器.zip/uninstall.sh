CORE=/data/local/tmp/core
LIST=/$CORE/net.txt
cmd connectivity set-chain3-enabled false
    while IFS= read -r pkg; do
      cmd connectivity set-package-networking-enabled false "$pkg"
    done < "$LIST"
    rm -r $CORE