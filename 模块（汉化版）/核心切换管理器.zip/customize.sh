CORE=/data/local/tmp/core
[ -d "$CORE" ] && exit 0
mkdir -p $CORE