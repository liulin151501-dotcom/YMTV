infodev() {
ver=$(getprop ro.build.version.release)

memgb=$(awk '/MemTotal/ {printf "%.2f",$2/1024/1024; exit}' /proc/meminfo)

load=$(cut -d' ' -f1 /proc/loadavg)

gfxinfo=$(dumpsys gfxinfo com.android.systemui)

selinux=$(getenforce)

missed_frame=$(printf '%s\n' "$gfxinfo" | grep -m1 'Number Frame deadline missed' | cut -d: -f2)
missed_frame=${missed_frame# }

missed_vsync=$(printf '%s\n' "$gfxinfo" | grep -m1 'Number Missed Vsync' | cut -d: -f2)
missed_vsync=${missed_vsync# }

render_90=$(printf '%s\n' "$gfxinfo" \
  | grep '90th' | grep -v 'gpu' | head -n1 | cut -d: -f2)
render_90=${render_90# }

gpu_90=$(printf '%s\n' "$gfxinfo" | grep '90th' | grep 'gpu' | head -n1 | cut -d: -f2) gpu_90=${gpu_90# }

block=$(cmd thermalservice dump 2>/dev/null \
  | awk '/^Current temperatures from HAL:$/ {c=1;next} c&&n<4 {print;n++}')
  
cpu_temp=$(printf '%s\n' "$block" \
  | grep -E 'mName=CPU(0)?,' \
  | cut -d'=' -f2 | cut -d',' -f1 | cut -d'.' -f1)

gpu_temp=$(printf '%s\n' "$block" \
  | grep -E 'mName=GPU(0)?,' \
  | cut -d'=' -f2 | cut -d',' -f1 | cut -d'.' -f1)

bat_temp=$(printf '%s\n' "$block" \
  | grep -Ei 'mName=battery,' \
  | cut -d'=' -f2 | cut -d',' -f1 | cut -d'.' -f1)

skin_temp=$(printf '%s\n' "$block" \
  | grep -Ei 'mName=skin,' \
  | cut -d'=' -f2 | cut -d',' -f1 | cut -d'.' -f1)
  
echo "仪表盘信息 ~"
echo "Android 版本    : $ver"
echo "内存总量        : ${memgb} GB"
echo "CPU 负载        : $load"
echo "SELinux         : $selinux"

echo ""
echo "帧统计信息 ~"
echo "掉帧数量        : ${missed_frame:-0}"
echo "错失垂直同步    : ${missed_vsync:-0}"
echo "90% 渲染耗时    : ${render_90:-0ms}"
echo "90% GPU 耗时    : ${gpu_90:-0ms}"
echo ""
if [ -n "${cpu_temp}${gpu_temp}${bat_temp}${skin_temp}" ]; then
    echo ""
    echo "温度 (°C) ~"
    [ -n "$cpu_temp" ] && echo "CPU 温度        : ${cpu_temp}"
    [ -n "$gpu_temp" ] && echo "GPU 温度        : ${gpu_temp}"
    [ -n "$bat_temp" ] && echo "电池温度        : ${bat_temp}"
    [ -n "$skin_temp" ] && echo "机身温度        : ${skin_temp}"
  fi
  }
infodev
