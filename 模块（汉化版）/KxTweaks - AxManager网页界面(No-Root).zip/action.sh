echo "======================================"
echo "TELEGRAM LINK"
echo "======================================"
am start -a android.intent.action.VIEW -d "https://t.me/kxtweaks"