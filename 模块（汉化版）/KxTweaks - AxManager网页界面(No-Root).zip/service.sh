# =========================================== #
# Source Code                                           #
# =========================================== #
while true;do cmd package trim-caches 999G;sleep 1h;done>/dev/null 2>&1&
cmd power set-fixed-performance-mode-enabled true
cmd power set-adaptive-power-saver-enabled false
cmd power set-mode 0
cmd thermalservice override-status 0
settings put global power_check_max_cpu_1 110
settings put global power_check_max_cpu_2 110
settings put global power_check_max_cpu_3 80
settings put global power_check_max_cpu_4 80
setprop debug.hwui.target_power_time_percent 100
setprop debug.hwui.trace_gpu_resources false
setprop debug.egl.force_msaa false
setprop debug.hwui.use_hint_manager 1
setprop debug.hwui.disable_vsync true
setprop debug.hwui.disable_scissor_opt true

setprop debug.performance.tuning 1

setprop debug.composition.type dyn

setprop debug.hwui.renderer vulkan
setprop debug.renderengine.backend skiavkthreaded

setprop debug.cpurend.vsync false

settings put global zram_enabled 0

device_config put interaction_jank_monitor enabled false
device_config put interaction_jank_monitor sampling_interval 99999999999999
device_config put interaction_jank_monitor trace_threshold_frame_time_millis -1
device_config put interaction_jank_monitor trace_threshold_missed_frames -1
device_config put activity_manager disable_app_profiler_pss_profiling true
cmd settings put system air_motion_engine 0
cmd settings put system master_motion 0
cmd settings put system motion_engine 0
setprop debug.cluster_little-set_his_speed $(cat /sys/devices/system/cpu/cpu1/cpufreq/cpuinfo_min_freq)
setprop debug.cluster_big-set_his_speed $(cat /sys/devices/system/cpu/cpu1/cpufreq/cpuinfo_max_freq)
setprop debug.powehint.cluster_little-set_his_speed $(cat /sys/devices/system/cpu/cpu1/cpufreq/cpuinfo_min_freq)
setprop debug.powehint.cluster_big-set_his_speed $(cat /sys/devices/system/cpu/cpu1/cpufreq/cpuinfo_max_freq)
cmd activity clear-debug-app
cmd activity clear-exit-info