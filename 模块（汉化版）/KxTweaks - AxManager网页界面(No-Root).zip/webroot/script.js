import { exec, spawn, toast, fullScreen } from 'https://cdn.jsdelivr.net/npm/kernelsu@1.0.6/+esm';
const loaderBlock = document.getElementById("loader-blocking")

let dataType = ""
let stateExecution = ""
let panelSelectElement = document.getElementById('panel-selection')
let valueParams = ""
let cacheCleanerInterval = null;
let cacheTimerInterval = null;
let nextCacheCleanTime = null;

const listSystem = {
  "ElixirSOC": execSystemElixir,
  "硬件加速渲染": execSystemHwui,
  "中央处理器": execSystemCpu,
  "显示表面优化": execSystemSurface,
  "OpenGL": execRender,
  "OpenGL后端": execRenderBackend,
  "Vulkan": execRender,
  "Vulkan后端": execRenderBackend,
  "Skia Vulkan": execRender,
  "Skia Vulkan后端": execRenderBackend,
  "Skia OpenGL": execRender,
  "Skia OpenGL后端": execRenderBackend,
  "60赫兹": execRefreshRate,
  "90赫兹": execRefreshRate,
  "120赫兹": execRefreshRate,
  "0.3倍动画缩放": execAnimationScale,
  "0.5倍动画缩放": execAnimationScale,
  "1.0倍动画缩放": execAnimationScale,
  "1.3倍动画缩放": execAnimationScale,
  "30帧每秒": execGameFps,
  "45帧每秒": execGameFps,
  "60帧每秒": execGameFps,
  "90帧每秒": execGameFps,
  "120帧每秒": execGameFps,
  "缓存清理": execCacheCleaner,
  "重置": execGameDriver,
  "Angle原生驱动": execGameDriver,
  "游戏驱动": execGameDriver,
  "网络增强": execNetEnh
}

// --- Package list
const GAME_PACKAGES = [
  "age.of.civilizations2.jakowski.lukasz",
  "com.bushiroad.en.bangdreamgbp",
  "com.ChillyRoom.DungeonShooter",
  "com.chillyroom.soulknightprequel",
  "com.Flanne.MinutesTillDawn.roguelike.shooting.gp",
  "com.GameCoaster.ProtectDungeon",
  "com.HoYoverse.hkrpgoversea",
  "com.RoamingStar.BlueArchive",
  "com.Shooter.ModernWarships",
  "com.Sunborn.SnqxExilium",
  "com.YoStar.AetherGazer",
  "com.YoStarEN.Arknights",
  "com.YoStarEN.MahjongSoul",
  "com.YoStarJP.MajSoul",
  "com.YoStarJP.BlueArchive",
  "com.ZeroCastleGameStudio.StrikeBusterPrototype",
  "com.ZeroCastleGameStudioINTL.StrikeBusterPrototype",
  "com.activision.callofduty.shooter",
  "com.activision.callofduty.warzone",
  "com.albiononline",
  "com.aligames.kuang.kybc",
  "com.autumn.skullgirls",
  "com.axlebolt.standoff2",
  "com.bandainamcoent.imas_millionlive_theaterdays",
  "com.bandainamcoent.sao",
  "com.bandainamcoent.shinycolorsprism",
  "com.bhvr.deadbydaylight",
  "com.bilibili.azurlane",
  "com.bilibili.deadcells.mobile",
  "com.bilibili.fatego",
  "com.bilibili.star.bili",
  "com.bilibili.warmsnow",
  "com.bilibiligame.heglgp",
  "com.bingkolo.kleins.cn",
  "com.blizzard.diablo.immortal",
  "com.bushiroad.d4dj",
  "com.bushiroad.lovelive.schoolidolfestival2",
  "com.carxtech.sr",
  "com.citra.emu",
  "com.cnvcs.xiangqi",
  "com.criticalforceentertainment.criticalops",
  "com.dena.a12026801",
  "com.denachina.g13002010",
  "com.dfjz.moba",
  "com.dgames.g15002002",
  "com.dolphinemu.dolphinemu",
  "com.dragonli.projectsnow.lhm",
  "com.dts.freefiremax",
  "com.dts.freefireth",
  "com.dts.freefireadv",
  "com.ea.gp.apexlegendsmobilefps",
  "com.ea.gp.fifamobile",
  "com.epicgames.fortnite",
  "com.fantablade.icey",
  "com.firsttouchgames.dls7",
  "com.gabama.monopostolite",
  "com.gameloft.android.ANMP.GloftA9HM",
  "com.gameloft.android.ANMP.GloftMVHM",
  "com.garena.game.codm",
  "com.garena.game.kgid",
  "com.garena.game.kgtw",
  "com.garena.game.kgvn",
  "com.guyou.deadstrike",
  "com.halo.windf.hero",
  "com.heavenburnsred",
  "com.hermes.j1game",
  "com.hottapkgs.hotta",
  "com.hypergryph.arknights",
  "com.ignm.raspberrymash.jp",
  "com.ilongyuan.implosion",
  "com.jacksparrow.jpmajiang",
  "com.je.supersus",
  "com.kakaogames.eversoul",
  "com.kakaogames.wdfp",
  "com.kog.grandchaseglobal",
  "com.komoe.kmumamusumegp",
  "com.kurogame.haru",
  "com.kurogame.haru.bilibili",
  "com.leiting.wf",
  "com.levelinfinite.hotta.gp",
  "com.levelinfinite.sgameGlobal",
  "com.levelinfinite.sgameGlobal.midaspay",
  "com.lilithgames.hgame.cn",
  "com.linegames.sl",
  "com.madfingergames.legends",
  "com.miHoYo.GenshinImpact",
  "com.miHoYo.Yuanshen",
  "com.miHoYo.bh3",
  "com.miHoYo.bh3global",
  "com.miHoYo.bh3oversea",
  "com.miHoYo.bh3oversea_vn",
  "com.miHoYo.enterprise.NGHSoD",
  "com.miHoYo.hkrpg",
  "com.miHoYo.ys",
  "com.miraclegames.farlight84",
  "com.mobile.legends",
  "com.mobilelegends.hwag",
  "com.mojang.hostilegg",
  "com.mojang.minecraftpe",
  "com.mojang.minecraftpe.patch",
  "com.nanostudios.games.twenty.minutes",
  "com.netease.AVALON",
  "com.netease.EVE",
  "com.netease.aceracer",
  "com.netease.dfjs",
  "com.netease.dwrg",
  "com.netease.eve.en",
  "com.netease.frxyna",
  "com.netease.g93na",
  "com.netease.h75na",
  "com.netease.jddsaef",
  "com.netease.lglr",
  "com.netease.ma84",
  "com.netease.moba",
  "com.netease.mrzh",
  "com.netease.newspike",
  "com.netease.nshm",
  "com.netease.onmyoji",
  "com.netease.party",
  "com.netease.partyglobal",
  "com.netease.race",
  "com.netease.racerna",
  "com.netease.sky",
  "com.netease.soulofhunter",
  "com.netease.tj",
  "com.netease.tom",
  "com.netease.wotb",
  "com.netease.x19",
  "com.netease.yhtj",
  "com.nexon.bluearchive",
  "com.nexon.kartdrift",
  "com.nianticlabs.monsterhunter",
  "com.olzhass.carparking.multyplayer",
  "com.pearlabyss.blackdesertm.gl",
  "com.pinkcore.tkfm",
  "com.playdigious.deadcells.mobile",
  "com.proximabeta.mf.uamo",
  "com.proximabeta.nikke",
  "com.prpr.musedash",
  "com.pubg.imobile",
  "com.pubg.krmobile",
  "com.pubg.newstate",
  "com.pwrd.hotta.laohu",
  "com.pwrd.huanta",
  "com.r2games.myhero.bilibili",
  "com.rayark.implosion",
  "com.rayark.sdorica",
  "com.rekoo.pubgm",
  "com.riotgames.league.teamfighttactics",
  "com.riotgames.league.teamfighttacticsvn",
  "com.riotgames.league.wildrift",
  "com.roblox.client",
  "com.rockstargames.gtasa",
  "com.sega.ColorfulStage.en",
  "com.sega.pjsekai",
  "com.shangyoo.neon",
  "com.shenlan.m.reverse1999",
  "com.smokoko.race",
  "com.sofunny.Sausage",
  "com.soulgamechst.majsoul",
  "com.sprduck.garena.vn",
  "com.stove.epic7.google",
  "com.supercell.brawlstars",
  "com.supercell.clashofclans",
  "com.supercell.clashroyale",
  "com.sy.dldlhsdj",
  "com.t2ksports.nba2k20and",
  "com.tencent.KiHan",
  "com.tencent.ig",
  "com.tencent.jkchess",
  "com.tencent.lolm",
  "com.tencent.mf.uam",
  "com.tencent.tmgp.WePop",
  "com.tencent.tmgp.bh3",
  "com.tencent.tmgp.cf",
  "com.tencent.tmgp.cod",
  "com.tencent.tmgp.dfjs",
  "com.tencent.tmgp.ffom",
  "com.tencent.tmgp.gnyx",
  "com.tencent.tmgp.kr.codm",
  "com.tencent.tmgp.pubgmhd",
  "com.tencent.tmgp.sgame",
  "com.tencent.tmgp.speedmobile",
  "com.tencent.tmgp.wuxia",
  "com.tencent.tmgp.yys.zqb",
  "com.tencent.toaa",
  "com.tgc.sky.android",
  "com.the10tons.dysmantle",
  "com.ubisoft.rainbowsixmobile.r6.fps.pvp.shooter",
  "com.unity.mmd",
  "com.valvesoftware.cswgsm",
  "com.valvesoftware.source",
  "com.vng.mlbbvn",
  "com.vng.pubgmobile",
  "com.vng.speedvn",
  "com.xd.TLglobal",
  "com.xd.rotaeno.googleplay",
  "com.xd.rotaeno.tapcn",
  "com.xindong.torchlight",
  "com.yongshi.tenojo",
  "com.zlongame.mhmnz",
  "com.ztgame.bob",
  "com.zy.wqmt.cn",
  "jp.co.craftegg.band",
  "jp.konami.pesam",
  "net.kdt.pojavlaunch",
  "net.wargaming.wot.blitz",
  "org.mm.jr",
  "org.vita3k.emulator",
  "pro.archiemeng.waifu2x",
  "skyline.emu",
  "skynet.cputhrottlingtest",
  "org.yuzu.yuzu_emu",
  "id.rj01117883.liomeko",
  "xyz.aethersx2.android",
  "com.pwrd.opmwsea",
  "com.kurogame.gplay.punishing.grayraven.en",
  "com.FosFenes.Sonolus",
  "com.devsisters.ck",
  "ro.alyn_sampmobile.game",
  "com.kakaogames.gdts",
  "com.Shooter.ModernWarship",
  "com.supercell.hayday",
  "com.nekki.shadowfight",
  "com.nekki.shadowfight3",
  "com.gamedevltd.wwh",
  "com.netease.ma100asia",
  "com.gryphline.exastris.gp",
  "org.sudachi.sudachi_emu.ea",
  "com.netmarble.sololv",
  "com.netease.g78na.gb",
  "com.pubg.imobile",
  "com.bandainamcoent.opbrww",
  "com.proximabeta.mf.uamo",
  "com.kurogame.wutheringwaves.global",
  "com.HoYoverse.Nap"
];

// --- Base CONFIG
const BASE_CONFIG = `mode=2,fps={FPS},skiavk=1,vsync=0,frameRateCap={FPS},refreshRate={FPS},minFrameRate={FPS},maxFrameRate={FPS},frameRateLimit={FPS},targetFrameRate={FPS},lowLatencyMode=1,angle=1,gpuBoost=1,cpuBoost=1,sustainedPerformanceMode=1,adaptiveFrameRate=0,renderAheadLimit=2,touchBoost=1,frameStabilization=1,frameRateSmoothing=1,gpuGovernor=performance,cpuGovernor=performance,thermalThrottling=0,surfaceFlingerTripleBuffering=1,gameMode=1,thermalHeadroomBoost=1,priorityBoost=1;mode=3,fps={FPS},skiavk=1,vsync=0,frameRateCap={FPS},refreshRate={FPS},minFrameRate={FPS},maxFrameRate={FPS},frameRateLimit={FPS},targetFrameRate={FPS},lowLatencyMode=1,angle=1,gpuBoost=1,cpuBoost=1,sustainedPerformanceMode=1,adaptiveFrameRate=0,renderAheadLimit=2,touchBoost=1,frameStabilization=1,frameRateSmoothing=1,gpuGovernor=performance,cpuGovernor=performance,thermalThrottling=0,surfaceFlingerTripleBuffering=1,gameMode=1,thermalHeadroomBoost=1,priorityBoost=1`;

function buildConfig(fps){
  return BASE_CONFIG.replace(/{FPS}/g, String(fps));
}

async function getProp(prop) {
    try {
        const { stdout } = await exec(`getprop ${prop}`);
        return stdout.trim();
    } catch (e) {
        return console.log(e);
    }
}

async function getSettings(settings) {
  try {
    const { stdout } = await exec(`settings get ${settings}`)
    return stdout.trim();
  } catch(e) {
    return "";
  }
}

async function getShellOutput(command, fallback = "") {
    try {
        const { stdout } = await exec(command);
        return stdout.trim();
    } catch (e) {
        return fallback;
    }
}

function LayoutSelectionUp(isActive, titleName, dataType) {
    console.log(isActive);
    const panelListSelection = document.getElementById('panel-selection')
    const component = document.getElementById('layout-selection');
    const titleComponent = document.getElementById('title-dsl');
    const blackBack = document.getElementById('black-ly');

    titleComponent.textContent = titleName;
    
    if (dataType == "select") {
      panelListSelection.style.display = "flex"
      document.getElementById("disable-btn").style.display = "none"
    } else {
      panelListSelection.style.display = "none"
      document.getElementById("disable-btn").style.display = "block"
    }

    if (isActive) {
        blackBack.style.display = 'block';
        setTimeout(() => {
            blackBack.style.opacity = '0.5'
            setTimeout(() => {
                component.style.transform = 'translateY(0)';
            }, 100)
        }, 200)
    } else {
        component.transform = 'translateY(100%)';
    }
}

function setDataItem(name, data) {
  localStorage.setItem(name, data);
}

function getDataItem(name) {
  return localStorage.getItem(name);
}

const component = document.getElementById('layout-selection');
const blackBack = document.getElementById('black-ly');

blackBack.addEventListener('click', () => {
    console.log('click');
    blackBack.style.opacity = '0'
    setTimeout(() => {
        blackBack.style.display = 'none';
        setTimeout(() => {
            component.style.transform = 'translateY(100%)';
        }, 100)
    }, 200)
});

function resetSelection() {
  panelSelectElement.innerHTML = ''
}


const idMode1 = document.getElementById('olixir-md');
const idMode2 = document.getElementById('hwui-md');
const idMode3 = document.getElementById('cpu-md');
const idMode4 = document.getElementById('dsf-md');
const idMode5 = document.getElementById('rdr-md');
const idMode6 = document.getElementById('rdrb-md');
const idMode7 = document.getElementById('rr-md');
const idMode8 = document.getElementById('as-md');
const idMode9 = document.getElementById('gamefps-md');
const idMode10 = document.getElementById('cache-md');
const idMode11 = document.getElementById('gamedriver-md');
const idMode12 = document.getElementById('netenh-md');

const idSts1 = document.getElementById('sts-elix')
const idSts2 = document.getElementById('sts-hwui')
const idSts3 = document.getElementById('sts-cpu')
const idSts4 = document.getElementById('sts-dsf')
const idSts5 = document.getElementById('sts-rdr')
const idSts6 = document.getElementById('sts-rdrb')
const idSts7 = document.getElementById('sts-rr')
const idSts8 = document.getElementById('sts-as')
const idSts9 = document.getElementById('sts-gamefps')
const idSts10 = document.getElementById('sts-cache');
const idSts11 = document.getElementById('sts-gamedriver');
const idSts12 = document.getElementById('sts-netenh');
const idTimer10 = document.getElementById('cache-timer');

idMode1.addEventListener('click', () => {
    LayoutSelectionUp(true, "ElixirSOC");
    stateExecution = "ElixirSOC"
    console.log(stateExecution);
});
idMode2.addEventListener('click', () => {
    LayoutSelectionUp(true, "HWUI Compotion");
    stateExecution = "HWUI"
});
idMode3.addEventListener('click', () => {
    LayoutSelectionUp(true, "CPU Scheme");
    stateExecution = "CPU"
});
idMode4.addEventListener('click', () => {
    LayoutSelectionUp(true, "Dynamic Surface Flinger");
    stateExecution = "DSF"
});
idMode5.addEventListener('click', () => {
    const dataRender = [["Vulkan", "vulkan"], ["Opengl", "opengl"], ["SkiaVk", "skiavk"], ["SkiaGl", "skiagl"]];
    LayoutSelectionUp(true, "Render Customization", "select");
    resetSelection();
    valueParams = ""
    selectionDec(dataRender, "GL", "renderBtn", idSts5);
});
idMode6.addEventListener('click', () => {
  const dataRender = [["VulkaN", "vulkan"], ["OpengL", "opengl"], ["SkiaVK", "skiavk"], ["SkiaGL", "skiagl"]];
    LayoutSelectionUp(true, "Render Backend Customization", "select");
    resetSelection();
    valueParams = ""
    selectionDec(dataRender, "GLB", "renderBtnB", idSts6);
});
idMode7.addEventListener('click', () => {
    const dataFrame = [["60Hz", "60"], ["90Hz", "90"], ["120Hz", "120"], ["144Hz", "144"]];
    LayoutSelectionUp(true, "Refresh Rate Selection", "select");
    resetSelection();
    valueParams = ""
    selectionDec(dataFrame, "FR", "frameRate", idSts7)
});
idMode8.addEventListener('click', () => {
    const dataScale = [["0,3", "0.3"], ["0,5", "0.5"], ["1,0", "1.0"], ["1,3", "1.3"]]
    LayoutSelectionUp(true, "Animation Scale", "select");
    resetSelection();
    valueParams = ""
    selectionDec(dataScale, "SC", "scaleAnim", idSts8)
});
idMode9.addEventListener('click', () => {
    const dataFps = [["30 FPS", "30"], ["45 FPS", "45"], ["60 FPS", "60"], ["90 FPS", "90"], ["120 FPS", "120"], ["144Hz", "144"]];
    LayoutSelectionUp(true, "Game FPS Selection", "select");
    resetSelection();
    valueParams = ""
    selectionDec(dataFps, "FPS", "gameFps", idSts9)
});
idMode10.addEventListener('click', () => {
    LayoutSelectionUp(true, "Cache Cleaner");
    stateExecution = "CacheCleaner"
});
idMode11.addEventListener('click', () => {
    const dataDriver = [["Reset", "Reset"], ["AngleNative", "AngleNative"], ["GameDriver", "GameDriver"]];
    LayoutSelectionUp(true, "Game Driver Selection", "select");
    resetSelection();
    valueParams = ""
    selectionDec(dataDriver, "DRV", "gameDriver", idSts11);
});
idMode12.addEventListener('click', () => {
    LayoutSelectionUp(true, "Network Enhancement");
    stateExecution = "NetEnh"
});

async function execSystemElixir(statusInit) {
  loaderBlock.style.display = "flex"
  const cekBeforeRunMediatek = await getProp("debug.mediatek.appgamepq_compress");
  const cekBeforeRunQualcomm = await getProp('debug.qctwa.statusbar');
  const cekCpuType = await getShellOutput("cat /proc/cpuinfo");
  let chipStatus = "";
  
  if (cekCpuType.includes("MT")) {
    chipStatus = "Mediatek"
  } else if(cekCpuType.includes("Qualcomm")) {
    chipStatus = "Qualcomm"
  }
  
  if (statusInit !== "rmv") {
    if (cekCpuType.includes("MT") && cekBeforeRunMediatek !== "1") {
      await exec(
        `
        setprop debug.mediatek.appgamepq_compress 1;
        setprop debug.mediatek.disp_decompress 1;
        setprop debug.mediatek.appgamepq 1;
        setprop debug.mediatek.game_pq_enable 1;
        setprop debug.mediatek.high_frame_rate_sf_set_big_core_fps_threshold 90;
        setprop debug.mtk.aee.db 0;
        setprop debug.netlog.writtingpath disable;
        setprop debug.mtklog.log2sd.path disable;
        setprop debug.mtklog.init.flag 0;
        setprop debug.MB.running 0;
        setprop debug.mtklog.netlog.enable "0"
        setprop debug.mtklog.aee.Running "0"
        setprop debug.mtklog.aee.enable "0"
        setprop debug.mtklog.log2sd.path ""
        `
      )
      const cek = await getProp("debug.mediatek.appgamepq_compress");
      if (cek == "1") {
        document.getElementById("log-ui").textContent += "\n OlixirSOC Status : Active Mediatek Version";
        idSts1.textContent = "On"
      }
    } else if(cekCpuType.includes("Qualcomm") && cekBeforeRunQualcomm !== "1") {
      await exec(
        `
        setprop debug.qti.am.resource.type "super-large"
        setprop debug.qc.hardware "true"
        setprop debug.qctwa.statusbar "1"
        setprop debug.qctwa.preservebuf "1"
        setprop debug.gralloc.gfx_ubwc_disable 0;
        setprop debug.qualcomm.sns.hal 0;
        setprop debug.qualcomm.sns.daemon 0;
        setprop debug.qualcomm.sns.libsensor1 0;
        `
      )
      const cek = await getProp("debug.qctwa.statusbar");
      if (cek == "1") {
        document.getElementById("log-ui").textContent += "\n OlixirSOC Status : Active Qualcomm Version";
        idSts1.textContent = "On"
      }
    } else {
      document.getElementById("log-ui").textContent += `\n OlixirSOC Status : Already Active ${chipStatus} Version`;
      idSts1.textContent = "On"
    }
  } else {
    if (cekCpuType.includes("MT") && cekBeforeRunMediatek !== "0") {
      await exec(
        `
        setprop debug.mediatek.appgamepq_compress 0;
        setprop debug.mediatek.disp_decompress 0;
        setprop debug.mediatek.appgamepq 0;
        setprop debug.mediatek.game_pq_enable 0;
        setprop debug.mediatek.high_frame_rate_sf_set_big_core_fps_threshold 0;
        setprop debug.mtk.aee.db 1;
        setprop debug.netlog.writtingpath enable;
        setprop debug.mtklog.log2sd.path enable;
        setprop debug.mtklog.init.flag 1;
        setprop debug.MB.running 1;
        setprop debug.mtklog.netlog.enable "1"
        setprop debug.mtklog.aee.Running "1"
        setprop debug.mtklog.aee.enable "1"
        setprop debug.mtklog.log2sd.path "/mnt/sdcard/mtklog"
        `
      )
      const cek = await getProp("debug.mediatek.appgamepq_compress");
      if (cek == "0") {
        document.getElementById("log-ui").textContent += "\n OlixirSOC Status : Disabled Mediatek Version";
        idSts1.textContent = "Off"
      }
    } else if (cekCpuType.includes("Qualcomm") && cekBeforeRunQualcomm !== "0") {
      await exec(
        `
        setprop debug.qti.am.resource.type "normal"
        setprop debug.qc.hardware "false"
        setprop debug.qctwa.statusbar "0"
        setprop debug.qctwa.preservebuf "0"
        setprop debug.gralloc.gfx_ubwc_disable 1;
        setprop debug.qualcomm.sns.hal 1;
        setprop debug.qualcomm.sns.daemon 1;
        setprop debug.qualcomm.sns.libsensor1 1;
        `
      )
      const cek = await getProp("debug.qctwa.statusbar");
      if (cek == "0") {
        document.getElementById("log-ui").textContent += "\n OlixirSOC Status : Disabled Qualcomm Version";
        idSts1.textContent = "Off"
      }
    } else {
      document.getElementById("log-ui").textContent += `\n OlixirSOC Status : Already Disabled ${chipStatus} Version`;
      idSts1.textContent = "Off"
    }
  }
  loaderBlock.style.display = "none"
}

async function execSystemHwui(statusInit) {
  loaderBlock.style.display = "flex"
  const cekStatesBefore = await getProp("debug.hwui.use_gpu_pixel_buffers")
  if (statusInit !== "rmv") {
    if (cekStatesBefore !== "false") {
      await exec(
        `
        setprop debug.hwui.disable_draw_defer true
        setprop debug.hwui.disable_draw_reorder true
        setprop debug.hwui.render_dirty_regions false
        setprop debug.hwui.skip_empty_damage true
        setprop debug.hwui.disable_vsync true
        setprop debug.hwui.fps_divisor 1
        setprop debug.hwui.render_thread true
        setprop debug.hwui.render_thread_count 1
        setprop debug.hwui.use_gpu_pixel_buffers false
        setprop debug.hwui.use_buffer_age false
        `
      )
      const cekStates = await getProp("debug.hwui.use_gpu_pixel_buffers")
      if (cekStates == "false") {
        document.getElementById("log-ui").textContent += `\n HWUI Compotion Status : Activation Succesfuly`;
        idSts2.textContent = "On"
      }
    } else {
      document.getElementById("log-ui").textContent += `\n HWUI Compotion Status : Is Active`;
    }
  } else {
    if (cekStatesBefore !== "true") {
      await exec(
        `
        setprop debug.hwui.disable_draw_defer false
        setprop debug.hwui.disable_draw_reorder false
        setprop debug.hwui.render_dirty_regions true
        setprop debug.hwui.skip_empty_damage false
        setprop debug.hwui.disable_vsync false
        setprop debug.hwui.fps_divisor 0
        setprop debug.hwui.render_thread false
        setprop debug.hwui.render_thread_count 0
        setprop debug.hwui.use_gpu_pixel_buffers true
        setprop debug.hwui.use_buffer_age true
        `
      )
      const cekStates = await getProp("debug.hwui.use_gpu_pixel_buffers")
      if (cekStates == "true") {
        document.getElementById("log-ui").textContent += `\n HWUI Composition Status : Disabled Successfully`;
        idSts2.textContent = "Off"
      }
    } else {
      document.getElementById("log-ui").textContent += `\n HWUI Composition Status : Already Disabled`;
    }
  }
  loaderBlock.style.display = "none"
}

async function execSystemCpu(statusInit) {
  loaderBlock.style.display = "flex"
  let cekStatus = await getProp("debug.cpu_core_ctl_active");
  if (statusInit !== "rmv") {
    if (cekStatus !== "1") {
      await exec(
        `
          setprop debug.hwui.target_cpu_time_percent 100
          setprop debug.hwui.target_gpu_time_percent 100
          setprop debug.cpuprio 7
          setprop debug.gpuprio 7
          setprop debug.ioprio 7
          setprop debug.sf.gpu_freq_index 7
          setprop debug.sf.cpu_freq_index 7
          setprop debug.cpu_core_ctl_active 1
          setprop debug.cpu_core_ctl_busy_down_thres 35
          setprop debug.cpu_core_ctl_busy_up_thres 70
        `
      )
      cekStatus = await getProp("debug.cpu_core_ctl_active");
      if (cekStatus == "1") {
        document.getElementById("log-ui").textContent += `\n CPU Scheme Status : Activation Succesfuly`;
        idSts3.textContent = "On"
      }
    } else {
      document.getElementById("log-ui").textContent += `\n CPU Scheme Status : Is Active`;
    }
  } else {
    if (cekStatus !== "0") {
      await exec(
        `
          setprop debug.hwui.target_cpu_time_percent 0
          setprop debug.hwui.target_gpu_time_percent 0
          setprop debug.cpuprio 0
          setprop debug.gpuprio 0
          setprop debug.ioprio 0
          setprop debug.sf.gpu_freq_index 0
          setprop debug.sf.cpu_freq_index 0
          setprop debug.cpu_core_ctl_active 0
          setprop debug.cpu_core_ctl_busy_down_thres 0
          setprop debug.cpu_core_ctl_busy_up_thres 0
        `
      )
      cekStatus = await getProp("debug.cpu_core_ctl_active");
      if (cekStatus == "0") {
        document.getElementById("log-ui").textContent += `\n CPU Scheme Status : Disabled Successfully`;
        idSts3.textContent = "Off"
      }
    } else {
      document.getElementById("log-ui").textContent += `\n CPU Scheme Status : Already Disabled`;
    }
  }
  loaderBlock.style.display = "none"
}

async function execSystemSurface(statusInit) {
  loaderBlock.style.display = "flex";
  let getStatusActive = await getProp("debug.sf.kernel_idle_timer_update_overlay")
  if (statusInit !== "rmv") {
    if (getStatusActive !== "1") {
      await exec(
        `
        setprop debug.sf.hw 1
        setprop debug.egl.hw 1
        setprop debug.sf.hwc.min.duration 16129032
        setprop debug.sf.early.app.duration 3225806
        setprop debug.sf.late.app.duration 13440860
        setprop debug.sf.early.sf.duration 3225806
        setprop debug.sf.late.sf.duration 13440860
        setprop debug.sf.set_idle_timer_ms 816
        setprop debug.sf.earlyGl.sf.duration 14516532
        setprop debug.sf.earlyGl.app.duration 14516532
        setprop debug.sf.early_phase_offset_ns 3225806
        setprop debug.sf.early_gl_phase_offset_ns 3225806
        setprop debug.sf.early_app_phase_offset_ns 3225806
        setprop debug.sf.early_gl_app_phase_offset_ns 3225806
        setprop debug.sf.high_fps_early_app_phase_offset_ns -3225806
        setprop debug.sf.high_fps_late_app_phase_offset_ns 13440860
        setprop debug.sf.high_fps_early_sf_phase_offset_ns -3225806
        setprop debug.sf.high_fps_late_sf_phase_offset_ns 13440860
        setprop debug.sf.high_fps_early_gl_phase_offset_ns 3225806
        setprop debug.sf.high_fps_early_gl_app_phase_offset_ns 3225806
        setprop debug.sf.luma_sampling 0
        setprop debug.sf.enable_gl_backpressure 1
        setprop debug.sf.enable_transaction_tracing 0
        setprop debug.sf.disable_client_composition_cache 0
        setprop debug.sf.predict_hwc_composition_strategy 0
        setprop debug.sf.vsync_reactor_ignore_present_fences 0
        setprop debug.sf.use_phase_offsets_as_durations 1
        setprop debug.sf.kernel_idle_timer_update_overlay 1
        setprop debug.sf.cache_source_crop_only_moved false
        setprop debug.sf.disable_client_composition_cache 0
        setprop debug.sf.enable_layer_command_batching false
        setprop debug.sf.fp16_client_target false
        setprop debug.sf.hw 0
        setprop debug.sf.latch_unsignaled 0
        setprop debug.sf.auto_latch_unsignaled 1
        setprop debug.sf.multithreaded_present false
        setprop debug.sf.predict_hwc_composition_strategy 0
        setprop debug.sf.screenshot_fence_preservation false
        `  
      )
      getStatusActive = await getProp("debug.sf.kernel_idle_timer_update_overlay")
      console.log(getStatusActive)
      if (getStatusActive == "1") {
        document.getElementById("log-ui").textContent += `\n Surface Flinger Status : Activation Succesfuly`;
        idSts4.textContent = "On"
      }
    } else {
      document.getElementById("log-ui").textContent += `\n Surface Flinger Status : Already To Gamer`;
    }
  } else {
    if (getStatusActive !== "0") {
      await exec(
        `
        setprop debug.sf.hw 0
        setprop debug.egl.hw 0
        setprop debug.sf.hwc.min.duration 0
        setprop debug.sf.early.app.duration 0
        setprop debug.sf.late.app.duration 0
        setprop debug.sf.early.sf.duration 0
        setprop debug.sf.late.sf.duration 0
        setprop debug.sf.set_idle_timer_ms 0
        setprop debug.sf.earlyGl.sf.duration 0
        setprop debug.sf.earlyGl.app.duration 0
        setprop debug.sf.early_phase_offset_ns 0
        setprop debug.sf.early_gl_phase_offset_ns 0
        setprop debug.sf.early_app_phase_offset_ns 0
        setprop debug.sf.early_gl_app_phase_offset_ns 0
        setprop debug.sf.high_fps_early_app_phase_offset_ns 0
        setprop debug.sf.high_fps_late_app_phase_offset_ns 0
        setprop debug.sf.high_fps_early_sf_phase_offset_ns 0
        setprop debug.sf.high_fps_late_sf_phase_offset_ns 0
        setprop debug.sf.high_fps_early_gl_phase_offset_ns 0
        setprop debug.sf.high_fps_early_gl_app_phase_offset_ns 0
        setprop debug.sf.luma_sampling 1
        setprop debug.sf.enable_gl_backpressure 0
        setprop debug.sf.enable_transaction_tracing 1
        setprop debug.sf.disable_client_composition_cache 1
        setprop debug.sf.predict_hwc_composition_strategy 1
        setprop debug.sf.vsync_reactor_ignore_present_fences 1
        setprop debug.sf.use_phase_offsets_as_durations 0
        setprop debug.sf.kernel_idle_timer_update_overlay 0
        setprop debug.sf.cache_source_crop_only_moved true
        setprop debug.sf.disable_client_composition_cache 1
        setprop debug.sf.enable_layer_command_batching true
        setprop debug.sf.fp16_client_target true
        setprop debug.sf.hw 1
        setprop debug.sf.latch_unsignaled 1
        setprop debug.sf.auto_latch_unsignaled 0
        setprop debug.sf.multithreaded_present true
        setprop debug.sf.predict_hwc_composition_strategy 1
        setprop debug.sf.screenshot_fence_preservation true
        `  
      )
      getStatusActive = await getProp("debug.sf.kernel_idle_timer_update_overlay")
      if (getStatusActive == "0") {
        document.getElementById("log-ui").textContent += `\n Surface Flinger Status : Disabled Succesfuly`;
        idSts4.textContent = "Off"
      }
    } else {
      document.getElementById("log-ui").textContent += `\n Surface Flinger Status : Disabled Already`;
    }
  }
  loaderBlock.style.display = "none"
}

const testData1 = [["Vulkan", "vulkan"], ["Opengl", "opengl"], ["SkiaVk", "skiavk"]];

function selectionDec(selectConfirm, btnType, btnName, sts) {
  const appendElement= document.getElementById('panel-selection')
  let changeBefore = false
  let valueAfter = ""
  selectConfirm.forEach((d,i) => {
    const name = d[0];
    const value = d[1];
    const createBox = document.createElement('div')
    createBox.className = "box-selection";
    createBox.setAttribute(`select${btnType}`, value)
    createBox.innerHTML = `
      <p>${name}</p>
    `
    
    
    createBox.addEventListener('click', () => {
      setDataItem(btnName, `${name}`)
      sts.textContent = name;
      if (changeBefore) {
        if (valueAfter !== name) {
          document.getElementById("log-ui").textContent += `\n Change Value To : ${name}`;
          valueAfter = name;
          stateExecution = name;
          valueParams = value;
          console.log(valueParams)
        }
      } else {
        document.getElementById("log-ui").textContent += `\n Value Selection : ${name}`;
        changeBefore = !changeBefore;
        valueAfter = name;
        stateExecution = name;
        valueParams = value;
      }
    });
    appendElement.appendChild(createBox);
    // addEventListener('click', () => {
    //   console.log(`Hello ${value}`)
    // })
  })
}

async function execRender(type) {
  loaderBlock.style.display = "flex"
  let getIsActive = await getProp(`debug.hwui.renderer`)
  if (type !== getIsActive) {
    await exec(
      `
        setprop debug.hwui.renderer ${type}
      `  
    )
    getIsActive = await getProp(`debug.hwui.renderer`)
    if (getIsActive == type) {
      document.getElementById("log-ui").textContent += `\n Render Status : ${type} Running And Selected`;
    }
  } else {
    document.getElementById("log-ui").textContent += `\n Render Status : ${type} Is Running`;
  }
  loaderBlock.style.display = "none"
}

async function execRenderBackend(type) {
  loaderBlock.style.display = "flex"
  let getIsActive = await getProp(`debug.renderengine.backend`)
  if (type !== getIsActive) {
    await exec(
      `
        setprop debug.renderengine.backend ${type}
      `  
    )
    getIsActive = await getProp(`debug.renderengine.backend`)
    if (getIsActive == type) {
      document.getElementById("log-ui").textContent += `\n Render Backend Status : ${type} Running And Selected`;
    }
  } else {
    document.getElementById("log-ui").textContent += `\n Render Backend Status : ${type} Is Running`;
  }
  loaderBlock.style.display = "none"
}

async function execAnimationScale(velue) {
  loaderBlock.style.display = "flex"
  let getIsActive = await getSettings("global window_animation_scale");
  if (velue !== getIsActive) {
    await exec(
      `
        settings put global window_animation_scale ${velue}
        settings put global transition_animation_scale ${velue}
        settings put global animator_duration_scale ${velue}
      `  
    )
    getIsActive = await getSettings(`global window_animation_scale`)
    if (getIsActive == velue) {
      document.getElementById("log-ui").textContent += `\n Animation Scale Status : ${velue} Running And Selected`;
    }
  } else {
    document.getElementById("log-ui").textContent += `\n Animation Scale Status : ${velue} Is Running`;
  }
  loaderBlock.style.display = "none"
}

async function execRefreshRate(velue) {
  loaderBlock.style.display = "flex"
  let getIsActive = await getSettings("system max_refresh_rate");
  if (velue !== getIsActive) {
    await exec(
      `
        settings put system peak_refresh_rate ${velue}
        settings put system user_refresh_rate ${velue}
        settings put system max_refresh_rate ${velue}
        settings put system min_refresh_rate ${velue}
        settings put system thermal_limit_refresh_rate ${velue}
      `  
    )
    getIsActive = await getSettings(`system max_refresh_rate`)
    if (getIsActive == velue) {
      document.getElementById("log-ui").textContent += `\n Refresh Rate Status : ${velue} Running And Selected`;
    }
  } else {
    document.getElementById("log-ui").textContent += `\n Refresh Rate Status : ${velue} Is Running`;
  }
  loaderBlock.style.display = "none"
}

async function execGameFps(fpsValue) {
  loaderBlock.style.display = "flex"
  
  // Extract numeric value from string like "30 FPS"
  const numericFps = typeof fpsValue === 'string' ? fpsValue.split(' ')[0] : fpsValue;
  
  try {
    const config = buildConfig(numericFps);
    const commands = [];

    // device_config put loop for all game packages
    for(const pkg of GAME_PACKAGES){
      commands.push(`cmd device_config put game_overlay ${pkg} "${config}"`);
    }

    // setprop three debug refresh props
    commands.push(`setprop debug.refresh_rate.min_fps ${numericFps}`);
    commands.push(`setprop debug.refresh_rate.max_fps ${numericFps}`);
    commands.push(`setprop debug.refresh_rate.peak_fps ${numericFps}`);

    document.getElementById("log-ui").textContent += `\n Applying Game FPS ${numericFps} to ${GAME_PACKAGES.length} packages...`;
    
    // Execute all commands
    for(const cmd of commands){
      try{
        await exec(cmd + ' >/dev/null 2>&1');
      }catch(e){
        console.log(`Error executing: ${cmd}`, e);
      }
    }
    
    document.getElementById("log-ui").textContent += `\n Game FPS ${numericFps} applied successfully`;
    idSts9.textContent = `${numericFps} FPS`;
    
  } catch (error) {
    document.getElementById("log-ui").textContent += `\n Error applying Game FPS: ${error.message}`;
  } finally {
    loaderBlock.style.display = "none"
  }
}

async function execCacheCleaner(statusInit) {
  loaderBlock.style.display = "flex"
  
  if (statusInit !== "rmv") {
    // Enable cache cleaner
    try {
      // Kill any existing cache cleaner process
      try {
        await exec('pkill -f "cmd package trim-caches"');
      } catch (e) {
        // Ignore errors if process doesn't exist
      }
      
      // Start the cache cleaner in background using nohup to keep it running
      await exec('nohup sh -c "while true; do cmd package trim-caches 999G; sleep 3600; done" > /dev/null 2>&1 &');
      
      // Store the start time
      const startTime = Date.now();
      setDataItem("cacheCleanerStart", startTime.toString());
      setDataItem("cacheCleanerEnabled", "true");
      
      // Start timer display
      startCacheTimer();
      
      document.getElementById("log-ui").textContent += `\n Cache Cleaner Status : Activated (runs every hour)`;
      idSts10.textContent = "On";
      
      // Test the cache cleaner immediately
      try {
        await exec('cmd package trim-caches 999G');
        document.getElementById("log-ui").textContent += `\n Cache Cleaner Test : Cache cleared successfully`;
      } catch (testError) {
        document.getElementById("log-ui").textContent += `\n Cache Cleaner Test : ${testError.message}`;
      }
      
    } catch (error) {
      document.getElementById("log-ui").textContent += `\n Error activating Cache Cleaner: ${error.message}`;
      idSts10.textContent = "Error";
    }
  } else {
    // Disable cache cleaner
    try {
      await exec('pkill -f "cmd package trim-caches"');
      setDataItem("cacheCleanerEnabled", "false");
      
      // Clear intervals
      if (cacheTimerInterval) {
        clearInterval(cacheTimerInterval);
        cacheTimerInterval = null;
      }
      
      document.getElementById("log-ui").textContent += `\n Cache Cleaner Status : Disabled`;
      idSts10.textContent = "Off";
      idTimer10.textContent = "--:--:--";
      
    } catch (error) {
      document.getElementById("log-ui").textContent += `\n Error disabling Cache Cleaner: ${error.message}`;
    }
  }
  
  loaderBlock.style.display = "none"
}

// Game Driver Function
async function execGameDriver(value) {
  loaderBlock.style.display = "flex"
  try {
    await applyDriver(value);
    document.getElementById("log-ui").textContent += `\n Game Driver Status : ${value} applied successfully`;
    idSts11.textContent = value;
  } catch (error) {
    document.getElementById("log-ui").textContent += `\n Error applying Game Driver: ${error.message}`;
  } finally {
    loaderBlock.style.display = "none"
  }
}

// Network Enhancement Function
async function execNetEnh(statusInit) {
  loaderBlock.style.display = "flex"
  try {
    if (statusInit !== "rmv") {
      await applyNetEnh(true);
      document.getElementById("log-ui").textContent += `\n Network Enhancement Status : Activated (Cloudflare DNS)`;
      idSts12.textContent = "On";
    } else {
      await applyNetEnh(false);
      document.getElementById("log-ui").textContent += `\n Network Enhancement Status : Disabled`;
      idSts12.textContent = "Off";
    }
  } catch (error) {
    document.getElementById("log-ui").textContent += `\n Error applying Network Enhancement: ${error.message}`;
  } finally {
    loaderBlock.style.display = "none"
  }
}

// Helper function to get installed game packages
async function getInstalledGamePackages() {
  try {
    const { stdout } = await exec('pm list packages');
    const allPackages = stdout.split('\n').filter(pkg => pkg.startsWith('package:')).map(pkg => pkg.replace('package:', ''));
    
    // Filter to only include packages from our GAME_PACKAGES list that are actually installed
    const installedGamePackages = allPackages.filter(pkg => GAME_PACKAGES.includes(pkg));
    
    return installedGamePackages;
  } catch (e) {
    console.error("Failed to get installed packages:", e);
    return [];
  }
}

// Game Driver Application Function
async function applyDriver(value) {
    try {
        const uniquePkgs = await getInstalledGamePackages();
        if (uniquePkgs.length === 0) {
          document.getElementById("log-ui").textContent += `\n No game packages found to apply driver settings`;
          return;
        }
        const joinedPkgs = uniquePkgs.join(",");

        const androidVersion = parseInt(await getProp("ro.build.version.release")) || 12;
        
        // FIX: Corrected logic for driver properties based on Android version (12+ vs <12)
        const driverIn = androidVersion >= 12 ? "updatable_driver_production_opt_in_apps" : "game_driver_opt_in_apps";
        const driverOut = androidVersion >= 12 ? "updatable_driver_production_opt_out_apps" : "game_driver_opt_out_apps";

        let command = '';
        if (value === "Reset") {
            command = `
                settings delete global angle_gl_driver_selection_pkgs || true;
                settings delete global angle_gl_driver_selection_values || true;
                settings delete global ${driverIn} || true;
                settings delete global ${driverOut} || true;
            `;
        } else if (value === "AngleNative") {
            command = `
                settings put global angle_gl_driver_selection_pkgs "${joinedPkgs}" || true;
                settings put global angle_gl_driver_selection_values "native" || true;
                settings put global ${driverIn} "${joinedPkgs}" || true;
                settings put global ${driverOut} "1" || true;
            `;
        } else if (value === "GameDriver") {
            command = `
                settings delete global angle_gl_driver_selection_pkgs || true;
                settings delete global angle_gl_driver_selection_values || true;
                settings put global ${driverIn} "${joinedPkgs}" || true;
                settings put global ${driverOut} "1" || true;
            `;
        }
        
        if (command) {
          await exec(command);
          document.getElementById("log-ui").textContent += `\n Applied ${value} to ${uniquePkgs.length} installed game packages`;
        }
    } catch (e) {
        console.error("Failed to apply Driver settings:", e);
        throw e;
    }
}

// Network Enhancement Function
async function applyNetEnh(enabled) {
    const command = enabled ?
        `settings put global private_dns_mode hostname; settings put global private_dns_specifier 1dot1dot1dot1.cloudflare-dns.com` :
        `settings put global private_dns_specifier ""; settings put global private_dns_mode off`;
    await exec(command).catch(e => console.error("Failed to apply NetEnh settings:", e));
}

function startCacheTimer() {
  if (cacheTimerInterval) {
    clearInterval(cacheTimerInterval);
  }
  
  const startTime = parseInt(getDataItem("cacheCleanerStart") || Date.now());
  const nextCleanTime = startTime + 3600000; // 1 hour in milliseconds
  
  function updateTimer() {
    const now = Date.now();
    const timeLeft = nextCleanTime - now;
    
    if (timeLeft <= 0) {
      // Timer completed, reset for next hour
      const newStartTime = now;
      setDataItem("cacheCleanerStart", newStartTime.toString());
      startCacheTimer(); // Restart timer
      
      // Log that cache was cleaned
      document.getElementById("log-ui").textContent += `\n Cache Cleaner : Automatic cache cleaning completed`;
      return;
    }
    
    // Convert to hours, minutes, seconds
    const hours = Math.floor(timeLeft / (1000 * 60 * 60));
    const minutes = Math.floor((timeLeft % (1000 * 60 * 60)) / (1000 * 60));
    const seconds = Math.floor((timeLeft % (1000 * 60)) / 1000);
    
    // Format as HH:MM:SS
    const formattedTime = 
      `${hours.toString().padStart(2, '0')}:${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`;
    
    idTimer10.textContent = formattedTime;
  }
  
  // Update immediately and then every second
  updateTimer();
  cacheTimerInterval = setInterval(updateTimer, 1000);
}

const btn = document.getElementById("run-btn")
const btnDisable = document.getElementById("disable-btn")

btn.addEventListener("click", () => {
  console.log(stateExecution)
  document.getElementById("log-ui").textContent += "\n Running Proses";
  if (listSystem[stateExecution]) {
    listSystem[stateExecution](valueParams)
      .finally(() => {
        document.getElementById("log-ui").textContent += "\n Done All Proses Is Complite\n ";
        loaderBlock.style.display = "none"
      })
  } else {
    document.getElementById("log-ui").textContent += "\n Error: No function found for this selection";
    loaderBlock.style.display = "none"
  }
});

btnDisable.addEventListener("click", () => {
  console.log(stateExecution)
  document.getElementById("log-ui").textContent += "\n Running Proses";
  if (listSystem[stateExecution]) {
    listSystem[stateExecution]("rmv")
      .finally(() => {
        document.getElementById("log-ui").textContent += "\n Done All Proses Is Complite\n ";
        loaderBlock.style.display = "none"
      })
  } else {
    document.getElementById("log-ui").textContent += "\n Error: No function found for this selection";
    loaderBlock.style.display = "none"
  }
});


async function getLoadSystemModule() {
  try {
    loaderBlock.style.display = "flex"
    const cekBeforeRunMediatek = await getProp("debug.mediatek.appgamepq_compress");
    const cekBeforeRunQualcomm = await getProp('debug.qctwa.statusbar');
    const cekStatesBefore = await getProp("debug.hwui.use_gpu_pixel_buffers");
    const cekStatus = await getProp("debug.cpu_core_ctl_active");
    const getStatusActive = await getProp("debug.sf.kernel_idle_timer_update_overlay");
    const dataRender = getDataItem("renderBtn")
    const dataRenderB = getDataItem("renderBtnB")
    const dataFrame = getDataItem("frameRate")
    const dataScale = getDataItem("scaleAnim");
    const dataGameFps = getDataItem("gameFps");
    const dataGameDriver = getDataItem("gameDriver");
    
    // NEW: Cache Cleaner status
    const cacheCleanerEnabled = getDataItem("cacheCleanerEnabled");
    
    console.log(dataFrame)
    
    if (dataRender) {
      idSts5.textContent = dataRender
    }
    
    if (dataRenderB) {
      idSts6.textContent = dataRenderB
    }
    
    if (dataFrame) {
      idSts7.textContent = dataFrame
    }
    
    if (dataScale) {
      idSts8.textContent = dataScale
    }
  
    if (dataGameFps) {
      idSts9.textContent = dataGameFps
    }
    
    if (dataGameDriver) {
      idSts11.textContent = dataGameDriver
    }
    
    // NEW: Initialize cache cleaner status and timer
    if (cacheCleanerEnabled === "true") {
      idSts10.textContent = "On";
      startCacheTimer();
      
      // Verify the process is still running
      try {
        await exec('pgrep -f "cmd package trim-caches"');
        document.getElementById("log-ui").textContent += `\n Cache Cleaner : Background process is running`;
      } catch (e) {
        // Process not running, restart it
        document.getElementById("log-ui").textContent += `\n Cache Cleaner : Process not found, restarting...`;
        try {
          await exec('nohup sh -c "while true; do cmd package trim-caches 999G; sleep 3600; done" > /dev/null 2>&1 &');
          document.getElementById("log-ui").textContent += `\n Cache Cleaner : Restarted successfully`;
        } catch (restartError) {
          idSts10.textContent = "Off";
          setDataItem("cacheCleanerEnabled", "false");
          idTimer10.textContent = "--:--:--";
          document.getElementById("log-ui").textContent += `\n Cache Cleaner : Failed to restart`;
        }
      }
    } else {
      idSts10.textContent = "Off";
      idTimer10.textContent = "--:--:--";
    }
    
    // Check Network Enhancement status
    try {
      const dnsMode = await getSettings("global private_dns_mode");
      if (dnsMode === "hostname") {
        idSts12.textContent = "On";
      } else {
        idSts12.textContent = "Off";
      }
    } catch (e) {
      idSts12.textContent = "Off";
    }
    
    if (cekBeforeRunMediatek == "1" || cekBeforeRunQualcomm == "1") {
      idSts1.textContent = "On"
    } else {
      idSts1.textContent = "Off"
    }
    
    if (cekStatesBefore == "false") {
      idSts2.textContent = "On"
    } else {
      idSts2.textContent = "Off"
    }
    
    if (cekStatus == "1") {
      idSts3.textContent = "On"
    } else {
      idSts3.textContent = "Off"
    }
    
    if (getStatusActive == "1") {
      idSts4.textContent = "On"
    } else {
      idSts4.textContent = "Off"
    }
  } catch (e) {
    console.log(e)
  } finally {
    loaderBlock.style.display = "none"
  }
}

getLoadSystemModule();