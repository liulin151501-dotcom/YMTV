# =========================================== #
# Restore Code                                        #
# =========================================== #
cmd power set-fixed-performance-mode-enabled false
cmd power set-adaptive-power-saver-enabled true
cmd power set-mode 1

cmd thermalservice override-status reset

settings delete global power_check_max_cpu_1
settings delete global power_check_max_cpu_2
settings delete global power_check_max_cpu_3
settings delete global power_check_max_cpu_4

setprop debug.hwui.target_power_time_percent 0
setprop debug.hwui.trace_gpu_resources true
setprop debug.egl.force_msaa true
setprop debug.hwui.use_hint_manager 0
setprop debug.hwui.disable_vsync false
setprop debug.hwui.disable_scissor_opt false

setprop debug.performance.tuning 0
setprop debug.composition.type gpu

setprop debug.hwui.renderer opengl
setprop debug.renderengine.backend skiagl

setprop debug.cpurend.vsync true

settings put global zram_enabled 1

device_config delete interaction_jank_monitor enabled
device_config delete interaction_jank_monitor sampling_interval
device_config delete interaction_jank_monitor trace_threshold_frame_time_millis
device_config delete interaction_jank_monitor trace_threshold_missed_frames
device_config delete activity_manager disable_app_profiler_pss_profiling

cmd settings delete system air_motion_engine
cmd settings delete system master_motion
cmd settings delete system motion_engine

setprop debug.cluster_little-set_his_speed ""
setprop debug.cluster_big-set_his_speed ""
setprop debug.powehint.cluster_little-set_his_speed ""
setprop debug.powehint.cluster_big-set_his_speed ""

cmd activity clear-debug-app
cmd activity clear-exit-info

echo "系统已恢复为默认设置"