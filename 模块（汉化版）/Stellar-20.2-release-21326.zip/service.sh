#!/system/bin/sh

# Copyright (C) 2024-2025 Kanao
# Licensed under the Apache License, Version 2.0
# See http://www.apache.org/licenses/LICENSE-2.0

# Run MonPerf
while true; do
    if ! pgrep -x stellars; then
        stellars daemon
    else
        exit 0
    fi
    sleep 30
done