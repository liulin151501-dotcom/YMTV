#!/system/bin/sh

# Copyright (C) 2024-2025 Kanao
# Licensed under the Apache License, Version 2.0
# See http://www.apache.org/licenses/LICENSE-2.0

SKIPMOUNT=false
PROPFILE=true
POSTFSDATA=true
LATESTARTSERVICE=true

TOAST_PKG="bellavita.toast"
BASEDIR="/data/adb/.config/stellar"

ENVIRONMENT=""
ROOT_METHOD=""
USE_SKIPMOUNT=false
CHIPSET_ID=0

BINS="stellars vmtouch stellar_helper"

ui_print() {
    echo "- $1"
    sleep 0.1
}

abort_clean() {
    echo " "
    echo "******************************************** "
    echo "! ERROR: $1"
    echo "! Installation failed! $2" 
    echo "******************************************** "
    echo " "
    exit 1
}

set_perm_simple() {
    chown $2:$3 "$1" 2>/dev/null
    chmod $4 "$1" 2>/dev/null
}

set_perm_recursive() {
    chown -R $2:$3 "$1" 2>/dev/null
    find "$1" -type d -exec chmod $4 {} \; 2>/dev/null
    find "$1" -type f -exec chmod $5 {} \; 2>/dev/null
}

abort() {
    echo "! ABORT: $1"
    exit 1
}

safe_extract() {
    ui_print "Extracting $1..."
    unzip -qo "$ZIPFILE" "$1" -d "$2" || abort_clean "Failed to extract $1"
}

check_architecture() {
    local arch=""
    local bits=""

    arch="$(uname -m 2>/dev/null)"

    if [ -z "$arch" ]; then
        arch="$(getprop ro.product.cpu.abi 2>/dev/null)"
    fi

    if [ -z "$arch" ]; then
        arch="$(file /system/bin/sh 2>/dev/null | grep -oE 'aarch64|arm64|x86.64|armv[0-9]|i[3-6]86')"
    fi

    if [ -z "$arch" ]; then
        local elf_class
        elf_class="$(od -An -tx1 -j4 -N1 /system/bin/sh 2>/dev/null | tr -d ' \n')"
        case "$elf_class" in
            02) arch="elf64" ;;
            01) arch="elf32" ;;
        esac
    fi

    case "$arch" in
        aarch64|arm64|arm64-v8a|elf64)
            bits=64 ;;
        x86_64|x64|x86_64-linux-android)
            bits=64 ;;
        armv7*|armeabi-v7a|arm-*|armv6*|armv5*)
            bits=32 ;;
        i386|i486|i586|i686|x86|elf32)
            bits=32 ;;
        *)
            local ptr_test
            ptr_test="$(awk 'BEGIN{print length(sprintf("%d", 2^62))}' 2>/dev/null)"
            if [ "$ptr_test" -ge 19 ] 2>/dev/null; then
                bits=64
            else
                bits=32
            fi
            ;;
    esac

    if [ "$bits" = "32" ]; then
        abort_clean "32-bit architecture is not supported" "Device arch: $arch — Only 64-bit devices are supported"
    fi

    ui_print "Architecture: $arch (${bits}-bit) — OK"
}

remove_config() {
    rm -rf /data/adb/.config/stellar
    rm -rf /data/user_de/0/com.android.shell/axeron/plugins/stellar/.config
    ui_print "Clean up config folders"
}

detect_environment() {
    ui_print "Detecting device environment..."
    
    if [ "$AXERON" = "true" ]; then
        ENVIRONMENT="AXERON"
        BASEDIR="/data/user_de/0/com.android.shell/axeron/plugins/stellar/.config"
        USE_SKIPMOUNT=true
        ui_print "Unrooted environment detected"
        return
    fi
    
    if [ "$(id | grep -c root)" -gt 0 ]; then
        if [ -d "/data/adb/ksu" ]; then
            ENVIRONMENT="KSU"
            USE_SKIPMOUNT=true
            ui_print "KernelSU detected"
            return
        fi
        
        if [ -d "/data/adb/ap" ]; then
            ENVIRONMENT="APATCH"
            USE_SKIPMOUNT=true
            ui_print "Apatch detected"
            return
        fi
        
        ENVIRONMENT="OTHER"
        ui_print "Root environment detected"
        return
    fi
    
    abort_clean "No environment detected" "Ensure you have one"
}

apply_skipmount() {
    if $USE_SKIPMOUNT; then
        ui_print "Applying some rules for $ENVIRONMENT"
        touch "$MODPATH/skip_mount"
        [ -f "$MODPATH/action.sh" ] && rm "$MODPATH/action.sh" && ui_print "Removed action.sh"
    fi
}

install_toast_apk() {
    ui_print "Installing Bellavita Toast"
    pm uninstall bellavita.toast >/dev/null 2>&1
    [ -f "$MODPATH/toast.apk" ] && pm install -r "$MODPATH/toast.apk" >/dev/null && ui_print "Toast APK installed" || ui_print "Warning: toast.apk not found"
}

setup_directories_and_configs() {
    ui_print "Setting up default directories..."
    mkdir -p "$BASEDIR" || abort_clean "Failed to create directory"
    chmod 777 "$BASEDIR"
    touch "$BASEDIR/lock" || abort_clean "Failed to create lock"
    touch "$BASEDIR/soc" || abort_clean "Failed to create soc"
    cp "$MODPATH/gamelist.toml" "$BASEDIR/gamelist.toml"
    cp "$MODPATH/config.json" "$BASEDIR/config.json"
    chmod 666 "$BASEDIR/"*
}

identify_chipset() {
    ui_print "Identifying chipset users..."
    
    [ -d /sys/kernel/ged/hal ] && CHIPSET_ID=1
    [ -d /sys/class/kgsl/kgsl-3d0/devfreq ] || [ -d /sys/devices/platform/kgsl-2d0.0/kgsl ] && CHIPSET_ID=2
    [ -d /sys/kernel/tegra_gpu ] && CHIPSET_ID=7
    
    if [ $CHIPSET_ID -eq 0 ]; then
        local SOC_INFO="$(getprop ro.board.platform 2>/dev/null) $(getprop ro.soc.model 2>/dev/null) $(getprop ro.hardware 2>/dev/null)"
        
        case "$SOC_INFO" in
            *mt*|*MT*) CHIPSET_ID=1 ;;
            *sm*|*qcom*|*SM*|*QCOM*|*Qualcomm*) CHIPSET_ID=2 ;;
            *exynos*|*Exynos*|*EXYNOS*) CHIPSET_ID=3 ;;
            *unisoc*|*UNISOC*|*ums*) CHIPSET_ID=4 ;;
            *tensor*|*Tensor*|*gs*) CHIPSET_ID=5 ;;
            *intel*|*Intel*) CHIPSET_ID=6 ;;
            *kirin*|*Kirin*) CHIPSET_ID=8 ;;
        esac
    fi
    
    case "$CHIPSET_ID" in
        1) ui_print "Detected as MediaTek" ;;
        2) ui_print "Detected as Snapdragon" ;;
        3) ui_print "Detected as Exynos" ;;
        4) ui_print "Detected as Unisoc" ;;
        5) ui_print "Detected as Google Tensor" ;;
        6) ui_print "Detected as Intel" ;;
        7) ui_print "Detected as Nvidia Tegra" ;;
        8) ui_print "Detected as Kirin" ;;
        *) ui_print "Suggesting for Universal (SoC Undetected)" ;;
    esac
    
    echo "$CHIPSET_ID" > "$BASEDIR/soc"
    ui_print "Saved id SoC for $CHIPSET_ID'"
}

copy_binaries() {
    ui_print "Moving binaries stellar to custom dir..."
    
    local SRC_BIN="$MODPATH/system/bin"
    local DEST_BIN=""
    
    case $ENVIRONMENT in
        "AXERON") DEST_BIN="/data/user_de/0/com.android.shell/axeron/bin" ;;
        "KSU") DEST_BIN="/data/adb/ksu/bin" ;;
        "APATCH") DEST_BIN="/data/adb/ap/bin" ;;
        "OTHER") return ;;
    esac
    
    if [ -n "$DEST_BIN" ] && [ -d "$SRC_BIN" ]; then
        mkdir -p "$DEST_BIN"
        for bin in $BINS; do
            [ -f "$SRC_BIN/$bin" ] && rm -f "$DEST_BIN/$bin"
            cp "$SRC_BIN/$bin" "$DEST_BIN/$bin" 
            chmod 777 "$DEST_BIN/$bin"
            ui_print "Moving Binary to: $bin >> $DEST_BIN" || ui_print "Warning: $bin not found"
        done
    else
        ui_print "Warning: Base binaries directory not found"
    fi
}

set_permissions() {
    ui_print "Setting all permissions for bin..."
    
    [ -d "$MODPATH" ] && set_perm_recursive "$MODPATH" 0 0 0755 0644
    [ -d "$MODPATH/system/bin" ] && set_perm_recursive "$MODPATH/system/bin" 0 2000 0755 0755
}

finalize_installation() {
    case $((RANDOM % 9 + 1)) in
        1) ui_print "Stars orbit until they die." ;;
        2) ui_print "Still Stellar-Stellar?" ;;
        3) ui_print "Against The Law, Dont Soft." ;;
        4) ui_print "Dead Stars, Exploding, Lost, Forgotten." ;;
        5) ui_print "Feed Me Donate Wen." ;;
        6) ui_print "Try Be Honest, May Can Safe You (?)" ;;
        7) ui_print "Anyone Would Seen This?!" ;;
        8) ui_print "Save the world? Save the cat!" ;;
        9) ui_print "The glitches that never saw again." ;;
    esac
    
    ui_print "Join our channel for keep updated!"
}

check_architecture
detect_environment
remove_config
apply_skipmount
install_toast_apk
setup_directories_and_configs
identify_chipset
copy_binaries
set_permissions
finalize_installation
