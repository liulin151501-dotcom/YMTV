#!/system/bin/sh

c(){ /system/bin/cmd "$@"; }
ca(){ /system/bin/cmd activity "$@"; }

# 顶级应用调度配置文件（用于提升前台应用关键线程优先级）
TOP_PROFILES="SCHED_SP_TOP_APP CPUSET_SP_TOP_APP"

# 状态文件路径（记录已提升优先级的线程ID）
STATE="/data/local/tmp/core/boosted.tids"
# 创建状态文件目录
mkdir -p /data/local/tmp/core

# 等待SystemUI启动（系统界面就绪后再执行后续操作）
while ! pidof com.android.systemui >/dev/null; do sleep 2; done

# 主循环（无限循环）
while :; do
  # 获取当前前台应用包名（通过activity stack list提取）
  fg=$(ca stack list | awk -F'[/{]' '/0,.*true/{print $3; exit}')
  # 若未获取到前台应用，休眠30秒后重试
  [ -z "$fg" ] && sleep 30 && continue

  # 遍历前台应用的所有进程ID
  for pid in $(pidof "$fg"); do
    # 检查进程任务目录是否存在（避免无效进程）
    [ -d "/proc/$pid/task" ] || continue

    # 遍历进程下的所有线程（每个线程对应/proc/$pid/task/$tid）
    for t in /proc/$pid/task/*; do
      # 提取线程ID（tid）
      tid=${t##*/}

      # 若线程ID已在状态文件中，跳过（避免重复提升）
      grep -qx "$tid" "$STATE" && continue

      # 读取线程名称（来自/proc/$tid/comm）
      name=$(cat "$t/comm")
      # 匹配关键线程名称（main：主线程；RenderThread：渲染线程）
      case "$name" in
        main|RenderThread)
          # 设置线程调度配置文件（提升优先级）
          settaskprofile "$tid" $TOP_PROFILES
          # 将线程ID写入状态文件（标记为已提升）
          echo "$tid" >> "$STATE"
          ;;
      esac
    done
  done

  # 循环间隔：休眠30秒
  sleep 30
done
