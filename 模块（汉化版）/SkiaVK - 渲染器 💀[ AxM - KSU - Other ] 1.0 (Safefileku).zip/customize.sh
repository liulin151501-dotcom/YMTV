#!/system/bin/sh
logcat -G 128K &>/dev/null

# 函数：以更清晰的格式打印
print_line() {
    ui_print "***************************************"
}

.# 磁盘分区整理
trim_partition () {
    for partition in system vendor data cache metadata odm system_ext product;do sm fstrim "/$partition";done>/dev/null 2>&1 &
    sleep 3
}

ANDROIDVERSION=$(getprop ro.build.version.release)
DEVICES=$(getprop ro.product.board)
MANUFACTURER=$(getprop ro.product.manufacturer)
API=$(getprop ro.build.version.sdk)
NAME="SkiaVK-渲染器 | Kzyo"
VERSION="1.0 | 个人版"
DATE=$(date)

printf "░█▀▀▀█ ░█─▄▀ ▀█▀ ─█▀▀█ ░█──░█ ░█─▄▀ ── ░█▀▀█ 
─▀▀▀▄▄ ░█▀▄─ ░█─ ░█▄▄█ ─░█░█─ ░█▀▄─ ▀▀ ░█▄▄▀ 
░█▄▄▄█ ░█─░█ ▄█▄ ░█─░█ ──▀▄▀─ ░█─░█ ── ░█─░█"
ui_print ""
sleep 0.5
printf "调整渲染设置以实现更流畅的性能表现。"
sleep 0.2
ui_print ""
print_line
printf "- 模块名称        : ${NAME}"
sleep 0.2
printf "- 版本            : ${VERSION}"
sleep 0.2
printf "- Android 版本    : ${ANDROIDVERSION:-未知}"
sleep 0.2
printf "- 当前日期        : ${DATE}"
sleep 0.2
print_line
printf "- 设备型号        : ${DEVICES:-未知}"
sleep 0.2
printf "- 制造商          : ${MANUFACTURER:-未知}"
sleep 0.2
print_line
printf "- 正在整理磁盘分区"
trim_partition &>/dev/null
printf "- 正在清理缓存和垃圾文件"
delete_trash_logs &>/dev/null
sleep 2

# 设置权限
set_perm_recursive $MODPATH 0 0 0755 0644
set_perm_recursive $MODPATH/system/bin 0 0 0755 0755

# 刷机模块完成或达到峰值性能
logcat -c &>/dev/null