#!/system/bin/sh
#
# SkiaVK-渲染器 由 kazuyoo 开发
# 基于开源力量——感谢 AOSP、Google 图形团队及所有贡献者。
# 遵循 MIT 许可证发布。
#
# 为 Android 渲染引擎启用 Skia Vulkan（SkiaVK）渲染后端，
# 以提供更流畅的动画、减少卡顿，并提升 GPU 效率。
# SkiaVK 利用 Vulkan 的低开销图形管线、异步命令队列
# 和先进的内存管理，以实现更快的 UI 合成与帧渲染。
#
# 为日常使用和游戏场景优化——在保持性能平衡的同时，
# 提供更好的温控表现和稳定的帧节奏，避免不必要的 GPU 负担。

# ----------------- 辅助函数 -----------------
send_notification() {
    # 通知用户优化已完成
    cmd notification post -S bigtext -t 'SkiaVK-渲染器 💀' 'tag' '状态：优化已完成！' >/dev/null 2>&1
}

# ----------------- 优化部分 -----------------
  setprop debug.hwui.renderer skiavk
  setprop debug.renderengine.backend skiavkthreaded
  setprop debug.renderengine.capture_skia_ms 0
  setprop debug.renderengine.skia_atrace_enabled false
  setprop debug.renderengine.skia_tracing_enabled false
  setprop debug.renderengine.skia_use_perfetto_track_events false
  setprop debug.hwui.skia_use_perfetto_track_events false
  setprop debug.hwui.skia_tracing_enabled false
  setprop debug.tracing.ctl.hwui.skia_tracing_enabled false
  setprop debug.tracing.ctl.hwui.skia_use_perfetto_track_events false
  setprop debug.tracing.ctl.renderengine.skia_tracing_enabled false
  setprop debug.tracing.ctl.renderengine.skia_use_perfetto_track_events false  
  

# 主执行流程并成功退出脚本
 sync;send_notification