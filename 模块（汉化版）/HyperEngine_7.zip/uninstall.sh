
#!/system/bin/sh
echo "Removendo Hyper Engine Extreme..."
settings delete global low_power
setprop debug.performance.tuning 0
echo "Removido."
