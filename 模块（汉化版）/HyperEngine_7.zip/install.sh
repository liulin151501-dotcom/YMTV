#!/system/bin/sh

MODDIR=${0%/*}

clear
echo "================================="
echo "        HYPER ENGINE 7"
echo "             v1.0"
echo "           by M.Joker"
echo "================================="

sleep 1
echo "Instalando engine..."
sleep 1

echo "Aplicando permissões..."

chmod -R 755 $MODDIR 2>/dev/null
chmod 755 $MODDIR/*.sh 2>/dev/null
chmod 755 $MODDIR/scripts/*.sh 2>/dev/null

chown -R root:root $MODDIR 2>/dev/null

sleep 1
echo "Configurando scripts..."
sleep 1

echo "Permissões aplicadas com sucesso."
echo "Hyper Engine instalado com sucesso."
