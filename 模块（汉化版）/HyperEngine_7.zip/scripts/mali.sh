
#!/system/bin/sh

setprop debug.hwui.renderer opengl
setprop debug.egl.swapinterval 0
