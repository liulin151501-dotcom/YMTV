
#!/system/bin/sh

for thermal in /sys/class/thermal/thermal_zone*/mode
do
echo disabled > $thermal
done
