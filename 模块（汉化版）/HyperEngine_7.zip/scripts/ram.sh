
#!/system/bin/sh

FREE=$(cat /proc/meminfo | grep MemAvailable | awk '{print $2}')

if [ "$FREE" -lt 500000 ]
then
sync
echo 3 > /proc/sys/vm/drop_caches
fi

echo 10 > /proc/sys/vm/swappiness
