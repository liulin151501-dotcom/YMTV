
#!/system/bin/sh

GPU=$(getprop ro.hardware.egl)

if echo "$GPU" | grep -i mali
then
sh /data/adb/modules/HyperEngineExtreme/scripts/mali.sh
fi

if echo "$GPU" | grep -i adreno
then
sh /data/adb/modules/HyperEngineExtreme/scripts/adreno.sh
fi
