
#!/system/bin/sh

setprop debug.hwui.renderer opengl
setprop debug.egl.force_msaa 1
