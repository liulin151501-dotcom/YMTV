
#!/system/bin/sh

setprop debug.sf.enable_gl_backpressure 1
setprop debug.sf.latch_unsignaled 1
setprop debug.sf.use_phase_offsets_as_durations 1
