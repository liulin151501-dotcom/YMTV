
#!/system/bin/sh

for cpu in /sys/devices/system/cpu/cpu*/online
do
echo 1 > $cpu
done

for gov in /sys/devices/system/cpu/cpu*/cpufreq/scaling_governor
do
echo performance > $gov
done
