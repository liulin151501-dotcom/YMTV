
#!/system/bin/sh

# Base graphics tweaks
setprop debug.hwui.renderer opengl
setprop debug.hwui.use_buffer_age true
setprop debug.hwui.render_dirty_regions false
setprop debug.hwui.target_cpu_time_percent 60
setprop debug.hwui.target_gpu_time_percent 70

# SurfaceFlinger
setprop debug.sf.hw 1
setprop debug.sf.enable_gl_backpressure 1
