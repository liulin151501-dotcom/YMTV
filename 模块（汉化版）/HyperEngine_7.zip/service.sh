#!/system/bin/sh

MODDIR=${0%/*}

# Permissões
chmod -R 755 $MODDIR 2>/dev/null
chown -R root:root $MODDIR 2>/dev/null

GAME_ACTIVE=0

while true
do

APP=$(dumpsys window | grep -E 'mCurrentFocus')

if echo "$APP" | grep -iqE "genshin|pubg|callofduty|fortnite|game"
then

if [ "$GAME_ACTIVE" = "0" ]; then

sh $MODDIR/scripts/cpu.sh
sh $MODDIR/scripts/gpu_detect.sh
sh $MODDIR/scripts/ram.sh
sh $MODDIR/scripts/fps_engine.sh
sh $MODDIR/scripts/io_boost.sh

cmd notification post -S bigtext -t "Hyper Engine" hyperengine "Game Turbo Ativado"

GAME_ACTIVE=1

fi

else
GAME_ACTIVE=0
fi

sleep 5
done
do"

fi

sleep 5
done

