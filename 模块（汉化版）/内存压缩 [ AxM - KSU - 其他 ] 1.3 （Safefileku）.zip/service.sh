#!/system/bin/sh
#
# 天界优先级UFW 由 Kazuyoo 开发
# 感谢 @reljawa 提供帮助
# 基于开源技术 — 致谢 GL-DP 及所有贡献者
# 遵循 MIT 许可证授权
#
# 基于UFW的Android动态进程优先级管理
# 自动调整系统和游戏进程的调度器和I/O加速
# 实现更流畅的性能、更低延迟和更好的资源平衡
# 无需额外开销。包含游戏的自适应预加载处理。
#

# ----------------- 辅助函数 -----------------
wait_until_boot_completed() {
    # 等待系统启动完成
    while [ "$(getprop sys.boot_completed)" != "1" ]; do
        sleep 2
    done

    # 等待存储挂载
    until [ -d "/sdcard/Android" ] || [ -d "/storage/emulated/0/Android" ]; do
        sleep 1
    done
}
  
send_notification() {
    # 通知用户优化完成
    if command -v su >/dev/null 2>&1; then
        su -lp 2000 -c "cmd notification post -S bigtext -t '内存压缩' tag '状态：优化已完成！'" >/dev/null 2>&1
    else
        cmd notification post -S bigtext -t '内存压缩' 'tag' '状态：优化已完成！' >/dev/null 2>&1
    fi
}
wait_until_boot_completed

# 主程序执行
RC;sleep 1;for y in $(pgrep -f RC); do renice -n 19 "$y";chrt -i -p 0 "$y";ionice -c 3 -n 7 -p "$y";done;send_notification;exit 0
