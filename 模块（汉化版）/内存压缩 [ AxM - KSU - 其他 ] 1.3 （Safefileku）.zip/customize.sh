#!/system/bin/sh
logcat -G 128K &>/dev/null

# === 打印函数选择 ===
if [ "$AXERON" == "true" ]; then
    PRINT="printf"
else
    PRINT="ui_print"
fi

# === 打印函数包装器 ===
print_msg() {
    case "$PRINT" in
        ui_print) ui_print "$1" ;;
        printf)   printf "$1" ;;
    esac
}

# === 分割线 ===
print_line() {
    ui_print "***************************************"
}

# === 修剪分区 ===
trim_partition() {
    if [ "$(id -u)" -eq 0 ]; then
        for partition in system vendor data cache metadata odm system_ext product; do
            fstrim -v "/$partition"
        done >/dev/null 2>&1 &
    else
        for partition in system vendor data cache metadata odm system_ext product; do
            sm fstrim "/$partition"
        done >/dev/null 2>&1 &
    fi
    sleep 3
}

# === 删除垃圾文件与日志 ===
delete_trash_logs() {
    # 清理 /data/data 中的垃圾文件
    for DIR in /data/data/*; do
        if [ -d "${DIR}" ]; then
            rm -rf "${DIR}/cache/"*
            rm -rf "${DIR}/no_backup/"*
            rm -rf "${DIR}/app_webview/"*
            rm -rf "${DIR}/code_cache/"*
        fi
    done

    # 来自 Taka 的缓存清理
    find /data/data/*/cache/* -delete &>/dev/null
    find /data/data/*/code_cache/* -delete &>/dev/null
    find /data/user_de/*/*/cache/* -delete &>/dev/null
    find /data/user_de/*/*/code_cache/* -delete &>/dev/null
    find /sdcard/Android/data/*/cache/* -delete &>/dev/null
}

# === 检查 compact 功能是否可用 ===
if ! cmd activity | grep -q "compact" 2>/dev/null; then
    echo "    [错误]: 此设备未找到 'cmd activity compact'。"
    echo "⚠️  该功能仅在"
    echo "    搭载 Android 13+ 或特定厂商框架的设备上可用。"
    rm -rf "$MODPATH"
    exit 1
fi

# === 设备信息 ===
ANDROIDVERSION=$(getprop ro.build.version.release)
DEVICES=$(getprop ro.product.board)
MANUFACTURER=$(getprop ro.product.manufacturer)
API=$(getprop ro.build.version.sdk)
NAME="Ram-Compaction | Kzyo"
VERSION="1.3 | Forceful"
DATE=$(date)

# === 显示横幅 ===
print_msg "░█▀▀█ ── ░█▀▀█ ░█▀▄▀█ ░█▀▀█ ▀▀█▀▀ 
░█▄▄▀ ▀▀ ░█─── ░█░█░█ ░█▄▄█ ─░█── 
░█─░█ ── ░█▄▄█ ░█──░█ ░█─── ─░█──"
ui_print ""
sleep 0.5
print_msg "         减少内存占用。"
sleep 0.2
ui_print ""
print_line
print_msg "- 名称            : ${NAME}"
sleep 0.2
print_msg "- 版本            : ${VERSION}"
sleep 0.2
print_msg "- Android 版本    : ${ANDROIDVERSION:-未知}"
sleep 0.2
print_msg "- 当前日期        : ${DATE}"
sleep 0.2
print_line
print_msg "- 设备代号        : ${DEVICES:-未知}"
sleep 0.2
print_msg "- 制造商          : ${MANUFACTURER:-未知}"
sleep 0.2
print_line
print_msg "- 正在整理分区"
trim_partition &>/dev/null
print_msg "- 正在删除缓存与垃圾文件"
delete_trash_logs &>/dev/null
sleep 2

# === 设置权限 ===
if [ "$AXERON" == "true" ]; then
    yes=yes
else
    ui_print "- 正在设置权限"
    set_perm_recursive $MODPATH 0 0 0755 0755
fi

# === 清理 ===
logcat -c &>/dev/null
