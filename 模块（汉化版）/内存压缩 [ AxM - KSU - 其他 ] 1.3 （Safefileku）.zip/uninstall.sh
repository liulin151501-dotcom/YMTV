# Don't modify anything after this
pkill -f RC;pkill -f RC