# ====== 检查 service.sh 是否正在运行 ======
check_service_status() {
    if pgrep RC &>/dev/null; then
        echo "[运行中] PID : $(pgrep RC) | 服务已在运行。"
        return 0
    else
        echo "[未运行] 服务未在运行。"
        return 1
    fi
}

# ====== 使用示例 ======
check_service_status
if [ $? -ne 0 ]; then
    echo "[启动中] 正在启动服务..."
    nohup sh -c "RC"
    echo "[运行中] PID : $(pgrep RC)"
    echo "服务已在运行。"
else
    echo "[已跳过] 服务已在运行，无需重启。"
fi
