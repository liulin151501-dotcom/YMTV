#!/system/bin/sh
exec>/dev/null 2>&1
while true;do sleep 1
  if ! pidof axeron_server;then
    $AXERONLIB/libaxeron.so
    cmd activity force-stop com.frb.axmanager
  fi
done