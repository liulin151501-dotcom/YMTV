#!/system/bin/sh
echo "[BatteryOptimizer] post-fs-data 已执行。"
