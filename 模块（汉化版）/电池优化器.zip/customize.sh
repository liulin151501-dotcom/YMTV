#!/system/bin/sh
echo "请选择电池优化模式："
echo "1) 均衡模式"
echo "2) 激进模式"
read -p "请输入选择 [1/2]: " choice

if [ "$choice" = "1" ]; then
  echo "aggressive" > /data/adb/modules/battery_optimizer/mode.conf
  echo "[BatteryOptimizer] 已设置为激进模式"
else
  echo "balance" > /data/adb/modules/battery_optimizer/mode.conf
  echo "[BatteryOptimizer] 已设置为均衡模式"
fi
