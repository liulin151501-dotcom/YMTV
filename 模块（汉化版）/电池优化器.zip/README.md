# Battery Optimizer 模块 (Shizuku) v1.2

## 模式说明
- 均衡模式：标准省电，使用仍保持舒适。
- 激进模式：最大限省电，同步与定位功能限制更严格。

## 使用方法
1. 确保 Shizuku 已激活。
2. 通过 AxManager 安装模块。
3. 执行 customize.sh 来选择模式。
4. 重启 AxManager 服务。
