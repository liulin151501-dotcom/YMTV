#!/system/bin/sh
# Battery Optimizer (AxManager + Shizuku) v1.2

mode=$(cat /data/adb/modules/battery_optimizer/mode.conf 2>/dev/null || echo "balance")

if [ "$mode" = "aggressive" ]; then
  # Aggressive tweaks
  cmd deviceidle force-idle
  settings put global sync_max_retry_delay_in_seconds 7200
  settings put global sync_min_gather_delay_in_seconds 1800
  settings put global wifi_scan_always_enabled 0
  settings put secure location_mode 0
  echo "[BatteryOptimizer] 已应用激进模式优化。"
else
  # Balance tweaks
  settings put global sync_max_retry_delay_in_seconds 3600
  settings put global sync_min_gather_delay_in_seconds 600
  settings put global wifi_scan_always_enabled 0
  settings put secure location_mode 1
  echo "[BatteryOptimizer] 已应用均衡模式优化。"
fi
