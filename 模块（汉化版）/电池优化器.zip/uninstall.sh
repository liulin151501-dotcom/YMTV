#!/system/bin/sh
rm -f /data/adb/modules/battery_optimizer/mode.conf

settings delete global sync_max_retry_delay_in_seconds
settings delete global sync_min_gather_delay_in_seconds
settings put global wifi_scan_always_enabled 1
settings put secure location_mode 3

echo "[BatteryOptimizer] 模块已卸载并恢复默认设置。"