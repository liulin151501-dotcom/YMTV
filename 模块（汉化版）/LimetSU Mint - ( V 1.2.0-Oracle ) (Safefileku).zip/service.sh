MODDIR=${0%/*}
game=$(dumpsys game | grep -oE 'Name:[^ ]+|package [^ ]+' | sed 's/Name://;s/package //')
package_list=$(cmd package list packages | cut -d ":" -f2)
current=""

VERSION="$(getprop ro.build.version.release)"
GAME_LIST=$(dumpsys game | grep -oE 'Name:[^ ]+|package [^ ]+' | sed 's/Name://;s/package //')
if [ "$VERSION" -ge 12 ]; then
    echo "$GAME_LIST" > /data/local/tmp/game.txt
else
    cp -f "$MODDIR/gamelist.txt" /data/local/tmp/game.txt
fi

mv "$MODDIR/system/path" /data/local/tmp
chmod 777 /data/local/tmp/path/limet_loop
chmod 777 /data/local/tmp/path/celestial_loop

# 产品版本
settings put global limetsu_product_name CGGHFG

# 由 Kzyoo 编写
# 来源 Celestial-Game-Opt [ AxM, KSU, Other ] 2.6-WebUI
  if [ "$(getprop ro.build.version.release)" -ge 14 ]; then
  # 图形与帧率 (SurfaceFlinger)
    cmd device_config override core_graphics com.android.graphics.surfaceflinger.flags.graphite_renderengine true
    cmd device_config override core_graphics com.android.graphics.surfaceflinger.flags.multithreaded_present true
    cmd device_config override core_graphics com.android.graphics.surfaceflinger.flags.enable_layer_command_batching true
    cmd display set-user-disabled-hdr-types 1 2 3 4
  service call SurfaceFlinger 1008 i32 0 &>/dev/null

  # ADPF (仅限 Android 14+)
    cmd device_config override game android.os.adpf_hwui_gpu true
    cmd device_config override game android.os.adpf_prefer_power_efficiency false
  fi

# 限制所有 Google 应用包
for a in $(cmd package list packages google|cut -f2 -d:|grep -v ia.mo);do
  cmd appops reset "$a"
  cmd appops set "$a" FOREGROUND_SERVICE_SPECIAL_USE ignore
  cmd appops set "$a" INSTANT_APP_START_FOREGROUND ignore
  cmd appops set "$a" RUN_ANY_IN_BACKGROUND ignore
  cmd appops set "$a" RUN_IN_BACKGROUND ignore
  cmd package revoke --all-permissions "$a"
done
cmd package grant com.google.android.gms android.permission.READ_CONTACTS
cmd package grant com.google.android.gms android.permission.WRITE_CONTACTS

# 释放所有进程占用的内存
for a in $(ps -eo PID,USER|grep u0_|cut -f1 -du);do
  cmd activity profile stop "$a"
  cmd activity set-watch-heap "$a" 0
done

# 禁用日志
  cmd stats clear-puller-cache
  cmd activity clear-debug-app
  cmd activity clear-watch-heap -a
  cmd stats print-logs 0
  cmd display ab-logging-disable
  cmd display dwb-logging-disable
  cmd display dmd-logging-disable
  cmd looper_stats disable
  simpleperf --log fatal --log-to-android-buffer 0
  cmd settings put global activity_starts_logging_enabled 0
  cmd settings put global kernel_cpu_thread_reader num_buckets=0,collected_uids=,minimum_total_cpu_usage_millis=999999999
  cmd device_config put runtime_native_boot disable_lock_profiling true
  cmd device_config put runtime_native_boot iorap_readahead_enable true
  cmd device_config put interaction_jank_monitor enabled false
  cmd device_config put interaction_jank_monitor debug_overlay_enabled false
  # 禁用来自 CMD-Lite (@HoyoSlave) 的跟踪和日志
  cmd accessibility stop-trace
  cmd migard dump-trace false
  cmd migard start-trace false
  cmd migard stop-trace true
  cmd migard trace-buffer-size 0
  cmd input_method tracing stop
  cmd window tracing size 0
  cmd window tracing stop
  cmd autofill set log_level off
  cmd miui_step_counter_service logging-disable
  cmd voiceinteraction set-debug-hotword-logging false
  cmd wifi set-verbose-logging disabled -l 0
  cmd window logging disable
  cmd window logging disable-text
  cmd window logging stop

# 系统垃圾清理
for a in $(cmd package list packages -s|cut -f2 -d:);do
  rm -rf "/sdcard/Android/data/$a"
  rm -rf "/sdcard/Android/media/$a"
  rm -rf "/sdcard/Android/obb/$a"
done
cmd activity clear-debug-app
cmd activity clear-exit-info
cmd activity clear-watch-heap all
cmd blob_store clear-all-blobs
cmd blob_store clear-all-sessions
cmd companiondevice clear-association-memory-cache
cmd device_policy clear-freeze-period-record
cmd font clear
cmd lock_settings clear
cmd media.camera clear-stream-use-case-override
cmd media.camera watch clear
cmd safety_center clear-data
cmd stats clear-puller-cache
cmd time_detector clear_network_time
cmd time_detector clear_system_clock_network_time
sm fstrim

# CPU 降频器

settings put global battery_saver_adaptive_constants advertise_is_enabled=false,enable_datasaver=false,enable_night_mode=true,disable_launch_boost=false,disable_vibration=true,disable_animation=true,disable_soundtrigger=true,defer_full_backup=true,defer_keyvalue_backup=true,enable_firewall=false,location_mode=2,gps_mode=2,enable_brightness_adjustment=false,adjust_brightness_factor=0.5,force_all_apps_standby=true,force_background_check=true,disable_optional_sensors=true,disable_aod=false,enable_quick_doze=true

settings put global battery_saver_constants advertise_is_enabled=false,enable_datasaver=false,enable_night_mode=true,disable_launch_boost=false,disable_vibration=true,disable_animation=true,disable_soundtrigger=true,defer_full_backup=true,defer_keyvalue_backup=true,enable_firewall=false,location_mode=2,gps_mode=2,enable_brightness_adjustment=false,adjust_brightness_factor=0.5,force_all_apps_standby=true,force_background_check=true,disable_optional_sensors=true,disable_aod=false,enable_quick_doze=true

settings put global battery_saver_device_specific_constants advertise_is_enabled=false,enable_datasaver=false,enable_night_mode=true,disable_launch_boost=false,disable_vibration=true,disable_animation=true,disable_soundtrigger=true,defer_full_backup=true,defer_keyvalue_backup=true,enable_firewall=false,location_mode=2,gps_mode=2,enable_brightness_adjustment=false,adjust_brightness_factor=0.5,force_all_apps_standby=true,force_background_check=true,disable_optional_sensors=true,disable_aod=false,enable_quick_doze=true

# 来源 https://t.me/dcx402 (telegram) 由 @reljawa 稍作修改
settings put global activity_manager_constants "max_cached_processes=0,background_settle_time=60000,fgservice_min_shown_time=2000,fgservice_min_report_time=3000,fgservice_screen_on_before_time=1000,fgservice_screen_on_after_time=5000,content_provider_retain_time=20000,gc_timeout=5000,gc_min_interval=60000,full_pss_min_interval=1200000,full_pss_lowered_interval=300000,power_check_interval=800000,power_check_max_cpu_1=0,power_check_max_cpu_2=0,power_check_max_cpu_3=5,power_check_max_cpu_4=1,service_usage_interaction_time=1800000,usage_stats_interaction_interval=7200000,service_restart_duration=1000,service_reset_run_duration=60000,service_restart_duration_factor=0,service_min_restart_time_between=10000,service_max_inactivity=1800000,service_bg_start_timeout=15000,service_bg_activity_start_timeout=10000,process_start_async=true,memory_info_throttle_time=300000"

# Devxonf 来自 DroidCmdX
# 设备配置
#https://t.me/dcx402/20
for key in adservice_system_service_enabled cobalt_logging_enabled enable_logged_topic adservice_error_logging_enabled measurement_enable_app_package_name_logging measurement_enable_source_debug_report fledge_app_package_name_logging fledge_auction_server_enable_debug_reporting fledge_auction_server_api_usage_metrics_enabled fledge_auction_server_enabled_for_report_event fledge_auction_server_enabled_for_report_impression fledge_auction_server_enabled_for_select_ads_mediation
do device_config put adservices $key false
done

#https://t.me/dcx402/22
for key in measurement_verbose_debug_reporting_job_required_network_type measurement_debug_reporting_fallback_job_required_network_type measurement_debug_reporting_job_required_network_type measurement_aggregate_fallback_reporting_job_required_network_type measurement_aggregate_reporting_job_required_network_type measurement_async_registration_fallback_job_required_network_type measurement_async_registration_queue_job_required_network_type measurement_event_fallback_reporting_job_required_network_type measurement_event_reporting_job_required_network_type
do device_config put adservices $key 0
done

#https://t.me/dcx402/33
device_config put runtime_native metrics.reporting-mods 0
device_config put runtime_native metrics.reporting-mods-server 0
device_config put runtime_native metrics.reporting-num-mods 0
device_config put runtime_native metrics.reporting-num-mods-server 0

#https://t.me/dcx402/34
for dcx in odp_enable_client_error_logging fcp_enable_client_error_logging odp_background_jobs_logging_enabled fcp_enable_background_jobs_logging
do device_config put on_device_personalization $dcx false
done

#https://t.me/dcx402/38
for dcx in westworld_logging log_error_model_id_westworld_enabled log_model_id_westworld log_model_version_westworld log_classification_latency_westworld moirai_additional_metrics_enabled mismatch_metrics_v2_enabled
do device_config put odad $dcx false
done

#https://t.me/dcx402/41
device_config put activity_manager fgs_start_allowed_log_sample_rate 0
device_config put activity_manager fgs_start_denied_log_sample_rate 0

# 停止日志采样率 (https://t.me/dcx4020/6)
for key in fgs_start_allowed_log_sample_rate fgs_start_denied_log_sample_rate fgs_atom_sample_rate compact_statsd_sample_rate freeze_statsd_sample_rate
do device_config put activity_manager "$key" 0
done

#https://t.me/dcx402/52
for dcx in Logging__enable_aiai_clearcut_logging AutofillVC__enable_clearcut_log Captions__enable_clearcut_logging PlatformLogging__enable_metric_wise_populations Superpacks__use_logging_listener Overview__enable_pir_clearcut_logging Overview__enable_pir_westworld_logging
do device_config put device_personalization_services $dcx false
done

#https://t.me/dcx402/59
device_config put runtime_native metrics.write-to-statsd false
device_config put runtime_native metrics.reporting-spec ''
device_config put runtime_native metrics.reporting-spec-server ''

#https://t.me/dcx402/67
for dcx in StatsLog__active_users_logger_enabled StatsLog__active_users_logger_non_persistent StatsLog__enable_new_logger_api
do device_config put device_personalization_services $dcx false
done

#https://t.me/dcx402/69
for dcx in odp_background_job_sampling_logging_rate fcp_background_job_logging_sampling_rate
do device_config put on_device_personalization $dcx 0
done

#https://t.me/dcx402/72
device_config put window_manager system_gesture_exclusion_log_debounce_millis 0

#https://t.me/dcx4020/30 (停止卡顿监控)
device_config put interaction_jank_monitor enabled false
device_config put interaction_jank_monitor sampling_interval 99999999999999
device_config put interaction_jank_monitor trace_threshold_frame_time_millis -1
device_config put interaction_jank_monitor trace_threshold_missed_frames -1

#https://t.me/dcx402/74
for dcx in mdd_android_sharing_sample_interval mdd_api_logging_sample_interval mdd_default_sample_interval mdd_download_events_sample_interval mdd_group_stats_logging_sample_interval mdd_mobstore_file_service_stats_sample_interval mdd_network_stats_logging_sample_interval mdd_storage_stats_logging_sample_interval
do device_config put adservices $dcx 99966000000
done

#https://t.me/dcx402/75
for dcx in AicModels__network_stats_log_sample_interval AicModels__group_stats_log_sample_interval AicModels__storage_stats_log_sample_interval AicModels__api_log_sample_interval AicModels__default_log_sample_interval
do device_config put aicore $dcx 99999999999999999999
done

#https://t.me/dcx402/76
for dcx in measurement_job_aggregate_fallback_reporting_kill_switch measurement_job_aggregate_reporting_kill_switch measurement_job_event_fallback_reporting_kill_switch measurement_job_event_reporting_kill_switch
do device_config put adservices $dcx true
done

#https://t.me/dcx402/80
device_config put latency_tracker enabled false
device_config put latency_tracker sampling_interval 9999999999999999
device_config put latency_tracker action_show_voice_interaction_enable false
device_config put latency_tracker action_show_voice_interaction_sample_interval 9999999999999999

#https://t.me/dcx402/114
device_config put activity_manager low_swap_threshold_percent 0.02

#https://t.me/dcx402/173
device_config put textclassifier smart_select_animation_enabled false

#https://t.me/dcx402/198
for k in measurement_flex_api_max_event_reports measurement_flex_api_max_event_report_windows
do device_config put adservices $k 0
done

#https://t.me/dcx402/210
for a in logcat_read_timeout_millis dumpsys_read_timeout_millis logcat_proc_timeout_millis dumpsys_proc_timeout_millis max_logcat_lines_low_mem max_logcat_lines
do device_config put telephony $a 0
done

# 停止后台监控 (https://t.me/dcx4020/14)
for a in bg_current_drain_monitor_enabled bg_fgs_monitor_enabled bg_media_session_monitor_enabled bg_permission_monitor_enabled bg_broadcast_monitor_enabled bg_bind_svc_monitor_enabled
do device_config put activity_manager $a false
done

#https://t.me/dcx4012/63
device_config put settings_ui event_logging_enabled false

#https://t.me/dcx4020/22 (减少部分网络统计)
device_config put tethering netstats_store_files_in_apexdata false
device_config put tethering netstats_import_legacy_target_attempts 0

#https://t.me/dcx4020/24 (减少部分日志/开销)
for dcx in mdd_logger_kill_switch background_jobs_logging_kill_switch mdd_background_task_kill_switch global_kill_switch
do device_config put adservices $dcx true
done

#https://t.me/dcx4020/29 (禁用应用分析器)
device_config put activity_manager disable_app_profiler_pss_profiling true

#https://t.me/pandora_kernel_release/200
device_config set_sync_disabled_for_tests until_reboot
device_config put activity_manager max_cached_processes 65535
device_config put activity_manager max_phantom_processes 65535
device_config put lmkd_native use_minfree_levels false
device_config delete lmkd_native thrashing_limit_critical

#https://t.me/dcx4020/39 (将 content_capture 日志历史和缓冲区大小设为 0)
device_config put content_capture log_history_size 0
device_config put content_capture max_buffer_size 0
