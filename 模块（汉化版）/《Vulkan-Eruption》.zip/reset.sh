#!/system/bin/sh

LOG="/data/local/tmp/volcano_reset.log"
echo "Reset do 《🔥Vulkan Eruption🔥》 iniciado" > $LOG

# =========================
# 🧠 RESTAURAR CPU
# =========================
for cpu in /sys/devices/system/cpu/cpu*/cpufreq/scaling_governor
do
    echo schedutil > $cpu 2>/dev/null
done

echo "CPU governor restaurado" >> $LOG

# =========================
# 🔥 RESTAURAR THERMAL
# =========================
echo 1 > /sys/module/thermal/parameters/enabled 2>/dev/null

echo "Thermal reativado" >> $LOG

# =========================
# 🎮 RESET GPU (Mali)
# =========================
echo powersave > /sys/class/devfreq/*gpu*/governor 2>/dev/null
echo 0 > /sys/module/mali/parameters/mali_boost 2>/dev/null

echo "GPU restaurada" >> $LOG

# =========================
# ⚙️ RESET I/O
# =========================
for queue in /sys/block/*/queue/scheduler
do
    echo cfq > $queue 2>/dev/null
done

echo "IO restaurado" >> $LOG

# =========================
# 🧠 RESET MEMÓRIA
# =========================
echo 60 > /proc/sys/vm/swappiness
echo 20 > /proc/sys/vm/dirty_ratio
echo 10 > /proc/sys/vm/dirty_background_ratio

echo "Memória restaurada" >> $LOG

# =========================
# 🚀 RESET PROPS
# =========================
resetprop debug.hwui.renderer ""
resetprop debug.renderengine.backend ""
resetprop persist.sys.renderengine.backend ""

resetprop debug.game.mode ""
resetprop debug.game.fps ""

echo "Props resetadas" >> $LOG

# =========================
# 🔒 REATIVAR VSYNC
# =========================
resetprop debug.hwui.disable_vsync false

echo "Vsync restaurado" >> $LOG

# =========================
# 🧹 LIMPEZA FINAL
# =========================
rm -f /data/local/tmp/vulkan_engine.log

echo "Logs limpos" >> $LOG

# =========================
# ✅ FINAL
# =========================
echo "Reset completo aplicado" >> $LOG