#!/system/bin/sh

MODDIR=${0%/*}

# =========================
#  ESPERAR BOOT COMPLETO
# =========================
while [ "$(getprop sys.boot_completed)" != "1" ]; do
    sleep 2
done

sleep 5

# =========================
#  VM / MEM�RIA (early tuning)
# =========================
echo 0 > /proc/sys/vm/swappiness 2>/dev/null
echo 5 > /proc/sys/vm/dirty_background_ratio 2>/dev/null
echo 10 > /proc/sys/vm/dirty_ratio 2>/dev/null
echo 0 > /proc/sys/vm/oom_kill_allocating_task 2>/dev/null

# =========================
#  DESATIVAR LIMITES INICIAIS
# =========================
echo 0 > /sys/module/thermal/parameters/enabled 2>/dev/null

# =========================
#  GPU PREP (Mali - MTK)
# =========================
echo always_on > /sys/class/devfreq/*gpu*/governor 2>/dev/null
echo 1 > /sys/module/mali/parameters/mali_boost 2>/dev/null

# =========================
#  I/O PREP
# =========================
for queue in /sys/block/*/queue/read_ahead_kb
do
    echo 512 > $queue 2>/dev/null
done

# =========================
#  PRELOAD PROPS
# =========================
resetprop debug.hwui.renderer vulkan
resetprop debug.renderengine.backend vulkan
resetprop persist.sys.renderengine.backend vulkan

# =========================
#  CPUS PREP
# =========================
for cpu in /sys/devices/system/cpu/cpu*/online
do
    echo 1 > $cpu 2>/dev/null
done

# =========================
#  PERMISS�ES (garantia)
# =========================
chmod 644 /proc/sys/vm/* 2>/dev/null
chmod 644 /sys/module/mali/parameters/* 2>/dev/null

# =========================
#  LOOP (mant�m ativo)
# =========================
while true
do
    sleep 60
done