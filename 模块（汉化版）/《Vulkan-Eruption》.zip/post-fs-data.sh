#!/system/bin/sh

MODDIR=${0%/*}

# =========================
# 🔒 PERMISSÕES DO MÓDULO
# =========================
chmod 0755 $MODDIR/service.sh
chmod 0755 $MODDIR/post-fs-data.sh
chmod 0755 $MODDIR/reset.sh 2>/dev/null

chown 0:0 $MODDIR/service.sh
chown 0:0 $MODDIR/post-fs-data.sh
chown 0:0 $MODDIR/reset.sh 2>/dev/null

# =========================
# LOG
# =========================
LOG="/data/local/tmp/vulkane_postfs.log"
echo "Post-fs-data iniciado (com permissões)" > $LOG

sleep 5

# =========================
# 🔥 VM / MEMÓRIA
# =========================
echo 0 > /proc/sys/vm/swappiness
echo 5 > /proc/sys/vm/dirty_background_ratio
echo 10 > /proc/sys/vm/dirty_ratio

# =========================
# 🌡️ THERMAL (relax)
# =========================
echo 0 > /sys/module/thermal/parameters/enabled 2>/dev/null

# =========================
# 🎮 GPU PREP
# =========================
echo always_on > /sys/class/devfreq/*gpu*/governor 2>/dev/null
echo 1 > /sys/module/mali/parameters/mali_boost 2>/dev/null

# =========================
# ⚙️ I/O
# =========================
for queue in /sys/block/*/queue/read_ahead_kb
do
    echo 512 > $queue 2>/dev/null
done

# =========================
# 🚀 VULKAN PRELOAD
# =========================
resetprop debug.hwui.renderer vulkan
resetprop debug.renderengine.backend vulkan
resetprop persist.sys.renderengine.backend vulkan

# =========================
# 🧠 CPU ONLINE
# =========================
for cpu in /sys/devices/system/cpu/cpu*/online
do
    echo 1 > $cpu 2>/dev/null
done

# =========================
# 🔒 PERMISSÕES SISTEMA (seguro)
# =========================
chmod 644 /proc/sys/vm/* 2>/dev/null
chmod 644 /sys/module/mali/parameters/* 2>/dev/null

echo "Permissões + otimizações aplicadas" >> $LOG