#!/system/bin/sh
# 不要假设您的模块位于何处。
# 如果您需要知道此脚本和模块的位置，请始终使用 $MODDIR。
# 如果将来 Magisk 更改其挂载点，这将确保您的模块仍然可以工作
MODDIR=${0%/*}

disable_kernel_panic() {
    sysctl -w kernel.panic=0
    sysctl -w vm.panic_on_oom=0
    sysctl -w kernel.panic_on_oops=0
    sysctl -w kernel.softlockup_panic=0
}

disable_printk() {
# Printk (感谢 KNTD-reborn)
    echo "0 0 0 0" > /proc/sys/kernel/printk
    echo "off" > /proc/sys/kernel/printk_devkmsg
    echo "1" > /sys/module/printk/parameters/ignore_loglevel
    echo "1" > /sys/module/printk/parameters/console_suspend
    echo "0" > /sys/module/printk/parameters/cpu
    echo "0" > /sys/kernel/printk_mode/printk_mode
    echo "0" > /sys/module/printk/parameters/pid
    echo "0" > /sys/module/printk/parameters/time
    echo "0" > /sys/module/printk/parameters/printk_ratelimit
}

main() {
    disable_kernel_panic
    disable_printk
}

# 主执行并成功退出脚本
sync && main
  
# 此脚本将在 post-fs-data 模式下执行
