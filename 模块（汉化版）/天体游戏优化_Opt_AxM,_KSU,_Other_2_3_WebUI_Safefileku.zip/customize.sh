#!/system/bin/sh
# 设置 logcat 缓冲区大小
logcat -G 64K &>/dev/null

if [ "$AXERON" == "true" ]; then
    PRINT="printf"
else
    PRINT="ui_print"
fi

# PRINT FUNCTION WRAPPER ===
print_msg() {
    case "$PRINT" in
        ui_print) ui_print "$1" ;;
        printf) printf "$1" ;;
    esac
}

# 以更清晰的格式打印的函数
print_line() {
    ui_print "***************************************"
}

# 修整分区
trim_partition () {
  if [ "$(id -u)" -eq 0 ]; then
    for partition in system vendor data cache metadata odm system_ext product; do
      fstrim -v "/$partition" &>/dev/null
    done
  else
    for partition in system vendor data cache metadata odm system_ext product; do
      sm fstrim "/$partition" &>/dev/null
    done
  fi
    sleep 3
}

# 删除垃圾和日志 by @Bias_khaliq
delete_trash_logs () {
# 清理 /data/data 下的垃圾
for DIR in /data/data/*; do
  if [ -d "${DIR}" ]; then
    rm -rf ${DIR}/cache/*
    rm -rf ${DIR}/no_backup/*
    rm -rf ${DIR}/app_webview/*
    rm -rf ${DIR}/code_cache/*
  fi
done

# 缓存清理器 by Taka
    # 搜索并清理 "/data/data" 目录下的应用缓存
    find /data/data/*/cache/* -delete &>/dev/null
    # 搜索并清理 "/data/data" 目录下的应用 code_cache
    find /data/data/*/code_cache/* -delete &>/dev/null
    # 搜索并清理 "/data/user_de/{UID}" 目录下的应用缓存
    find /data/user_de/*/*/cache/* -delete &>/dev/null
    # 搜索并清理 "/data/user_de/{UID}" 目录下的应用 code_cache
    find /data/user_de/*/*/code_cache/* -delete &>/dev/null
    # 搜索并清理 "/sdcard/Android/data" 目录下的应用缓存
    find /sdcard/Android/data/*/cache/* -delete &>/dev/null
}

ANDROIDVERSION=$(getprop ro.build.version.release)
DEVICES=$(getprop ro.product.board)
MANUFACTURER=$(getprop ro.product.manufacturer)
API=$(getprop ro.build.version.sdk)
NAME="Celestial-Game-Opt | Kzyo"
VERSION="2.3 Lumina"
DATE=$(date)

printf "░█▀▀█ ── ░█▀▀█ ─█▀▀█ ░█▀▄▀█ ░█▀▀▀ ── ░█▀▀▀█ ░█▀▀█ ▀▀█▀▀ 
░█─── ▀▀ ░█─▄▄ ░█▄▄█ ░█░█░█ ░█▀▀▀ ▀▀ ░█──░█ ░█▄▄█ ─░█── 
░█▄▄█ ── ░█▄▄█ ░█─░█ ░█──░█ ░█▄▄▄ ── ░█▄▄▄█ ░█─── ─░█──"
ui_print ""
sleep 0.5
printf " 增强游戏性能的调整与改进。"
sleep 0.2
ui_print ""
print_line
print_msg "- 名称             : ${NAME}"
sleep 0.2
print_msg "- 版本            : ${VERSION}"
sleep 0.2
print_msg "- Android 版本   : ${ANDROIDVERSION:-未知}"
sleep 0.2
print_msg "- 当前日期        : ${DATE}"
sleep 0.2
print_line
print_msg "- 设备            : ${DEVICES:-未知}"
sleep 0.2
print_msg "- 制造商          : ${MANUFACTURER:-未知}"
sleep 0.2
print_line
print_msg "- 正在修整分区"
trim_partition &>/dev/null
print_msg "- 正在删除缓存和垃圾文件"
delete_trash_logs &>/dev/null
sleep 2

# 设置权限
set_perm_recursive $MODPATH 0 0 0755 0644
set_perm_recursive $MODPATH/system/etc/init/surfaceflinger.rc 0 0 0755 0755

# 关闭或完成刷入模块的峰值操作
logcat -c &>/dev/null
