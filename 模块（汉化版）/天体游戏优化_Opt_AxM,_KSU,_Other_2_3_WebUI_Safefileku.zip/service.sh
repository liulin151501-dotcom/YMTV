#!/system/bin/sh
# Celestial-Game-Opt by the kazuyoo
# Created NR By @KazuyooOpenSources
# 开源爱着 GL-DP 和所有贡献者；
# 已调整系统属性，以便应用程序运行更完美、更响应灵敏。
#
MODDIR=${0%/*}

# ----------------- 辅助功能部分 -----------------
TEMP="game_auto_temperature_control"
      
log() {
    echo "$1"
}

write_val() {
    local file="$1"
    local value="$2"
    if [ -e "$file" ]; then
        chmod +w "$file" 2>/dev/null
        echo "$value" > "$file" && log "写入 : $file → $value" || log "写入失败 : $file"
    fi
}

wait_until_boot_completed() {
    # 等待 sys.boot_completed
    while [ "$(getprop sys.boot_completed)" != "1" ]; do
        sleep 2
    done

    # 等待存储挂载
    until [ -d "/sdcard/Android" ] || [ -d "/storage/emulated/0/Android" ]; do
        sleep 1
    done
}

send_notification() {
    # 通知用户优化完成
    if command -v su >/dev/null 2>&1; then
        su -lp 2000 -c "cmd notification post -S bigtext -t 'Celestial-Game-Opt 🕊️' tag '状态 : 优化完成！'" >/dev/null 2>&1
    else
        cmd notification post -S bigtext -t 'Celestial-Game-Opt 🕊️' 'tags' '状态 : 优化完成！' >/dev/null 2>&1
    fi
}

wait_until_boot_completed
# ----------------- 优化部分 -----------------
root_optimization() {
  # 文件系统调整 (感谢 Matt Yang)
  if [ -d "/proc/sys/fs" ]; then 
     write_val "/proc/sys/fs/inotify/max_queued_events" "1048576"
     write_val "/proc/sys/fs/inotify/max_user_watches" "1048576"
     write_val "/proc/sys/fs/inotify/max_user_instances" "1024"
     write_val "/proc/sys/fs/dir-notify-enable" "0"
     write_val "/proc/sys/fs/lease-break-time" "20"
     write_val "/proc/sys/kernel/hung_task_timeout_secs" "0"
  fi
  
  # 禁用 Fsync
  if [ -d "/sys/module/sync/parameters" ]; then
     write_val "/sys/module/sync/parameters/fsync_enabled" "N"
  fi
  
  # Qualcomm 进入 C-state 级别 3 耗时约 500us
  if [ -d "/sys/module/lpm_levels/" ]; then
     write_val "/sys/module/lpm_levels/parameters/lpm_ipi_prediction" "0"
     write_val "/sys/module/lpm_levels/parameters/lpm_prediction" "0"
     write_val "/sys/module/lpm_levels/parameters/bias_hyst" "2"
  fi
  
  # 触摸加速
  write_val "/sys/module/msm_performance/parameters/touchboost" "1"
  write_val "/sys/power/pnpmgr/touch_boost" "1"
  
  # CPU 高效
  write_val "/sys/module/workqueue/parameters/power_efficient" "Y"
  
  # 禁用日志和调试器 (感谢 @Bias_Khaliq)
  for exception_trace in $(find /proc/sys/ -name exception-trace); do
    write_val "$exception_trace" "0"
  done

  for sched_schedstats in $(find /proc/sys/ -name sched_schedstats); do
    write_val "$sched_schedstats" "0"
  done

  for printk in $(find /proc/sys/ -name printk); do
    write_val "$printk" "0 0 0 0"
  done

  for printk_devkmsg in $(find /proc/sys/ -name printk_devkmsg); do
    write_val "$printk_devkmsg" "off"
  done

  for tracing_on in $(find /proc/sys/ -name tracing_on); do
    write_val "$tracing_on" "0"
  done

  for log_ecn_error in $(find /sys/ -name log_ecn_error); do
    write_val "$log_ecn_error" "0"
  done

  for snapshot_crashdumper in $(find /sys/ -name snapshot_crashdumper); do
    write_val "$snapshot_crashdumper" "0"
  done

  # 禁用 CRC 检查
  for use_spi_crc in $(find /sys/module -name use_spi_crc); do
    write_val "$use_spi_crc" "0"
  done
  
  # 启动时释放缓存 (尝试清理)
  write_val "/proc/sys/vm/drop_caches" "3"
  write_val "/proc/sys/vm/compact_memory" "1"
}

lite_disablelog() {
  cmd stats clear-puller-cache
  cmd activity clear-debug-app
  cmd activity clear-watch-heap -a
  cmd stats print-logs 0
  cmd display ab-logging-disable
  cmd display dwb-logging-disable
  cmd display dmd-logging-disable
  cmd looper_stats disable
  simpleperf --log fatal --log-to-android-buffer 0
  cmd settings put global activity_starts_logging_enabled 0
  cmd settings put global kernel_cpu_thread_reader num_buckets=0,collected_uids=,minimum_total_cpu_usage_millis=999999999
  cmd device_config put runtime_native_boot disable_lock_profiling true
  cmd device_config put runtime_native_boot iorap_readahead_enable true
  cmd device_config put interaction_jank_monitor enabled false
  cmd device_config put interaction_jank_monitor debug_overlay_enabled false
  # 从 CMD-Lite 禁用跟踪和日志 (@HoyoSlave)
  cmd accessibility stop-trace
  cmd migard dump-trace false
  cmd migard start-trace false
  cmd migard stop-trace true
  cmd migard trace-buffer-size 0
  cmd input_method tracing stop
  cmd window tracing size 0
  cmd window tracing stop
  cmd autofill set log_level off
  cmd miui_step_counter_service logging-disable
  cmd voiceinteraction set-debug-hotword-logging false
  cmd wifi set-verbose-logging disabled -l 0
  cmd window logging disable
  cmd window logging disable-text
  cmd window logging stop
}

game_optimization() {
  # 禁用自动温控功能
  if settings list secure | grep $TEMP; then
     settings put secure game_auto_temperature_control 1
  fi
  
  # 移除并停止进程的统计测试模式。来自 ZT @vestia_zeta
  for procstats_option in --clear --stop-testing;do dumpsys procstats "$procstats_option";done

  # 限制或加速后台运行自动同步的终止。
  /system/bin/device_config put activity_manager data_sync_fgs_timeout_duration 1

  # 防止媒体应用程序在前台服务中长时间运行。
  /system/bin/device_config put activity_manager media_processing_fgs_timeout_duration 1

  # 禁止 FGS 被允许启动时的日志记录。
  /system/bin/device_config put activity_manager fgs_start_allowed_log_sample_rate 0

  # 禁止 FGS 被拒绝启动时的日志记录。
  /system/bin/device_config put activity_manager fgs_start_denied_log_sample_rate 0

  # 启用内核 cgroup "freezer" 以冻结空闲进程。
  /system/bin/device_config put activity_manager_native_boot use_freezer true
  
  # 幽灵进程的数量没有限制，系统将尽可能缓存所有应用程序。
  /system/bin/device_config put activity_manager max_phantom_processes 2147483647
  
  # 设置系统存储的缓存（后台非活动）应用程序的最大数量。
  /system/bin/device_config put activity_manager max_cached_processes 256
  
  # 空进程 = 不再活跃但尚未被系统清理的应用程序 → 保存以便再次打开时快速启动。
  /system/bin/device_config put activity_manager max_empty_time_millis 43200000
  
  # 假定存储空间不足
  cmd devicestoragemonitor force-not-low

  # 调整刷新率首选项
  cmd display set-match-content-frame-rate-pref 1

  # 禁用 HDR 以提高流畅度 
  cmd display set-user-disabled-hdr-types 1 2 3 4
  
  # 禁用监控/限制幽灵进程。
  settings put global settings_enable_monitor_phantom_procs false
  
  # 禁用应用待机 (耗电量可能会增加)
  settings put global app_standby_enabled 0
  
  # 触摸增强
  settings put secure long_press_timeout 180
  settings put secure multi_press_timeout 200
}
  
# ----------------- 主执行部分 -----------------
main() {
    root_optimization
    lite_disablelog
    game_optimization
}

# 主执行并成功退出脚本
sync;main;send_notification;exit 1
