#!/system/bin/sh

iorenice $$ 7 idle
renice -n 19 -p $$

echo "Thanks to (Telegram):"
echo @Nekotor1999
echo @reljawa
