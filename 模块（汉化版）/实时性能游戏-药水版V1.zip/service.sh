#!/system/bin/sh

iorenice $$ 7 idle
renice -n 19 -p $$

dir=/data/data/com.android.shell/AxManager/plugins/taskble
sh $dir/game

am start -a AxManager.TOAST -e text "已应用到游戏"