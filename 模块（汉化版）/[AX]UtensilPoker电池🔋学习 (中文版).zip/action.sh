#!/system/bin/sh

# Copyright 2024 Dcx400
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

# 定义工具路径
utensil="/data/local/tmp/utensil"
threshold_file="$utensil/battery_threshold.dat"
dimconfig="$utensil/dimdisplay"
sensorconfig="$utensil/sensorconfiguration"
airplaneconfig="$utensil/airplaneconfiguration"
chargelogconfig="$utensil/charglogconfiguration"
compactconfig="$utensil/compactionconfiguration"
modifiedtimeout="$utensil/timeoutflag"
datasaveconfig="$utensil/datasaverconfiguration"
noticonfig="$utensil/notificationconfiguration"
dndconfig="$utensil/dndconfiguration"
watchdogconfig="$utensil/watchdogconfiguration"
jobrestrict="$utensil/jobschedulerconfiguration"
infodev() {
up=$(cut -d' ' -f1 /proc/uptime | cut -d. -f1)
boot_time=$(date -d "@$(($(date +%s) - up))" "+%Y-%m-%d %H:%M:%S")
days=$((up / 86400)); hours=$(((up / 3600) % 24)); mins=$(((up / 60) % 60))
[ $days -gt 0 ] && timer="${days}天 ${hours}小时 ${mins}分钟" || timer="${hours}小时 ${mins}分钟"

echo "仪表盘 ~
========================================
Android 版本 : $(getprop ro.build.version.release)
总内存 : $(awk '/MemTotal/ {printf "%.2f GB", $2/1024/1024}' /proc/meminfo)
重启时间 : $boot_time
运行时长 : $timer"
}

drain_stats() {

POWER_SAVE_MODE=$(settings get global low_power)

if [ "$POWER_SAVE_MODE" -eq 1 ]; then
  echo "========================================"
  echo "无法进行比较 - 省电模式当前已开启。"
  return
fi

cmd power dump | awk '
/Drain stats:/ {in_section=1; next}
/^$/ {in_section=0}
in_section && /mAh\/h/ {
  split($0, arr, "mAh/h")
  off_val = arr[1]
  on_val  = arr[2]
  gsub(/.* /, "", off_val)
  gsub(/[^0-9.,]/, "", off_val)
  gsub(/.* /, "", on_val)
  gsub(/[^0-9.,]/, "", on_val)

  if (index($0, "NonDoze")) mode="非Doze"
  else if (index($0, "Deep")) mode="深度"
  else if (index($0, "Light")) mode="浅度"
  if (index($0, "NonIntr")) type="非侵入"
  else if (index($0, "Intr")) type="侵入"

  key = mode "-" type
  if (off_val != "" && on_val != "") {
     off[key] = off_val
     on[key]  = on_val
     sum_off += off_val
     sum_on  += on_val
     n++
  }
}
END {
  print "========================================"
  printf "%-17s | %-11s | %-11s\n", "省电模式", "关 (mAh/h)", "开 (mAh/h)"
  print "----------------------------------------"
  for (k in off) {
     printf "%-17s | %-11s | %-11s\n", k, off[k], on[k]
  }
  print "----------------------------------------"
  if (n>0) {
     avg_off = sum_off / n
     avg_on  = sum_on / n
     eff = (1 - avg_on / avg_off) * 100
     printf "平均省电关闭耗电: %.1f mAh/h\n", avg_off
     printf "平均省电开启耗电:  %.1f mAh/h\n", avg_on
  } else {
     print "未找到耗电数据。"
  }
}'
}
infodev
drain_stats

echo "========================================"
if [ ! -f "$threshold_file" ]; then echo "样本不足，请再充电几次以收集足够样本"
else echo "省电模式将在电池达到 $(cat "$threshold_file")% 时自动触发，并且阈值可能会根据您的充电习惯改变"
fi
echo "========================================"
echo "[ 您的配置 ]
飞行模式配置 : $( if [ -f "$airplaneconfig" ]; then echo 开启;else echo 关闭;fi)
传感器配置   : $( if [ -f "$sensorconfig" ]; then echo 开启;else echo 关闭;fi)
充电记录器    : $( if [ -f "$chargelogconfig" ]; then echo 开启;else echo 关闭;fi )
内存压缩    : $( if [ -f "$compactconfig" ]; then echo 开启;else echo 关闭;fi )
屏幕超时    : $( if [ -f "$modifiedtimeout" ]; then echo 开启; else echo 关闭;fi )
数据节省    : $( if [ -f "$datasaveconfig" ]; then echo 开启; else echo 关闭;fi )
通知监听器    : $( if [ -f "$noticonfig" ];then echo 开启;else echo 关闭;fi  )
勿扰模式    : $( if [ -f "$dndconfig" ];then echo 开启;else echo 关闭;fi )
看门狗控制器  : $( if [ -f "$watchdogconfig" ];then echo 开启;else echo 关闭;fi )
限制任务调度器 : $( if [ -f "$jobrestrict" ]; then echo 开启;else echo 关闭;fi )
调暗屏幕    : $( if [ -f "$dimconfig" ]; then echo 开启;else echo 关闭;fi)"
