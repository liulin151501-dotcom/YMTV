#!/system/bin/sh

# Copyright 2024 Dcx400
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

# 定义工具路径
utensil="/data/local/tmp/utensil"

rm $utensil/battery_learning.dat
rm $utensil/battery_threshold.dat
rm $utensil/sensorconfiguration
rm $utensil/airplaneconfiguration
rm $utensil/charglogconfiguration
rm $utensil/notificationconfiguration
rm $utensil/dndconfiguration
rm $utensil/watchdogconfiguration
rm $utensil/dimdisplay
rm $utensil/fileconfig.txt
rm /sdcard/chargelog.txt
for a in $(cat $utensil/whitelistapps.txt); do dumpsys deviceidle whitelist +$a;done
rm $utensil/whitelistapps.txt
#勿扰模式
cmd notification set_dnd off

#删除所有常量
settings delete global battery_saver_constants
settings put global battery_stats_constants track_cpu_times_by_proc_state=false
settings delete global binder_calls_stats
settings delete global activity_manager_constants
settings delete global device_idle_constants
#删除所有常量

#切换WiFi和蓝牙扫描
wifiscan="$utensil/wifiscan"
bluetoothscan="$utensil/bluetoothscan"

if [ -f "$wifiscan" ]; then
settings put global wifi_scan_always_enabled 1
rm $wifiscan
fi
if [ -f "$bluetoothscan" ]; then
settings put global ble_scan_always_enabled 1
rm $bluetoothscan
fi
#切换WiFi和蓝牙扫描

#恢复默认配置/从循环配置

datasaveconfig="$utensil/datasaverconfiguration"
if [ -f "$datasaveconfig" ]; then
cmd netpolicy set restrict-background false
rm $datasaveconfig
fi


cmd power set-mode 0
cmd power set-adaptive-power-saver-enabled false
settings put global low_power 0
settings delete global forced_app_standby_for_small_battery_enabled
if [ "$(getprop ro.product.manufacturer)" = "Xiaomi" ]; then settings put system POWER_SAVE_MODE_OPEN 0;fi
if getprop ro.product.brand | tr '[:upper:]' '[:lower:]' | grep -Eq 'tecno|xos|infinix|itel'; then settings put system tran_settings_long_battery_mode 1;fi
#恢复默认配置/从循环配置

backup="$utensil/batteryconfiguration.dat"

if [ -f "$backup" ]; then
    . "$backup"
    [ -n "$low_power_sticky" ] && settings put global low_power_sticky "$low_power_sticky"
    rm -f "$backup"
fi

#开启传感器
dumpsys sensorservice enable

#关闭飞行模式
cmd connectivity airplane-mode disable

#内存压缩
compactconfig="$utensil/compactionconfiguration"

if [ -f "$compactconfig" ]; then
compactionstate=$(dumpsys activity settings | grep 'use_compaction=' | head -n1 | cut -d= -f2)
if [ "$compactionstate" != "false" ]; then device_config put activity_manager use_compaction false;fi
fi
rm $compactconfig

backupcompact="$utensil/savestatcompact"

if [ -f "$backupcompact" ];then
device_config put activity_manager use_compaction true
fi
rm $backupcompact

#屏幕超时
timeoutflag="$utensil/timeoutflag"
timeoutfile="$utensil/screentimeout.dat"
modifiedtimeout="$utensil/screentimeoutconfiguration"

if [ -f "$timeoutfile" ]; then
	settings put system screen_off_timeout $(cat $timeoutfile)
	rm $timeoutfile
	rm $modifiedtimeout
	rm $timeoutflag
fi

jobrestrict="$utensil/jobschedulerconfiguration"
if [ -f "$jobrestrict" ]; then
	rm $jobrestrict
fi

highrr="$utensil/has_high_rr"
defaultrr="$utensil/default_rr_val"
rrconfig="$utensil/refreshrateconfig"
refresh_rate=$(dumpsys display | awk -F'fps=' '/fps=/{split($2,a,","); if(a[1]>m)m=a[1]} END{print int(m)}')
if [ -z "$refresh_rate" ]; then refresh_rate=60;fi

if [ -f "$highrr" ]; then
	settings put system peak_refresh_rate ${refresh_rate}.0
	rm -f "$highrr"
	rm -f "$defaultrr"
	rm -f "$rrconfig"
fi
