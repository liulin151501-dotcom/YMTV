#!/system/bin/sh

# Copyright 2024 Dcx400
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

(
# 定义工具路径
utensil="/data/local/tmp/utensil"
# 此定义将防止循环中出现任何垃圾消息
prev_state="none"
prev_charging="none"
prev_apm="none"
prev_sensor="none"
android=$(getprop ro.build.version.release)
# 本地学习
data_file="$utensil/battery_learning.dat"
threshold_file="$utensil/battery_threshold.dat"
smooth_factor=0.3
min_threshold=25
max_threshold=60
# 文件配置
sensorconfig="$utensil/sensorconfiguration"
airplaneconfig="$utensil/airplaneconfiguration"
chargelogconfig="$utensil/charglogconfiguration"
datasaveconfig="$utensil/datasaverconfiguration"
dimconfig="$utensil/dimdisplay"
dndconfig="$utensil/dndconfiguration"
# 刷新率配置
rrconfig="$utensil/refreshrateconfig"
[ -f "$utensil/has_high_rr" ] && defaultrr=$(cat $utensil/default_rr_val)
# 充电记录器
data_logger="/sdcard/chargelog.txt"
# 超时文件
timeoutflag="$utensil/timeoutflag"
timeoutfile="$utensil/screentimeout.dat"
modifiedtimeout="$utensil/screentimeoutconfiguration"

# 缓存
gmspkgs="$(pm list packages -s --user 0 | grep gms | cut -d: -f2)"


changerefreshrate() {
rrinput="$1"

if [ -f "$rrconfig" ]; then
	if [ "$rrinput" = "lowprofile" ];then
		settings put system peak_refresh_rate 60.0
	elif [ "$rrinput" = "defaultprofile" ]; then
		settings put system peak_refresh_rate ${defaultrr}
	fi
fi
}

stepdeep() {
    [ "$android" -le 11 ] && return
	cmd deviceidle step deep
}

# 通知
noti() {
if [ -f $utensil/notificationconfiguration ]; then
cmd notification post a "[ Utensil Poker : $1 ]"
fi
}
# 通知

# 充电记录器函数
log_battery() {
    if [ -f "$chargelogconfig" ]; then 
        timestamp=$(date "+%Y-%m-%d %H:%M:%S")
        if [ "$1" = "c" ]; then
            title="***** 正在充电  *****"
        else
            title="*****未充电*****"
        fi

        {
            echo "$title"
            echo "时间戳: $timestamp"
            echo "电池电量: $2"
            echo "*****------------*****"
        } >> "$data_logger"
    fi
}
# 充电记录器函数

# 在有充电记录后进行计算函数
get_dynamic_threshold() {	
	if [ -f "$threshold_file" ]; then
        old_level=$(cat "$threshold_file")
    else
        old_level=25
    fi

	avg_level=$(tail -n 15 "$data_file" | awk '{sum+=$1} END {if(NR>0) print sum/NR; else print 25}')
	new_level=$(awk -v s="$smooth_factor" -v now="$avg_level" -v old="$old_level" 'BEGIN {print (s*now)+((1-s)*old)}')
	new_level=$(awk -v v="$new_level" -v min="$min_threshold" -v max="$max_threshold" 'BEGIN {
        if(v<min)v=min; if(v>max)v=max; print int(v+0.5)
    }')
    echo "$new_level" > "$threshold_file"
}

# 基于15次充电样本进行学习
learn_charge_point() {
    inputlevel="$1"
    echo "$inputlevel" >> "$data_file"

    lines=$(wc -l < "$data_file")

    if [ "$lines" -ge 15 ]; then
        get_dynamic_threshold
        tail -n 15 "$data_file" > "${data_file}.tmp"
        mv "${data_file}.tmp" "$data_file"
    fi
}

# 亮度调节函数
adjust_brightness() {
if [ -f "$dimconfig" ]; then
    in="$1"
    brightness=$(settings get system screen_brightness)
    brightness=$((brightness + in))

    if [ "$brightness" -lt 5 ]; then
      brightness=5
    elif [ "$brightness" -gt 90 ]; then
      brightness=90
    fi

    settings put system screen_brightness "$brightness"
fi
}
# 亮度调节函数

# 循环
while :; do sleep 80

# 定义变量
eval "$(dumpsys battery | awk -F': ' '/level/ {printf "level=%s\n",$2} /AC powered|USB powered/ {if($2=="true") c=1} END{printf "charging=%s\n",c?"yes":"no"}')"
display=$(nice -n19 cmd deviceidle get screen)
lps=$(nice -n19 settings get global low_power_sticky)
# 定义变量

	# 防止low_power_sticky自动开启的条件检查
	if [ "$lps" = 1 ];then
		settings put global low_power_sticky 0
	fi

	# 基于$data_file进行学习的条件检查
    if [ "$charging" = "yes" ] && [ "$prev_charging" != "yes" ]; then
		log_battery c "$level"
        learn_charge_point "$level"
		if [ -f "$dndconfig" ]; then cmd notification set_dnd alarms;fi
		noti "手机正在充电"
    elif [ "$charging" = "no" ] && [ "$prev_charging" != "no" ]; then
		log_battery nc "$level"
		if [ -f "$dndconfig" ]; then cmd notification set_dnd off;fi
		noti "手机未充电"
	fi
	prev_charging="$charging"
	
	# 一旦$threshold_file存在就定义动态阈值
    if [ -f "$threshold_file" ]; then
        dynamic_threshold=$(cat "$threshold_file")
    else
        dynamic_threshold=25
    fi

	# 电池状态检查
    if [ "$level" -le "$dynamic_threshold" ]; then
        if [ "$prev_state" != "low" ]; then
			changerefreshrate lowprofile
            adjust_brightness -12
			noti "电量低!!"
            cmd power set-mode 1
            cmd power set-adaptive-power-saver-enabled true
            settings put global low_power 1
			settings put global forced_app_standby_for_small_battery_enabled 1
			if [ -f "$datasaveconfig" ]; then cmd netpolicy set restrict-background true;fi
			if [ -f "$timeoutflag" ]; then settings put system screen_off_timeout $(cat $modifiedtimeout);fi
			if [ "$(getprop ro.product.manufacturer)" = "Xiaomi" ]; then settings put system POWER_SAVE_MODE_OPEN 1;fi
			if getprop ro.product.brand | tr '[:upper:]' '[:lower:]' | grep -Eq 'tecno|xos|infinix|itel'; then settings put system tran_settings_long_battery_mode 1;fi
            prev_state="low"
        fi
    else
        if [ "$prev_state" != "high" ]; then
			changerefreshrate defaultprofile
            adjust_brightness +12
            cmd power set-mode 0
            cmd power set-adaptive-power-saver-enabled false
            settings put global low_power 0
			settings put global forced_app_standby_for_small_battery_enabled 0
			if [ -f "$datasaveconfig" ]; then cmd netpolicy set restrict-background false;fi
			if [ -f "$timeoutflag" ]; then settings put system screen_off_timeout $(cat $timeoutfile);fi
			if [ "$(getprop ro.product.manufacturer)" = "Xiaomi" ]; then settings put system POWER_SAVE_MODE_OPEN 0;fi
			if getprop ro.product.brand | tr '[:upper:]' '[:lower:]' | grep -Eq 'tecno|xos|infinix|itel'; then settings put system tran_settings_long_battery_mode 0;fi
            prev_state="high"
        fi
    fi
	
	
		# -----------------------
		# 传感器控制器
		# -----------------------
	if [ -f "$sensorconfig" ]; then	
		if [ "$display" = "false" ] && [ "$charging" = "no" ] && [ "$level" -le "$dynamic_threshold" ] && [ "$prev_sensor" != "OFF" ]; then
			for a in $gmspkgs; do 
				dumpsys sensorservice restrict $a
			done
			prev_sensor="OFF"
		elif [ "$level" -ge "$dynamic_threshold" ] && [ "$prev_sensor" != "ON" ]; then
			dumpsys sensorservice enable
			noti "传感器已启用"
			prev_sensor="ON"		
			
		elif [ "$display" = "true" ] && [ "$prev_sensor" != "ON" ]; then
			dumpsys sensorservice enable
			noti "传感器已启用"
			prev_sensor="ON"	
		fi
	fi
		
		# -----------------------
		# 传感器控制器
		# -----------------------
	
		# -----------------------
		# 设备空闲控制器
		# -----------------------
		current_idle="$(nice -n19 dumpsys deviceidle | grep -o 'mLightState=[^ ]*' |cut -d= -f2)"
		if [ "$display" = "false" ] && [ "$current_idle" = "INACTIVE" ] && [ "$charging" = "no" ]; then
			if [ "$level" -le "$dynamic_threshold" ]; then
				stepdeep
			else
				for a in $(seq 4); do stepdeep;done
			fi
		fi
		# -----------------------
		# 设备空闲控制器
		# -----------------------
	
		# -----------------------
		# 飞行模式控制器
		# -----------------------
	if [ -f "$airplaneconfig" ];then
		if [ "$display" = "false" ] && [ "$charging" = "yes" ] && [ "$level" -le "$dynamic_threshold" ] && [ "$prev_apm" != "enabled" ]; then
			cmd connectivity airplane-mode enable
			sleep 2
			wifistatus=$(nice -n19 dumpsys wifi | grep "Wi-Fi is" | awk '{print $3}')
			if [ "$wifistatus" = "disabled" ]; then svc wifi enable;fi
			prev_apm="enabled"
		elif [ "$display" = "true" ] && [ "$prev_apm" != "disabled" ]; then
			cmd connectivity airplane-mode disable
			prev_apm="disabled"
		elif [ "$level" -gt "$max_threshold" ] && [ "$prev_apm" != "disabled" ]; then
			cmd connectivity airplane-mode disable
			prev_apm="disabled"	
		fi
	fi
	
		# -----------------------
		# 飞行模式控制器
		# -----------------------
done ) &

(
# 定义工具路径
utensil=/data/local/tmp/utensil
# 内存压缩控制器
compactconfg="$utensil/compactionconfiguration"
adrv=$(getprop ro.build.version.release)
if [ -f "$compactconfg" ]; then
compactionstate=$(dumpsys activity settings | grep 'use_compaction=' | head -n1 | cut -d= -f2)
if [ "$compactionstate" != "true" ]; then device_config put activity_manager use_compaction true;fi
time=0
ran=0
hardlock=$((150 * 4))
while :; do
    sleep 150
    screen_state=$(nice -n 19 cmd deviceidle get screen)

    if [ "$screen_state" = "true" ]; then
        time=0
		ran=0
    else
        time=$((time + 150))
    fi
	
	
	if [ "$time" -ge "$hardlock" ] && [ "$ran" -eq 0 ]; then
	ran=1
		if [ "$adrv" -ge 12 ] && [ "$adrv" -le 13 ]; then
			pm list packages -U | while read -r l; do p=$(echo "$l" | awk -F'[: ]' '{print $2}'); u=$(echo "$l" | awk -F'[: ]' '{print $4}'); [ "$p" ] && [ "$u" ] && am compact "$p" "$u" some 2>/dev/null && am compact "$p" "$u" full 2>/dev/null; done
		elif [ "$adrv" -ge 14 ]; then  ps -A -o USER,NAME | awk '$1 ~ /^u0_/ { sub(/:.*/,"",$2); print $2 }' | while read -r package;do am compact full $package;done;am compact system
		fi
	fi
    
done
fi ) &

# 看门狗控制器
(
# 定义工具路径
utensil="/data/local/tmp/utensil"
CONFIG="$utensil/fileconfig.txt"
watchdogconfig="$utensil/watchdogconfiguration"
PROTECT_LIST=$(grep -v '^#' "$CONFIG" | sed '/^[[:space:]]*$/d')
if [ -f "$watchdogconfig" ]; then
interval=60
timeout_app=240

apps=$(pm list packages -3 -e | cut -d: -f2)

MEM_DB=""

# 任务调度器标志
job_done=0
screen_off_time=0
idle_threshold=500
get_running_apps() {
    nice -n 19 ps -A -o USER,NAME | awk '$1 ~ /^u0_/ { sub(/:.*/,"",$2); print $2 }' | while read -r proc; do
        case "$apps" in *"$proc"*) echo "$proc" ;; esac
    done | sort -u
}

jobsch() {
    if [ -f "$utensil/jobschedulerconfiguration" ]; then
        for a in $apps; do
            case "$PROTECT_LIST" in *"$a"*) continue ;; esac
            cmd jobscheduler cancel "$a"
        done
    fi
} > /dev/null

get_mem_time() {
    local pkg=$1
    case "$MEM_DB" in
        *"$pkg:"*)
            local suffix="${MEM_DB#*"$pkg:"}"
            echo "${suffix%% *}"
            ;;
        *)
            echo ""
            ;;
    esac
}

# 主循环
while true; do
    screenon=$(nice -n 19 cmd deviceidle get screen)

    if [ "$screenon" = "true" ]; then
        MEM_DB=""
        job_done=0
        screen_off_time=0
        sleep "$interval"
        continue
    fi

    now=$(date +%s)
	
	if [ "$screen_off_time" -eq 0 ]; then
        screen_off_time=$now
    fi

    idle_duration=$((now - screen_off_time))
        
    if [ "$idle_duration" -ge "$idle_threshold" ] && [ "$job_done" -eq 0 ]; then
        jobsch
        job_done=1
    fi
	
    pkgs=$(get_running_apps)
    new_memo_db=""

    for pkg in $pkgs; do
        case "$PROTECT_LIST" in *"$pkg"*) continue ;; esac

        ts=$(get_mem_time "$pkg")
        
        if [ -z "$ts" ]; then
            new_memo_db="$new_memo_db $pkg:$now"
        else
            diff=$((now - ts))
            if [ "$diff" -ge "$timeout_app" ]; then
                am force-stop "$pkg"
            else
                new_memo_db="$new_memo_db $pkg:$ts"
            fi
        fi
    done

    MEM_DB="$new_memo_db"
    sleep "$interval"
done
fi ) &
