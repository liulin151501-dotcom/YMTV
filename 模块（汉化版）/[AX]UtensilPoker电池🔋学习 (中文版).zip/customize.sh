#!/system/bin/sh

# Copyright 2024 Dcx400
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.


# 定义工具路径 /// 感谢 @Nekotor1999 提供的想法
utensil="/data/local/tmp/utensil"
mkdir -p "$utensil"

# 首次设置所有内容
android=$(getprop ro.build.version.release)

if [ "$(getprop ro.debuggable)" = 1 ]; then
	ui_print "检测到可调试环境"
fi

# 屏幕超时
screen_time_out() {
# 定义路径
# 备份原始超时
timeoutfile="$utensil/screentimeout.dat"
# 存储计算后的超时
modifiedtimeout="$utensil/screentimeoutconfiguration"
if [ ! -f "$timeoutfile" ]; then
settings get system screen_off_timeout > "$timeoutfile"
fi
# 读取 $timeoutfile
timeoutop="$(cat $timeoutfile)"
# 如果未检测到超时，防止出现任何问题
if [ -z "$timeoutop" ] || [ "$timeoutop" = "null" ];then
return
fi
calculationtimeout=$(( $timeoutop * 9 / 15 ))
echo "$calculationtimeout" > "$modifiedtimeout"
}
screen_time_out

if [ "$android" -le 11 ]; then 
settings put global battery_saver_constants \
advertise_is_enabled=true,\
datasaver_disabled=false,\
enable_night_mode=true,\
launch_boost_disabled=true,\
vibration_disabled=true,\
animation_disabled=true,\
soundtrigger_disabled=true,\
fullbackup_deferred=true,\
keyvaluebackup_deferred=true,\
firewall_disabled=false,\
gps_mode=2,\
adjust_brightness_disabled=false,\
adjust_brightness_factor=0.5,\
force_all_apps_standby=true,\
force_background_check=true,\
optional_sensors_disabled=true,\
aod_disabled=true,\
quick_doze_enabled=true
else
settings put global battery_saver_constants \
advertise_is_enabled=true,\
enable_datasaver=false,\
enable_night_mode=true,\
disable_launch_boost=true,\
disable_vibration=true,\
disable_animation=true,\
soundtrigger_mode=2,\
defer_full_backup=true,\
defer_keyvalue_backup=true,\
enable_firewall=true,\
location_mode=2,\
enable_brightness_adjustment=false,\
adjust_brightness_factor=0.5,\
force_all_apps_standby=true,\
force_background_check=true,\
disable_optional_sensors=true,\
disable_aod=true,\
enable_quick_doze=true
fi

if [ "$android" -le 13 ]; then
settings put global battery_stats_constants track_cpu_times_by_proc_state=false,track_cpu_active_cluster_time=false,read_binary_cpu_time=false,max_history_files=0,max_history_buffer_kb=0
else
settings put global battery_stats_constants track_cpu_times_by_proc_state=false,track_cpu_active_cluster_time=false,read_binary_cpu_time=false,max_history_files=0,max_history_buffer_kb=0,phone_on_external_stats_collection=false
fi


# 仅适用于 Android 11 或更低版本的配置文件
if [ "$android" -le 11 ];then
inactive_to=$((1 * 60 * 1000))
sensing_to=$((0 * 1000))
motion_inactive_to=$((0 * 1000))
idle_after_inactive_to=$((0 * 1000))
idle_pending_to=$((5 * 60 * 1000))
max_idle_pending_to=$((5 * 60 * 1000))
quick_doze_delay_to=$((1 * 60 * 1000))
idle_to=$((30 * 60 * 1000))
max_idle_to=$((8 * 60 * 60 * 1000))

constants="inactive_to=${inactive_to},\
sensing_to=${sensing_to},\
motion_inactive_to=${motion_inactive_to},\
idle_after_inactive_to=${idle_after_inactive_to},\
idle_pending_to=${idle_pending_to},\
max_idle_pending_to=${max_idle_pending_to},\
quick_doze_delay_to=${quick_doze_delay_to},\
idle_to=${idle_to},\
max_idle_to=${max_idle_to}"
settings put global device_idle_constants "${constants}"
fi



settings put global binder_calls_stats detailed_tracking=false,enabled=false,upload_data=false,collect_latency_data=false,track_calling_uid=false
if [ "$(settings get global wifi_scan_always_enabled)" = 1 ]; then 
settings put global wifi_scan_always_enabled 0
touch "$utensil/wifiscan"
fi
if [ "$(settings get global ble_scan_always_enabled)" = 1 ]; then 
settings put global ble_scan_always_enabled 0
touch "$utensil/bluetoothscan"
fi

# 备份 sticky 设置
backup="$utensil/batteryconfiguration.dat"

if [ ! -f "$backup" ]; then

	current_lps=$(settings get global low_power_sticky)
	echo "low_power_sticky=$current_lps" > "$backup"
	echo "sticky power 配置已保存至 "$backup""
	
	if [ "$(settings get global low_power_sticky)" = 1 ]; then 
		echo "低电量 sticky 已禁用"
	settings put global low_power_sticky 0
	fi
	
fi

# 刷新率
refresh_rate=$(dumpsys display | awk -F'fps=' '/fps=/{split($2,a,","); if(a[1]>m)m=a[1]} END{print int(m)}')
current_refresh_rate=$(settings get system peak_refresh_rate | cut -d'.' -f1 || echo 60)
if [ "$refresh_rate" -ge 90 ] && [ "$current_refresh_rate" -ge 90 ] ; then
	touch "$utensil/has_high_rr"
	echo "$(settings get system peak_refresh_rate)" > "$utensil/default_rr_val"
else
	if [ -f "$utensil/has_high_rr" ]; then rm -f "$utensil/has_high_rr";fi
fi
# 刷新率


# 活动管理器配置
power_interval=$((4 * 60 * 1000))
pss_interval=$((25 * 60 * 1000))
pss_low_interval=$((10 * 60 * 1000))
settings put global activity_manager_constants \
power_check_max_cpu_1=20,\
power_check_max_cpu_2=20,\
power_check_max_cpu_3=5,\
power_check_max_cpu_4=1,\
power_check_interval=$power_interval,\
full_pss_min_interval=$pss_interval,\
full_pss_lowered_interval=$pss_low_interval


# 保护层
if [ "$(dumpsys activity settings | grep 'use_compaction=' | head -n1 | cut -d= -f2)" = "true" ] ;then 
	touch $utensil/savestatcompact
fi

watchdogconfig="$utensil/watchdogconfiguration"
CONFIG="$utensil/fileconfig.txt"
launcher=$(pm resolve-activity --brief -a android.intent.action.MAIN -c android.intent.category.HOME | cut -d/ -f1 | tail -n1)
keyboard=$(settings get secure default_input_method | cut -d/ -f1)

echo "# 受保护的应用
$launcher
$keyboard
com.zing.zalo

" > "$CONFIG"
echo "默认看门狗配置已写入至 $CONFIG"


echo "
所有设置已完成，请坐下来，我们将为您完成其余工作。
"
.