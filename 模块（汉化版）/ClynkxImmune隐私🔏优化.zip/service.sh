#!/system/bin/sh
 
若scene守护进程未运行，执行对应启动脚本
 
if ! pidof scene-daemon
then sh /sdcard/Android/data/com.omarea.vtools/up.sh
fi
 
若shizuku服务未运行，执行本地启动程序
 
if ! pidof shizuku_server
then /data/local/tmp/shizuku_starter
fi
 
发送通知，提示CLYNKXIMMUNE已安装
 
cmd notification post a "[CLYNKXIMMUNE INSTALLED]"