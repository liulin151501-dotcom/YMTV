#!/system/bin/sh
 
临时禁用设备配置同步，重启后失效
 
cmd device_config set_sync_disabled_for_tests until_reboot
 
遍历所有设备配置项并删除
 
for a in $(cmd device_config list|cut -f1 -d=);do
cmd device_config delete "{a%/*}" "{a#*/}"
done
 
执行结果判断+通知提示
 
if [ $? -eq 0 ]; then
cmd notification post a "[配置清理完成] 所有device_config已删除，重启失效"
else
cmd notification post a "[配置清理失败] 部分项删除异常，请检查权限"
fi