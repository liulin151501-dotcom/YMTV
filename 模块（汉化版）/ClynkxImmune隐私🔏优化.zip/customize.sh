#!/system/bin/sh
 
版权所有 2024 Dcx400
 
#
 
遵循Apache许可证2.0版本（下称"许可证"）授权；
 
除非符合许可证规定，否则不得使用此文件。
 
可在以下地址获取许可证副本：
 
#
 
http://www.apache.org/licenses/LICENSE-2.0
 
#
 
除非适用法律要求或书面同意，否则根据许可证分发的软件
 
均按"原样"分发，无任何明示或暗示的担保或条件。
 
请依据许可证查看特定语言管辖下的权限和限制。
 
cmd device_config setsystem/bin/sh
 
版权所有 2024 Dcx400
 
#
 
遵循Apache许可证2.0版本（下称"许可证"）授权；
 
除非符合许可证规定，否则不得使用此文件。
 
可在以下地址获取许可证副本：
 
#
 
http://www.apache.org/licenses/LICENSE-2.0
 
#
 
除非适用法律要求或书面同意，否则根据许可证分发的软件
 
均按"原样"分发，无任何明示或暗示的担保或条件。
 
请依据许可证查看特定语言管辖下的权限和限制。
 
cmd device_config set_sync_disabled_for_tests persistent
 
来源：https://t.me/dcx402/20  关闭广告服务相关日志与功能开关
 
for key in adservice_system_service_enabled cobalt_logging_enabled enable_logged_topic adservice_error_logging_enabled measurement_enable_app_package_name_logging measurement_enable_source_debug_report fledge_app_package_name_logging fledge_auction_server_enable_debug_reporting fledge_auction_server_api_usage_metrics_enabled fledge_auction_server_enabled_for_report_event fledge_auction_server_enabled_for_report_impression fledge_auction_server_enabled_for_select_ads_mediation
do device_config put adservices $key false
done
 
来源：https://t.me/dcx402/22  关闭广告服务各类调试报告任务的网络限制要求
 
for key in measurement_verbose_debug_reporting_job_required_network_type measurement_debug_reporting_fallback_job_required_network_type measurement_debug_reporting_job_required_network_type measurement_aggregate_fallback_reporting_job_required_network_type measurement_aggregate_reporting_job_required_network_type measurement_async_registration_fallback_job_required_network_type measurement_async_registration_queue_job_required_network_type measurement_event_fallback_reporting_job_required_network_type measurement_event_reporting_job_required_network_type
do device_config put adservices $key 0
done
 
来源：https://t.me/dcx402/33  关闭原生运行时相关模块统计上报
 
device_config put runtime_native metrics.reporting-mods 0
device_config put runtime_native metrics.reporting-mods-server 0
device_config put runtime_native metrics.reporting-num-mods 0
device_config put runtime_native metrics.reporting-num-mods-server 0
 
来源：https://t.me/dcx402/34  关闭设备端个性化服务的客户端错误日志与后台任务日志
 
for dcx in odp_enable_client_error_logging fcp_enable_client_error_logging odp_background_jobs_logging_enabled fcp_enable_background_jobs_logging
do device_config put on_device_personalization $dcx false
done
 
来源：https://t.me/dcx402/38  关闭设备端广告相关各类日志与指标统计
 
for dcx in westworld_logging log_error_model_id_westworld_enabled log_model_id_westworld log_model_version_westworld log_classification_latency_westworld moirai_additional_metrics_enabled mismatch_metrics_v2_enabled
do device_config put odad $dcx false
done
 
来源：https://t.me/dcx402/41  关闭前台服务启动允许/拒绝日志采样
 
device_config put activity_manager fgs_start_allowed_log_sample_rate 0
device_config put activity_manager fgs_start_denied_log_sample_rate 0
 
来源：https://t.me/dcx402/52  关闭设备个性化服务下各类功能的日志上报
 
for dcx in Logging__enable_aiai_clearcut_logging AutofillVC__enable_clearcut_log Captions__enable_clearcut_logging PlatformLogging__enable_metric_wise_populations Superpacks__use_logging_listener Overview__enable_pir_clearcut_logging Overview__enable_pir_westworld_logging
do device_config put device_personalization_services $dcx false
done
 
来源：https://t.me/dcx402/59  关闭原生运行时向statsd写入指标与上报规格配置
 
device_config put runtime_native metrics.write-to-statsd false
device_config put runtime_native metrics.reporting-spec ''
device_config put runtime_native metrics.reporting-spec-server ''
 
来源：https://t.me/dcx402/67  关闭设备个性化服务的活跃用户日志相关功能
 
for dcx in StatsLog__active_users_logger_enabled StatsLog__active_users_logger_non_persistent StatsLog__enable_new_logger_api
do device_config put device_personalization_services $dcx false
done
 
来源：https://t.me/dcx402/69  关闭设备端个性化服务后台任务日志采样率
 
for dcx in odp_background_job_sampling_logging_rate fcp_background_job_logging_sampling_rate
do device_config put on_device_personalization $dcx 0
done
 
来源：https://t.me/dcx402/72  关闭窗口管理器系统手势排除日志防抖延时
 
device_config put window_manager system_gesture_exclusion_log_debounce_millis 0
 
来源：https://t.me/dcx402/74  最大化广告服务各类日志采样间隔（等同于关闭）
 
for dcx in mdd_android_sharing_sample_interval mdd_api_logging_sample_interval mdd_default_sample_interval mdd_download_events_sample_interval mdd_group_stats_logging_sample_interval mdd_mobstore_file_service_stats_sample_interval mdd_network_stats_logging_sample_interval mdd_storage_stats_logging_sample_interval
do device_config put adservices $dcx $(echo 2^64|bc)
done
 
来源：https://t.me/dcx402/75  最大化AI核心各类日志采样间隔（等同于关闭）
 
for dcx in AicModels__network_stats_log_sample_interval AicModels__group_stats_log_sample_interval AicModels__storage_stats_log_sample_interval AicModels__api_log_sample_interval AicModels__default_log_sample_interval
do device_config put aicore $dcx $(echo 2^64|bc)
done
 
来源：https://t.me/dcx402/76  启用广告服务各类测量任务的熔断开关（停止任务执行）
 
for dcx in measurement_job_aggregate_fallback_reporting_kill_switch measurement_job_aggregate_reporting_kill_switch measurement_job_event_fallback_reporting_kill_switch measurement_job_event_reporting_kill_switch
do device_config put adservices $dcx true
done
 
来源：https://t.me/dcx402/80  关闭延迟追踪功能并最大化采样间隔
 
device_config put latency_tracker enabled false
device_config put latency_tracker sampling_interval $(echo 2^64|bc)
device_config put latency_tracker action_show_voice_interaction_enable false
device_config put latency_tracker action_show_voice_interaction_sample_interval $(echo 2^64|bc)
 
来源：https://t.me/dcx402/173  关闭文本分类器智能选择动画
 
device_config put textclassifier smart_select_animation_enabled false
 
来源：https://t.me/dcx402/198  关闭广告服务测量弹性接口最大事件报告数与窗口数
 
for k in measurement_flex_api_max_event_reports measurement_flex_api_max_event_report_windows
do device_config put adservices $k 0
done
 
来源：https://t.me/dcx402/210  关闭电话服务各类日志读取超时时间与最大日志行数限制
 
for a in logcat_read_timeout_millis dumpsys_read_timeout_millis logcat_proc_timeout_millis dumpsys_proc_timeout_millis max_logcat_lines_low_mem max_logcat_lines
do device_config put telephony $a 0
done
 
停止日志采样（来源：https://t.me/dcx4020/6）
 
for key in fgs_start_allowed_log_sample_rate fgs_start_denied_log_sample_rate fgs_atom_sample_rate compact_statsd_sample_rate freeze_statsd_sample_rate
do device_config put activity_manager "$key" 0
done
 
停止后台各类监控（来源：https://t.me/dcx4020/14）
 
for a in bg_current_drain_monitor_enabled bg_fgs_monitor_enabled bg_media_session_monitor_enabled bg_permission_monitor_enabled bg_broadcast_monitor_enabled bg_bind_svc_monitor_enabled
do device_config put activity_manager $a false
done
 
来源：https://t.me/dcx4020/22  减少网络统计相关开销（关闭网络共享统计文件存储与旧数据导入尝试）
 
device_config put tethering netstats_store_files_in_apexdata false
device_config put tethering netstats_import_legacy_target_attempts 0
 
来源：https://t.me/dcx4020/24  减少日志与系统开销（启用广告服务各类熔断开关）
 
for dcx in mdd_logger_kill_switch background_jobs_logging_kill_switch mdd_background_task_kill_switch global_kill_switch
do device_config put adservices $dcx true
done
 
来源：https://t.me/dcx4020/29  关闭应用性能分析器的内存占用分析功能
 
device_config put activity_manager disable_app_profiler_pss_profiling true
 
来源：https://t.me/dcx4020/30  停止卡顿监控功能
 
device_config put interaction_jank_monitor enabled false
device_config put interaction_jank_monitor sampling_interval $(echo 2^64|bc)
device_config put interaction_jank_monitor trace_threshold_frame_time_millis -1
device_config put interaction_jank_monitor trace_threshold_missed_frames -1
 
来源：https://t.me/dcx4020/39  清零内容捕获的日志历史大小与最大缓冲区大小
 
device_config put content_capture log_history_size 0
device_config put content_capture max_buffer_size 0
 
来源：https://t.me/dcx4012/62  关闭设置界面通用事件日志
 
device_config put settings_ui event_logging_enabled false
 
来源：https://t.me/dcx4012/523  关闭媒体指标统计
 
device_config put media media_metrics_mode 0
 
来源：https://t.me/dcx4012/676  设置低交换空间阈值百分比
 
device_config put activity_manager proactive_kills_enabled true
device_config put activity_manager low_swap_threshold_percent 0.5
 
来源：https://t.me/dcx4012/733  加快开机速度（启用预读，关闭性能追踪）
 
device_config put runtime_native_boot iorap_readahead_enable true
device_config put runtime_native_boot iorap_perfetto_enable false
 
来源：https://t.me/dcx4012/880  启用内存碎片整理功能
 
device_config put activity_manager use_compaction true
 
来源：https://t.me/dcx4012/893  设置内存中最大进程数（缓存进程+幽灵进程）
 
device_config put activity_manager max_cached_processes 64
device_config put activity_manager max_phantom_processes 128
 
来源：https://t.me/dcx4012/1100  有助于节省电量（自动限制后台滥用资源应用）
 
device_config put activity_manager bg_auto_restrict_abusive_apps true
device_config put activity_manager bg_current_drain_auto_restrict_abusive_apps_enabled true