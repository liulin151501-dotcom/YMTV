#!/system/bin/sh

NAME="Disable V-sync"
VERSION="1.0.0 | DisableVsync"
ANDROIDVERSION=$(getprop ro.build.version.release)
DEVICE=$(getprop ro.product.device)
MANUFACTURER=$(getprop ro.product.manufacturer)
DATE=$(date)

sleep 2
echo "
░█▀▀▄ ▀█▀ ░█▀▀▀█ ─█▀▀█ ░█▀▀█ ░█─── ░█▀▀▀ 
░█─░█ ░█─ ─▀▀▀▄▄ ░█▄▄█ ░█▀▀▄ ░█─── ░█▀▀▀ 
░█▄▄▀ ▄█▄ ░█▄▄▄█ ░█─░█ ░█▄▄█ ░█▄▄█ ░█▄▄▄"
echo ""
echo "
░█──░█ ── ░█▀▀▀█ ░█──░█ ░█▄─░█ ░█▀▀█ 
─░█░█─ ▀▀ ─▀▀▀▄▄ ░█▄▄▄█ ░█░█░█ ░█─── 
──▀▄▀─ ── ░█▄▄▄█ ──░█── ░█──▀█ ░█▄▄█"
echo ""
sleep 2

echo "==============================="
echo "   $NAME"
echo "   版本   : $VERSION"
echo "   安卓版本 : ${ANDROIDVERSION:-未知}"
echo "   设备型号 : ${DEVICE:-未知}"
echo "   制造商   : ${MANUFACTURER:-未知}"
echo "   执行日期 : $DATE"
echo "==============================="



echo "[$NAME] 优化中⚡."
cmd notification post -S bigtext -t '禁用垂直同步' '⚡' " 正在应用调整"
