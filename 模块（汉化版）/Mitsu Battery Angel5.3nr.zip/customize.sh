/uptime=$(cut -d. -f1 /proc/uptime);memory=$(cat /proc/meminfo|tr -s \ );
echo "OS: Android $(getprop ro.build.version.release)"
echo "Model: $(getprop ro.product.manufacturer) $(getprop ro.product.model)"
echo "Kernel: $(uname -r|cut -f1,2,3 -d-)"
echo "Uptime: $((uptime/3600)) hour, $((uptime%3600/60)) mins"
echo "Packages: $(cmd package list packages -s --user 0|wc -l) (sys), $(cmd package list packages -3 --user 0|wc -l) (trd)"
echo "Resolution:$(wm size|cut -d: -f2)"
echo "Theme: $(getprop ro.build.fingerprint|cut -f5 -d\/|cut -f1 -d:)"
echo "Terminal: $(dumpsys window|grep mTopFullscreenOpaqueWindowState|cut -f7 -d\ |cut -f1 -d/)"
echo "CPU: $(getprop ro.soc.manufacturer) $(getprop ro.soc.model)"
echo "GPU:$(dumpsys SurfaceFlinger|grep GLES:|cut -f2 -d,)"
echo "Memory: $((($(echo "$memory"|grep MemTotal|cut -f2 -d\ )-$(echo "$memory"|grep MemAvailable|cut -f2 -d\ ))/1024))MiB / $(($(echo "$memory"|grep MemTotal|cut -f2 -d\ )/1024))MiB"

(echo "
  Press Volume Button
   Volume + : Appops
   Volume - : Skip
";while true;do input="$(timeout 0.1 getevent -l|grep -Eo 'VOLUMEUP|VOLUMEDOWN'|head -n1)";if [ "$input" = "VOLUMEUP" ];then echo "   Selected : Appops
";pm list packages -s \
 | awk -F: '{print $2}' \
 | xargs -n1 -P3 sh -c 'appops set "$1" ACTIVITY_RECOGNITION ignore
appops set "$1" ACTIVITY_RECOGNITION_SOURCE ignore
appops set "$1" GET_ACCOUNTS ignore
appops set "$1" INSTANT_APP_START_FOREGROUND ignore
appops set "$1" MONITOR_LOCATION ignore
appops set "$1" RUN_ANY_IN_BACKGROUND ignore
appops set "$1" RUN_IN_BACKGROUND ignore
appops set "$1" RUN_USER_INITIATED_JOBS ignore
appops set "$1" ACTIVITY_RECOGNITION ignore
appops set "$1" ACTIVITY_RECOGNITION_SOURCE ignore
appops set "$1" INTERACT_ACROSS_PROFILES ignore
appops set "$1" MONITOR_HIGH_POWER_LOCATION ignore
appops set "$1" START_FOREGROUND ignore
appops set "$1" CAPTURE_CONSENTLESS_BUGREPORT_ON_USERDEBUG_BUILD ignore
appops set "$1" SYSTEM_EXEMPT_FROM_HIBERNATION ignore
appops set "$1" SYSTEM_EXEMPT_FROM_POWER_RESTRICTIONS ignore
appops set "$1" WAKE_LOCK ignore
appops set "$1" GET_ACCOUNTS ignore
appops set "$1" LOADER_USAGE_STATS ignore' _;break;elif [ "$input" = "VOLUMEDOWN" ];then echo "   Selected : Skip";break;fi;done)2>/dev/null

echo ""

echo "more twins"

settings put global activity_manager_constants "power_check_max_cpu_1=0,power_check_max_cpu_2=0,power_check_max_cpu_3=0,power_check_max_cpu_4=0,full_pss_min_interval=216000000,full_pss_lowered_interval=216000000,kill_bg_restricted_cached_idle=true,low_swap_threshold_percent=60,proactive_kills_enabled=true,system_exempt_power_restrictions_enabled=true,kill_bg_restricted_cached_idle_settle_time=10000"

settings put global binder_calls_stats "sampling_interval=600000000,detailed_tracking=disable,enabled=false,upload_data=false"
settings put global cached_apps_freezer 1
settings put global freezer_stats_enabled false
settings put system haptic_feedback_disable 1
settings put secure screensaver_activate_on_dock 0
settings put secure screensaver_enabled 0
simpleperf --log fatal --log-to-android-buffer 0

settings put global battery_stats_constants "track_cpu_active_cluster_time=false,read_binary_cpu_time=false,proc_state_cpu_times_read_delay_ms=5000000000,kernel_uid_readers_throttle_time=1,external_stats_collection_rate_limit_ms=0,battery_level_collection_delay_ms=30000000000,max_history_buffer_kb=0,max_history_files=0,track_cpu_times_by_proc_state=false,phone_on_external_stats_collection=false"

settings put global device_idle_constants "inactive_to=5000,sensing_to=0,locating_to=0,location_accuracy=0,motion_inactive_to=0,idle_after_inactive_to=0,idle_pending_to=60000,max_idle_pending_to=120000,idle_pending_factor=2.0,idle_to=900000,max_idle_to=86400000,idle_factor=2.0,min_time_to_alarm=600000,max_temp_app_whitelist_duration=10000,wait_for_unlock=false"

for tag in system_server system_server/Subject data_app_wtf storage_trim SYSTEM_BOOT SYSTEM_AUDIT system_server_wtf SYSTEM_LAST_KMSG; do cmd dropbox add-low-priority $tag; done; cmd dropbox set-rate-limit 99999999999999; settings put global dropbox_age_seconds 0; settings put global dropbox_max_files 0;settings put global dropbox_quota_kb 0;settings put global dropbox_quota_percent 0
cmd settings put global netstats_enabled 0 
settings put global activity_starts_logging_enabled 0
settings put global autofill_logging_level 0
settings put global foreground_service_starts_logging_enabled 0
settings put global force_enable_pss_profiling 0
settings put global looper_stats 0
settings put global netstats_combine_subtype_enabled 0
settings put system haptic_feedback_enabled 0
settings put global captive_portal_detection_enabled 0

sm idle-maint run
wm tracing level critical
wm tracing size 0

pm disable com.google.android.gms/com.google.android.gms.clearcut.debug.ClearcutDebugDumpService
 pm disable com.google.android.gms/.chimera.GmsIntentOperationService
 pm disable com.google.android.gms/com.google.android.gms.mdm.receivers.MdmDeviceAdminReceiver
pm disable com.google.android.gms/com.google.android.gms.measurement.AppMeasurementService
pm disable com.google.android.gms/com.google.android.gms.measurement.AppMeasurementJobService
pm disable com.google.android.gms/com.google.android.gms.measurement.AppMeasurementReceiver
pm disable com.google.android.gms/.checkin.CheckinService
echo "applying devconf by dcx.."

device_config put device_idle inactive_to 5000;device_config put device_idle sensing_to 0;device_config put device_idle locating_to 0;device_config put device_idle location_accuracy 0;device_config put device_idle motion_inactive_to 0;device_config put device_idle idle_after_inactive_to 0;device_config put device_idle idle_pending_to 60000;device_config put device_idle max_idle_pending_to 120000;device_config put device_idle idle_pending_factor 2.0;device_config put device_idle idle_to 900000;device_config put device_idle max_idle_to 86400000;device_config put device_idle idle_factor 2.0;device_config put device_idle min_time_to_alarm 600000;device_config put device_idle max_temp_app_whitelist_duration 10000;device_config put device_idle wait_for_unlock false

device_config put alarm_manager save_battery_on_idle true
device_config put alarm_manager power_check_interval 0
device_config put alarm_manager min_futurity 0
for k_safety in safety_center_is_enabled safety_center_notifications_enabled safety_center_replace_lock_screen_icon_action safety_center_show_subpages safety_center_allow_statsd_logging; do
  device_config put privacy "$k_safety" false
done
device_config put privacy safety_center_allow_statsd_logging false
for key in adservice_system_service_enabled cobalt_logging_enabled enable_logged_topic adservice_error_logging_enabled measurement_enable_app_package_name_logging measurement_enable_source_debug_report fledge_app_package_name_logging fledge_auction_server_enable_debug_reporting fledge_auction_server_api_usage_metrics_enabled fledge_auction_server_enabled_for_report_event fledge_auction_server_enabled_for_report_impression fledge_auction_server_enabled_for_select_ads_mediation
do device_config put adservices $key false
done
device_config put runtime_native metrics.reporting-mods 0
device_config put runtime_native metrics.reporting-mods-server 0
device_config put runtime_native metrics.reporting-num-mods 0
device_config put runtime_native metrics.reporting-num-mods-server 0
device_config put tethering netstats_store_files_in_apexdata false
device_config put tethering netstats_import_legacy_target_attempts 0
device_config put activity_manager disable_app_profiler_pss_profiling true
device_config put activity_manager activity_start_pss_defer 999999999999999999
device_config put telephony max_logcat_lines 0
device_config put telephony max_logcat_lines_low_mem 0
device_config put activity_manager_native_boot use_freezer true
device_config put activity_manager use_compaction true
device_config put runtime_native_boot iorap_readahead_enable true
device_config put runtime_native_boot iorap_perfetto_enable false
device_config put settings_ui event_logging_enabled false
device_config put media media_metrics_mode 0
device_config put runtime_native metrics.write-to-statsd false
device_config put runtime_native metrics.reporting-spec ''
device_config put runtime_native metrics.reporting-spec-server ''
device_config put runtime_native usap_pool_enabled false
device_config put runtime_native use_app_image_startup_cache true
device_config put device_personalization_service enable_assistant_memory_generator true
device_config put runtime_native_boot enable_profile_system_server false
device_config put runtime_native_boot enable_profile_boot_class_path false
device_config put runtime_native_boot enable_readahead false
device_config put settings_ui event_logging_enabled false
device_config put activity_manager activity_start_pss_defer 999999999999999999
device_config put telephony max_logcat_lines 0
device_config put telephony max_logcat_lines_low_mem 0
device_config put activity_manager_native_boot use_freezer true
device_config put activity_manager use_compaction true
device_config put interaction_jank_monitor enabled false
device_config put interaction_jank_monitor trace_threshold_frame_time_millis -1
device_config put interaction_jank_monitor trace_threshold_missed_frames -1
device_config set_sync_disabled_for_tests persistent

echo ""

echo "don"