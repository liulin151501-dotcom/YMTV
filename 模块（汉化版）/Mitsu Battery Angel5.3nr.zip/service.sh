cmd notification post -S bigtext -t 'Mitsuki' tag 'Preparing...'
mitsu()
(
setprop debug.tracing.battery_stats.wifi 0
setprop debug.mdpcomp.logs 0
setprop debugtool.anrhistory 0
setprop debug.miui.perf.inspector 0
setprop debug.incremental.always_enable_read_timeouts_for_system_dataloaders 0 
setprop debug.incremental.enforce_readlogs_max_interval_for_system_dataloaders 0
setprop persist.sys.use_8bpp_alpha 1
setprop persist.sys.use_16bpp_alpha 0
setprop persist.traced.enable 0 
setprop persist.traced_perf.enable false 
setprop persist.sys.lmk.reportkills false 
setprop persist.sys.exceptionreport.support 0 
setprop persist.sys.manual.cloud.support 0 
setprop persist.sys.mdlog_dumpback 0 
setprop persist.sys.tran_alc support 0 
setprop persist.sys.trancares2r 0 
setprop persist.sys.tran.aegean.proc.error_status 0
setprop sys.wifitracing.started false
setprop debug.multiwindow.log 0 
setprop debug.necessity.log
setprop debug.sf.latch_unsignaled 1
setprop debug.sf.auto_latch_unsignaled 1
)&

(
current_props="$(getprop | cut -f1 -d ']')"
eval "$(echo "$current_props" | grep -F '[log.tag' | sed 's/\[/setprop persist./g' | sed 's/$/ S/g')"
eval "$(echo "$current_props" | grep -F '[persist.log.tag' | sed 's/\[persist./setprop /g' | sed 's/$/ S/g')"
eval "$(echo "$current_props" | grep 'log.tag' | sed 's/\[/setprop /g' | sed 's/$/ S/g')"

for a in $(cmd package list packages -s|cut -f2 -d:);do cmd deviceidle whitelist -"$a";done
cmd deviceidle enable all
cmd deviceidle force-idle deep
cmd deviceidle step deep

for db_tag in system_server system_server/Subject data_app_wtf storage_trim SYSTEM_BOOT SYSTEM_AUDIT system_server_wtf SYSTEM_LAST_KMSG; do
  cmd dropbox add-low-priority "$db_tag"
done
cmd dropbox set-rate-limit 99999999999999
settings put global dropbox_age_seconds 0
settings put global dropbox_max_files 0

for f in $(dumpsys window | grep "^  Proto:" | sed 's/^  Proto: //' | tr ' ' '\n'; dumpsys window | grep "^  Logcat:" | sed 's/^  Logcat: //' | tr ' ' '\n'); 
do wm logging disable "$f"; wm logging disable-text "$f"; done
cmd window logging stop
)&

(
atrace --async_stop
bmgr enable 0
cmd accessibility stop-trace
cmd stats clear-puller-cache
am set-stop-user-on-switch true
am clear-watch-heap all
am untrack-associations
cmd wifi set-scan-always-available disabled
cmd wifi set-verbose-logging disabled
cmd voiceinteraction set-debug-hotword-logging false
cmd input_method tracing stop
cmd connectivity set-chain3-enabled false
cmd display set-user-disabled-hdr-types 1 2 3 4
cmd display ab-logging-disable
cmd display dmd-logging-disable
cmd display dwb-logging-disable
cmd greezer debug false
cmd greezer enable true
dumpsys batterystats --reset
dumpsys batterystats --reset-all
dumpsys batterystats disable full-history
dumpsys batterystats disable no-auto-reset
dumpsys batterystats enable pretend-screen-off
cmd print set-bind-instant-service-allowed false
cmd device_policy clear-freeze-period-record
cmd autofill reset
cmd autofill set log_level off
cmd autofill set bind-instant-service-allowed false
cmd autofill set default-augmented-service-enabled 0 false
cmd autofill set max_visible_datasets 0
cmd autofill set max_partitions 0
cmd webviewupdate disable-multiprocess
cmd companiondevice disable-perm-sync
cmd companiondevice remove-perm-sync-state
cmd blob_store clear-all-sessions
cmd blob_store clear-all-blobs
cmd blob_store idle-maintenance
cmd content_capture destroy sessions
cmd content_capture set bind-instant-service-allowed false
cmd content_capture set default-service-enabled 0 false
cmd migard dump-trace false
cmd migard start-trace false
cmd migard stop-trace true
cmd migard trace-buffer-size 0
cmd miui.downscale clear-debug-apps
cmd miui.downscale disable-downscale true
cmd miui.downscale set-debug-mode false
cmd miui_embedding_window clear-fixedOri
cmd miui_step_counter_service disable
cmd miui_step_counter_service logging-disable
cmd miui_step_counter_service set-delay 999999999
cmd miui_step_counter_service trim-all
device_config put activity_manager use_compaction true
device_config set_sync_disabled_for_tests persistent
dumpsys binder_calls_stats --disable
dumpsys binder_calls_stats --disable-detailed-tracking
)&

(
logcat -P "$(pgrep *|sed 's/^/~/g')"

pm list packages -s \
 | awk -F: '{print $2}' \
 | xargs -n1 -P3 sh -c '
cmd activity service-restart-backoff disable "$1"
cmd activity set-bg-restriction-level --user 0 "$1" background_restricted
cmd activity set-foreground-service-delegate --user 0 "$1" stop
cmd activity set-ignore-delivery-group-policy "$1"
cmd activity  set-standby-bucket "$1" restricted
cmd dropbox add-low-priority "$1"
logcat -c
cmd package log-visibility "$1" --disable
cmd activity make-uid-idle --user 0 "$1" all
cmd ambient_context stop-detection 0 "$1"
cmd usagestats clear-last-used-timestamps "$1" --user 0
am clear-exit-info --user 0 all "$1"' _

cmd notification post -S bigtext -t 'Mitsuki' tag 'preparation completed,enjoy.'

am kill-all
)&

wait;mitsu applied