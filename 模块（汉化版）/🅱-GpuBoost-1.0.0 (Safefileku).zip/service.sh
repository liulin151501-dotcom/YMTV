#!/system/bin/sh

alias SP="setprop"
alias STS="settings"
alias CMD="cmd"
alias RSPT="resetprop"

SP debug.sf.enable_transaction_tracing 0
SP debug.tracing.battery_status 3
SP debug.skia.enable_reuse_scratch_textures 1
SP debug.renderengine.blur_algorithm true
SP debug.renderengine.capture_skia_ms 0
SP debug.renderengine.capture_filename ""
SP debug.renderengine.graphite true
SP debug.renderengine.restore_blur_step true
SP debug.renderengine.graphite_preview_optin true
SP debug.renderengine.skia_atrace_enabled false
SP debug.renderengine.skia_tracing_enabled false
SP debug.renderengine.skia_use_perfetto_track_events false
SP persist.sys.renderengine.maxLuminance ""
RSPT persist.sys.renderengine.maxLuminance

SP debug.sf.hwc_service_name drmfb
SP debug.hwc.compose_level 1
SP debug.hwc.force_gpu 1
SP debug.hwc.asyncdisp 1
SP debug.hwc.otf 1
SP debug.hwc.bq_count 3
SP debug.hwc.disabletonemapping false
SP debug.egl.force_msaa false
SP debug.hwui.disable_vsync false
SP debug.hwui.use_buffer_age 1
SP debug.sf.disable_backpressure 1

SP debug.drm.mode.auto 1
SP debug.sf.enable_gl_backpressure 0
SP debug.sf.disable_client_composition_cache 1
SP debug.sf.disable_hwc_overlays 0
SP debug.sf.disable_hwc 0
SP debug.sf.enable_hwc_vds 1
SP debug.sf.gpu_comp_tiling 1
SP debug.sf.predict_hwc_composition_strategy 0
SP debug.sf.hwc.min.duration 16666666
SP debug.sf.high_fps.hwc.min.duration 11111111
SP persist.sys.hwcomposer.force_gpu 1
SP persist.sys.sf.enable_hwc_vds 1
SP persist.sys.rendercomposer.enable true

CMD deviceidle disable
CMD power set-fixed-performance-mode-enabled true
CMD display set-user-disabled-hdr-types 1 2 3 4
SP debug.performance.profile 1 
SP debug.perf.tuning 1
SP debug.composition.type gpu
STS put global low_power 0
STS put global low_power_sticky 0
STS put global enable_gpu_debug_layers 0
SP debug.hwui.trace_gpu_resources false
STS put global settings_enable_monitor_phantom_procs false

am start -a AxManager.TOAST -e text "🅱️-GpuBoost 优化已激活"
