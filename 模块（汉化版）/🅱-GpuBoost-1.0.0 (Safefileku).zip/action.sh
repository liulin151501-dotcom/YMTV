#!/system/bin/sh

alias STS="settings"
alias CMD="cmd"

STS put --user 0 global activity_starts_logging_enabled 0
STS put --user 0 global always_finish_activities 0

echo "请稍候"

for f in $(dumpsys window | grep "^  Proto:" | sed 's/^  Proto: //' | tr ' ' '\n'; dumpsys window | grep "^  Logcat:" | sed 's/^  Logcat: //' | tr ' ' '\n'); do wm logging disable "$f"; wm logging disable-text "$f"; done
CMD window logging disable
CMD window logging disable-text
CMD window logging stop

CMD autofill reset
CMD autofill set log_level off
CMD autofill set bind-instant-service-allowed false
CMD autofill set default-augmented-service-enabled 0 
CMD autofill set max_visible_datasets 0
CMD autofill set max_partitions 0
CMD display ab-logging-disable
CMD display dmd-logging-disable
CMD display dwb-logging-disable
CMD voiceinteraction set-debug-hotword-logging false
CMD wifi set-verbose-logging disabled -l 0
simpleperf --log fatal --log-to-android-buffer 0
CMD wifi set-scan-always-available disabled
CMD wifi set-connected-score 60
CMD wifi set-ipreach-disconnect disabled
CMD content_capture set bind-instant-service-allowed false
CMD content_capture set default-service-enabled 0 false
CMD wifi set-network-selection-config disabled enabled -a 0
CMD wifi set-network-selection-config enabled disabled -a 0
CMD media.camera watch stop
CMD media_session dispatch stop
CMD location_time_zone_manager stop
CMD print set-bind-instant-service-allowed false
CMD role set-bypassing-role-qualification false
CMD audio reset-sound-dose-timeout
CMD audio set-ringer-mode SILENT
CMD time_zone_detector set_auto_detection_enabled false
CMD time_zone_detector set_auto_detection_enabled true
CMD wearable_sensing destroy-data-stream

STS put --user 0 global activity_manager_constants max_cached_processes=2147483647,background_settle_time=0,fgservice_min_shown_time=0,fgservice_min_report_time=0,fgservice_screen_on_before_time=0,fgservice_screen_on_after_time=0,gc_timeout=0,gc_min_interval=0,full_pss_min_interval=0,full_pss_lowered_interval=0,power_check_max_cpu_1=100,power_check_max_cpu_2=100,power_check_max_cpu_3=100,power_check_max_cpu_4=100,service_usage_interaction_time=0,usage_stats_interaction_interval=0,service_restart_duration=0,service_reset_run_duration=0,service_restart_duration_factor=0,service_min_restart_time_between=0,service_max_inactivity=0,service_bg_start_timeout=0,service_bg_activity_start_timeout=0,process_start_async=true,content_provider_retain_time=0,CUR_MAX_CACHED_PROCESSES=2147483647,CUR_MAX_EMPTY_PROCESSES=2147483647,CUR_TRIM_EMPTY_PROCESSES=0,CUR_TRIM_CACHED_PROCESSES=0

STS put --user 0 system activity_manager_constants max_cached_processes=2147483647,background_settle_time=0,fgservice_min_shown_time=0,fgservice_min_report_time=0,fgservice_screen_on_before_time=0,fgservice_screen_on_after_time=0,gc_timeout=0,gc_min_interval=0,full_pss_min_interval=0,full_pss_lowered_interval=0,power_check_max_cpu_1=100,power_check_max_cpu_2=100,power_check_max_cpu_3=100,power_check_max_cpu_4=100,service_usage_interaction_time=0,usage_stats_interaction_interval=0,service_restart_duration=0,service_reset_run_duration=0,service_restart_duration_factor=0,service_min_restart_time_between=0,service_max_inactivity=0,service_bg_start_timeout=0,service_bg_activity_start_timeout=0,process_start_async=true,content_provider_retain_time=0,CUR_MAX_CACHED_PROCESSES=2147483647,CUR_MAX_EMPTY_PROCESSES=2147483647,CUR_TRIM_EMPTY_PROCESSES=0,CUR_TRIM_CACHED_PROCESSES=0

pm disable --user 0 com.google.android.gms/com.google.android.gms.auth.managed.admin.DeviceAdminReceiver
pm disable --user 0 com.google.android.gms/com.google.android.gms.mdm.receivers.MdmDeviceAdminReceiver
pm disable --user 0 com.google.android.gms/com.google.android.gms.kids.account.receiver.ProfileOwnerReceiver

STS put --user 0 global app_standby_enabled 0
STS put --user 0 global force_background_check 0
STS put --user 0 global forced_app_standby_enabled 0
STS put --user 0 global forced_app_standby_for_small_battery_enabled 0
STS put --user 0 global force_all_apps_standby 0
STS put --user 0 global adaptive_battery_management_enabled 0

for app in $(CMD package list packages --user 0 | cut -f2 -d:); do
    am set-standby-bucket --user 0 "$app" active
    CMD appops set "$app" RUN_IN_BACKGROUND allow
    CMD appops set "$app" RUN_ANY_IN_BACKGROUND allow
    CMD appops set "$app" WAKE_LOCK allow
    CMD appops set "$app" START_FOREGROUND allow
    CMD deviceidle whitelist +"$app"
done

am start -a AxManager.TOAST -e text "🅱️-GpuBoost : 正在编译.."
CMD deviceidle disable

echo "请稍候"

i=0
success=0
failure=0

GAME_FILE="dftrgme.txt"

if [ ! -f "$GAME_FILE" ]; then
  echo "游戏列表文件 $GAME_FILE 未找到！"
  exit 1
fi

while IFS= read -r app || [ -n "$app" ]; do
  [ -z "$app" ] && continue

  # Skip jika app tidak terpasang
  if ! pm path "$app" >/dev/null 2>&1; then
    skip=$((skip+1))
    continue
  fi

  i=$((i+1))

  if pm compile -m speed-profile -f "$app" >/dev/null 2>&1; then
    success=$((success+1))
    echo "[$i] 成功 → $app"
    cmd notification post \
      -t "🅱️-[ $i:$app]" \
      -i "@android:drawable/stat_sys_download_done" \
      mytag \
      "成功 ✅ $app" >/dev/null 2>&1
  else
    failure=$((failure+1))
    echo "[$i] 失败 → $app"
    cmd notification post \
      -t "🅱️-[ $i:$app]" \
      -i "@android:drawable/stat_notify_error" \
      mytag \
      "失败 ❌ $app" >/dev/null 2>&1
  fi

  find /data/data/*/cache/* -delete 2>/dev/null
  find /data/data/*/code_cache/* -delete 2>/dev/null
  find /data/user_de/*/*/cache/* -delete 2>/dev/null
  find /data/user_de/*/*/code_cache/* -delete 2>/dev/null
  find /sdcard/Android/data/*/cache/* -delete 2>/dev/null
  pm trim-caches 999G

done < "$GAME_FILE"

echo "--------------------------------"
echo "总编译数量 : $i"
echo "成功数量        : $success"
echo "失败数量        : $failure"
echo "执行成功"

am start -a AxManager.TOAST -e text "🅱️-GpuBoost 优化成功"
cmd notification post -S bigtext -t '🅱️-GpuBoost' '✅' "优化成功"
