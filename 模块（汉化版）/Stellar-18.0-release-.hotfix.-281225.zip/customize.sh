#!/system/bin/sh

# Copyright (C) 2024-2025 Kanao
# Licensed under the Apache License, Version 2.0
# See http://www.apache.org/licenses/LICENSE-2.0

SKIPMOUNT=false
PROPFILE=true
POSTFSDATA=true
LATESTARTSERVICE=true

TOAST_PKG="bellavita.toast"
BASEDIR="/data/adb/.config/stellar"

ENVIRONMENT=""
ROOT_METHOD=""
USE_SKIPMOUNT=false
CHIPSET_ID=0

BINS="stellars vmt stellar_helper"

print_status() {
    ui_print "- $1"
    sleep 0.1
}

abort_clean() {
    ui_print " "
    ui_print "******************************************** "
    ui_print "! ERROR: $1"
    ui_print "! Installation failed! $2" 
    ui_print "******************************************** "
    ui_print " "
    abort "$1"
}

safe_extract() {
    local file_pattern="$1"
    local dest="$2"
    ui_print "- Extracting $file_pattern..."
    if ! unzip -qo "$ZIPFILE" "$file_pattern" -d "$dest"; then
        abort_clean "Failed to extract $file_pattern"
    fi
}

detect_environment() {
    ui_print "- Detecting environment..."
    
    # Cek Axeron (non-root)
    if [ -n "$AXERON" ] && [ "$AXERON" = "true" ]; then
        ENVIRONMENT="AXERON"
        BASEDIR="/data/data/com.android.shell/AxManager/plugins/stellar/.config"
        USE_SKIPMOUNT=true
        print_status "Axeron environment detected (Non-root)"
        return
    fi
    
    # Cek root environment
    if su --version > /dev/null 2>&1; then
        # Cek KSU
        if [ -d "/data/adb/ksu" ]; then
            ENVIRONMENT="KSU"
            USE_SKIPMOUNT=true
            print_status "KernelSU detected"
            return
        fi
        
        # Cek Apatch
        if [ -d "/data/adb/ap" ]; then
            ENVIRONMENT="APATCH"
            USE_SKIPMOUNT=true
            print_status "Apatch detected"
            return
        fi
        
        # Default Magisk
        ENVIRONMENT="MAGISK"
        print_status "Magisk detected"
        return
    fi
    
    abort_clean "No environment detected" "Ensure you have root or Axeron environment"
}

apply_skipmount() {
    if $USE_SKIPMOUNT; then
        print_status "Applying skip_mount for $ENVIRONMENT"
        touch "$MODPATH/skip_mount"
        if [ -f "$MODPATH/action.sh" ]; then
            rm "$MODPATH/action.sh"
            print_status "Removed action.sh"
        fi
    fi
}

install_toast_apk() {
    print_status "Installing Bellavita Toast"
    pm uninstall bellavita.toast >/dev/null 2>&1
    pm install -r $MODPATH/toast.apk >/dev/null
}

setup_directories_and_configs() {
    print_status "Setting up directories..."
    
    mkdir -p "$BASEDIR" || abort_clean "Failed to create directory"
    touch "$BASEDIR/lock" || abort_clean "Failed to create lock"
    touch "$BASEDIR/soc" || abort_clean "Failed to create soc"
    
    print_status "Creating config..."
    cat > "$BASEDIR/config.json" <<EOF
{
  "utility_tool": {
    "gms_auto": false,
    "clear_ram": false
  },
  "cpu_governors": {
    "normal": "interactive",
    "game": "performance",
    "powersave": "interactive"
  },
  "scheduler_io": {
    "normal": "",
    "game": "",
    "powersave": ""
  },
  "battery_saving": {
    "disable_network": false,
    "ultra_saving": false,
    "bypass_charging": false
  },
  "advanced_dvfs": {
    "cpu_limit": 100,
    "gpu_limit": 100
  },
  "downscaling": {
    "scale": 1.0
  },
  "devmode": {
    "debug_logging": false
  },
  "ai_configuration": {
    "master_enabled": false
  }
}
EOF
}

identify_chipset() {
    print_status "Identifying chipset..."
    
    if [ -d /sys/kernel/ged/hal ]; then CHIPSET_ID=1
    elif [ -d /sys/class/kgsl/kgsl-3d0/devfreq ] || [ -d /sys/devices/platform/kgsl-2d0.0/kgsl ]; then CHIPSET_ID=2
    elif [ -d /sys/kernel/tegra_gpu ]; then CHIPSET_ID=7
    fi
    
    if [ $CHIPSET_ID -eq 0 ]; then
        local SOC_PROP_LIST="
        ro.board.platform ro.soc.model ro.hardware ro.chipname
        ro.hardware.chipname ro.vendor.soc.model.external_name
        ro.vendor.qti.soc_name ro.vendor.soc.model.part_name ro.vendor.soc.model"
        
        local SOC_STRING
        for prop in $SOC_PROP_LIST; do
            SOC_STRING="$SOC_STRING $(getprop "$prop")"
        done
        
        case "$SOC_STRING" in
            *mt*|*MT*) CHIPSET_ID=1 ;;
            *sm*|*qcom*|*SM*|*QCOM*|*Qualcomm*) CHIPSET_ID=2 ;;
            *exynos*|*Exynos*|*EXYNOS*|*universal*|*samsung*|*erd*|*s5e*) CHIPSET_ID=3 ;;
            *Unisoc*|*unisoc*|*ums*) CHIPSET_ID=4 ;;
            *gs*|*Tensor*|*tensor*) CHIPSET_ID=5 ;;
            *Intel*|*intel*) CHIPSET_ID=6 ;;
            *kirin*) CHIPSET_ID=8 ;;
        esac
    fi
    
    case "$CHIPSET_ID" in
        1) print_status "MediaTek" ;;
        2) print_status "Snapdragon" ;;
        3) print_status "Exynos" ;;
        4) print_status "Unisoc" ;;
        5) print_status "Google Tensor" ;;
        6) print_status "Intel" ;;
        7) print_status "Nvidia Tegra" ;;
        8) print_status "Kirin" ;;
        *) print_status "Universal" ;;
    esac
    
    echo "$CHIPSET_ID" > "$BASEDIR/soc"
}

copy_binaries() {
    print_status "Copying binaries..."
    
    local SRC_BIN="$MODPATH/system/bin"
    local DEST_BIN=""
    
    case $ENVIRONMENT in
        "AXERON")
            DEST_BIN="/data/data/com.android.shell/AxManager/bin"
            mkdir -p "$DEST_BIN"
            ;;
        "KSU")
            DEST_BIN="/data/adb/ksu/bin"
            mkdir -p "$DEST_BIN"
            ;;
        "APATCH")
            DEST_BIN="/data/adb/ap/bin"
            mkdir -p "$DEST_BIN"
            ;;
        "MAGISK")
            DEST_BIN="/data/adb/modules/stellar/system/bin"
            ;;
    esac
    
    if [ -n "$DEST_BIN" ]; then
        for bin in $BINS; do
            if [ -f "$SRC_BIN/$bin" ]; then
                # Hapus dulu binary lama
                rm -f "$DEST_BIN/$bin"
                # Copy binary baru
                cp "$SRC_BIN/$bin" "$DEST_BIN/$bin"
                chmod 777 "$DEST_BIN/$bin"
                print_status "Copied: $bin → $DEST_BIN"
            fi
        done
    fi
}

set_permissions() {
    print_status "Setting permissions..."
    
    if [ "$ENVIRONMENT" = "MAGISK" ]; then
        set_perm_recursive "$MODPATH" 0 0 0755 0644
        set_perm_recursive "$MODPATH/system/bin" 0 2000 0755 0755
    fi
}

finalize_installation() {
    RAND_MSG=$((RANDOM % 8 + 1))
    case $RAND_MSG in
        1) print_status "Fall star from heaven -stellar" ;;
        2) print_status "Void Feeling The Negative Effect." ;;
        3) print_status "Against The Law, Dont Soft." ;;
        4) print_status "Emotion Anger From Stellar." ;;
        5) print_status "Feed Me Donate Wen." ;;
        6) print_status "Try Be Honest, May Can Safe You (?)" ;;
        7) print_status "Anyone Would Seen This?!" ;;
        8) print_status "Premium Vvip Gaming 6969?!" ;;
    esac
    
    print_status "Join our channel for updates!"
    sleep 1
    am start -a android.intent.action.VIEW -d "https://t.me/hosshi_prjkt" >/dev/null 2>&1
}

# Main
detect_environment
apply_skipmount
install_toast_apk
setup_directories_and_configs
identify_chipset
copy_binaries
set_permissions
finalize_installation