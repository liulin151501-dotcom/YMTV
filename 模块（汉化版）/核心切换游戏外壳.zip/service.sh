#!/system/bin/sh
MODDIR="${0%/*}"
CORE=/data/local/tmp/core
GAMEFILE="$CORE/gamelist.txt"
INTERVAL=15

while [ "$(getprop sys.boot_completed)" != "1" ]; do
  sleep 2
done
while ! pidof com.android.systemui >/dev/null; do
  sleep 2
done

mkdir -p "$CORE"

if [ -f "$CORE/gamelist.txt" ]; then
  cp "$CORE/gamelist.txt" "$MODDIR/gamelist.txt"
elif [ -f "$MODDIR/gamelist.txt" ]; then
  cp "$MODDIR/gamelist.txt" "$CORE/gamelist.txt"
fi

am start -a AxManager.TOAST -e text "核心切换游戏外壳正在运行中"

cmdwrap() { /system/bin/cmd "$@"; }
setg() { settings put global "$1" "$2"; }
sets() { settings put system "$1" "$2"; }
delg() { settings delete global "$1" 2>/dev/null; }

get_foreground_pkg() {
  cmd activity stack list \
    | awk -F'[/{]' '/0,.*true/{print $3; exit}'
}

#fps capture from DroidEverything
get_max_fps() {
  dumpsys display | grep -o -E 'fps=[0-9]+(\.[0-9]+)?' | cut -d'=' -f2 | sort -nr | head -n1 | awk '{printf("%d\n", ($1+0.5)/1)}'
}

MAX_FPS="$(get_max_fps)"
[ -z "$MAX_FPS" ] && MAX_FPS=60
MAX_FPS="${MAX_FPS}.0"

MIN_FPS="60.0"

########################################
# 游戏模式
########################################
apply_game_mode() {
  # renderer (do not force, align stack)
RENDERER="$(getprop debug.hwui.renderer)"
if [ "$RENDERER" = "skiavk" ]; then
  setprop debug.hwui.renderer skiavk
  setprop debug.renderengine.backend skiavkthreaded
  setprop debug.stagefright.renderengine.backend skiavkthreaded
  setprop debug.renderengine.vulkan true
else
  setprop debug.hwui.renderer skiagl
  setprop debug.renderengine.backend skiaglthreaded
  setprop debug.stagefright.renderengine.backend skiaglthreaded
  setprop debug.renderengine.vulkan false
fi

# EGL / HWUI
setprop debug.egl.blobcache.multifile true
setprop debug.egl.callstack false
setprop debug.egl.finish false
setprop debug.egl.force_msaa false

# SurfaceFlinger – 性能模式
setprop debug.sf.buffer_fence_tracker false
setprop debug.sf.enable_egl_image_tracker false
setprop debug.sf.latch_unsignaled false
setprop debug.sf.disable_backpressure 0

# ADPF / scheduler hints – 启用
setprop debug.sf.enable_adpf_cpu_hint true
setprop debug.sf.send_early_power_session_hint true
setprop debug.sf.send_late_power_session_hint true
setprop debug.sf.enable_planner_prediction true
setprop debug.sf.use_frame_rate_priority 1
setprop debug.sf.predict_hwc_composition_strategy 1

# Choreographer / HWUI
setprop debug.choreographer.frameslog false
setprop debug.choreographer.frametime false
setprop debug.choreographer.janklog false
setprop debug.choreographer.vsync false

setprop debug.hwui.capture_skp_enabled false
setprop debug.hwui.filter_test_overhead false
setprop debug.hwui.level 0

# CPU / frame budget – 激进
setprop debug.hwui.target_cpu_time_percent 70
setprop debug.hwui.render_ahead 1
setprop debug.hwui.use_hint_manager true
setprop debug.hwui.skip_empty_damage true
setprop debug.hwui.use_buffer_age true
setprop debug.hwui.use_partial_updates true

# MediaTek guard
if [ -n "$(getprop ro.mediatek.version.release)" ]; then
  setprop debug.mediatek.disp_decompress 1
  setprop debug.mediatek.appgamepq 1
  setprop debug.mediatek.appgamepq_compress 1
  setprop debug.mediatek.game_pq_enable 1

fi
  # 刷新率
  sets peak_refresh_rate "$MAX_FPS"
  sets min_refresh_rate  "$MAX_FPS"
  
  # 动画（快）
  setg window_animation_scale 0.15
  setg transition_animation_scale 0.15
  setg animator_duration_scale 0.15

  # 电源 / 热管理
  cmdwrap power set-adaptive-power-saver-enabled false
  cmdwrap activity memory-factor set 2
  cmdwrap power set-mode 0
  cmdwrap display set-match-content-frame-rate-pref 2
  cmdwrap thermalservice override-status 0

  # 帧节奏 / 调度提示
  setg game_driver_all_apps 1
  setg updatable_driver_all_apps 1

  # 减少后台干扰
  cmdwrap activity set-deterministic-uid-idle true || :
}

########################################
# 普通模式
########################################
apply_normal_mode() {
# EGL / HWUI – 保守
setprop debug.egl.blobcache.multifile true
setprop debug.egl.callstack false
setprop debug.egl.finish false
setprop debug.egl.force_msaa false

# SurfaceFlinger – 均衡
setprop debug.sf.buffer_fence_tracker false
setprop debug.sf.enable_egl_image_tracker false
setprop debug.sf.latch_unsignaled false
setprop debug.sf.disable_backpressure 0

# ADPF / scheduler hints – 关闭（省电、降温）
setprop debug.sf.enable_adpf_cpu_hint false
setprop debug.sf.send_early_power_session_hint false
setprop debug.sf.send_late_power_session_hint true
setprop debug.sf.enable_planner_prediction false
setprop debug.sf.use_frame_rate_priority 0
setprop debug.sf.predict_hwc_composition_strategy 0

# Choreographer / HWUI – 无性能分析
setprop debug.choreographer.frameslog false
setprop debug.choreographer.frametime false
setprop debug.choreographer.janklog false
setprop debug.choreographer.vsync false

setprop debug.hwui.capture_skp_enabled false
setprop debug.hwui.filter_test_overhead false
setprop debug.hwui.level 0

# CPU / frame budget – 均衡
setprop debug.hwui.target_cpu_time_percent 35
setprop debug.hwui.render_ahead 0
setprop debug.hwui.use_hint_manager false
setprop debug.hwui.skip_empty_damage true
setprop debug.hwui.use_buffer_age true
setprop debug.hwui.use_partial_updates true

# MediaTek guard – 普通（厂商默认）
if [ -n "$(getprop ro.mediatek.version.release)" ]; then
  setprop debug.mediatek.disp_decompress 1
  setprop debug.mediatek.appgamepq 0
  setprop debug.mediatek.appgamepq_compress 1
  setprop debug.mediatek.game_pq_enable 0
fi
  # 刷新率
  sets peak_refresh_rate "$MIN_FPS"
  sets min_refresh_rate  "$MIN_FPS"
  
  # 动画（平滑 / 省电）
  setg window_animation_scale 0.3
  setg transition_animation_scale 0.3
  setg animator_duration_scale 0.3

  # 电源 / 热管理恢复
  cmdwrap power set-fixed-performance-mode-enabled false
  cmdwrap power set-adaptive-power-saver-enabled true
  cmdwrap display set-match-content-frame 1
  cmdwrap thermalservice override-status 1
  cmdwrap activity memory-factor set 0

  # 清除游戏驱动强制
  delg game_driver_all_apps
  delg updatable_driver_all_apps

  # 恢复空闲行为
  cmdwrap activity set-deterministic-uid-idle false || :
}

########################################
# 循环
########################################
LAST_STATE=""

while true; do
  FG="$(get_foreground_pkg)"
  [ -z "$FG" ] && sleep "$INTERVAL" && continue

  if [ -f "$GAMEFILE" ] && grep -qx "$FG" "$GAMEFILE"; then
    if [ "$LAST_STATE" != "game" ]; then
    am start -a AxManager.TOAST -e text "进入游戏模式"
    cmd notification post -t GameShell bigtext 游戏模式
      apply_game_mode
      LAST_STATE="game"
    fi
  else
    if [ "$LAST_STATE" != "normal" ]; then
    am start -a AxManager.TOAST -e text "进入普通模式"
    cmd notification post -t GameShell bigtext 普通模式
      apply_normal_mode
      LAST_STATE="normal"
    fi
  fi

  sleep "$INTERVAL"
done
