a="$(echo 2^30|bc)"                                   # 计算 2^30，结果存入 a（约 1GB，用作 loadingBoost 参数）
b="$(getprop ro.build.version.release)"               # 获取 Android 版本号（如 13、14）
for c in $(dumpsys game|grep -Eo 'package [^ ]+|Name:[^ ]+'|sed 's/.* //;s/Name://'); do
  # 遍历所有游戏包名或名称（从 dumpsys game 提取）
  cmd device_config put game_overlay "$c" "mode=2,downscaleFactor=$1,useAngle=false,fps=144,loadingBoost=$a"
  # 设置游戏覆盖层配置：模式2、缩放因子$1、禁用 ANGLE、120fps、加载加速内存=$a

  if [ "$b" = 13 ]; then
    cmd game set --mode 2 --downscale "$1" --fps 120 "$c"
    # Android 13：使用旧版 game 命令设置模式、缩放、帧率
  elif [ "$b" -gt 13 ]; then
    cmd game mode 2 "$c"
    # Android 14+：使用新版简写命令设置游戏模式
  fi
done
