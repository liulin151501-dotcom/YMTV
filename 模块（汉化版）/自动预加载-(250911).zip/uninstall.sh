#!/system/bin/sh
exec>/dev/null 2>&1
rm -rf /storage/emulated/0/Android/media/.jpg
rm -rf /storage/emulated/0/Android/media/.txt
pkill -f sh