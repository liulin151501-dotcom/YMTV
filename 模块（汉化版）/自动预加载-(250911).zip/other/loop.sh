# 降低 CPU 负载
taskset -ap 1 $$
iorenice $$ 7 idle
renice -n 19 -p $$
# 降低 CPU 负载

sleep 10;sync

# 检测前台应用（重要变量）
top_app="$(nice -n 19 cmd activity stack list|nice -n 19 grep 0,0.*visible=true|nice -n 19 tr -d ' '|nice -n 19 cut -f1 -d/|nice -n 19 cut -f2 -d:)"
# 检测前台应用（重要变量）

# 检测是否在玩游戏
if [ "$current_app" != "$top_app" ];then current_app="$top_app"
  if grep -o "$top_app" /storage/emulated/0/Android/media/.txt;then

    # 自动预加载
    # 会占用内存使用
    su -lp 2000 -c "cmd notification post -t 正在预加载 -i file:///storage/emulated/0/Android/media/.jpg -I file:///storage/emulated/0/Android/media/.jpg preload $top_app"
    cmd notification post -t 正在预加载 -i file:///storage/emulated/0/Android/media/.jpg -I file:///storage/emulated/0/Android/media/.jpg preload $top_app
    for package_assets in $(find "/data/user/0/$top_app" -type f;find "/storage/emulated/0/Android/data/$top_app" -type f;find "$(dumpsys package "$top_app"|grep -o codePath=.*|sed 's/codePath=//')" -type f);do
      cat "$package_assets"
    done
    su -lp 2000 -c "cmd notification post -t 预加载完成 -i file:///storage/emulated/0/Android/media/.jpg -I file:///storage/emulated/0/Android/media/.jpg preload $top_app"
    cmd notification post -t 预加载完成 -i file:///storage/emulated/0/Android/media/.jpg -I file:///storage/emulated/0/Android/media/.jpg preload $top_app
  else
    if [ "$current_mode" != "powersave" ];then current_mode="powersave"
      cmd activity force-stop com.android.shell
    fi
    # 会占用内存使用
    # 自动预加载

  fi
fi
# 检测是否在玩游戏
