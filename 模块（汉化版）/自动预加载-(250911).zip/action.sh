#!/system/bin/sh
PID="$(pgrep -f ${0%/*}/service.sh)" uptime=$(cut -d. -f1 /proc/uptime) memory=$(cat /proc/meminfo|tr -s \ )
if echo ${0%/*}|grep Ax;then
  a()(sleep 0.01;printf "$@")
else
  a()(sleep 0.01;echo "$@")
fi>/dev/null
a "${0%/*}"
a " "
a "***********************************************"
a "$(grep name= ${0%/*}/module.prop|cut -f2 -d=)"
a "$(grep version= ${0%/*}/module.prop|cut -f2 -d=) by $(grep author= ${0%/*}/module.prop|cut -f2 -d=)"
a "***********************************************"
a " "
a "- 服务进程 ($PID)"
a "- CPU 使用率: $(ps -eo %cpu,pid|grep "$PID"|grep -ov "$PID"|tr -d \ )%%"
a "- 常驻内存使用: $(ps -eo res,pid|grep "$PID"|grep -ov "$PID"|tr -d \ )"
a "- 共享内存使用: $(ps -eo shr,pid|grep "$PID"|grep -ov "$PID"|tr -d \ )"
a " "
a "· 操作系统: Android $(getprop ro.build.version.release)"
a "· 型号: $(getprop ro.product.manufacturer) $(getprop ro.product.model)"
a "· 内核: $(uname -r|cut -f1,2,3 -d-)"
a "· 运行时间: $((uptime/3600)) 小时, $((uptime%3600/60)) 分钟"
a "· 应用数量: $(cmd package list packages -s --user 0|wc -l) (系统), $(cmd package list packages -3 --user 0|wc -l) (第三方)"
a "· 分辨率:$(wm size|cut -d: -f2)"
a "· 主题: $(getprop ro.build.fingerprint|cut -f5 -d\/|cut -f1 -d:)"
a "· 终端: $(dumpsys window|grep mTopFullscreenOpaqueWindowState|cut -f7 -d\ |cut -f1 -d/)"
a "· CPU: $(getprop ro.soc.manufacturer) $(getprop ro.soc.model)"
a "· GPU:$(dumpsys SurfaceFlinger|grep GLES:|cut -f2 -d,)"
a "· 内存: $((($(echo "$memory"|grep MemTotal|cut -f2 -d\ )-$(echo "$memory"|grep MemAvailable|cut -f2 -d\ ))/1024))MiB / $(($(echo "$memory"|grep MemTotal|cut -f2 -d\ )/1024))MiB"
a " "
