#!/system/bin/sh
export PATH="/system/bin";while [ $(getprop sys.boot_completed) != 1 ];do sleep 5;done;exec>/dev/null 2>&1;for a in /proc/sys/kernel/*panic*;do chmod 644 "$a";echo 0>"$a";chmod 444 "$a";done;MODDIR=${0%/*}

(# 预加载所有库文件
if getprop ro.product.cpu.abi|grep 64;then
  cat /*/lib64/*
else
  cat /*/lib/*
fi
)&

(# loop.sh 循环器
while :;do
  . "$MODDIR/other/loop.sh"
done
)&
