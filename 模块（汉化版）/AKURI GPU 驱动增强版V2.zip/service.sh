#!/system/bin/sh

# ----------------- 优化部分 -----------------
  setprop debug.hwui.renderer vulkan
  setprop debug.renderengine.vulkan true
  setprop debug.renderengine.backend skiavkthreaded
  setprop debug.renderengine.capture_skia_ms 0
  setprop debug.renderengine.skia_atrace_enabled true
  setprop debug.hwui.skia_use_perfetto_track_events true
  setprop debug.hwui.skia_tracing_enabled true
  setprop debug.tracing.ctl.hwui.skia_tracing_enabled true
  setprop debug.tracing.ctl.hwui.skia_use_perfetto_track_events true
  setprop debug.tracing.ctl.renderengine.skia_tracing_enabled true
  setprop debug.tracing.ctl.renderengine.skia_use_perfetto_track_events true  
  setprop debug.renderengine.skia_tracing_enabled true
  setprop debug.renderengine.skia_use_perfetto_track_events true

# 等待直到启动完成
while [ -z "$(getprop sys.boot_completed)" ]; do
	sleep 20
done

chmod 755 /data/data/com.android.shell/AxManager/plugins/akuri/akuri"
nice -n -20 "$akuri" > /dev/null 2>&1
