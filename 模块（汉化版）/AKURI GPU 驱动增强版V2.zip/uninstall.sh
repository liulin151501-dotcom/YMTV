#!/bin/sh

# Uninstall toast
pm uninstall bellavita.toast


