ui_print "***************************************"
ui_print "- 设备型号         : $(getprop ro.product.board)"
sleep 0.2
ui_print "- 制造商          : $(getprop ro.product.manufacturer)"
sleep 0.2
ui_print "- Android 版本     : $(getprop ro.build.version.release)"
sleep 0.2
ui_print "- 内核版本        : $(uname -r) "
sleep 0.2
ui_print "- 处理器          : $(getprop ro.product.board) "
sleep 0.2
ui_print "- CPU 信息        : $(getprop ro.hardware) "
sleep 0.2
ui_print "- 内存大小        : $(free | grep Mem | awk '{print $2}') "
sleep 0.2
ui_print "***************************************"
sleep 0.2
    if [ -n "$AXERON" ] && [ "$AXERON" = "true" ]; then
        ENVIRONMENT="AXERON"
        BASEDIR="/data/data/com.android.shell/AxManager/plugins/akuri/akurii"
        USE_SKIPMOUNT=true
        ui_print "检测到 Axeron 环境（无 Root）"
        return
    fi
if [ -d "/data/adb/ksu" ]; then
    ROOT_METHOD="KernelSU"
    if command -v su &>/dev/null; then
        ROOT_VERSION=$(su --version 2>/dev/null | cut -d ':' -f 1)
    fi
elif [ -d "/data/adb/magisk" ]; then
    ROOT_METHOD="Magisk"
    if command -v magisk &>/dev/null; then
        ROOT_VERSION=$(magisk -V)
fi
ui_print "- 使用 ${ROOT_METHOD} (${ROOT_VERSION}) 进行安装"
sleep 0.5
ui_print " 正在安装 Toast 应用.."
if pm list packages | grep -q "bellavita.toast"; then
    pm uninstall "bellavita.toast" >/dev/null 2>&1
fi

if ! pm install "$MODPATH/Toast.apk" >/dev/null 2>&1; then

    pm install "$MODPATH/Toast.apk" >/dev/null 2>&1
else

    cmd install "$MODPATH/Toast.apk" >/dev/null 2>&1
fi
rm -f "$MODPATH/Toast.apk"

# === 权限设置 ===
ui_print "- 设置可执行权限..."
ui_print "- 解压模块文件"
unzip -o "$ZIPFILE" 'system/*' -d $MODPATH >&2
sleep 0.5
ui_print "- 成功于 $(date "+%d, %b - %H:%M %Z") !!"
