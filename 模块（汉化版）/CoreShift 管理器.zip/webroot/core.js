let out;

document.addEventListener("DOMContentLoaded", () => {
  out = document.getElementById("output");
});

function log(s) {
  if (!out) return;
  out.textContent += s + "\n";
  out.scrollTop = out.scrollHeight;
}

function openTerminal() {
  const overlay = document.getElementById("terminal-overlay");
  if (!overlay || !out) return;

  overlay.classList.remove("hidden");
  out.textContent = "";
}

function closeTerminal() {
  const overlay = document.getElementById("terminal-overlay");
  if (overlay) overlay.classList.add("hidden");
}

function execCmd(cmd) {
  openTerminal();

  if (!window.ksu || typeof window.ksu.exec !== "function") {
    log("错误: KernelSU 桥接不可用");
    return;
  }

  try {
    const r = window.ksu.exec(cmd);
    if (r !== undefined) log(String(r));
  } catch (e) {
    log("执行错误: " + e);
  }
}

function getVal(id) {
  const el = document.getElementById(id);
  if (!el) {
    log("错误: 缺少输入项");
    throw new Error("missing input");
  }

  const v = el.value.trim();
  if (!v) {
    log("错误: 输入为空");
    throw new Error("empty input");
  }
  return v;
}

function compile() {
  const scope = document.getElementById("compile-scope").value;
  const mode  = document.getElementById("compile-mode").value;
  execCmd(`compile ${scope} ${mode}`);
}

function execPkg(sub) {
  const p = getVal("pkg-input");
  execCmd(`pkg ${sub} ${p}`);
}

function execOp(mode) {
  const p = getVal("op-input");
  execCmd(mode ? `op ${mode} ${p}` : `op ${p}`);
}

function execNet(mode) {
  const p = getVal("net-input");
  execCmd(`net ${mode} ${p}`);
}