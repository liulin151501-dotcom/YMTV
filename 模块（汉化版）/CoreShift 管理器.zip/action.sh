infodev() {
exec 2>/dev/null

CORE="/data/local/tmp/core"
mkdir -p "$CORE"

NOW=$(date +%s)

OUT_TTL=60
DUMPSYS_TTL=300

OUT_CACHE="$CORE/infodev.out"
GFX_CACHE="$CORE/gfx.cache"

if [ -f "$OUT_CACHE" ]; then
  read ts < "$OUT_CACHE"
  if [ $((NOW - ts)) -lt "$OUT_TTL" ]; then
    sed '1d' "$OUT_CACHE"
    return
  fi
fi

get_cache() {
  f="$1"; ttl="$2"; shift 2
  if [ -f "$f" ]; then
    read ts < "$f"
    if [ $((NOW - ts)) -lt "$ttl" ]; then
      sed '1d' "$f"
      return
    fi
  fi
  { echo "$NOW"; "$@"; } > "$f"
  sed '1d' "$f"
}

gfx="$(get_cache "$GFX_CACHE" "$DUMPSYS_TTL" dumpsys gfxinfo com.android.systemui)"

read _ u n s i w irq sirq st _ < /proc/stat
sleep 0.25
read _ u2 n2 s2 i2 w2 irq2 sirq2 st2 _ < /proc/stat

idle=$(( (i2 + w2) - (i + w) ))
total=$(( (u2 + n2 + s2 + i2 + w2 + irq2 + sirq2 + st2) -
          (u + n + s + i + w + irq + sirq + st) ))

cpu_pct=$(( total > 0 ? 100 * (total - idle) / total : 0 ))
[ "$cpu_pct" -lt 10 ] && load_label="$(cut -d' ' -f1 /proc/loadavg)" || load_label="${cpu_pct}%"

sum=0 cnt=0
for f in /sys/devices/system/cpu/cpu*/cpufreq/scaling_cur_freq; do
  [ -r "$f" ] || continue
  v=$(cat "$f")
  sum=$((sum+v))
  cnt=$((cnt+1))
done
[ "$cnt" -gt 0 ] && cpu_freq="$((sum/cnt/1000)) MHz" || cpu_freq="N/A"

memgb=$(awk '/MemTotal/ {printf "%.2f",$2/1024/1024; exit}' /proc/meminfo)

refresh="$(settings get system peak_refresh_rate)"
[ "$refresh" = "null" ] && refresh="$(settings get system min_refresh_rate)"
refresh="${refresh%%.*}"
[ -n "$refresh" ] && refresh="$refresh Hz" || refresh="unknown"

missed_frame="$(dumpsys SurfaceFlinger | grep -m1 'Total missed frame' | awk '{print $NF}')"

missed_vsync="$(printf '%s\n' "$gfx" | grep -m1 'Number Missed Vsync' | cut -d: -f2 | sed 's/^ *//')"
render_90="$(printf '%s\n' "$gfx" | grep '90th' | grep -v gpu | head -n1 | cut -d: -f2 | sed 's/^ *//')"
gpu_90="$(printf '%s\n' "$gfx" | grep '90th' | grep gpu | head -n1 | cut -d: -f2 | sed 's/^ *//')"

therm="$(cmd thermalservice dump |
  awk '
    /^Current temperatures from HAL:/ {on=1; next}
    on && /^[A-Z]/ {exit}
    on {print}
  '
)"

get_modules() {
  module status 2>/dev/null \
    | grep -v -i '^[[:space:]]*modules' \
    | sed '/^[[:space:]]*$/d'
}

cpu_temp="$(printf '%s\n' "$therm" | grep -E 'mName=CPU(0)?,' | head -n1 | cut -d= -f2 | cut -d, -f1 | cut -d. -f1)"
gpu_temp="$(printf '%s\n' "$therm" | grep -E 'mName=GPU(0)?,' | head -n1 | cut -d= -f2 | cut -d, -f1 | cut -d. -f1)"
bat_temp="$(printf '%s\n' "$therm" | grep -Ei 'mName=battery,' | head -n1 | cut -d= -f2 | cut -d, -f1 | cut -d. -f1)"
skin_temp="$(printf '%s\n' "$therm" | grep -Ei 'mName=skin,' | head -n1 | cut -d= -f2 | cut -d, -f1 | cut -d. -f1)"

{
echo "$NOW"
echo "仪表盘 ~"
echo "安卓版本            : $(getprop ro.build.version.release)"
echo "内存总量            : ${memgb} GB"
echo "CPU 负载            : $load_label"
echo "CPU 频率            : $cpu_freq"
echo "刷新率              : $refresh"
echo "SELinux             : $(getenforce)"

echo ""
echo "帧统计 ~"
echo "丢帧数              : ${missed_frame:-0}"
echo "丢失 Vsync          : ${missed_vsync:-0}"
echo "90% 渲染耗时        : ${render_90:-0ms}"
echo "90% GPU 耗时        : ${gpu_90:-0ms}"

if [ -n "${cpu_temp}${gpu_temp}${bat_temp}${skin_temp}" ]; then
  echo ""
  echo "温度 (°C) ~"
  [ -n "$cpu_temp" ] && echo "CPU 温度            : $cpu_temp"
  [ -n "$gpu_temp" ] && echo "GPU 温度            : $gpu_temp"
  [ -n "$bat_temp" ] && echo "电池温度            : $bat_temp"
  [ -n "$skin_temp" ] && echo "外壳温度            : $skin_temp"
fi

mods="$(get_modules)"

if [ -n "$mods" ]; then
  echo ""
  echo "CoreShift 守护进程 ~"
  echo "$mods" | while IFS=':' read -r name state; do
    state="${state# }"
    [ "$state" != "running" ] && continue

    cname="$(echo "$name" | awk '
      {
        sub(/^ *core/, "", $0)
        printf "Core%s%s", toupper(substr($0,1,1)), substr($0,2)
      }
    ')"

    s="$(echo "$state" | awk '{print toupper(substr($0,1,1)) substr($0,2)}')"
    echo "$(echo "$cname                  " | cut -c1-19) : $s"
  done
fi
} > "$OUT_CACHE"

sed '1d' "$OUT_CACHE"
}

infodev