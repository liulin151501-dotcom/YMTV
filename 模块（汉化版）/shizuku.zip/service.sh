#!/system/bin/sh
exec>/dev/null 2>&1
while :;do sleep 5
  if ! pidof shizuku_server;then
    /data/local/tmp/shizuku_starter
  fi
done