#!/system/bin/sh
# Shizuku 启动器回滚脚本
# 删除已复制到以下 shell 目录的 shizuku_starter 文件：
STARTER_PATH="/storage/emulated/0/HᔰXMOĐ • Shizuku Injection (βeta◇) [AxM][NoRoot].zip/starter"
STARTER_PATH="/storage/emulated/0/Download/HᔰXMOĐ • Shizuku Injection (βeta◇) [AxM][NoRoot].zip/starter"
STARTER_PATH="/storage/emulated/0/Download/Telegram/HᔰXMOĐ • Shizuku Injection (βeta◇) [AxM][NoRoot].zip/starter"
STARTER_PATH="/data/data/com.android.shell/shizuku_starter"
# 删除 shizuku_starter 进程的 CMD： 
[ -f "$STARTER_PATH" ] && rm -f "$STARTER_PATH"

exit 0
