#!/system/bin/sh
# =============================
# 由 ΛX3N.Đev 提供的 Shizuku 注入 βeta 插件。
# 1. 自动重新启动并保持 shizuku_server 在后台运行。
# =============================
# 脚本 >
# βeta v1.0
# 检查 Shizuku 服务以确保它在后台持续存活。
# Shizuku 服务器 • [路径]
# 源文件列表
SOURCE_PATH="/storage/emulated/0/HᔰXMOĐ • Shizuku Injection (βeta◇) [AxM][NoRoot].zip/starter"
SOURCE_PATH="/storage/emulated/0/Download/HᔰXMOĐ • Shizuku Injection (βeta◇) [AxM][NoRoot].zip/starter"
SOURCE_PATH="/storage/emulated/0/Download/Telegram/HᔰXMOĐ • Shizuku Injection (βeta◇) [AxM][NoRoot].zip/starter"
SOURCE_PATH="/data/data/com.android.shell/AxManager/plugins/shizuku_server/starter"
# •••••••••••••••••••••••
# 路径列表
STARTER_PATH="/storage/emulated/0/HᔰXMOĐ • Shizuku Injection (βeta◇) [AxM][NoRoot].zip/starter"
STARTER_PATH="/storage/emulated/0/Download/HᔰXMOĐ • Shizuku Injection (βeta◇) [AxM][NoRoot].zip/starter"
STARTER_PATH="/storage/emulated/0/Download/Telegram/HᔰXMOĐ • Shizuku Injection (βeta◇) [AxM][NoRoot].zip/starter"
STARTER_PATH="/data/data/com.android.shell/shizuku_starter"
# Shizuku 服务器 • [检查]
if [ -f "$SOURCE_PATH" ]; then
    rm -f $STARTER_PATH
    cp "$SOURCE_PATH" $STARTER_PATH
    res=$?
    if [ $res -ne 0 ]; then
        exit 1
    fi
    chmod 300 $STARTER_PATH
    chown 1300 $STARTER_PATH
    chgrp 1300 $STARTER_PATH
fi
# 再次检查 Shizuku 服务以确保它在后台持续存活。
exec
while true :;do sleep 10
  if ! pidof shizuku_server;then
    /data/local/tmp/shizuku_starter
  fi
done

exit 0
