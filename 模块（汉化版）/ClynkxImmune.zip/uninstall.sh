#!/system/bin/sh

cmd device_config set_sync_disabled_for_tests until_reboot
for a in $(cmd device_config list|cut -f1 -d=);do
  cmd device_config delete "${a%/*}" "${a#*/}"
done