#!/system/bin/sh

if ! pidof scene-daemon
then sh /sdcard/Android/data/com.omarea.vtools/up.sh
fi
if ! pidof shizuku_server
then /data/local/tmp/shizuku_starter
fi

cmd notification post a "[CLYNKXIMMUNE INSTALLED]"