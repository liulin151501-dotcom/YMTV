#!/system/bin/sh

last_state=""

while :; do
    screen=$(cmd deviceidle get screen 2>/dev/null | awk '{print $NF}')

    if [ "$screen" = "off" ]; then
        current_state="空闲"
    else
        current_state="活跃"
    fi

    # 仅在状态变化时执行
    if [ "$current_state" != "$last_state" ]; then
        if [ "$current_state" = "空闲" ]; then
            cmd deviceidle force-idle >/dev/null 2>&1
        else
            cmd deviceidle unforce >/dev/null 2>&1
        fi
        last_state="$current_state"
    fi

    sleep 5
done

# 禁用日志
getprop | grep '\[log.tag' | while read -r line;do prop_name=$(echo "$line" | sed -n 's/^$$log.tag[^]]*$$\].*/\1/p');if [ -n "$prop_name" ]; then setprop "$prop_name" "S";fi;done;getprop | grep '\[persist.log.tag' | while read -r line; do prop_name=$(echo "$line" | sed -n 's/^$$persist.log.tag[^]]*$$\].*/\1/p');if [ -n "$prop_name" ]; then setprop "$prop_name" "S";fi;done

for a in --reset --disable --disable-detailed-tracking;do dumpsys binder_calls_stats $a;done
for b in --clear --stop-testing; do dumpsys procstats $b;done
for c in ab-logging-disable dwb-logging-disable dmd-logging-disable; do cmd display $c;done
for procstats_option in --clear --stop-testing;do dumpsys procstats "$procstats_option";done

# 内存压缩
pm list packages -U | awk '{print $2,$4}' | while read -r p u; do
      [ -n "$p" ] && [ -n "$u" ] || continue
      am compact "$p" "$u" some
      am compact "$p" "$u" full
      
      
# 窗口日志
dumpsys window 2>/dev/null | grep -E "^  (Proto|Logcat):" | sed -E 's/^  (Proto|Logcat): //' | tr ' ' '\n' | while read -r f; do
        if [ -n "$f" ]; then
            wm logging disable "$f"
            wm logging disable-text "$f"
        fi
    done
    cmd power set-mode 1
    cmd power set-adaptive-power-saver-enabled true
    
# 内存压缩
exec 2>/dev/null;for a in $(ps -o pid,user|grep u0_|cut -f1 -du);do cmd activity compact full "$a"&cmd activity compact native full "$a"&done;wait;cmd activity compact system

# 禁用跟踪
(for a in $(find /sys/kernel/tracing -type f 2>/dev/null);do
  echo 0>"$a"
done
atrace --async_stop>/dev/null
cmd accessibility stop-trace
cmd activity trace-ipc stop
cmd migard dump-trace false
cmd migard start-trace false
cmd migard stop-trace true
cmd migard trace-buffer-size 0
cmd input_method tracing stop
cmd statusbar tracing stop
cmd window tracing size 0
cmd window tracing stop
_ disable tracing)&

# 一些设置以改善你的电池
settings put global battery_stats_constants track_cpu_active_cluster_time=false,read_binary_cpu_time=0,proc_state_cpu_times_read_delay_ms=5000000000,kernel_uid_readers_throttle_time=1,external_stats_collection_rate_limit_ms=0,battery_level_collection_delay_ms=30000000000,max_history_buffer_kb=0,max_history_files=0,track_cpu_times_by_proc_state=false,track_cpu_active_cluster_time=false,read_binary_cpu_time=false,max_history_files=0,max_history_buffer_kb=0,phone_on_external_stats_collection=false
settings put global binder_calls_stats "sampling_interval=600000000,detailed_tracking=disable,enabled=false,upload_data=false"
settings put global device_idle_constants inactive_to=15000,sensing_to=0,locating_to=0,location_accuracy=20.0,motion_inactive_to=0,idle_after_inactive_to=0,idle_pending_to=60000,max_idle_pending_to=120000,idle_pending_factor=2.0,idle_to=900000,max_idle_to=86400000,idle_factor=2.0,min_time_to_alarm=600000,max_temp_app_whitelist_duration=10000
for a in $(strings /system/lib*/libgui.so 2>/dev/null | grep debug.sf. | sort -u); do setprop "$a" false; done 
settings put global app_standby_enabled 1
settings put global adaptive_battery_management_enabled 1
settings put global cached_apps_freezer 1
settings put system haptic_feedback_disable 1
settings put secure screensaver_activate_on_dock 0
settings put secure screensaver_enabled 0
settings put global battery_saver_device_specific_constants advertise_is_enabled=false,enable_datasaver=false,enable_night_mode=true,disable_launch_boost=false,disable_vibration=true,disable_animation=true,disable_soundtrigger=true,defer_full_backup=true,defer_keyvalue_backup=true,enable_firewall=false,location_mode=2,gps_mode=2,enable_brightness_adjustment=false,adjust_brightness_factor=0.5,force_all_apps_standby=true,force_background_check=true,disable_optional_sensors=true,disable_aod=false,enable_quick_doze=true
heavy_use_factor=0.8,moderate_use_factor=0.5,max_job_min_storage_not_low_count=4,max_job_max_bg_on_normal=4,max_job_total_on_normal=6,max_job_total_off_normal=10,max_job_total_off_moderate=10,max_job_total_on_low=2,max_job_total_on_moderate=4,quota_frac_executing_time=0.9,min_ready_jobs_count=3,standby_and_sync_min_interval_ms=600000,conn_congestion_delay_ms=2000,conn_min_stable_time_ms=2000,min_linear_backoff_time_ms=10000
settings put secure setting_app_startup_anim_speed 0-315-350
  settings put secure long_press_timeout 180
  settings put secure multi_press_timeout 200
  settings put global activity_starts_logging_enabled 0
settings put global autofill_logging_level 0
settings put global foreground_service_starts_logging_enabled 0
settings put global force_enable_pss_profiling 0
settings put global looper_stats 0
settings put global netstats_combine_subtype_enabled 0

# 一些设备配置
device_config put runtime_native metrics.reporting-mods 0
device_config put runtime_native metrics.reporting-mods-server 0
device_config put runtime_native metrics.reporting-num-mods 0
device_config put runtime_native metrics.reporting-num-mods-server 0
device_config put tethering netstats_store_files_in_apexdata false
device_config put tethering netstats_import_legacy_target_attempts 0
device_config put activity_manager disable_app_profiler_pss_profiling true
device_config put activity_manager activity_start_pss_defer 999999999999999999
device_config put telephony max_logcat_lines 0
device_config put telephony max_logcat_lines_low_mem 0
device_config put activity_manager_native_boot use_freezer true
cmd device_config override core_graphics com.android.graphics.hwui.flags.clip_shader true
    cmd device_config override core_graphics com.android.graphics.hwui.flags.draw_region false
    cmd device_config override core_graphics com.android.graphics.hwui.flags.animate_hdr_transitions fa
    
    
# 设备空闲
dumpsys deviceidle force-idle && dumpsys deviceidle enable all && settings put global device_idle_constants "light_after_inactive_to=0,light_pre_idle_to=5000,light_idle_to=3600000,light_max_idle_to=43200000,locating_to=5000,location_accuracy=1000,inactive_to=0,sensing_to=0,motion_inactive_to=0,idle_after_inactive_to=0,idle_to=21600000,max_idle_to=172800000,quick_doze_delay_to=5000,min_time_to_alarm=300000,deep_idle_to=7200000,deep_max_idle_to=86400000,deep_idle_maintenance_max_interval=86400000,deep_idle_maintenance_min_interval=43200000,deep_still_threshold=0,deep_idle_prefetch=1,deep_idle_prefetch_delay=300000,deep_idle_delay_factor=2,deep_idle_factor=3"

# GMS 休眠，感谢 kazuyoo
cmd package list packages -a | cut -f2 -d: | grep "gms" | grep -v "revanced"
appops set "$gms" ACCESS_RESTRICTED_SETTINGS ignore
    appops set "$gms" ACTIVITY_RECOGNITION deny
    appops set "$gms" ACTIVITY_RECOGNITION_SOURCE deny
    appops set "$gms" ASSIST_STRUCTURE ignore
    appops set "$gms" AUTO_REVOKE_PERMISSIONS_IF_UNUSED ignore
    appops set "$gms" BODY_SENSORS deny
    appops set "$gms" ACTIVITY_RECOGNITION_SOURCE ignore
appops set "$gms" FOREGROUND_SERVICE_SPECIAL_USE ignore
appops set "$gms" GET_ACCOUNTS ignore
appops set "$gms" INSTANT_APP_START_FOREGROUND ignore
appops set "$gms" MONITOR_LOCATION ignore
appops set "$gms" RUN_ANY_IN_BACKGROUND ignore
appops set "$gms" RUN_IN_BACKGROUND ignore
appops set "$gms" RUN_USER_INITIATED_JOBS ignore
appops set "$gms" INTERACT_ACROSS_PROFILES ignore
appops set "$gms" START_FOREGROUND ignore
appops set "$gms" SYSTEM_EXEMPT_FROM_HIBERNATION ignore
appops set "$gms" SYSTEM_EXEMPT_FROM_POWER_RESTRICTIONS ignore
appops set "$gms" WAKE_LOCK ignore
appops set "$gms" LOADER_USAGE_STATS ignore
    cmd connectivity set-background-networking-enabled-for-uid "$gms" false
    cmd netpolicy remove restrict-background-whitelist "$gms"
    cmd netpolicy add restrict-background-blacklist "$gms"
    cmd netpolicy remove app-idle-whitelist "$gms"
    cmd activity clear-ignore-delivery-group-policy "$gms"
    cmd activity service-restart-backoff disable "$gms"
    cmd activity set-standby-bucket "$gms" 50
    cmd connectivity set-package-networking-enabled false "$gms"
    cmd package art clear-app-profiles "$gms"
    cmd sdk_sandbox stop "$gms"
    cmd package grant com.google.android.gms android.permission.READ_CONTACTS
cmd package grant com.google.android.gms android.permission.WRITE_CONTACTS
settings put secure assistant 0
    settings put secure smartspace 0
    settings put global google_core_control 0
    settings put global hotword_detection_enabled 0
    settings put secure systemui.google.opa_enabled 0
    settings put secure adaptive_connectivity_enabled 0
    settings put system gearhead:driving_mode_settings_enabled 0
    settings put global gms_checkin_timeout_min 120
   
    
        # 内核跟踪大小，感谢 koneko
    (for a in /sys/kernel/tracing/buffer_size_kb /sys/kernel/tracing/saved_cmdlines_size; do
        if [ -w "$a" ]; then echo 1 > "$a"; fi
    done)
    
    # surfaceflinger 来自 cmd 调整
    for a in $(echo "$getprop"|grep -E 'debug.sf.enable_.*layer|debug.sf.disable.*backpressure');do
  setprop "$a" true
done
for b in $(echo "$getprop"|grep -E 'debug.sf.disable_.*layer|debug.sf.enable.*backpressure');do
  setprop "$b" false
done
c="$(dumpsys display|grep -Eo 'fps=[^.]+'|cut -f2 -d=|sort -n|uniq|tail -n1)"
d="$((1000000000/c))"
e="$(echo "$d*1.968+1"|bc|cut -f1 -d.)"
setprop debug.sf.early.app.duration "$e"
setprop debug.sf.earlyGl.app.duration "$e"
setprop debug.sf.high_fps.early.app.duration "$e"
setprop debug.sf.high_fps.earlyGl.app.duration "$e"
setprop debug.sf.high_fps.late.app.duration "$e"
setprop debug.sf.late.app.duration "$e"
f="$(echo "$d*1.512+1"|bc|cut -f1 -d.)"
setprop debug.sf.early.sf.duration "$f"
setprop debug.sf.earlyGl.sf.duration "$f"
setprop debug.sf.high_fps.early.sf.duration "$f"
setprop debug.sf.high_fps.earlyGl.sf.duration "$f"
setprop debug.sf.high_fps.late.sf.duration "$f"
setprop debug.sf.late.sf.duration "$f"
g="$(echo "-$d*1.968-1"|bc|cut -f1 -d.)"
setprop debug.sf.earlyGl_app_phase_offset_ns "$g"
setprop debug.sf.early_app_phase_offset_ns "$g"
setprop debug.sf.high_fps_earlyGl_app_phase_offset_ns "$g"
setprop debug.sf.high_fps_early_app_phase_offset_ns "$g"
setprop debug.sf.high_fps_late_app_phase_offset_ns "$g"
setprop debug.sf.late_app_phase_offset_ns "$g"
h="$(echo "-$d*1.512-1"|bc|cut -f1 -d.)"
setprop debug.sf.earlyGl_phase_offset_ns "$h"
setprop debug.sf.early_phase_offset_ns "$h"
setprop debug.sf.high_fps_earlyGl_phase_offset_ns "$h"
setprop debug.sf.high_fps_early_phase_offset_ns "$h"
setprop debug.sf.high_fps_late_phase_offset_ns "$h"
setprop debug.sf.late_phase_offset_ns "$h"

# 低电量模式
settings put global low_power 1

# 动画缩放
settings put global window_animation_scale 0.3
    settings put global transition_animation_scale 0.3
    settings put global animator_duration_scale 0.3

# cmd
cmd settings put global security_center_pc_save_mode_data '{"a":0,"b":-1,"c":0,"d":0}' default
  cmd settings put system POWER_BALANCED_MODE_OPEN 1
  cmd settings put system POWER_PERFORMANCE_MODE_OPEN 0
  cmd settings put system POWER_SAVE_MODE_OPEN 0
  cmd settings put system POWER_SAVE_PRE_HIDE_MODE enhance
  cmd settings put system cloud_schedboost_enable false
  cmd settings put system speed_mode 0
  cmd thermalservice override-status 1
cmd display ab-logging-disable
cmd display dwb-logging-disable
cmd migard dump-trace false
cmd migard start-trace false
cmd migard stop-trace true
cmd statusbar tracing stop
cmd autofill set log_level off
cmd activity clear-watch-heap
cmd activity untrack-associations
cmd blob_store idle-maintenance
cmd companiondevice remove-inactive-associations
cmd blob_store clear-all-sessions
cmd companiondevice clear-association-memory-cache
cmd looper_stats disable
cmd activity clear-debug-app
cmd jobscheduler monitor-battery off
cmd settings put global netstats_enabled 0 
sm defragment run
sm idle-maint run
wm tracing level critical
wm tracing size 0
dumpsys batterystats enable pretend-screen-off
cmd print set-bind-instant-service-allowed false
cmd device_policy clear-freeze-period-record
cmd autofill reset
cmd autofill set log_level off
cmd autofill set bind-instant-service-allowed false
cmd autofill set default-augmented-service-enabled 0 false
cmd autofill set max_visible_datasets 0
cmd autofill set max_partitions 0
cmd webviewupdate disable-multiprocess
cmd companiondevice remove--associations
cmd companiondevice clear-association-memory-cache
cmd blob_store clear-all-sessions
cmd blob_store clear-all-blobs
cmd blob_store idle-maintenance
cmd content_capture destroy sessions
cmd content_capture set bind-instant-service-allowed false
cmd content_capture set default-service-enabled 0 false
cmd migard dump-trace false
cmd migard start-trace false
cmd migard stop-trace true
cmd migard trace-buffer-size 0
cmd miui.downscale clear-debug-apps
cmd miui.downscale disable-downscale true
cmd miui.downscale set-debug-mode false
cmd miui_embedding_window clear-fixedOri
cmd miui_step_counter_service disable
cmd miui_step_counter_service logging-disable
cmd miui_step_counter_service set-delay 999999999
cmd miui_step_counter_service trim-all
for sys_pkg in $(pm list packages -s | cut -f2 -d:); do
  am set-bg-restriction-level "$sys_pkg" hibernation
  am service-restart-backoff disable "$sys_pkg"
  am set-standby-bucket "$sys_pkg" restricted
  am kill "$sys_pkg"
  cmd app_hibernation set-state --global true "$sys_pkg"
  cmd tare set-vip 0 "$sys_pkg" false
  am set-inactive --user 0  "$sys_pkg" true
  for a in $(cmd package list packages --user 0|cut -f2 -d:);do
  cmd connectivity set-package-networking-enabled true "$a"
done
for b in $(cmd package list packages --user 0 -U|cut -f3 -d:);do
  cmd connectivity set-background-networking-enabled-for-uid "$b" true
  cmd netpolicy remove restrict-background-whitelist "$b"
  cmd netpolicy remove restrict-background-blacklist "$b"
  cmd netpolicy remove app-idle-whitelist "$b"
done
cmd connectivity set-chain3-enabled false
cmd wifi set-ipreach-disconnect disabled
cmd wifi set-network-selection-config disabled enabled -a 0
cmd wifi set-network-selection-config enabled disabled -a 0
cmd wifi set-scan-always-available disabled
for a in $(cmd settings list global|grep _constants=|cut -f1 -d=);do
 cmd settings delete global "$a"
done
cmd settings put global activity_starts_logging_enabled 0
  cmd settings put global kernel_cpu_thread_reader num_buckets=0,collected_uids=,minimum_total_cpu_usage_millis=999999999
  
fstrim -v /cache
fstrim -v /system
fstrim -v /vendor
fstrim -v /data
fstrim -v /preload
fstrim -v /product
fstrim -v /metadata
fstrim -v /odm
fstrim -v /data/dalvik-cache
fstrim -v /system_ext
sm defragment abort
sm idle-maint abort
sm fstrim /cache
sm fstrim /data
sm fstrim /preload
sm fstrim /system
sm fstrim /vendor
sm idle-maint abort >/dev/null 2>&1 &
wm tracing level critical
wm tracing size 0

for a in $(cmd package list packages --user 0 -s|grep -Eiv 'youtube|theme'|cut -f2 -d:);do
  rm -rf "/storage/emulated/0/Android/data/$a"
  rm -rf "/storage/emulated/0/Android/media/.sosp/$a"
  rm -rf "/storage/emulated/0/Android/Android/obb/$a"
done
for b in $(cmd package list packages --user 0|cut -f2 -d:);do
  cmd activity clear-ignore-delivery-group-policy "$b"
  cmd usagestats clear-last-used-timestamps "$b"
  cmd usagestats delete-package-data "$b"
done

# Ping 优化器
for a in netpolicy_override_enabled netpolicy_quota_enabled netpolicy_quota_frac_jobs netpolicy_quota_frac_multipath netpolicy_quota_limited netpolicy_quota_unlimited netstats_augment_enabled netstats_combine_subtype_enabled netstats_dev_bucket_duration netstats_dev_delete_age netstats_dev_persist_bytes netstats_dev_rotate_age netstats_enabled netstats_global_alert_bytes netstats_poll_interval netstats_sample_enabled netstats_time_cache_max_age netstats_uid_bucket_duration netstats_uid_delete_age netstats_uid_persist_bytes netstats_uid_rotate_age netstats_uid_tag_bucket_duration netstats_uid_tag_delete_age netstats_uid_tag_persist_bytes netstats_uid_tag_rotate_age network_avoid_bad_wifi network_default_daily_multipath_quota_bytes network_location_opt_in network_metered_multipath_preference network_preference network_recommendations_enabled network_recommendations_package network_scorer_app network_scoring_provisioned network_scoring_ui_enabled network_switch_notification_daily_limit network_switch_notification_rate_limit_millis network_watchlist_enabled network_watchlist_last_report_time;do
  settings put global "$a" 0
done
settings put global wifi_wakeup_enabled "0"
settings put global network_avoid_bad_wifi "0"
settings put global wifi_country_code "GB"
settings put global wifi_framework_scan_interval_ms "0"
settings put global wifi_supplicant_scan_interval_ms "5000"
settings put global wifi_watchdog_poor_network_test_enabled "0"
settings put global wifi_scan_always_enabled "0"
settings put global wifi_scan_throttle_enabled "0"
cmd wifi set-verbose-logging disabled -l 0
cmd wifi set-connected-score 60
for a in $(cmd package list packages --user 0|cut -f2 -d:);do
  cmd connectivity set-package-networking-enabled true "$a"
done
for b in $(cmd package list packages --user 0 -U|cut -f3 -d:);do
  cmd connectivity set-background-networking-enabled-for-uid "$b" true
  cmd netpolicy remove restrict-background-whitelist "$b"
  cmd netpolicy remove restrict-background-blacklist "$b"
  cmd netpolicy remove app-idle-whitelist "$b"
done
settings put global network_recommendations_enabled 0
settings put global preferred_network_mode 9

# 提升多任务
cmd activity memory-factor set 1
  cmd device_config put activity_manager low_swap_threshold_percent 0.6
settings put global app_standby_enabled 1
settings put global adaptive_battery_management_enabled 1
cmd appops set * RUN_IN_BACKGROUND ignore 2>/dev/null
cmd appops set * RUN_ANY_IN_BACKGROUND ignore 2>/dev/null
cmd activity idle-maintenance 2>/dev/null

taskset -ap 1 $$
ionice -c 3 -n 7 $$
iorenice $$ 7 idle
renice -n 19 -p $$

# Skiagl 来自 kazuyoo 
setprop debug.hwui.renderer skiagl
  setprop debug.renderengine.vulkan false
  setprop debug.renderengine.backend skiaglthreaded
  setprop debug.renderengine.capture_skia_ms 0
  setprop debug.renderengine.skia_atrace_enabled false
  setprop debug.hwui.skia_use_perfetto_track_events false
  setprop debug.hwui.skia_tracing_enabled false
  setprop debug.tracing.ctl.hwui.skia_tracing_enabled false
  setprop debug.tracing.ctl.hwui.skia_use_perfetto_track_events false
  setprop debug.tracing.ctl.renderengine.skia_tracing_enabled false
  setprop debug.tracing.ctl.renderengine.skia_use_perfetto_track_events false  
  setprop debug.renderengine.skia_tracing_enabled false
  setprop debug.renderengine.skia_use_perfetto_track_events false
