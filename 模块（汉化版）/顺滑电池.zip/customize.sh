echo "你好！我看到你正在 axeron 中执行这个模块。"
sleep 1
echo "我很高兴！"
sleep 0.5
exho "正在安装.. AWHWBDJDBSMSJAKALQO"
sleep 0.5
echo "完成"
echo "再见"
