#!/system/bin/sh

# === 日志重定向（强烈建议）===
LOG="/data/local/tmp/preload.log"
exec >> "$LOG" 2>&1
echo "[$(date)] 预加载脚本启动"

# === 初始化 ===
MODDIR=${0%/*}
# alias cmd=/system/bin/cmd  # 可省略

# 初始前台应用检测
initial_top_app=$(cmd activity stack list 2>/dev/null | grep -m1 '0,0.*=true' | awk -F'[/{}]' '{print $3}')
[ -n "$initial_top_app" ] && cmd activity force-stop "$initial_top_app"

cmd settings put secure speed_mode_enable 1 default

# 内存计算
mem_total_kb=$(grep MemTotal /proc/meminfo | awk '{print $2}')
file_limit=$((mem_total_kb / 46656))

# 降低自身优先级（可选）
renice 19 $$ >/dev/null 2>&1

# 主循环
current_app=""
current_mode=""
while :; do
  # 前台应用检测
  top_app=$(dumpsys window windows 2>/dev/null | grep -E 'mCurrentFocus|mFocusedApp' | grep -o '/[^ }]*' | head -n1 | awk -F'/' '{print $NF}')
  [ -z "$top_app" ] && top_app=$(cmd activity stack list 2>/dev/null | grep -m1 '0,0.*=true' | awk -F'[/{}]' '{print $3}')

  if [ "$current_app" != "$top_app" ] && [ -n "$top_app" ]; then
    current_app="$top_app"
    echo "[$(date)] 当前前台: $top_app"

    PERFLIST_PATH="/storage/emulated/0/Android/perflist.txt"
    if [ -f "$PERFLIST_PATH" ] && grep -Fqm1 "$top_app" "$PERFLIST_PATH"; then
      NOTIFY_ICON="file:///storage/emulated/0/Android/media/.apl.jpg"
      cmd notification post -t "正在预加载" -i "$NOTIFY_ICON" -I "$NOTIFY_ICON" apl "$top_app"

      # 预加载路径
      app_data_dir="/data/user/0/$top_app"
      ext_data_dir="/storage/emulated/0/Android/data/$top_app"
      code_path=$(dumpsys package "$top_app" 2>/dev/null | grep -m1 'codePath=' | sed 's/.*codePath=//;s/ .*//')
      search_paths="$app_data_dir $ext_data_dir"
      [ -n "$code_path" ] && search_paths="$search_paths $code_path"

      # 查找文件并预加载
      find_cmd="find $search_paths -maxdepth 5 -type f -size -50M -print0 2>/dev/null"
      sorted_files=$(eval "$find_cmd" | xargs -0 du -b 2>/dev/null | sort -nr | head -n "$file_limit" | awk '{$1=""; sub(/^ /,""); print}')

      max_jobs=20
      job_count=0
      for f in $sorted_files; do
        dd if="$f" of=/dev/null bs=1M >/dev/null 2>&1 &
        ((job_count++))
        if ((job_count >= max_jobs)); then
          wait -n
          ((job_count--))
        fi
      done
      wait

      cmd notification post -t "预加载完成" -i "$NOTIFY_ICON" -I "$NOTIFY_ICON" apl "$top_app"

      if [ "$current_mode" != "performance" ]; then
        current_mode="performance"
        # 温和清理后台
        cmd activity idle --user 0 >/dev/null 2>&1
      fi
    else
      if [ "$current_mode" != "battery" ]; then
        current_mode="battery"
        cmd activity force-stop com.android.shell >/dev/null 2>&1
      fi
    fi
  fi

  sleep 10
done
