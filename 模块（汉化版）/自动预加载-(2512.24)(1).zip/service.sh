#!/system/bin/sh
exec>/dev/null 2>&1;if [ -z "$AXERON" ];then sleep 1m;fi;while [ $(getprop sys.boot_completed) != 1 ];do sleep 5;done
MODDIR=${0%/*};for a in /proc/sys/kernel/*panic*;do echo 0>"$a";done;nohup $MODDIR/other/loop.sh&disown