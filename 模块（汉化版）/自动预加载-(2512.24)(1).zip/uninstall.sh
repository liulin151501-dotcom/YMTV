#!/system/bin/sh
cmd notification post un Uninstalled
su -lp 2000 -c "cmd notification post un Uninstalled"