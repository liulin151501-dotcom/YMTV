CORE=/data/local/tmp/core
[ -d "$CORE" ] && exit 0
mkdir -p $CORE
settings put global battery_stats_constants "track_cpu_times_by_proc_state=false,track_cpu_active_cluster_time=false,read_binary_cpu_time=false,max_history_files=0,max_history_buffer_kb=0,phone_on_external_stats_collection=false"
settings put global appop_history_parameters "mode=0,baseIntervalMillis=0,intervalMultiplier=0"
settings put global binder_calls_stats "enabled=false,detailed_tracking=false,upload_data=false,track_screen_state=false,track_calling_uid=false,track_screen_interactive=false,collect_latency_data=false,ignore_battery_status=false,max_call_stats_count=0"
settings put global battery_tip_constants "battery_tip_enabled=false"
settings put global dropbox_age_seconds 0; settings put global dropbox_max_files 0; settings put global dropbox_quota_kb 0; settings put global dropbox_quota_percent 0
settings put global statsd_logging_enabled 0; settings put global media_event_logging_enabled 0; settings put global sampling_profiler_lifetime 0; settings put global anr_show_background 0; settings put global send_action_app_error 0
settings put global captive_portal_mode 0;settings put global captive_portal_detection_enabled 0
setprop persist.heapprofd.enable 0;setprop persist.traced_perf.enable 0; setprop persist.traced.enable 0; setprop persist.simpleperf.profile_app_expiration_time -1; setprop persist.simpleperf.profile_app_uid ""
setprop persist.log.tag E; getprop | grep '\[persist.log.tag' | sed -n 's/^\[\(persist.log.tag[^]]*\)\].*/\1/p' | grep -v '^$' | xargs -r -n1 -P8 sh -c 'setprop "$1" E' sh
device_config put activity_manager_native_boot modern_queue_enabled true
device_config put runtime_native use_app_image_startup_cache true
device_config put runtime_native metrics.write-to-statsd false
device_config put runtime_native_boot disable_lock_profiling true
device_config put runtime_native_boot enable_uffd_gc_2 true
device_config put runtime_native_boot use_generational_gc true
device_config put runtime_native_boot iorap_readahead_enable true
device_config put runtime_native_boot iorap_perfetto_enable false
device_config put lmkd_native thrashing_limit_critical 0
device_config put netd_native parallel_lookup true
device_config put netd_native sort_nameservers true
device_config put netd_native doh false
device_config put nnapi_native telemetry_enable false
device_config put storage_native_boot smart_idle_maint_enabled true
device_config put surface_flinger_native_boot SkiaTracingFeature__use_skia_tracing false
echo "渲染配置"
echo "[+] 音量加   : 使用 SkiaVK 渲染器"
echo "[-] 音量减 : 使用 SkiaGL 渲染器"
echo

volume_key() {
  getevent -l | while read -r l; do
    case "$l" in
      *KEY_VOLUMEUP*)   echo UP; break ;;
      *KEY_VOLUMEDOWN*) echo DOWN; break ;;
    esac
  done
}

case "$(volume_key)" in
  UP)
    echo skiavk > "$CORE/render.txt"
    ;;
  DOWN)
    echo skiagl > "$CORE/render.txt"
    ;;
esac
