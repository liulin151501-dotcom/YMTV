#!/system/bin/sh

S1=$(cat /proc/softirqs 2>/dev/null)
sleep 1
S2=$(cat /proc/softirqs 2>/dev/null)

printf "%s\n===SEP===\n%s\n" "$S1" "$S2" | awk -v SEP="===SEP===" '
$0==SEP { phase=2; next }
$0=="" { next }

phase!=2 {
  if ($1=="CPU") { cpu_count = NF-1; next }
  name=$1
  for(i=2;i<=NF;i++) A[name,i-1]=$i+0
  next
}

{
  if ($1=="CPU") next
  name=$1
  total=0; per=""
  for(i=2;i<=NF;i++){
    v2=$i+0; v1=A[name,i-1]+0
    d=v2-v1
    total+=d
    per = per (i==2? "" : ",") d
  }
  T[name]=total
  P[name]=per
  list[++n]=name
}

END{
  printf "%-12s | %7s | %6s\n", "TYPE", "TOTAL", "CPU-AVG"
  printf "%-12s-+-%7s-+-%6s\n", "------------", "-------", "--------"

  # sort types by total desc
  for(i=1;i<=n;i++){
    for(j=i+1;j<=n;j++){
      if (T[list[j]] > T[list[i]]) { tmp=list[i]; list[i]=list[j]; list[j]=tmp }
    }
  }

  limit = (n<6? n:6)

  for(i=1;i<=limit;i++){
    k=list[i]

    # compute avg from per-CPU values
    split(P[k], arr, ",")
    sum=0
    count=0
    for (j in arr){
      sum += arr[j]
      count++
    }
    avg = (count>0 ? sum/count : 0)

    printf "%-12s | %7d | %6.1f\n", k, T[k], avg
  }
}'