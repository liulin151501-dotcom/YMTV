rm -r /data/local/tmp/core
settings delete global battery_stats_constants
settings delete global appop_history_parameters
settings delete global binder_calls_stats
settings delete global battery_tip_constants
settings delete global dropbox_age_seconds
settings delete global dropbox_max_files
settings delete global dropbox_quota_kb
settings delete global dropbox_quota_percent
settings delete global statsd_logging_enabled
settings delete global media_event_logging_enabled
settings delete global sampling_profiler_lifetime
settings delete global anr_show_background
settings delete global send_action_app_error
settings delete global captive_portal_mode
settings delete global captive_portal_detection_enabled

setprop persist.heapprofd.enable ""
setprop persist.simpleperf.profile_app_expiration_time ""
setprop persist.simpleperf.profile_app_uid ""
setprop persist.log.tag I
getprop | grep '\[persist.log.tag' \
  | sed -n 's/^\[\(persist.log.tag[^]]*\)\].*/\1/p' \
  | grep -v '^$' \
  | xargs -r -n1 -P8 sh -c 'setprop "$1" I' sh