#!/system/bin/sh
command -v resetprop >/dev/null 2>&1 || exit 0
RP="resetprop -n"

$RP persist.sys.strictmode.disable 1
$RP persist.android.strictmode 0
$RP ro.kernel.checkjni 0
$RP ro.kernel.android.checkjni 0
$RP persist.radio.adb_log_on 0
$RP persist.vendor.radio.adb_log_on 0
$RP persist.ims.disableDebugLogs 1
$RP persist.vendor.log.tel_log_ctrl 0
$RP persist.vendor.mtklog.enable 0
$RP persist.vendor.sys.mtklog.disable 1
$RP vendor.mtklog.enable 0

$RP debug.atrace.tags.enableflags 0
$RP debug.egl.traceGpuCompletion 0
$RP debug.egl.trace 0
$RP debug.hwui.skia_tracing_enabled 0
$RP debug.egl.blobcache.multifile true
$RP debug.egl.callstack false
$RP debug.egl.finish false
$RP debug.egl.force_msaa false
$RP debug.atrace.user_initiated 0

$RP debug.rs.precision rs_rp_imprecise
$RP debug.rs.profile false
$RP debug.rs.debug false
$RP debug.rs.visual 0
$RP debug.tflite.trace 0
$RP debug.ocl.trace 0
$RP debug.mtk_tflite.vlog 0
$RP debug.nn.vlog 0
$RP debug.gpunn.enable_profiler false

$RP debug.sf.buffer_fence_tracker false
$RP debug.sf.enable_egl_image_tracker false
$RP debug.sf.enable_adpf_cpu_hint false
$RP debug.sf.latch_unsignaled false
$RP debug.sf.disable_backpressure 0
$RP debug.sf.enable_planner_prediction true

$RP debug.choreographer.frameslog false
$RP debug.choreographer.frametime false
$RP debug.choreographer.janklog false
$RP debug.choreographer.vsync false

$RP debug.hwui.capture_skp_enabled false
$RP debug.hwui.filter_test_overhead false
$RP debug.hwui.level 0
$RP debug.hwui.overdraw false
$RP debug.hwui.profile false
$RP debug.hwui.show_dirty_regions false
$RP debug.hwui.show_layers_updates false
$RP debug.hwui.show_non_rect_clip hide
$RP debug.hwui.skia_use_perfetto_track_events false
$RP debug.hwui.target_cpu_time_percent 60
$RP debug.hwui.skip_empty_damage true
$RP debug.hwui.use_buffer_age true
$RP debug.hwui.use_partial_updates true
$RP debug.hwui.use_hint_manager true

$RP debug.angle.validation false
$RP debug.art.monitor.app false
$RP debug.assert 0
$RP debug.c2.use_dmabufheaps 1
$RP debug.checkjni 0
$RP debug.debuggerd.wait_for_debugger false
$RP debug.debuggerd.wait_for_gdb false
$RP debug.generate-debug-info false
$RP debug.graphics.gpu.profiler.perfetto false
$RP debug.sys.looper_stats_enabled false
$RP debug.traceview-buffer-size-mb 0

$RP debug.contacts.ksad 0
$RP debug.cp2.scan_all_packages 0
$RP debug.force_low_ram false
$RP debug.force_remoteinput_history false
$RP debug.layout false

$RP debug.stagefright.enableshaping 0
$RP debug.stagefright.experiments 0
$RP debug.stagefright.omx-debug 0
$RP debug.stagefright.profilecodec 0
$RP debug.stagefright.rtp false
$RP debug.stagefright.swcodec 0

$RP debug.surfacecontrol.log 0
$RP debug.surfaceview.log 0
$RP debug.synclog 0
$RP debug.track-associations 0
$RP debug.velocitytracker.alt 0
$RP debug.vulkan.enable_callback false
$RP debug.orientation.log false

$RP debug.incremental.enable_read_timeouts_after_install 0
$RP debug.incremental.always_enable_read_timeouts_for_system_dataloaders 0
$RP debug.incremental.enforce_readlogs_max_interval_for_system_dataloaders 0

$RP debug.perf_cpu_time_max_percent 0
$RP debug.perf_event_max_sample_rate 1
$RP debug.perf_event_mlock_kb 0

$RP log.tag S
$RP log.tag.APM_AudioPolicyManager S