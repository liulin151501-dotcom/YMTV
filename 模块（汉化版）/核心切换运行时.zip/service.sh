#!/system/bin/sh
MODDIR=${0%/*}
CORE=/data/local/tmp/core
CMD=/system/bin/cmd
PROP=/system/bin/setprop
c() { "$CMD" "$@"; }
s() { "$PROP" "debug.$1" "$2"; }
t() { timeout 0.1 "$@"; }

iorenice $$ 7 idle
renice -n 19 -p $$

props() {
 s setup.state Completed
 
 if [ "$(cat "$CORE/render.txt" 2>/dev/null)" = "skiavk" ]; then s hwui.renderer skiavk; s stagefright.renderengine.backend skiavkthreaded; s renderengine.backend skiavkthreaded; s renderengine.vulkan true
 else
  s hwui.renderer skiagl; s stagefright.renderengine.backend skiaglthreaded; s renderengine.backend skiaglthreaded; s renderengine.vulkan false
 fi

s atrace.tags.enableflags 0; s egl.traceGpuCompletion 0; s egl.trace 0; s hwui.skia_tracing_enabled 0; s egl.blobcache.multifile true; s egl.callstack false; s egl.finish false; s egl.force_msaa false; s atrace.user_initiated 0

s rs.precision rs_rp_imprecise; s rs.profile false; s rs.debug false; s rs.visual 0; s tflite.trace 0; s ocl.trace 0; s mtk_tflite.vlog 0; s nn.vlog 0; s gpunn.enable_profiler false

s sf.buffer_fence_tracker false; s sf.enable_egl_image_tracker false; s sf.enable_adpf_cpu_hint false; s sf.latch_unsignaled false; s sf.disable_backpressure 0; s sf.enable_planner_prediction true

s choreographer.frameslog false; s choreographer.frametime false; s choreographer.janklog false; s choreographer.vsync false; s hwui.capture_skp_enabled false; s hwui.filter_test_overhead false; s hwui.level 0; s hwui.overdraw false; s hwui.profile false; s hwui.show_dirty_regions false; s hwui.show_layers_updates false; s hwui.show_non_rect_clip hide; s hwui.skia_use_perfetto_track_events false; s hwui.target_cpu_time_percent 60; s hwui.skip_empty_damage true; s hwui.use_buffer_age true; s hwui.use_partial_updates true; s hwui.use_hint_manager true

s angle.validation false; s art.monitor.app false; s assert 0; s c2.use_dmabufheaps 1; s checkjni 0; s debuggerd.wait_for_debugger false; s debuggerd.wait_for_gdb false; s generate-debug-info false; s graphics.gpu.profiler.perfetto false; s sys.looper_stats_enabled false; s traceview-buffer-size-mb 0

s contacts.ksad 0; s cp2.scan_all_packages 0; s force_low_ram false; s force_remoteinput_history false; s layout false

if [ -n "$(getprop ro.mediatek.version.release)" ]; then
s mediatek.disp_decompress 0; s mediatek.appgamepq 1; s mediatek.appgamepq_compress 0; s mediatek.game_pq_enable 0; s mediatek.vklayer.rq_glsl_dump_all false; s mediatek.vklayer.dump_debug_mem_enabled false; s mediatek.vklayer.dump_blas_info_enabled false; s mediatek.vklayer.dump_debug_enabled false; s mediatek.vklayer.dump_analysis_enabled false; s mediatek.vklayer.dump_debug_mem_size_KB 0; s mediatek.vklayer.dump_vk_api_enabled false; s mediatek.vklayer.dump_debug_mem_at_QSubmit false; s mtklog.netlog.Running 0; s mtk_throughputmode.log 0; s mtk_throughputmode.log false; s mtk_tflite.vlog 0; s MB.running 0; s mdlogger.Running 0
fi

s stagefright.enableshaping 0; s stagefright.experiments 0; s stagefright.omx-debug 0; s stagefright.profilecodec 0; s stagefright.rtp false; s stagefright.swcodec 0; s surfacecontrol.log 0; s surfaceview.log 0; s synclog 0

s track-associations 0; s velocitytracker.alt 0; s vulkan.enable_callback false; s orientation.log false

s incremental.enable_read_timeouts_after_install 0; s incremental.always_enable_read_timeouts_for_system_dataloaders 0; s incremental.enforce_readlogs_max_interval_for_system_dataloaders 0

s perf_cpu_time_max_percent 0; s perf_event_max_sample_rate 1; s perf_event_mlock_kb 0

 $PROP log.tag S; $PROP log.tag.APM_AudioPolicyManager S
}
cmd(){
c activity kill-all
  t dumpsys binder_calls_stats --disable --disable-detailed-tracking --reset
  t dumpsys procstats --clear --stop-testing

  c display ab-logging-disable; c display dwb-logging-disable; c display dmd-logging-disable;c looper_stats disable
  
  c input_method ime tracing stop; c input_method tracing stop; c statusbar tracing stop;c accessibility stop-trace; c activity trace-ipc stop --dump-file $CORE/dump
  
  c activity set-stop-user-on-switch true; c activity fgs-notification-rate-limit enable
  c activity idle-maintenance; c activity set-deterministic-uid-idle true
  
  c activity untrack-associations; c activity memory-factor set 0
  
  c stats config remove 0; c stats clear-puller-cache; c stats print-logs 0
  
  c time_zone_detector set_auto_detection_enabled false
  
  bmgr enable 0; bmgr cancel backups
  
  c wifi set-verbose-logging disabled;c wifi reset-connected-score;c wifi set-connected-score 60; c wifi set-ipreach-disconnect disabled;c wifi set-network-selection-config disabled enabled -a 0;
  
  c blob_store idle-maintenance
  
  c autofill set log_level off; c autofill set bind-instant-service-allowed false;c autofill set default-augmented-service-enabled 0 false; c autofill set max_visible_datasets 0;c autofill set max_partitions 0;
  
  c content_capture destroy sessions; c content_capture set bind-instant-service-allowed false;c content_capture set default-service-enabled 0 false
  
  c media.camera watch stop;c media_session dispatch stop
  
  c voiceinteraction set-debug-hotword-logging false
  
  c print set-bind-instant-service-allowed false;c wearable_sensing destroy-data-stream
}
utility(){
parallelism=$(nproc)

  xargs -P"$parallelism" -n1 sh -c '
    CMD="$0"; f="$1"
    "$CMD" window logging disable "$f" || :
    "$CMD" window logging disable-text "$f" || :
  ' "$CMD" < "$MODDIR/wm.txt"

  PKGLIST="$CORE/dozelist.txt"
[ -s "$PKGLIST" ] || PKGLIST="$MODDIR/dozelist.txt"

xargs -n1 -P"$parallelism" sh -c '
  CMD="$0"
  pkg="$1"

  "$CMD" sensorservice set-uid-state "$pkg" idle || :
  "$CMD" package log-visibility --disable "$pkg" || :
  "$CMD" activity service-restart-backoff enable "$pkg" || :
  "$CMD" activity set-foreground-service-delegate --user 0 "$pkg" stop || :
  "$CMD" activity set-inactive "$pkg" true || :
  "$CMD" activity set-standby-bucket "$pkg" || :restricted

  pidof "$pkg" 2>/dev/null
' "$CMD" < "$PKGLIST" |
tr " " "\n" |
sort -n | uniq |
xargs -r -P"$parallelism" -n1 sh -c '
  CMD="$0"
  pid="$1"
  [ -d "/proc/$pid/task" ] || exit 0
  "$CMD" activity profile stop "$pid" || :
  "$CMD" activity set-watch-heap "$pid" 0 || :
' "$CMD"
}
case "$1" in
  --root)
    utility
    exit 0
    ;;
esac
setup() {
  while [ "$(getprop sys.boot_completed)" != 1 ]; do
    sleep 5
  done

  while ! pidof com.android.systemui >/dev/null; do
    sleep 2
  done
  sleep 10

  if su -c true >/dev/null 2>&1; then
    su -c "$0 --root"
  else
    props
    utility
    cmd
  fi
}
[ -z "$(getprop debug.setup.state)" ] && setup
  
if su -lp 2000 -c true >/dev/null 2>&1; then
  su -lp 2000 -c 'cmd notification post -S bigpicture --picture "data:image/png;base64,'"$(cat "$MODDIR/banner.b64")"'" core "设置已完成"'
else
  cmd notification post -S bigpicture --picture "data:image/png;base64,$(cat "$MODDIR/banner.b64")" core "设置已完成"
fi

[ -f "$CORE/dozelist.txt" ] && cp $CORE/dozelist.txt $MODDIR/ && exit 0
cp "$MODDIR/dozelist.txt" "$CORE/"

/data/app/~~hKuRR8lDtuPHyWYw_sPF2g==/com.frb.axmanager-_36lHAeadennebGBTj2wbQ==/lib/arm64/libaxeron.so
