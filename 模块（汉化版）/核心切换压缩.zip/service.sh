#!/system/bin/sh

while [ "$(getprop sys.boot_completed)" != "1" ]; do sleep 2; done
while ! pidof com.android.systemui >/dev/null; do sleep 2; done

am start -a AxManager.TOAST -e text "核心切换压缩正在运行中"

API="$(getprop ro.build.version.sdk)"

compact_all() {
  if [ "$API" -ge 34 ]; then
    cmd activity compact system
  else
    pm list packages -U | while read -r l; do
      p=$(echo "$l" | awk -F'[: ]' '{print $2}')
      u=$(echo "$l" | awk -F'[: ]' '{print $4}')
      [ -n "$p" ] && [ -n "$u" ] || continue
      am compact "$p" "$u" some 2>/dev/null
      am compact "$p" "$u" full 2>/dev/null
    done
  fi
}
compact_all
sleep 3600
while true; do
  [ "$(cmd deviceidle get screen 2>/dev/null)" = "false" ] || { sleep 60; continue; }
  sleep 60
  [ "$(cmd deviceidle get screen 2>/dev/null)" = "false" ] || { sleep 60; continue; }

  compact_all
  sleep 3600
done
