#!/system/bin/sh
# 版权所有 2024 Dcx400
#
# 根据 Apache 许可证 2.0 版（“许可证”）授权；
# 除非遵守许可证，否则您不得使用此文件。
# 您可以在以下位置获取许可证副本：
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# 除非适用法律要求或书面同意，否则根据许可证分发的软件
# 是按“原样”基础分发的，不附带任何明示或暗示的担保或条件。
# 请参阅许可证，了解许可证下的特定语言管理权限和
# 限制。
if ! cmd connectivity | grep -q set-chain3-enabled; then
rm -r "$MODPATH"
abort "您的手机不支持 set-chain3-enabled，正在中止。"
fi
mkdir -p /data/local/tmp/oxil
echo 0 > /data/local/tmp/oxil/state
touch /data/local/tmp/oxil/appstate
ui_print "完成，请打开 webui 根据您的偏好进行配置"