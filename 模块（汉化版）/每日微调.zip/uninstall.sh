#!/system/bin/sh atau #!/bin/sh
for pkg in $(cmd package list packages  | cut -d ":" -f2); do
appops set $pkg RUN_IN_BACKGROUND allow
appops set $pkg START_FOREGROUND allow
appops set $pkg INSTANT_APP_START_FOREGROUND allow
appops set $pkg RUN_ANY_IN_BACKGROUND allow
appops set $pkg WAKE_LOCK allow
am set-inactive --user 0 $pkg false
done

for package in $(cmd package list packages  | cut -f 2 -d ":"); do
cmd appops set "$package" RUN_IN_BACKGROUND allow 
cmd appops set "$package" POST_NOTIFICATION allow
cmd appops set "$package" RUN_ANY_IN_BACKGROUND allow
cmd appops set "$package" START_FOREGROUND allow
cmd netpolicy set restrict-background "$package" no-restrict-background
dumpsys deviceidle whitelist +"$package"
am set-standby-bucket "$package" active
am set-inactive "$package" false
am set-bg-restriction-level --user 0 "$package" unrestricted
am set-foreground-service-delegate --user 0 "$package" start
cmd netpolicy set restrict-background "$package"  no-restrict-background
done

for a in $(pm list packages|cut -f2 -d:);do appops reset $a&done

for a in $(dumpsys game|grep -o "$(cmd package list packages|cut -f2 -d:)");do cmd device_config delete game_overlay "$a";done
cmd settings delete global activity_manager_constants