#!/system/bin/sh
#Surface 增强器
prop="$(getprop|cut -f1 -d])";surface="$(dumpsys SurfaceFlinger|tr -d ' ')";appdur="$(echo "$surface"|grep -Eio 'appduration[^ns]+'|cut -f2 -d:|sort|head -n1)";hwcmindur="$(echo "$surface"|grep -Eio 'hwcminduration[^ns]+'|cut -f2 -d:|sort|head -n1)";sfdur="$(echo "$surface"|grep -Eio 'sfduration[^ns]+'|cut -f2 -d:|sort|head -n1)";eval "$(echo "$prop"|grep app.duration|sed "s/\[/setprop /;s/$/ "$appdur"/")";eval "$(echo "$prop"|grep hwc.min.duration|sed "s/\[/setprop /;s/$/ "$hwcmindur"/")";eval "$(echo "$prop"|grep sf.duration|sed "s/\[/setprop /;s/$/ "$sfdur"/")"

#CPU 调优
for a in $(ps|awk '{print $2}');do ionice -c 3 -n 7 -p "$a"&iorenice "$a" 7 idle&renice -n 19 -p "$a"&&echo 成功: "$a";done 2>/dev/null

#设备空闲与电源调节
for a in $(cmd package list packages -s|cut -f2 -d:);do cmd deviceidle whitelist -"$a";done;for a in $(cmd package list packages -3|cut -f2 -d:);do cmd deviceidle whitelist +"$a";done;cmd deviceidle enable all;cmd deviceidle force-idle deep;cmd deviceidle step deep;am idle-maintenance >/dev/null 2>&1 &
cmd activity memory-factor set 0
  cmd device_config put activity_manager low_swap_threshold_percent 0.0
  cmd device_config put activity_manager max_cached_processes 256
  cmd device_config put activity_manager max_phantom_processes 512
  cmd device_config put activity_manager power_check_max_cpu_1 64
  cmd device_config put activity_manager power_check_max_cpu_2 64
  cmd device_config put activity_manager power_check_max_cpu_3 32
  cmd device_config put activity_manager power_check_max_cpu_4 16
  cmd device_config put activity_manager power_check_max_cpu_5 16
  cmd settings put global activity_manager_constants low_swap_threshold_percent=0.0,max_cached_processes=256,max_phantom_processes=512,power_check_max_cpu_1=64,power_check_max_cpu_2=64,power_check_max_cpu_3=32,power_check_max_cpu_4=16,power_check_max_cpu_5=16
  
#系统限制器
for a in $(pm list packages -s|cut -d: -f2|grep -vEi 'com\.android\.settings$|com\.android\.phone$|^android$|com\.android\.systemui$')
do appops set "$a" RUN_ANY_IN_BACKGROUND deny
appops set "$a" RUN_IN_BACKGROUND deny
done

#GMS 清理器
for a in $(dumpsys package com.google.android.gms|grep gms/|cut -f10 -d" "|sort|uniq);do cmd activity force-stop "$a";done;PID=$(pgrep com.google.android.gms);[ -n "$PID" ]&&kill $PID

for a in $(getprop|grep '^\[log.tag'|cut -d']' -f1|sed 's/^\[//;s/^/persist./') $(getprop|grep '^\[persist.log.tag'|cut -d']' -f1|sed 's/^\[persist\.//');do echo "$a" S;setprop $a S;done

#驱动触摸重置
pm grant com.android.shell android.permission.WRITE_SECURE_SETTINGS
content insert --uri content://settings/secure --bind name:s:touch_blocking_period --bind value:i:0

#GMS 限制器
for pkg in $(cmd package list packages -s | grep com.google.android.gms | cut -d ":" -f2); do
  appops set $pkg RUN_IN_BACKGROUND deny
  appops set $pkg START_FOREGROUND deny
  appops set $pkg INSTANT_APP_START_FOREGROUND deny
  cmd appops set $pkg RUN_ANY_IN_BACKGROUND deny
am set-standby-bucket $pkg never
  appops set $pkg RUN_ANY_IN_BACKGROUND deny
done

#游戏加速
for a in $(dumpsys game|grep -o "$(cmd package list packages|cut -f2 -d:)");do cmd device_config put game_overlay "$a" mode=2,downscaleFactor=1,useAngle=true,fps=144,loadingBoost=999999999;cmd game set --mode 2 --downscale 0.6 "$a";done
