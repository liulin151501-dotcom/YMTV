echo " 正在清理并刷新界面"
echo "请稍候......"
sleep  1
cmd shortcut reset-throttling 
cmd shortcut reset-all-throttling
exec 2>/dev/null;cmd activity clear-debug-app;cmd activity clear-exit-info;cmd activity clear-watch-heap all;cmd blob_store clear-all-blobs;cmd blob_store clear-all-sessions;cmd companiondevice remove-inactive-associations;cmd device_policy clear-freeze-period-record;cmd font clear;cmd greezer clearmonitor;cmd location_time_zone_manager clear_recorded_provider_states;cmd lock_settings clear;cmd lock_settings remove-cache;cmd media.camera clear-stream-use-case-override;cmd media.camera watch clear;cmd miui.downscale clear-debug-apps;cmd miui_embedding_window clear-fixedOri;cmd miui_embedding_window_projection clear-fixedOri;cmd safety_center clear-data;cmd stats clear-puller-cache;cmd time_detector clear_network_time;cmd time_detector clear_system_clock_network_time;cmd wifi remove-all-suggestions;find /storage/emulated/0/ -size 0 -delete;find /storage/emulated/0/ -type f -name *.log -delete 2>/dev/null;find /storage/emulated/0/ -empty -delete;sm fstrim

input keyevent 26;eval "$(cmd package list packages|grep -v ia.mo|sed "s/package:/cmd activity force-stop /g"|sed "s/$/\&/g")";input keyevent 26
