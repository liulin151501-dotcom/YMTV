#!/system/bin/sh
MODDIR=${0%/*}
GAMES_FILE="$MODDIR/packages.txt"

# 获取电池信息
get_battery_info() {
    # 1. 获取设计容量（出厂规格）
    # 尝试微安或毫安路径
    design_raw=""
    actual_raw=""
    
    if [ -f /sys/class/power_supply/battery/charge_full_design ]; then
        design_raw=$(cat /sys/class/power_supply/battery/charge_full_design 2>/dev/null)
    elif [ -f /sys/class/power_supply/battery/energy_full_design ]; then
        design_raw=$(cat /sys/class/power_supply/battery/energy_full_design 2>/dev/null)
    fi

    # 2. 获取实际“满”容量（电池当前能储存的电量）
    if [ -f /sys/class/power_supply/battery/charge_full ]; then
        actual_raw=$(cat /sys/class/power_supply/battery/charge_full 2>/dev/null)
    elif [ -f /sys/class/power_supply/battery/energy_full ]; then
        actual_raw=$(cat /sys/class/power_supply/battery/energy_full 2>/dev/null)
    fi

    # 3. 转换为 mAh（标准化数值）
    # 如果数值很大（例如 5000000），则单位为 µAh，需除以 1000
    design_mah=0
    actual_mah=0
    
    if [ -n "$design_raw" ] && [ "$design_raw" -gt 0 ] 2>/dev/null; then
        design_mah=$((design_raw > 100000 ? design_raw / 1000 : design_raw))
    fi
    
    if [ -n "$actual_raw" ] && [ "$actual_raw" -gt 0 ] 2>/dev/null; then
        actual_mah=$((actual_raw > 100000 ? actual_raw / 1000 : actual_raw))
    fi

    # 4. 计算健康百分比
    if [ "$design_mah" -gt 0 ] 2>/dev/null && [ "$actual_mah" -gt 0 ] 2>/dev/null; then
        health_percent=$(( (actual_mah * 100) / design_mah ))
        echo "${health_percent}% (${actual_mah}mAh/${design_mah}mAh)"
    else
        echo "不可用"
    fi
}

# 主运行函数
run() {
    mode=$(getprop debug.togglegss 2>/dev/null)
    [ -z "$mode" ] && mode=off

    device=$(getprop ro.product.model 2>/dev/null)
    cpu=$(getprop ro.product.cpu.abi 2>/dev/null)
    android_ver=$(getprop ro.build.version.release 2>/dev/null)
    date_now=$(date '+%Y-%m-%d %H:%M:%S' 2>/dev/null)
    renderer=$(getprop debug.hwui.renderer 2>/dev/null)
    battery_info=$(get_battery_info)

    # 切换服务状态
    if [ "$mode" = on ]; then
        setprop debug.togglegss off 2>/dev/null
        status="关闭 ❌"
    else
        setprop debug.togglegss on 2>/dev/null
        status="开启 ✅"
    fi

    echo "================ 系统信息 ================"
    echo "设备型号    : ${device:-未知}"
    echo "CPU 架构   : ${cpu:-未知}"
    echo "安卓版本   : ${android_ver:-未知}"
    echo "渲染器     : ${renderer:-默认}"
    echo "电池健康   : $battery_info"
    echo "GSS 守护进程 : $status"
    echo "检查时间   : ${date_now:-未知}"
    echo "============================================"

    # 显示设备上已安装的游戏（来自 packages.txt）
    if [ -f "$GAMES_FILE" ]; then
        echo "当前设备上支持的游戏："
        pm list packages 2>/dev/null | cut -d':' -f2 | while read -r installed; do
            grep -Fxq "$installed" "$GAMES_FILE" 2>/dev/null && echo " - $installed"
        done
    else
        echo "未找到 packages.txt 文件。"
    fi
    echo "============================================"

    echo "在 quickshell 中输入 gss 以使用命令行界面"
    echo "感谢 dcx400 允许我继续他的项目！！"
}

run 2>/dev/null
