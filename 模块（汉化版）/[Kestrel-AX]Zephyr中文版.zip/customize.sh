#!/system/bin/sh

echo "========================================"
echo "正在应用 devconf by dcx400"
echo "========================================"
echo ""

# 应用 adservices 配置
echo "[1/31] 正在应用 adservices 配置..."
printf '%s\n' \
  adservice_system_service_enabled false \
  cobalt_logging_enabled false \
  enable_logged_topic false \
  adservice_error_logging_enabled false \
  measurement_enable_app_package_name_logging false \
  measurement_enable_source_debug_report false \
  fledge_app_package_name_logging false \
  fledge_auction_server_enable_debug_reporting false \
  fledge_auction_server_api_usage_metrics_enabled false \
  fledge_auction_server_enabled_for_report_event false \
  fledge_auction_server_enabled_for_report_impression false \
  fledge_auction_server_enabled_for_select_ads_mediation false |
xargs -P8 -n2 device_config put adservices

# 应用 adservices 网络类型配置
echo "[2/31] 正在应用网络类型配置..."
printf '%s\n' \
  measurement_verbose_debug_reporting_job_required_network_type 0 \
  measurement_debug_reporting_fallback_job_required_network_type 0 \
  measurement_debug_reporting_job_required_network_type 0 \
  measurement_aggregate_fallback_reporting_job_required_network_type 0 \
  measurement_aggregate_reporting_job_required_network_type 0 \
  measurement_async_registration_fallback_job_required_network_type 0 \
  measurement_async_registration_queue_job_required_network_type 0 \
  measurement_event_fallback_reporting_job_required_network_type 0 \
  measurement_event_reporting_job_required_network_type 0 |
xargs -P8 -n2 device_config put adservices

# 应用运行时原生指标
echo "[3/31] 正在应用运行时原生指标..."
device_config put runtime_native metrics.reporting-mods 0
device_config put runtime_native metrics.reporting-mods-server 0
device_config put runtime_native metrics.reporting-num-mods 0
device_config put runtime_native metrics.reporting-num-mods-server 0

# 应用 on_device_personalization 配置
echo "[4/31] 正在应用 on_device_personalization..."
printf '%s\n' \
  odp_enable_client_error_logging false \
  fcp_enable_client_error_logging false \
  odp_background_jobs_logging_enabled false \
  fcp_enable_background_jobs_logging false |
xargs -P8 -n2 device_config put on_device_personalization

# 应用 odad 配置
echo "[5/31] 正在应用 odad 配置..."
printf '%s\n' \
  westworld_logging false \
  log_error_model_id_westworld_enabled false \
  log_model_id_westworld false \
  log_model_version_westworld false \
  log_classification_latency_westworld false \
  moirai_additional_metrics_enabled false \
  mismatch_metrics_v2_enabled false |
xargs -P8 -n2 device_config put odad

# 应用 activity_manager fgs 配置
echo "[6/31] 正在应用 activity_manager fgs 配置..."
device_config put activity_manager fgs_start_allowed_log_sample_rate 0
device_config put activity_manager fgs_start_denied_log_sample_rate 0

# 应用 device_personalization_services 配置
echo "[7/31] 正在应用 device_personalization_services..."
printf '%s\n' \
  Logging__enable_aiai_clearcut_logging false \
  AutofillVC__enable_clearcut_log false \
  Captions__enable_clearcut_logging false \
  PlatformLogging__enable_metric_wise_populations false \
  Superpacks__use_logging_listener false \
  Overview__enable_pir_clearcut_logging false \
  Overview__enable_pir_westworld_logging false |
xargs -P8 -n2 device_config put device_personalization_services

# 应用 runtime_native 指标配置
echo "[8/31] 正在应用 runtime_native 指标..."
device_config put runtime_native metrics.write-to-statsd false
device_config put runtime_native metrics.reporting-spec ''
device_config put runtime_native metrics.reporting-spec-server ''

# 应用 device_personalization_services 统计配置
echo "[9/31] 正在应用统计配置..."
printf '%s\n' \
  StatsLog__active_users_logger_enabled false \
  StatsLog__active_users_logger_non_persistent false \
  StatsLog__enable_new_logger_api false |
xargs -P8 -n2 device_config put device_personalization_services

# 应用 on_device_personalization 后台任务配置
echo "[10/31] 正在应用后台任务配置..."
printf '%s\n' \
  odp_background_job_sampling_logging_rate 0 \
  fcp_background_job_logging_sampling_rate 0 |
xargs -P8 -n2 device_config put on_device_personalization

# 应用 window_manager 配置
echo "[11/31] 正在应用 window_manager 配置..."
device_config put window_manager system_gesture_exclusion_log_debounce_millis 0

# 应用 adservices 采样间隔配置
echo "[12/31] 正在应用采样间隔配置..."
printf '%s\n' \
  mdd_android_sharing_sample_interval 99966000000 \
  mdd_api_logging_sample_interval 99966000000 \
  mdd_default_sample_interval 99966000000 \
  mdd_download_events_sample_interval 99966000000 \
  mdd_group_stats_logging_sample_interval 99966000000 \
  mdd_mobstore_file_service_stats_sample_interval 99966000000 \
  mdd_network_stats_logging_sample_interval 99966000000 \
  mdd_storage_stats_logging_sample_interval 99966000000 |
xargs -P8 -n2 device_config put adservices

# 应用 aicore 配置
echo "[13/31] 正在应用 aicore 配置..."
printf '%s\n' \
  AicModels__network_stats_log_sample_interval 99999999999999999999 \
  AicModels__group_stats_log_sample_interval 99999999999999999999 \
  AicModels__storage_stats_log_sample_interval 99999999999999999999 \
  AicModels__api_log_sample_interval 99999999999999999999 \
  AicModels__default_log_sample_interval 99999999999999999999 |
xargs -P8 -n2 device_config put aicore

# 应用 adservices 杀开关配置
echo "[14/31] 正在应用杀开关配置..."
printf '%s\n' \
  measurement_job_aggregate_fallback_reporting_kill_switch true \
  measurement_job_aggregate_reporting_kill_switch true \
  measurement_job_event_fallback_reporting_kill_switch true \
  measurement_job_event_reporting_kill_switch true |
xargs -P8 -n2 device_config put adservices

# 应用 latency_tracker 配置
echo "[15/31] 正在应用 latency_tracker 配置..."
device_config put latency_tracker enabled false
device_config put latency_tracker sampling_interval 9999999999999999
device_config put latency_tracker action_show_voice_interaction_enable false
device_config put latency_tracker action_show_voice_interaction_sample_interval 9999999999999999

# 应用 textclassifier 配置
echo "[16/31] 正在应用 textclassifier 配置..."
device_config put textclassifier smart_select_animation_enabled false

# 应用 adservices flex api 配置
echo "[17/31] 正在应用 flex api 配置..."
printf '%s\n' \
  measurement_flex_api_max_event_reports 0 \
  measurement_flex_api_max_event_report_windows 0 |
xargs -P8 -n2 device_config put adservices

# 应用 telephony 配置
echo "[18/31] 正在应用 telephony 配置..."
printf '%s\n' \
  logcat_read_timeout_millis 0 \
  dumpsys_read_timeout_millis 0 \
  logcat_proc_timeout_millis 0 \
  dumpsys_proc_timeout_millis 0 \
  max_logcat_lines_low_mem 0 \
  max_logcat_lines 0 |
xargs -P8 -n2 device_config put telephony

# 应用 activity_manager 日志速率配置
echo "[19/31] 正在应用日志速率配置..."
printf '%s\n' \
  fgs_start_allowed_log_sample_rate 0 \
  fgs_start_denied_log_sample_rate 0 \
  fgs_atom_sample_rate 0 \
  compact_statsd_sample_rate 0 \
  freeze_statsd_sample_rate 0 |
xargs -P8 -n2 device_config put activity_manager

# 应用 activity_manager 后台监控配置
echo "[20/31] 正在应用后台监控配置..."
printf '%s\n' \
  bg_current_drain_monitor_enabled false \
  bg_fgs_monitor_enabled false \
  bg_media_session_monitor_enabled false \
  bg_permission_monitor_enabled false \
  bg_broadcast_monitor_enabled false \
  bg_bind_svc_monitor_enabled false |
xargs -P8 -n2 device_config put activity_manager

# 应用 tethering 配置
echo "[21/31] 正在应用 tethering 配置..."
device_config put tethering netstats_store_files_in_apexdata false
device_config put tethering netstats_import_legacy_target_attempts 0

# 应用 adservices 日志配置
echo "[22/31] 正在应用日志配置..."
printf '%s\n' \
  mdd_logger_kill_switch true \
  background_jobs_logging_kill_switch true \
  mdd_background_task_kill_switch true \
  global_kill_switch true |
xargs -P8 -n2 device_config put adservices

# 应用 activity_manager 应用分析器配置
echo "[23/31] 正在应用应用分析器配置..."
device_config put activity_manager disable_app_profiler_pss_profiling true

# 应用 interaction_jank_monitor 配置
echo "[24/31] 正在应用 interaction_jank_monitor 配置..."
device_config put interaction_jank_monitor enabled false
device_config put interaction_jank_monitor sampling_interval 99999999999999
device_config put interaction_jank_monitor trace_threshold_frame_time_millis -1
device_config put interaction_jank_monitor trace_threshold_missed_frames -1

# 应用 content_capture 配置
echo "[25/31] 正在应用 content_capture 配置..."
device_config put content_capture log_history_size 0
device_config put content_capture max_buffer_size 0

# 应用 settings_ui 配置
echo "[26/31] 正在应用 settings_ui 配置..."
device_config put settings_ui event_logging_enabled false

# 应用 media 配置
echo "[27/31] 正在应用 media 配置..."
device_config put media media_metrics_mode 0

# 计算并应用交换阈值
echo "[28/31] 正在计算并应用交换阈值..."
swap_total=$(grep SwapTotal /proc/meminfo | awk '{print $2}')
swap_free=$(grep SwapFree /proc/meminfo | awk '{print $2}')
swap_used=$((swap_total - swap_free))
swap_used_pct=$((swap_used * 100 / swap_total))
new_threshold=$(( 10 + (swap_used_pct * 20 / 100) ))
device_config put activity_manager proactive_kills_enabled true
device_config put activity_manager low_swap_threshold_percent "0.$new_threshold"

# 应用启动优化
echo "[29/31] 正在应用启动优化..."
device_config put runtime_native_boot iorap_readahead_enable true
device_config put runtime_native_boot iorap_perfetto_enable false

# 应用压缩配置
echo "[30/31] 正在应用压缩配置..."
device_config put activity_manager use_compaction true

# 计算并应用进程限制
echo "[31/31] 正在计算并应用进程限制..."
total_mb=$(awk '/MemTotal/ {print int($2/1024)}' /proc/meminfo)
free_mb=$(awk '/MemAvailable/ {print int($2/1024)}' /proc/meminfo)
percent_free=$(( (free_mb * 100) / total_mb ))
max_cached=$(( total_mb / 96 + percent_free / 10 ))
max_phantom=$(( total_mb / 48 + percent_free / 5 ))
device_config put activity_manager max_cached_processes $max_cached
device_config put activity_manager max_phantom_processes $max_phantom

echo ""
echo "╔══════════════════════════════════════╗"
echo "║         已应用 Devconf               ║"
echo "║        GameShell 已安装             ║"
echo "╚══════════════════════════════════════╝"
echo ""
echo "所有配置已成功应用！"
echo "总配置数量：31"
echo ""
echo "========================================"
