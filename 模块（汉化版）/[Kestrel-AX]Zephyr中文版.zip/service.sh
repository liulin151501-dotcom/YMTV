#!/system/bin/sh

MODDIR=${0%/*}
GAMES_FILE="$MODDIR/packages.txt"

# 加载游戏列表
load_games() {
    if [ -f "$GAMES_FILE" ]; then
        GAMING_APPS="$(tr '\n' ' ' < "$GAMES_FILE")"
    else
        GAMING_APPS=""
    fi
}
load_games

# 关闭 GSS 守护进程
setprop debug.togglegss off
cpul=67

# 启用游戏免打扰模式
enable_game_dnd() {
    cmd notification set_dnd priority
}

# 禁用游戏免打扰模式
disable_game_dnd() {
    cmd notification set_dnd off
}

# 启用性能模式
cmdpower() {
if [ "$(getprop debug.togglegss)" = on ]; then
cmd power set-adaptive-power-saver-enabled false
cmd power set-fixed-performance-mode-enabled true
cmd display set-match-content-frame-rate-pref 2
cmd thermalservice override-status 0
fi
}

# 恢复默认电源设置
uncmdpower() {
if [ "$(getprop debug.togglegss)" = on ]; then
cmd power set-adaptive-power-saver-enabled true
cmd power set-fixed-performance-mode-enabled false
cmd display set-match-content-frame-rate-pref 1
cmd thermalservice override-status 1
fi
}

# 设置属性函数
s () { setprop "$1" "$2"; }

LAST_APP=""
fps=$(dumpsys SurfaceFlinger | grep "refresh-rate" | awk '{printf "%.0f", $3}')
lockcpuload="$cpul"

# 性能优化相关函数
hunting() {
runfence() {
buffer=$(nice -n 19 strings /system/lib*/libgui.so | grep debug.sf. | sort -u)
for a in $buffer; do setprop "$a" false; done
}
runfence

runhwui() {
buffer=$(nice -n 19 strings /system/lib*/libhwui.so | grep debug.hwui.memory | sort -u)
setprop "$buffer" true 1>/dev/null
}
runhwui

runmiui() {
buffer=$(nice -n19 find /system/app -type f -iname "*.apk" 2>/dev/null | while read -r f; do
strings "$f" 2>/dev/null | grep -E 'debug.sensors.diag_buffer_log|debug.wifi-log-daemon'
done)
for a in $buffer; do setprop "$a" false; done
cl=$(strings /vendor/lib64/libOpenCL.so | grep debug.ocl.trace)
setprop "$cl" false
}
runmiui
}

# 内核优化
kern() {
write() {
[ -f "$1" ] && echo "$2" > "$1"
}
write /sys/kernel/tracing/trace ""
write /sys/kernel/tracing/tracing_on 0
write /sys/kernel/tracing/buffer_size_kb 1
write /sys/kernel/tracing/saved_cmdlines_size 1
s debug.perf_cpu_time_max_percent 0
s debug.perf_event_max_sample_rate 1
s debug.perf_event_mlock_kb 0
s security.perf_harden 1
s security.perf_harden 0
s persist.traced_perf.enable false
s persist.traced.enable 0
}

# 获取 CPU 负载
get_cpu_load() {
read cpu user nice system idle iowait irq softirq steal guest guest_nice < /proc/stat
total1=$((user + nice + system + idle + iowait + irq + softirq + steal))
idle1=$((idle + iowait))
sleep 0.12
read cpu user nice system idle iowait irq softirq steal guest guest_nice < /proc/stat
total2=$((user + nice + system + idle + iowait + irq + softirq + steal))
idle2=$((idle + iowait))
diff_total=$((total2 - total1))
diff_idle=$((idle2 - idle1))
load=$(( (100 * (diff_total - diff_idle)) / diff_total ))
echo "$load"
}

# 锁定 CPU 负载
lockcpu() {
load=$(get_cpu_load)
if [ "$load" -ge "$lockcpuload" ]; then
echo $lockcpuload
else
echo $load
fi
}

# 首次设置优化
firstsetup() {
for a in --reset --disable --disable-detailed-tracking; do dumpsys binder_calls_stats $a; done
for b in --clear --stop-testing; do dumpsys procstats $b; done
for c in ab-logging-disable dwb-logging-disable dmd-logging-disable; do cmd display $c; done
dumpsys media.metrics --clear
cmd wifi set-verbose-logging disabled
cmd wifi reset-connected-score
cmd wifi set-connected-score 60
cmd wifi remove-all-suggestions
cmd looper_stats disable
cmd autofill log_level off
cmd voiceinteraction set-debug-hotword-logging false
cmd statusbar tracing stop
s debug.sf.frame_rate_multiple_threshold "$fps"
s debug.rs.max-threads "$(nproc)"
} >/dev/null

# 恢复默认属性
unprop() {
s debug.egl.hw 0
s debug.sf.hw 0
s debug.sf.multithreaded_present 0
s debug.sf.use_frame_rate_priority 0
s debug.sf.predict_hwc_composition_strategy 0
s debug.hwui.render_ahead 0
s debug.sf.send_early_power_session_hint false
s debug.sf.send_late_power_session_hint true
s debug.sf.enable_adpf_cpu_hint false
s debug.hwui.use_hint_manager false
s debug.sf.enable_planner_prediction false
s debug.sf.normalize_hint_session_durations false
s debug.hwc.normalize_hint_session_durations false
s debug.hwui.target_cpu_time_percent 35
s debug.sf.auto_latch_unsignaled false
s debug.sf.latch_unsignaled false
}

# 设置游戏优化属性
prop() {
s debug.egl.hw 1
s debug.sf.hw 1
s debug.sf.multithreaded_present 1
s debug.sf.use_frame_rate_priority 1
s debug.sf.predict_hwc_composition_strategy 1
s debug.hwui.render_ahead 1
s debug.sf.send_early_power_session_hint true
s debug.sf.send_late_power_session_hint true
s debug.sf.enable_adpf_cpu_hint true
s debug.hwui.use_hint_manager true
s debug.sf.enable_planner_prediction true
s debug.sf.normalize_hint_session_durations true
s debug.hwc.normalize_hint_session_durations true
s debug.hwui.target_cpu_time_percent "$(lockcpu)"
s debug.sf.auto_latch_unsignaled true
s debug.sf.latch_unsignaled true
}

# 绑定延迟渲染
binddefer() {
ms=55
base=5
calms=$(( (ms * base + (fps / 2)) / fps ))
s debug.sf.cached_set_max_defer_render_attmpts $calms
}

# 解除延迟渲染绑定
unbinddefer() {
ms=75
base=150
calms=$(( (ms * base + (fps / 2)) / fps ))
s debug.sf.cached_set_max_defer_render_attmpts $calms
}

# 设置边距
set_margin() {
margincal=$(( 1180 * fps / 50 ))
s debug.sf.hint_margin_us $margincal
}

# 恢复默认边距
unset_margin() {
margincal=$(( 420 * fps / 50 ))
s debug.sf.hint_margin_us $margincal
}

# 设置空闲计时器
setidle() {
  s debug.sf.set_idle_timer_ms 10000
  chipchip=$(getprop ro.hardware | tr '[:upper:]' '[:lower:]')
  if echo "$chipchip" | grep -Eq 'qualcomm|qcom|qti'; then s debug.mdpcomp.idletime 10000; fi
}

# 恢复默认空闲计时器
unsetidle() {
  s debug.sf.set_idle_timer_ms 1200
  chipchip=$(getprop ro.hardware | tr '[:upper:]' '[:lower:]')
  if echo "$chipchip" | grep -Eq 'qualcomm|qcom|qti'; then s debug.mdpcomp.idletime 1200; fi
}

# 多文件缓存设置
multifile() {
multical=$(( 1024 * 1024 * fps ))
s debug.egl.blobcache.multifile_limit $multical
}

# 恢复默认多文件缓存
unmultifile() {
multical=$(( 24 * 1024 * 1024  ))
s debug.egl.blobcache.multifile_limit $multical
}

# 恢复默认 SQLite 设置
unsqlite() {
s debug.sqlite.journalmode MEMORY
s debug.sqlite.wal.syncmode NORMAL
s debug.sqlite.syncmode NORMAL
}

# 优化 SQLite 设置
sqlite() {
s debug.sqlite.journalmode OFF
s debug.sqlite.wal.syncmode OFF
s debug.sqlite.syncmode OFF
}

# 芯片特定优化
chip() {
chipchip=$(getprop ro.hardware | tr '[:upper:]' '[:lower:]')

if echo "$chipchip" | grep -Eq 'qualcomm|qcom|qti'; then
s debug.composition.type mdp
s debug.mdpcomp.logs 0 
s debug.enable.wl_log 0
s debug.gralloc.map_fb_memory 0
s debug.gralloc.gfx_ubwc_disable 0 
s debug.gralloc.enable_fb_ubwc 1 
s debug.sensor.logging.slpi false
elif echo "$chipchip" | grep -Eq 'mediatek|mtk|mt'; then
s debug.composition.type gpu
s debug.mediatek.disp_decompress 1
s debug.mediatek.appgamepq 1
s debug.mediatek.appgamepq_compress 1
s debug.mediatek.game_pq_enable 1
s debug.mediatek.vklayer.rq_glsl_dump_all false
s debug.mediatek.vklayer.dump_debug_mem_enabled false
s debug.mediatek.vklayer.dump_blas_info_enabled false
s debug.mediatek.vklayer.dump_debug_enabled false
s debug.mediatek.vklayer.dump_analysis_enabled false
s debug.mediatek.vklayer.dump_debug_mem_size_KB 0
s debug.mediatek.vklayer.dump_vk_api_enabled false
s debug.mediatek.vklayer.dump_debug_mem_at_QSubmit false
s debug.mtklog.netlog.Running 0
s debug.mtk_throughputmode.log 0
s debug.mtk_tflite.vlog 0
s debug.MB.running 0
s debug.mdlogger.Running 0
elif echo "$chipchip" | grep -Eq 'exynos'; then
s debug.composition.type gpu
s debug.sf.swaprect 1
s debug.hwc.force_gpu 1
s debug.hwc.winupdate 1
s debug.hwc.otf 1
s debug.slsi_platform 1
s debug.enable.sglscale 1
s debug.skia.force_sw_gles false
s debug.hbmc.log false
s debug.perfmond.atrace.enabled false
else
s debug.composition.type dyn
fi
}

# Vulkan 渲染优化
vkgl() {
checkprop=$(getprop debug.hwui.renderer)
if [ "$checkprop" = skiavk ]; then
s debug.renderengine.vulkan true
s debug.renderengine.backend skiavkthreaded
s debug.stagefright.renderengine.backend skiavkthreaded
s debug.hwui.initialize_gl_always false
s debug.hwui.early_preload_gl_context false
else
s debug.vulkan.enable_callback false
s debug.renderengine.vulkan false
s debug.renderengine.backend skiaglthreaded
s debug.stagefright.renderengine.backend skiaglthreaded
s debug.hwui.initialize_gl_always true
s debug.hwui.early_preload_gl_context true
fi
}

# 预加载应用资源
app_cat() {
vmtouch () { cat $1 ;} 1>/dev/null
  PKG_NAME=$1
  APK_PATHS=$(pm path "$PKG_NAME" | cut -d: -f2)
  LIBDIR=$(dirname "$(echo "$APK_PATHS" | head -n1)")/lib

  for APK in $APK_PATHS; do
    vmtouch "$APK" 
  done

  if [ -d "$LIBDIR" ]; then
    for so in $(find "$LIBDIR" -type f 2>/dev/null); do
     vmtouch "$so"
    done
  fi

abi=$(getprop ro.product.cpu.abi); if echo "$abi" | grep -q arm64;then path="/system/lib64/";else path="/system/lib/";fi
find "$path" \( -iname "libsurfacef*" -o -iname "libhwui.so" \) 2>/dev/null | while read -r graphics; do vmtouch "$graphics" >/dev/null;done
}

# 启动后台优化
chip&
firstsetup&
vkgl&
kern&
hunting&

# 主循环
mainaction() {
while true; do
    sleep 1
    load_games

    app=$(dumpsys window | grep mCurrentFocus | grep -Eo '([a-zA-Z0-9._]+/[^}]+)' | cut -d/ -f1)
    [ -z "$app" ] && continue

    if echo "$GAMING_APPS" | grep -w "$app" >/dev/null; then
        if [ "$app" != "$LAST_APP" ]; then
            LAST_APP="$app"

            cmd game mode 2 "$app"
            settings put global game_driver_all_apps 1
            settings put global updatable_driver_all_apps 1
            settings put global angle_gl_driver_selection_pkgs "$app"
            settings put global angle_gl_driver_selection_values native
            settings put global updatable_driver_production_opt_in_apps "$app"
            settings put global game_driver_opt_in_apps "$app"
            
            enable_game_dnd
            
            app_cat "$app"
            prop
            binddefer
            cmdpower
            set_margin
            setidle
            multifile
            sqlite

            cmd notification post gameinfo "[ 游戏 : $app ~ 延迟帧数: "$(getprop debug.sf.cached_set_max_defer_render_attmpts)" ] [ 刷新率 : "$fps"Hz ]"
        fi
    else
        if [ -n "$LAST_APP" ]; then
            cmd notification post gameinfo "游戏已退出，正在恢复优化"
            
            disable_game_dnd
            
            LAST_APP=""
            for driver in $(settings list global | grep _driver_ | cut -d= -f1 | awk '{print $1}'); do settings delete global $driver; done
            unprop
            unbinddefer
            uncmdpower
            unset_margin
            unsetidle
            unmultifile
            unsqlite
            cmd notification post gameinfo "优化已恢复 - 系统已还原"
        fi
    fi
done &
}

mainaction
