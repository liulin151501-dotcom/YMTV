#!/system/bin/sh

alias SP="setprop"
alias STS="settings"
alias C="cmd"

BRAND=$(getprop ro.product.brand | tr 'A-Z' 'a-z')
MANU=$(getprop ro.product.manufacturer | tr 'A-Z' 'a-z')
NAME=$(getprop ro.product.name | tr 'A-Z' 'a-z')
MODEL=$(getprop ro.product.model | tr 'A-Z' 'a-z')
HW=$(getprop ro.hardware | tr 'A-Z' 'a-z')
SOC=$(getprop ro.soc.manufacturer | tr 'A-Z' 'a-z')
ANDROID_VER=$(getprop ro.build.version.release)

FPS_LIST=$(dumpsys display 2>/dev/null | grep -Eo 'refreshRate=[0-9]+(.[0-9]+)?' | cut -d= -f2 | awk '{print int($1)}' | sort -u -nr)
FPSI=$(echo "$FPS_LIST" | head -n1)

[ -z "$FPSI" ] && FPSI=60
[ "$FPSI" -lt 60 ] && FPSI=60
[ "$FPSI" -gt 240 ] && FPSI=240

FRAME_NS=$((1000000000 / FPSI))

case $FPSI in
240|239|238|237|236|235|234|233|232|231|230|229|228|227|226|225|224|223|222|221|220)
EARLY_APP=58
LATE_APP=82
EARLY_SF=30
LATE_SF=54 ;;
200|199|198|197|196|195|194|193|192|191|190)
EARLY_APP=59
LATE_APP=81
EARLY_SF=31
LATE_SF=53 ;;
160|159|158|157|156|155|154|153|152|151|150)
EARLY_APP=61
LATE_APP=79
EARLY_SF=33
LATE_SF=51 ;;
130|129|128|127|126|125|124|123|122|121|120)
EARLY_APP=62
LATE_APP=78
EARLY_SF=34
LATE_SF=50 ;;
100|99|98|97|96|95|94|93|92|91|90)
EARLY_APP=63
LATE_APP=77
EARLY_SF=35
LATE_SF=49 ;;
*)
EARLY_APP=64
LATE_APP=76
EARLY_SF=36
LATE_SF=48 ;;
esac

EARLY_APP_NS=$((FRAME_NS * EARLY_APP / 100))
LATE_APP_NS=$((FRAME_NS * LATE_APP / 100))
EARLY_SF_NS=$((FRAME_NS * EARLY_SF / 100))
LATE_SF_NS=$((FRAME_NS * LATE_SF / 100))

OFFSET_EARLY_NS=$((-(FRAME_NS * 22 / 100)))
OFFSET_LATE_NS=$((-(FRAME_NS * 32 / 100)))

SP debug.sf.use_phase_offsets_as_durations 1
SP debug.sf.vsync_reactor 1
SP debug.sf.vsync_reactor_apply_phase_offsets 1
SP debug.sf.enable_vsync_immed 1
SP debug.sf.disable_backpressure 0
SP debug.sf.latch_unsignaled true
SP debug.sf.max_frame_latency 1
SP debug.sf.frame_rate_multiple_threshold 0
SP debug.sf.use_frame_rate_priority 1
SP debug.sf.phase_offset_threshold_for_next_vsync_ns $((FRAME_NS / 4))

SP debug.sf.early.app.duration "$EARLY_APP_NS"
SP debug.sf.late.app.duration "$LATE_APP_NS"
SP debug.sf.high_fps.early.app.duration "$EARLY_APP_NS"
SP debug.sf.high_fps.late.app.duration "$LATE_APP_NS"

SP debug.sf.early.sf.duration "$EARLY_SF_NS"
SP debug.sf.late.sf.duration "$LATE_SF_NS"
SP debug.sf.high_fps.early.sf.duration "$EARLY_SF_NS"
SP debug.sf.high_fps.late.sf.duration "$LATE_SF_NS"

SP debug.sf.early.app.phase_offset_ns "$OFFSET_EARLY_NS"
SP debug.sf.late.app.phase_offset_ns "$OFFSET_LATE_NS"
SP debug.sf.high_fps.early.app.phase_offset_ns "$OFFSET_EARLY_NS"
SP debug.sf.high_fps.late.app.phase_offset_ns "$OFFSET_LATE_NS"

SP debug.sf.early.sf.phase_offset_ns "$OFFSET_EARLY_NS"
SP debug.sf.late.sf.phase_offset_ns "$OFFSET_LATE_NS"
SP debug.sf.high_fps.early.sf.phase_offset_ns "$OFFSET_EARLY_NS"
SP debug.sf.high_fps.late.sf.phase_offset_ns "$OFFSET_LATE_NS"

CALLBACK_US=$((1000000 / FPSI))
SP debug.choreographer.callback "$CALLBACK_US"
SP debug.choreographer.low_latency 1
SP debug.choreographer.zero_jitter 1
SP debug.choreographer.skipwarning "$FPSI"

SP debug.input.lowlatency 1
SP debug.touchscreen.latency.scale 0.0
SP debug.sf.default_touch_timer_ms 0
SP debug.sf.set_touch_timer_ms 0

SP debug.hwui.use_buffer_age 1
SP debug.hwui.enable_buffer_queue_pacing 1
SP debug.hwui.skip_empty_damage 1
SP debug.hwui.use_partial_updates 1
SP debug.hwui.disable_vsync 0

SP debug.egl.swapinterval 1
SP debug.gr.swapinterval 1

RES=$(wm size | awk '{print $3}')
W=$(echo "$RES" | cut -d'x' -f1)
H=$(echo "$RES" | cut -d'x' -f2)

STS put --user 0 system preferred_refresh_rate "$FPSI"
STS put --user 0 system max_refresh_rate "$FPSI"
STS put --user 0 system min_refresh_rate "$FPSI"
STS put --user 0 system default_refresh_rate "$FPSI"
STS put --user 0 system refresh_default_rate "$FPSI"

C display set-user-preferred-display-mode "$W" "$H" "$FPSI".0 0
C device_config put game_overlay default_fps_override 0
C device_config put game_overlay enable_frame_pacing false
cmd display set-match-content-frame-rate-pref 0
settings put --user 0 secure match_content_frame_rate 0

SP debug.sf.default_refresh_rate "$FPSI"
SP debug.sf.min_refresh_rate "$FPSI"
SP debug.sf.max_refresh_rate "$FPSI"
SP debug.sf.peak_refresh_rate "$FPSI"
SP debug.hwui.profile.maxframes "$FPSI"

inputflinger set-display-mode-fps "$FPSI"

if echo "$BRAND $MANU $NAME $MODEL" | grep -Eq "xiaomi|redmi|poco"; then

pm clear --user 0 com.miui.powerkeeper  
pm clear --user 0 com.miui.daemon  
pm clear --user 0 com.miui.securitycenter  

SP put --user 0 system miui_refresh_rate "$FPSI"  
SP put --user 0 secure miui_refresh_rate "$FPSI"  
SP put --user 0 system thermal_limit_refresh_rate "$FPSI"  

fi

if echo "$BRAND $MANU $NAME $MODEL" | grep -Eq 'oppo|realme|oneplus|oplus'; then

STS put --user 0 secure coloros_screen_refresh_rate 0  
STS put --user 0 secure oplus_customize_screen_refresh_rate 7  
STS put --user 0 secure oplus_customize_min_refresh_rate 7  
STS put --user 0 secure oplus_customize_peak_refresh_rate 7  
STS put --user 0 global oneplus_screen_refresh_rate 0  
STS put --user 0 global oneplus_screen_resolution_adjust 1  
STS put --user 0 secure refresh_rate_mode 7  
STS put --user 0 system db_screen_rate 7  
STS put --user 0 global 6ecb9657_screen_refresh_rate 0  
STS put --user 0 system power_save_pre_refresh_state 0  
STS put --user 0 system power_save_screen_refresh_rate 0  
STS put --user 0 system power_save_coloros_screen_refresh_rate 0

fi

if echo "$BRAND $MANU $NAME $MODEL" | grep -Eq 'itel|infinix|tecno'; then

STS put --user 0 system last_tran_refresh_mode_in_refresh_setting "$FPSI"
STS put --user 0 system tran_refresh_mode "$FPSI"
STS put --user 0 system tran_need_recovery_refresh_mode "$FPSI"
STS put --user 0 system tran_need_recovery_refresh_rate "$FPSI"

fi

if echo "$BRAND $MANU $NAME $MODEL" | grep -Eq 'vivo|iqoo'; then

STS put --user 0 global vivo_screen_refresh_rate_mode "$FPSI"  
STS put --user 0 system gamecube_frame_interpolation 0:-1:0:0:0  
STS put --user 0 system gamewatch_game_target_fps "$FPSI"

fi

cmd notification post -S bigtext -t '🅱️-FramePacing' '✅' "Tweak 已激活"