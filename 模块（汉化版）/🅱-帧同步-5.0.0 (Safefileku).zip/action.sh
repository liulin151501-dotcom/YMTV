#!/system/bin/sh
R="\033[31m"
G="\033[32m"
Y="\033[33m"
B="\033[34m"
P="\033[35m"
C="\033[36m"
W="\033[37m"
N="\033[0m"
line() {
  echo -e "${B}────────────────────────────────────${N}"
}
echo
line
echo -e "${P}===== 显示刷新率 =====${N}"
_HZ=$(dumpsys SurfaceFlinger 2>/dev/null \
| grep -i "Active refresh rate" \
| grep -Eo '[0-9]+(\.[0-9]+)?' \
| head -n1)
[ -z "$_HZ" ] && _HZ=$(dumpsys SurfaceFlinger 2>/dev/null \
| grep -i "refresh-rate" \
| grep -Eo '[0-9]+(\.[0-9]+)?' \
| head -n1)
[ -z "$_HZ" ] && _HZ="UNKNOWN"
echo -e "${G}刷新率 : ${W}${_HZ} Hz${N}"
echo
line
echo -e "${P}===== SURFACEFLINGER APP 持续时间 =====${N}"
echo -e "${G}提前应用        : ${W}$(getprop debug.sf.early.app.duration)${N}"
echo -e "${G}滞后应用         : ${W}$(getprop debug.sf.late.app.duration)${N}"
echo -e "${G}高帧率 提前应用   : ${W}$(getprop debug.sf.high_fps.early.app.duration)${N}"
echo -e "${G}高帧率 滞后应用    : ${W}$(getprop debug.sf.high_fps.late.app.duration)${N}"
echo
line
echo -e "${P}===== SURFACEFLINGER SF 持续时间 =====${N}"
echo -e "${Y}提前 SF         : ${W}$(getprop debug.sf.early.sf.duration)${N}"
echo -e "${Y}滞后 SF          : ${W}$(getprop debug.sf.late.sf.duration)${N}"
echo -e "${Y}高帧率 提前 SF    : ${W}$(getprop debug.sf.high_fps.early.sf.duration)${N}"
echo -e "${Y}高帧率 滞后 SF     : ${W}$(getprop debug.sf.high_fps.late.sf.duration)${N}"
echo
line
echo -e "${P}===== VSYNC 相位偏移 =====${N}"
echo -e "${C}应用 提前偏移 : ${W}$(getprop debug.sf.early.app.phase_offset_ns)${N}"
echo -e "${C}应用 滞后偏移  : ${W}$(getprop debug.sf.late.app.phase_offset_ns)${N}"
echo -e "${C}高帧率 应用 提前   : ${W}$(getprop debug.sf.high_fps.early.app.phase_offset_ns)${N}"
echo -e "${C}高帧率 应用 滞后    : ${W}$(getprop debug.sf.high_fps.late.app.phase_offset_ns)${N}"
echo -e "${C}SF 提前偏移  : ${W}$(getprop debug.sf.early.sf.phase_offset_ns)${N}"
echo -e "${C}SF 滞后偏移   : ${W}$(getprop debug.sf.late.sf.phase_offset_ns)${N}"
echo -e "${C}高帧率 SF 提前    : ${W}$(getprop debug.sf.high_fps.early.sf.phase_offset_ns)${N}"
echo -e "${C}高帧率 SF 滞后     : ${W}$(getprop debug.sf.high_fps.late.sf.phase_offset_ns)${N}"
line() {
  echo -e "${B}────────────────────────────────────${N}"
}