while [ "$(getprop sys.boot_completed)" != "1" ]; do
  sleep 2
done
exec "$(dirname "$(readlink -f "$0")")/frmpcng.sh"

