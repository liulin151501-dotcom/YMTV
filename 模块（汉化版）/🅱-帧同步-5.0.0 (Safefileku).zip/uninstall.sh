#!/system/bin/sh

alias SP="setprop"
alias STS="settings"
alias C="cmd"

STS delete system peak_refresh_rate
STS delete system max_refresh_rate
STS delete system min_refresh_rate
STS delete system preferred_refresh_rate
STS delete system user_refresh_rate
STS delete secure user_refresh_rate
STS delete system default_refresh_rate
STS delete system refresh_default_rate
STS delete system min_render_frame_rate
STS delete system peak_render_frame_rate
STS delete system default_refresh_mode
STS delete system refresh_default_mode
STS delete system flicker_refresh_rate
STS delete system flicker_refresh_rate_switch
STS delete system auth_optimizer_render_frame_rate
STS delete system hwui_target_fps
STS delete system game_render_fps
STS delete system sf_frame_rate_override

STS delete global force_peak_refresh_rate
STS delete global force_min_refresh_rate
STS delete global force_max_refresh_rate
STS delete global refresh_rate_mode
STS delete global game_fps_limit
STS delete global fps_limit

STS delete secure adaptive_refresh_rate
STS delete secure refresh_rate_override
STS delete secure refresh_rate_policy
STS delete secure frame_rate_multiple_threshold

C device_config delete game_overlay default_fps_override
C device_config delete game_overlay enable_frame_pacing
C device_config delete game_overlay enable_dynamic_fps
C device_config delete game_overlay use_device_refresh_rate
C device_config delete game_overlay frame_rate_cap

C device_config delete display_manager peak_refresh_rate
C device_config delete display_manager min_refresh_rate
C device_config delete display_manager user_refresh_rate

C device_config delete surfaceflinger max_frame_latency
C device_config delete surfaceflinger frame_rate_multiple_threshold
C device_config delete surfaceflinger use_vsync

C display clear-user-preferred-display-mode 2>/dev/null

SP persist.sys.refresh_rate ""
SP persist.sys.sf.refresh_rate ""
SP persist.sys.fps.max ""
SP persist.sys.fps.limit ""
SP persist.sys.FPSLIMIT ""
SP persist.sys.NV_FPSLIMIT ""
SP persist.sys.ui.hwframes ""
SP persist.sys.min_refresh_rate ""
SP persist.sys.max_refresh_rate ""
SP persist.sys.peak_refresh_rate ""
SP persist.sys.smartfps ""
SP persist.sys.autofps.mode ""
SP persist.sys.fpsctrl.enable ""
SP persist.sys.dynamic_fps.enable ""
SP persist.sys.adaptive_fps ""
SP persist.sys.game_fps ""

SP debug.sf.use_phase_offsets_as_durations ""
SP debug.sf.vsync_reactor ""
SP debug.sf.vsync_reactor_apply_phase_offsets ""
SP debug.sf.enable_vsync_immed ""
SP debug.sf.disable_backpressure ""
SP debug.sf.latch_unsignaled ""
SP debug.sf.max_frame_latency ""
SP debug.sf.frame_rate_multiple_threshold ""
SP debug.sf.use_vsync ""

SP debug.choreographer.callback ""
SP debug.choreographer.low_latency ""
SP debug.choreographer.zero_jitter ""
SP debug.choreographer.skipwarning ""

SP debug.input.lowlatency ""
SP debug.touchscreen.latency.scale ""

SP debug.hwui.use_buffer_age ""
SP debug.hwui.enable_buffer_queue_pacing ""
SP debug.hwui.skip_empty_damage ""
SP debug.hwui.use_partial_updates ""
SP debug.hwui.disable_vsync ""
SP debug.hwui.target_fps ""

SP debug.egl.swapinterval ""
SP debug.gr.swapinterval ""

C power set-fixed-performance-mode-enabled false 2>/dev/null
C thermalservice override-status 0 2>/dev/null
C game set --mode 0 --user 0 2>/dev/null

BRAND=$(getprop ro.product.brand | tr 'A-Z' 'a-z')

if echo "$BRAND" | grep -Eq "xiaomi|redmi|poco"; then
    STS delete system miui_refresh_rate
    STS delete secure miui_refresh_rate
    STS delete system thermal_limit_refresh_rate
    STS delete system game_booster_fps
fi

if echo "$BRAND" | grep -Eq "oppo|realme|oneplus|oplus"; then
    STS delete secure coloros_screen_refresh_rate
    STS delete secure oplus_customize_screen_refresh_rate
    STS delete secure oplus_customize_min_refresh_rate
    STS delete secure oplus_customize_peak_refresh_rate
    STS delete secure refresh_rate_mode
    STS delete system db_screen_rate
    STS delete system power_save_pre_refresh_state
    STS delete system power_save_screen_refresh_rate
    STS delete system power_save_coloros_screen_refresh_rate
fi

if echo "$BRAND" | grep -Eq "vivo|iqoo"; then
    STS delete global vivo_screen_refresh_rate_mode
    STS delete system gamewatch_game_target_fps
    STS delete system gamecube_frame_interpolation
    STS delete system vivo_game_fps
fi

if echo "$BRAND" | grep -Eq "samsung"; then
    STS delete system peak_refresh_rate_game
    STS delete system adaptive_refresh_rate_game
fi

if echo "$BRAND" | grep -Eq "itel|infinix|tecno"; then
    STS delete system last_tran_refresh_mode_in_refresh_setting
    STS delete system tran_refresh_mode
    STS delete system tran_need_recovery_refresh_mode
    STS delete system tran_need_recovery_refresh_rate
fi

cmd notification post -S bigtext -t '🅱️-FramePacing' '🛑' " 已卸载"
