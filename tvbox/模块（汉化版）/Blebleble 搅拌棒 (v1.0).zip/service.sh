#!/system/bin/sh
a="$AXERONDIR/plugins/taskblu"
sleep 5
cp -n "$a/bleblegamelist.txt" /sdcard/axeron/
sleep 2
sh $AXERONXBIN/OiAiOgk1656
am start -a AxManager.TOAST -e text "已应用到游戏"
