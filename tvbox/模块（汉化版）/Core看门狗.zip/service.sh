#!/system/bin/sh

CORE=/data/local/tmp/core
FILE="$CORE/watchdoglist.txt"
STATE="$CORE/watchdog.state"

# Wait for system boot completed
# 等待系统启动完成
while [ "$(getprop sys.boot_completed)" != "1" ]; do sleep 2; done
# Wait for SystemUI process
# 等待 SystemUI 进程
while ! pidof com.android.systemui >/dev/null; do sleep 2; done

# Notify user that CoreShift Watchdog is running
# 通知用户 CoreShift Watchdog 正在运行
am start -a AxManager.TOAST -e text "CoreShift Watchdog running"

# Generate watchdog list file if not exists
# 如果看门狗列表文件不存在则生成
if [ ! -f "$FILE" ]; then
  {
    # List system packages containing ext.service or systemui
    # 列出包含 ext.service 或 systemui 的系统包
    pm list packages -s|grep -E 'ext\.service$|systemui$' | cut -d: -f2
    # List all third-party packages
    # 列出所有第三方包
    pm list packages -3 | cut -d: -f2
  } | sed '/^$/d' | sort -u > "$FILE"
fi

while :; do
  NOW="$(date +%s)"

  # Read process info and check against whitelist & state
  # 读取进程信息并对照白名单与状态进行检查
  ps -o PID,UID,ARGS |
  awk -v SELF="$$" -v NOW="$NOW" -v STATE="$STATE" -v WLFILE="$FILE" '
    BEGIN {
      TH=60

      # Load last kill timestamp from state file
      # 从状态文件加载上次杀死的时间戳
      while ((getline < STATE) > 0) {
        split($0,a,"|")
        last[a[1]]=a[2]
      }
      close(STATE)

      # Load whitelist packages
      # 加载白名单包
      while ((getline < WLFILE) > 0)
        wl[$0]=1
      close(WLFILE)
    }

    NR>1 {
      pid=$1; uid=$2; cmd=$3
      sub(/:.*/,"",cmd)
      pkg=cmd

      # Skip self process
      # 跳过自身进程
      if (pid==SELF) next
      # Skip system UIDs (<10000)
      # 跳过系统 UID（小于 10000）
      if (uid<10000) next
      # Skip empty package or whitelisted package
      # 跳过空包或白名单包
      if (pkg=="" || wl[pkg]) next

      thr=0
      st="/proc/"pid"/status"
      # Read thread count from status file
      # 从 status 文件读取线程数
      while ((getline l < st) > 0)
        if (index(l,"Threads:")==1){split(l,f,":");thr=f[2]+0}
      close(st)

      # Skip if thread count below threshold
      # 如果线程数低于阈值则跳过
      if (thr<TH) next
      # Skip if killed within 120 seconds
      # 如果在 120 秒内已杀死则跳过
      if (last[pkg] && NOW-last[pkg]<120) next

      # Output package and timestamp
      # 输出包名与时间戳
      print pkg "|" NOW
    }
  ' | while IFS='|' read -r pkg ts; do
        # Kill the package via activity manager
        # 通过 Activity Manager 杀死包
        cmd activity kill "$pkg"
        # Remove old record from state file
        # 从状态文件中移除旧记录
        sed -i "/^$pkg|/d" "$STATE"
        # Add new kill timestamp
        # 添加新的杀死时间戳
        echo "$pkg|$ts" >> "$STATE"
      done

  # Wait before next check cycle
  # 在下次检查周期前等待
  sleep 30
done