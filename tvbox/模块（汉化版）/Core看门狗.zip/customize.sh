CORE=/data/local/tmp/core
[ -f "$CORE/watchdoglist.txt" ] && exit 0
mkdir -p $CORE