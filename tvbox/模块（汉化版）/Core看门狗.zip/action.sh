#!/system/bin/sh

# Print table header
# 打印表头
echo " CPU%   |     RSS | THRDS | NAME"
echo "--------+----------+--------+---------------------------"

# Get process info: USER,PID,PCPU,RSS,ARGS
# 获取进程信息：USER,PID,PCPU,RSS,ARGS
ps -o USER,PID,PCPU,RSS,ARGS \
| awk '
NR>1 {
  pid=$2; cpu_raw=($3+0); rss_kb=($4+0)
  cmd=""
  # Concatenate arguments into full command string
  # 将参数拼接成完整命令字符串
  for(i=5;i<=NF;i++) cmd=cmd (i==5?"":" ") $i
  # If command empty or starts with "[", try reading from cmdline
  # 如果命令为空或以 "[" 开头，尝试从 cmdline 读取
  if(cmd=="" || cmd ~ /^\[/){
    cp="/proc/"pid"/cmdline"
    if((getline cl < cp)>0){ gsub(/\0/," ",cl); cmd=cl }
    close(cp)
  }
  # Skip if still empty or kernel thread
  # 如果仍为空或是内核线程则跳过
  if(cmd=="" || cmd ~ /^\[/) next
  # Remove non-printable characters
  # 去除不可打印字符
  gsub(/[^ -~]/,"",cmd)
  name=cmd
  # Extract basename from path
  # 从路径中提取基名
  n=split(cmd,a,"/"); if(n>1) name=a[n]
  # Extract first word if multiple words
  # 如果有多个单词则提取第一个单词
  split(name,b," "); name=b[1]
  # Remove anything after colon
  # 去除冒号后的内容
  sub(/:.*/,"",name)
  # Extract extension-like part if exists
  # 如果存在类似扩展名的部分则提取
  m=split(name,c,"."); if(m>1) name=c[m]
  if(name=="") name="unknown"
  # Get thread count from /proc/PID/status
  # 从 /proc/PID/status 获取线程数
  thr=0
  sp="/proc/"pid"/status"
  while((getline ln < sp)>0){
    if(index(ln,"Threads:")==1){ split(ln,d,":"); thr=d[2]+0; break }
  }
  close(sp)
  # Convert RSS from KB to MB
  # 将 RSS 从 KB 转换为 MB
  rss_mb=(rss_kb>0?int((rss_kb/1024)+0.5):0)
  # Skip processes with very low memory
  # 跳过内存占用非常低的进程
  if(rss_mb<5) next
  # Skip processes with CPU usage below 1%
  # 跳过 CPU 使用率低于 1% 的进程
  if(cpu_raw<1.0) next
  # Format CPU percentage
  # 格式化 CPU 百分比
  cpu_str=sprintf("%.1f%%",cpu_raw)
  cpu_str=sprintf("%7s",cpu_str)
  # Format RSS as MB
  # 将 RSS 格式化为 MB
  rss_str=sprintf("%8s",rss_mb "MB")
  # Format thread count
  # 格式化线程数
  thr_str=sprintf("%6d",thr)
  # Format process name field
  # 格式化进程名字段
  name_str=sprintf("%-32s",name)
  # Print formatted line
  # 打印格式化行
  print cpu_str " | " rss_str " | " thr_str " | " name_str
}
' \
| sort -k1,1nr \
| head -n 25 \
| sed '/^[[:space:]]*$/d' \
| while IFS= read -r line; do echo "$line"; done
