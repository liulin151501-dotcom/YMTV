#!/system/bin/sh

# Copyright 2024 Dcx400
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.


#define path for utensil /// 感谢 @Nekotor1999 的建议
utensil="/data/local/tmp/utensil"
mkdir -p "$utensil"

#首次初始化设置
android=$(getprop ro.build.version.release)

#屏幕超时配置
screen_time_out() {
#define path
#备份原始超时时间
timeoutfile="$utensil/screentimeout.dat"

# 存储计算后的超时值
modifiedtimeout="$utensil/screentimeoutconfiguration"

if [ ! -f "$timeoutfile" ]; then
settings get system screen_off_timeout > "$timeoutfile"
fi

#读取 $timeoutfile
timeoutop="$(cat $timeoutfile)"

# 防止未检测到超时值导致错误
if [ -z "$timeoutop" ] || [ "$timeoutop" = "null" ];then
return
fi

calculationtimeout=$(( $timeoutop * 9 / 15 ))

echo "$calculationtimeout" > "$modifiedtimeout"

}




if [ "$android" -le 11 ]; then 
settings put global battery_saver_constants \
advertise_is_enabled=true,\
datasaver_disabled=false,\
enable_night_mode=true,\
launch_boost_disabled=true,\
vibration_disabled=true,\
animation_disabled=true,\
soundtrigger_disabled=true,\
fullbackup_deferred=true,\
keyvaluebackup_deferred=true,\
firewall_disabled=false,\
gps_mode=2,\
adjust_brightness_disabled=false,\
adjust_brightness_factor=0.5,\
force_all_apps_standby=true,\
force_background_check=true,\
optional_sensors_disabled=true,\
aod_disabled=true,\
quick_doze_enabled=true
else
settings put global battery_saver_constants \
advertise_is_enabled=true,\
enable_datasaver=false,\
enable_night_mode=true,\
disable_launch_boost=true,\
disable_vibration=true,\
disable_animation=true,\
soundtrigger_mode=2,\
defer_full_backup=true,\
defer_keyvalue_backup=true,\
enable_firewall=true,\
location_mode=2,\
enable_brightness_adjustment=false,\
adjust_brightness_factor=0.5,\
force_all_apps_standby=true,\
force_background_check=true,\
disable_optional_sensors=true,\
disable_aod=true,\
enable_quick_doze=true
fi

if [ "$android" -le 13 ]; then
settings put global battery_stats_constants track_cpu_times_by_proc_state=false,track_cpu_active_cluster_time=false,read_binary_cpu_time=false,max_history_files=0,max_history_buffer_kb=0
else
settings put global battery_stats_constants track_cpu_times_by_proc_state=false,track_cpu_active_cluster_time=false,read_binary_cpu_time=false,max_history_files=0,max_history_buffer_kb=0,phone_on_external_stats_collection=false
fi


settings put global binder_calls_stats sampling_interval=600000000,detailed_tracking=false,enabled=false,upload_data=false,collect_latency_data=false,track_calling_uid=false
if [ "$(settings get global wifi_scan_always_enabled)" = 1 ]; then settings put global wifi_scan_always_enabled 0;fi
if [ "$(settings get global ble_scan_always_enabled)" = 1 ]; then settings put global ble_scan_always_enabled 0;fi

#备份低电粘性状态
backup="$utensil/batteryconfiguration.dat"

if [ ! -f "$backup" ]; then

	current_lps=$(settings get global low_power_sticky)
	echo "low_power_sticky=$current_lps" > "$backup"
	echo "粘性电源配置已保存至 "$backup""
	
	if [ "$(settings get global low_power_sticky)" = 1 ]; then 
		echo "已禁用低电粘性模式"
	settings put global low_power_sticky 0
	fi
	
fi


#活动管理器配置
power_interval=$((4 * 60 * 1000))
pss_interval=$((25 * 60 * 1000))
pss_low_interval=$((10 * 60 * 1000))
settings put global activity_manager_constants \
power_check_max_cpu_1=20,\
power_check_max_cpu_2=20,\
power_check_max_cpu_3=5,\
power_check_max_cpu_4=1,\
power_check_interval=$power_interval,\
full_pss_min_interval=$pss_interval,\
full_pss_lowered_interval=$pss_low_interval

##音量键选择配置
volume_key() {
    getevent -l | while read -r line; do
        case "$line" in
            *KEY_VOLUMEUP*) echo UP; break;;
            *KEY_VOLUMEDOWN*) echo DOWN; break;;
        esac
    done
}


ask_config() {
    title="$1"
    description="$2"
    outfile="$3"

    echo "
$title

$description

[+] 音量加       : 启用此设置
[-] 音量减       : 跳过此设置
"

    choice=$(volume_key)

    if [ "$choice" = "UP" ]; then
        echo true > "$outfile"
		echo "已保存！"
	else
		echo "已跳过"
    fi
	echo "
#############################
"
}



echo "
屏幕超时时间配置

在电量较低时让手机更快关闭屏幕

[+] 音量加       : 启用此设置
[-] 音量减       : 跳过此设置
"

choice=$(volume_key)

if [ "$choice" = "UP" ]; then
    screen_time_out
    echo "您的配置已保存"
else
    echo "您的配置已跳过"
fi

echo "
#############################
"
ask_config "通知配置" "为每个不同事件始终发送通知" "$utensil/notificationconfiguration"

ask_config "传感器配置" "电量低时禁用传感器" "$utensil/sensorconfiguration"

ask_config "飞行模式配置" "充电时启用飞行模式（仅在电量低时）" "$utensil/airplaneconfiguration"

ask_config "充电日志记录配置" "在充电/未充电时记录日志（文件保存在 /sdcard/chargelog.txt），请谨慎使用" "$utensil/charglogconfiguration"

ask_config "数据节省配置" "电量低时启用数据节省模式" "$utensil/datasaverconfiguration"

ask_config "温控服务配置" "在后台创建另一个 Shell 监控温度" "$utensil/thermalserviceconfiguration"

ask_config "勿扰模式配置" "充电时启用勿扰模式" "$utensil/dndconfiguration"

ask_config "内存压缩配置" "使用内存压缩功能（Android 11+）" "$utensil/compactionconfiguration"
#保护机制层
if [ -f "$utensil/compactionconfiguration" ];then 
	if [ "$(dumpsys activity settings | grep 'use_compaction=' | head -n1 | cut -d= -f2)" = "true" ] ;then 
		echo true > $utensil/savestatcompact
	fi
fi

ask_config "看门狗控制器" "在后台创建另一个 Shell 杀死不重要的缓存应用（可通过 /sdcard/ 配置以保护您的应用）" "$utensil/watchdogconfiguration"

watchdogconfig="$utensil/watchdogconfiguration"
CONFIG="/sdcard/fileconfig.txt"

if [ -f "$watchdogconfig" ]; then
    launcher=$(pm resolve-activity --brief -a android.intent.action.MAIN -c android.intent.category.HOME | cut -d/ -f1 | tail -n1)
    keyboard=$(settings get secure default_input_method | cut -d/ -f1)

    echo "# 受保护的应用
$launcher
$keyboard
com.zing.zalo
" > "$CONFIG"
    echo "默认看门狗配置已写入 $CONFIG"
fi

echo "
所有设置已完成，请坐下来并打开 WebUi。
"