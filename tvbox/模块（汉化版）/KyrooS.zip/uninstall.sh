#!/system/bin/sh

# Copyright 2024 Dcx400
#
# 根据 Apache License 2.0 许可协议授权 (the "License");
# 除非符合许可协议的规定，否则不得使用本文件。
# 您可以从以下地址获取许可协议副本:
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# 除非法律要求或书面同意，否则按"现状"分发软件，
# 不提供任何明示或暗示的担保或条件。
# 详见许可协议中关于权限和限制的具体条款。


#定义 utensil 路径
utensil="/data/local/tmp/utensil"

rm $utensil/battery_learning.dat
rm $utensil/battery_threshold.dat
rm $utensil/sensorconfiguration
rm $utensil/airplaneconfiguration
rm $utensil/charglogconfiguration
rm $utensil/notificationconfiguration
rm $utensil/dndconfiguration
rm $utensil/watchdogconfiguration
rm $utensil/watchdog.db
rm /sdcard/fileconfig.txt
rm /sdcard/chargelog.txt
rm /storage/emulated/0/Android/media/.kyroos_icon.jpg
rm /data/local/tmp/kyroos_selected_apps.list

#关闭勿扰模式
cmd notification set_dnd off

#删除所有常量配置
settings delete global battery_saver_constants
settings put global battery_stats_constants track_cpu_times_by_proc_state=false
settings delete global binder_calls_stats
settings delete global activity_manager_constants
#删除所有常量配置

#恢复WiFi和蓝牙扫描默认状态
if [ "$(settings get global wifi_scan_always_enabled)" = 0 ]; then settings put global wifi_scan_always_enabled 1;fi
if [ "$(settings get global ble_scan_always_enabled)" = 0 ]; then settings put global ble_scan_always_enabled 1;fi
#恢复WiFi和蓝牙扫描默认状态

#恢复默认配置/来自循环的配置

datasaveconfig="$utensil/datasaverconfiguration"
if [ -f "$datasaveconfig" ]; then
cmd netpolicy set restrict-background false
rm $datasaveconfig
fi


cmd power set-mode 0
cmd power set-adaptive-power-saver-enabled false
settings put global low_power 0
if [ "$(getprop ro.product.manufacturer)" = "Xiaomi" ]; then settings put system POWER_SAVE_MODE_OPEN 0;fi
#恢复默认配置/来自循环的配置

backup="$utensil/batteryconfiguration.dat"

if [ -f "$backup" ]; then
    . "$backup"
    [ -n "$low_power_sticky" ] && settings put global low_power_sticky "$low_power_sticky"
    rm -f "$backup"
fi

#开启传感器
dumpsys sensorservice enable

#关闭飞行模式
cmd connectivity airplane-mode disable

#内存压缩配置还原
compactconfig="$utensil/compactionconfiguration"

if [ -f "$compactconfig" ]; then
compactionstate=$(dumpsys activity settings | grep 'use_compaction=' | head -n1 | cut -d= -f2)
if [ "$compactionstate" != "false" ]; then device_config put activity_manager use_compaction false;fi
fi
rm $compactconfig

backupcompact="$utensil/savestatcompact"

if [ -f "$backupcompact" ];then
device_config put activity_manager use_compaction true
fi
rm $backupcompact

#屏幕超时时间还原
timeoutfile="$utensil/screentimeout.dat"
modifiedtimeout="$utensil/screentimeoutconfiguration"

if [ -f "$timeoutfile" ]; then
	settings put system screen_off_timeout $(cat $timeoutfile)
	rm $timeoutfile
	rm $modifiedtimeout
fi

thermalconfig="$utensil/thermalserviceconfiguration"
if [ -f "$thermalconfig" ];then 
cmd thermalservice override-status 0
rm $thermalconfig
fi
