async function safeExec(cmd) {
    if (window.webuix && window.webuix.send) return await window.webuix.send(cmd);
    if (window.ksu && window.ksu.exec) {
        const r = await window.ksu.exec(cmd);
        return r.stdout ? r.stdout : r;
    }
    return "";
}

window.openLink = async (url) => {
    await safeExec(`cmd activity start -a android.intent.action.VIEW -d "${url}"`);
};

const SAVED_PKG_PATH = "/data/local/tmp/kyroos_selected_apps.list";
let savedPackagesSet = new Set();

async function loadSavedPackagesList() {
    try {
        await safeExec(`touch ${SAVED_PKG_PATH}`);
        const content = await safeExec(`cat ${SAVED_PKG_PATH}`);
        if (content) {
            const list = content.split('\n').map(s => s.trim()).filter(Boolean);
            savedPackagesSet = new Set(list);
        } else {
            savedPackagesSet = new Set();
        }
    } catch (e) {
        savedPackagesSet = new Set();
    }
}

window.toggleAppSelection = async (pkg, checkbox) => {
    const isChecked = checkbox.checked;

    if (isChecked) {
        savedPackagesSet.add(pkg);
        await safeExec(`echo "${pkg}" >> ${SAVED_PKG_PATH}`);
    } else {
        savedPackagesSet.delete(pkg);
        if (savedPackagesSet.size === 0) {
            await safeExec(`rm -rf ${SAVED_PKG_PATH}`);
        } else {
            const safePkg = pkg.replace(/\./g, '\\.');
            await safeExec(`sed -i "/^${safePkg}$/d" ${SAVED_PKG_PATH}`);
        }
    }
};

const REFRESH_RATE_MAP = {
    0: 60,
    1: 90,
    2: 120,
    3: 144,
    4: -1
};
const REFRESH_RATE_TEXT = {
    '60': '60 Hz',
    '90': '90 Hz',
    '120': '120 Hz',
    '144': '144 Hz',
    '-1': 'Max (Stock/Auto)',
    '0': 'Max (Stock/Auto)'
};

function updateText(id, text, isSkeleton = false) {
    const el = document.getElementById(id);
    if (!el) return;
    if (el.textContent !== text) el.textContent = text;
    isSkeleton ? el.classList.add('skeleton') : el.classList.remove('skeleton');
}

async function runCmd(command) {
    return await safeExec(command);
}

window.toggleDescription = (cardId, descriptionId) => {
    const card = document.getElementById(cardId);
    const desc = document.getElementById(descriptionId);
    if (!card || !desc) return;

    document.querySelectorAll('.hidden-desc.expanded').forEach(d => {
        if (d.id !== descriptionId) {
            d.classList.remove('expanded');
            if (d.previousElementSibling) d.previousElementSibling.classList.remove('is-open');
        }
    });

    const isExpanded = desc.classList.contains('expanded');
    if (!isExpanded) {
        desc.classList.add('expanded');
        card.classList.add('is-open');
    } else {
        desc.classList.remove('expanded');
        card.classList.remove('is-open');
    }
};

const currentTheme = localStorage.getItem('theme');
const themeIcon = document.getElementById('theme-icon');

if (currentTheme) {
    document.documentElement.setAttribute('data-theme', currentTheme);
    if (currentTheme === 'dark' && themeIcon) {
        themeIcon.textContent = 'light_mode';
    }
}

function toggleTheme() {
    const attr = document.documentElement.getAttribute('data-theme');
    const icon = document.getElementById('theme-icon');
    if (attr === 'dark') {
        document.documentElement.setAttribute('data-theme', 'light');
        localStorage.setItem('theme', 'light');
        if (icon) icon.textContent = 'dark_mode';
    } else {
        document.documentElement.setAttribute('data-theme', 'dark');
        localStorage.setItem('theme', 'dark');
        if (icon) icon.textContent = 'light_mode';
    }
}

function setStatusVisuals(kyroosActive, perfActive) {
    const img = document.getElementById('status-image');
    const title = document.getElementById('status-title');
    const pid = document.getElementById('status-pid');
    const thresholdCard = document.getElementById('threshold-card');

    if (!img || !title || !pid) return;

    if (kyroosActive && perfActive) {
        img.src = 'status_working.png';
        title.textContent = 'Hybrid';
        title.style.color = '#9C27B0'; 
        
        pid.innerHTML = `<span class="material-symbols-rounded" style="font-size:14px; color:#9C27B0;">bolt</span> Dual Engine`;
        pid.style.borderColor = '#9C27B0';
        pid.style.color = '#9C27B0';
        pid.style.background = 'rgba(0, 184, 212, 0.1)';

        if (thresholdCard) thresholdCard.style.display = 'flex';

    } else if (perfActive) {
        img.src = 'status_working.png';
        title.textContent = 'Performance';
        title.style.color = '#C2185B'; 
        
        pid.innerHTML = `<span class="material-symbols-rounded" style="font-size:14px; color:#C2185B;">rocket_launch</span> Gaming Mode`;
        pid.style.borderColor = '#C2185B';
        pid.style.color = '#C2185B';
        pid.style.background = 'rgba(194, 24, 91, 0.1)';

        if (thresholdCard) thresholdCard.style.display = 'none';

    } else if (kyroosActive) {
        img.src = 'status_working.png';
        title.textContent = 'Active';
        title.style.color = 'var(--primary-color)'; 
        
        pid.innerHTML = `<span class="material-symbols-rounded" style="font-size:14px; color:var(--primary-color);">check_circle</span> Service Active`;
        pid.style.borderColor = 'var(--primary-color)';
        pid.style.color = 'var(--primary-color)';
        pid.style.background = 'var(--primary-container)';

        if (thresholdCard) thresholdCard.style.display = 'flex';

    } else {
        img.src = 'status_stopped.png';
        title.textContent = 'Inactive';
        title.style.color = 'var(--text-main)';
        
        pid.innerHTML = `<span class="material-symbols-rounded" style="font-size:14px;">power_settings_new</span> Inactive`;
        pid.style.borderColor = 'var(--outline)';
        pid.style.color = 'var(--text-sub)';
        pid.style.background = 'var(--surface-container)';

        if (thresholdCard) thresholdCard.style.display = 'flex';
    }
}

async function readMemTotalKB() {
    let raw = await runCmd("cat /proc/meminfo | grep MemTotal");
    if (!raw) raw = await runCmd("awk '/MemTotal/ {print $2}' /proc/meminfo");
    const kb = parseInt(raw.replace(/\D/g, ''), 10);
    return isNaN(kb) ? null : kb;
}

async function readThresholdFile() {
    const f = "/data/local/tmp/utensil/battery_learning.dat";
    const pct = await runCmd(`cat ${f}`);
    return pct && /^\d+$/.test(pct.trim()) ? pct.trim() : '';
}

async function loadHomeData(kyroosActive, perfActive) {
    const memEl = document.getElementById('memory-total-val');
    if (memEl && memEl.textContent === '...') updateText('memory-total-val', '...', true);
    
    const shouldReadThreshold = kyroosActive;

    if (shouldReadThreshold) {
        updateText('threshold-status-text', 'Reading...', false);
    }

    const [kb, thresholdPct] = await Promise.all([
        readMemTotalKB(),
        shouldReadThreshold ? readThresholdFile() : Promise.resolve('')
    ]);

    updateText('memory-total-val', kb ? (kb / 1024 / 1024).toFixed(1) + ' GB' : 'N/A', false);

    let fullMsg = '',
        summaryMsg = '';

    if (kyroosActive && perfActive) {
        if (thresholdPct) {
            fullMsg = `Hybrid Active. Threshold: ${thresholdPct}%`;
            summaryMsg = `Dual • ${thresholdPct}%`;
        } else {
            fullMsg = "Hybrid Mode Active";
            summaryMsg = "Dual Engine";
        }
    } else if (perfActive) {
        fullMsg = "";
        summaryMsg = "";
    } else if (kyroosActive) {
        if (thresholdPct) {
            fullMsg = `Battery saver triggers at ${thresholdPct}%`;
            summaryMsg = `Trigger at ${thresholdPct}%`;
        } else {
            fullMsg = "Please charge to calibrate data";
            summaryMsg = "Calibrating...";
        }
    } else {
        fullMsg = "Daemon is currently sleeping.";
        summaryMsg = "Service Stopped";
    }
    
    updateText('threshold-summary-msg', summaryMsg, false);
    updateText('threshold-status-text', fullMsg, false);
}

async function loadSystemInfo() {
    const daemonSwitch = document.getElementById('daemon-switch');
    const daemonText = document.getElementById('daemon-state-text');
    
    const perfSwitch = document.getElementById('perf-switch');
    const perfText = document.getElementById('perf-state-text');

    let isKyroosActive = false;
    let isPerfActive = false;

    let pidSigma = await runCmd('pgrep sigma');
    if (pidSigma && /^\d+$/.test(pidSigma.trim())) isKyroosActive = true;
    else {
        const sPs = await runCmd('ps -A | grep sigma | grep -v grep');
        if (sPs && sPs.match(/(\d+)/im)) isKyroosActive = true;
    }

    let pidGorr = await runCmd('pgrep gorrfu');
    if (pidGorr && /^\d+$/.test(pidGorr.trim())) isPerfActive = true;
    else {
        const gPs = await runCmd('ps -A | grep gorrfu | grep -v grep');
        if (gPs && gPs.match(/(\d+)/im)) isPerfActive = true;
    }

    setStatusVisuals(isKyroosActive, isPerfActive);

    if (daemonSwitch && daemonText) {
        daemonSwitch.checked = isKyroosActive;
        if (isKyroosActive) {
            daemonText.textContent = "Active • Balanced";
            daemonText.style.color = "var(--primary-color)";
            daemonText.style.fontWeight = "600";
        } else {
            daemonText.textContent = "Inactive";
            daemonText.style.color = "var(--text-sub)";
            daemonText.style.fontWeight = "500";
        }
    }

    if (perfSwitch && perfText) {
        perfSwitch.checked = isPerfActive;
        if (isPerfActive) {
            perfText.textContent = "Active • Performance";
            perfText.style.color = "#C2185B";
            perfText.style.fontWeight = "700";
        } else {
            perfText.textContent = "Inactive";
            perfText.style.color = "var(--text-sub)";
            perfText.style.fontWeight = "500";
        }
    }

    const relValEl = document.getElementById('release-val');
    if (relValEl && relValEl.classList.contains('skeleton')) {
        const [rel, kern, chipRaw, ndkRaw] = await Promise.all([
            runCmd('getprop ro.build.version.release'),
            runCmd('uname -r'),
            runCmd('getprop ro.board.platform'),
            runCmd('getprop ro.build.version.sdk')
        ]);

        let androidVersion = rel.trim() || 'Unknown';
        const ndkValue = ndkRaw.trim();
        let relText = androidVersion;

        if (ndkValue && ndkValue !== 'Unknown') {
            relText = `${androidVersion} (SDK ${ndkValue})`;
        }
        updateText('release-val', relText, false);

        updateText('kernel-val', kern || 'Unknown', false);
        let chip = chipRaw;
        if (chip && /sm|sdm/i.test(chip)) chip = `Snapdragon ${chip}`;
        updateText('chipset-val', chip || 'Unknown', false);
    }
    loadHomeData(isKyroosActive, isPerfActive);
}

async function loadRendererInfo() {
    updateText('current-renderer-val', 'Checking...', true);
    let val = await runCmd('getprop debug.hwui.renderer');
    if (!val) val = await runCmd('getprop ro.hwui.renderer');
    if (val) {
        val = val.trim().toLowerCase();
        if (val === 'skiagl') val = 'OpenGL';
        else if (val === 'skiavk') val = 'Vulkan';
        else val = val.charAt(0).toUpperCase() + val.slice(1);
    } else val = 'Default';
    updateText('current-renderer-val', val, false);
}

async function loadDriverInfo() {
    updateText('current-driver-val', 'Checking...', true);
    const driverVal = await runCmd('settings get global updatable_driver_all_apps');
    let valText = '';
    switch (driverVal.trim()) {
        case '0': valText = 'Default (0)'; break;
        case '1': valText = 'Game (1)'; break;
        case '2': valText = 'Dev (2)'; break;
        case '3': valText = 'Off (3)'; break;
        default: valText = `Unknown (${driverVal.trim()})`; break;
    }
    updateText('current-driver-val', valText, false);
}

async function loadRefreshRateInfo() {
    updateText('current-refresh-rate-val', 'Reading...', true);
    const slider = document.getElementById('refresh-rate-slider');
    let val = await runCmd('settings get system peak_refresh_rate');
    val = val.trim();
    let valText = REFRESH_RATE_TEXT[val] || `${val} Hz`;
    let closestIndex = -1;
    let currentValue = parseInt(val);

    if (isNaN(currentValue) || currentValue <= 0) {
        valText = REFRESH_RATE_TEXT['-1'];
        closestIndex = 4;
    } else {
        let foundMatch = false;
        for (const index in REFRESH_RATE_MAP) {
            if (REFRESH_RATE_MAP[index] === currentValue) {
                closestIndex = parseInt(index);
                foundMatch = true;
                break;
            }
        }
        if (!foundMatch) {
            valText = `${currentValue} Hz (Custom)`;
            closestIndex = -1;
        } else {
            valText = REFRESH_RATE_TEXT[currentValue];
        }
    }

    updateText('current-refresh-rate-val', valText, false);
    const labels = document.querySelectorAll('#refresh-rate-labels span');
    labels.forEach((label, i) => {
        const isCurrent = i === closestIndex;
        label.style.color = isCurrent ? 'var(--md-sys-color-primary)' : 'var(--md-sys-color-on-surface-variant)';
        label.style.fontWeight = isCurrent ? '700' : '500';
        label.style.transform = isCurrent ? (i > 0 && i < 4 ? 'translateX(-50%) scale(1.1)' : 'scale(1.1)') : (i > 0 && i < 4 ? 'translateX(-50%)' : 'none');
    });
    if (closestIndex >= 0 && slider) slider.value = closestIndex;
}

async function loadConfigData() {
    await Promise.all([
        loadRendererInfo(),
        loadDriverInfo(),
        loadRefreshRateInfo()
    ]);
}

let allPackages = [];
const PLACEHOLDER_ICON = 'data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHZpZXdCb3g9IjAgMCAyNCAyNCIgZmlsbD0iIzQ4NDY0QyI+PHBhdGggZD0iTTEyIDJDNi40OCAyIDIgNi40OCAyIDEyczQuNDggMTAgMTAgMTAgMTAtNC40OCAxMC0xMFMxNy41MiAyIDEyIDJ6bTAgMThjLTQuNDEgMC04LTMuNTktOC04czMuNTktOCA4LTggOCAzLjU5IDggOC0zLg55MiAzLTY0IDgtOCA4LTggOCAzLg55MiAzLTY0IDgtOCA4LTggOCAzLg55MiAzLTY0IDgtOCA4LTggOCAzLg55MiAzLTY0IDgtOCA4LTggOCAzLg55MiAzLTY0IDgtOCA4LTggOCAzLg55MiAzLTY0IDgtOCA4LTggOCAzLg55MiAzLTY0IDgtOCA4eiIvPjwvc3ZnPg==';

function debounce(func, delay) {
    let timeout;
    return function(...args) {
        const context = this;
        clearTimeout(timeout);
        timeout = setTimeout(() => func.apply(context, args), delay);
    };
}

async function fetchPackages() {
    try {
        let pkgList = [];
        if (window.ksu && window.ksu.listAllPackages) {
            pkgList = JSON.parse(window.ksu.listAllPackages());
        } else {
            const raw = await safeExec("pm list packages -u");
            pkgList = raw.split("\n")
                .filter(l => l.includes("package:"))
                .map(x => x.replace("package:", "").trim())
                .filter(Boolean);
        }
        return pkgList;
    } catch (err) {
        return [];
    }
}

const infoCache = {};

async function renderAppList(filter = '') {
    const container = document.getElementById('app-list-target');
    const countInfo = document.getElementById('app-count-info');
    const filterLower = filter.toLowerCase();

    const filtered = allPackages.filter(pkg =>
        pkg.toLowerCase().includes(filterLower) ||
        (infoCache[pkg]?.label || '').toLowerCase().includes(filterLower)
    );

    filtered.sort((a, b) => {
        const la = (infoCache[a]?.label || a).toLowerCase();
        const lb = (infoCache[b]?.label || b).toLowerCase();
        return la.localeCompare(lb);
    });

    if (countInfo) {
        countInfo.textContent = `${filtered.length} installed apps`;
        countInfo.style.display = 'block';
    }

    if (filtered.length === 0) {
        container.innerHTML = `
            <div class="empty-state" style="padding:40px 0; text-align:center;">
                <span class="material-symbols-rounded" style="font-size: 40px; opacity: 0.3;">search_off</span>
                <div style="opacity: 0.6; font-size:13px; margin-top:8px;">No applications found</div>
            </div>`;
        return;
    }

    const limit = 200;
    const shown = filtered.slice(0, limit);

    container.innerHTML = shown
        .map(pkg => {
            const info = infoCache[pkg];
            const label = info ? info.label : pkg;
            const icon = info ? info.icon : PLACEHOLDER_ICON;
            const isChecked = savedPackagesSet.has(pkg) ? 'checked' : '';

            return `
                <div class="app-card-item" id="app-${pkg}" onclick="openAppDetails('${pkg}')">
                    <img src="${icon}" class="app-card-icon" alt="icon">
                    <div class="app-card-info">
                        <div class="app-card-title">${label}</div>
                        <div class="app-card-pkg">${pkg}</div>
                    </div>
                    <div class="app-card-actions">
                        <label class="mini-switch" onclick="event.stopPropagation()">
                            <input type="checkbox" onchange="toggleAppSelection('${pkg}', this)" ${isChecked}>
                            <span class="mini-slider"></span>
                        </label>
                    </div>
                </div>
            `;
        })
        .join('') +
        (filtered.length > limit ?
            `<div style="text-align:center; padding:20px; font-size:11px; opacity:0.5;">+${filtered.length - limit} more</div>` :
            '');

    const missingPkgs = shown.filter(pkg => !infoCache[pkg]);
    if (missingPkgs.length === 0) return;

    if (window.ksu && window.ksu.getPackagesInfo && window.ksu.getPackagesIcons) {
        try {
            const [infoListRaw, iconListRaw] = await Promise.all([
                window.ksu.getPackagesInfo(JSON.stringify(missingPkgs)),
                window.ksu.getPackagesIcons(JSON.stringify(missingPkgs), 100)
            ]);

            const infoList = JSON.parse(infoListRaw);
            const iconList = JSON.parse(iconListRaw);

            const iconMap = {};
            for (const i of iconList) iconMap[i.packageName] = i.icon || '';

            for (const info of infoList) {
                infoCache[info.packageName] = {
                    label: info.appLabel || info.packageName,
                    icon: iconMap[info.packageName] || PLACEHOLDER_ICON,
                };
            }

            for (const pkg of missingPkgs) {
                const el = document.getElementById(`app-${pkg}`);
                if (!el || !infoCache[pkg]) continue;

                if (el.querySelector) {
                    el.querySelector(".app-card-title").textContent = infoCache[pkg].label;
                    el.querySelector(".app-card-icon").src = infoCache[pkg].icon;
                }
            }
        } catch (e) {}
    }
}

async function loadAppManager() {
    const container = document.getElementById('app-list-target');
    const loading = document.getElementById('app-list-loading');
    const scanBtn = document.getElementById('btn-scan-apps');
    const countInfo = document.getElementById('app-count-info');
    const notice = document.getElementById('app-manager-notice');

    if (scanBtn) scanBtn.style.display = 'none';
    if (countInfo) countInfo.style.display = 'none';
    if (notice) notice.style.display = 'flex';
    if (loading) loading.style.display = 'block';
    if (container) container.innerHTML = '';

    await loadSavedPackagesList();

    allPackages = [];
    allPackages = await fetchPackages();

    if (loading) loading.style.display = 'none';
    if (notice) notice.style.display = 'none';
    if (scanBtn) scanBtn.style.display = 'flex';

    if (allPackages.length > 0) {
        if (window.ksu && window.ksu.getPackagesInfo) {
            const initialPackages = allPackages.slice(0, 50);
            try {
                const [infoListRaw, iconListRaw] = await Promise.all([
                    window.ksu.getPackagesInfo(JSON.stringify(initialPackages)),
                    window.ksu.getPackagesIcons(JSON.stringify(initialPackages), 100)
                ]);
                const infoList = JSON.parse(infoListRaw);
                const iconList = JSON.parse(iconListRaw);
                const iconMap = {};
                for (const i of iconList) iconMap[i.packageName] = i.icon || '';
                for (const info of infoList) {
                    infoCache[info.packageName] = {
                        label: info.appLabel || info.packageName,
                        icon: iconMap[info.packageName] || PLACEHOLDER_ICON,
                    };
                }
            } catch (e) {}
        } else {
            allPackages.forEach(pkg => {
                infoCache[pkg] = {
                    label: pkg,
                    icon: PLACEHOLDER_ICON
                };
            });
        }

        renderAppList(document.getElementById('app-search-input').value);
    } else {
        container.innerHTML = `<div class="empty-state">Could not list packages.<br>Check permission or root access.</div>`;
    }
}

const debouncedRenderAppList = debounce((value) => {
    if (allPackages.length > 0) renderAppList(value);
}, 300);

document.getElementById('app-search-input').addEventListener('input', (e) => {
    debouncedRenderAppList(e.target.value);
});

document.getElementById('btn-scan-apps').onclick = loadAppManager;

let isNavigating = false;

function switchTab(targetId) {
    if (isNavigating) return;
    const current = document.querySelector('.content-section.active-section');
    const target = document.getElementById(targetId);

    if (targetId === 'modules-content') {
        document.getElementById('app-detail-content').classList.remove('active-subpage');
        document.getElementById('modules-content').style.display = 'flex';
        document.getElementById('main-nav').classList.remove('nav-hidden');
    }

    if (current === target) return;
    isNavigating = true;

    document.querySelectorAll('.nav-item').forEach(n => n.classList.remove('active'));
    document.getElementById(`nav-${targetId.replace('-content', '')}`).classList.add('active');

    const titleEl = document.getElementById('page-title');
    let iconName = '';
    let titleText = 'KyrooS';

    if (targetId === 'home-content') {
        iconName = '';
        titleText = 'KyrooS';
        setTimeout(loadSystemInfo, 300);
    } else if (targetId === 'configuration-content') {
        iconName = 'cookie';
        titleText = 'Config';
        setTimeout(loadConfigData, 300);
    } else if (targetId === 'modules-content') {
        iconName = 'inventory_2';
        titleText = 'App Manager';
    } else if (targetId === 'settings-content') {
        iconName = 'settings';
        titleText = 'Settings';
    }

    titleEl.innerHTML = `<span class="material-symbols-rounded filled-icon">${iconName}</span> ${titleText}`;

    if (current) {
        current.style.opacity = '0';
        current.style.transition = 'opacity 0.15s ease';
        setTimeout(() => {
            current.style.display = 'none';
            current.classList.remove('active-section');
            target.style.display = 'flex';
            void target.offsetWidth;
            target.classList.add('active-section');
            target.style.opacity = '1';
            isNavigating = false;
        }, 150);
    } else {
        target.style.display = 'flex';
        setTimeout(() => {
            target.classList.add('active-section');
            target.style.opacity = '1';
            isNavigating = false;
        }, 10);
    }
}

document.getElementById('nav-home').onclick = () => switchTab('home-content');
document.getElementById('nav-configuration').onclick = () => switchTab('configuration-content');
document.getElementById('nav-modules').onclick = () => switchTab('modules-content');
document.getElementById('nav-settings').onclick = () => switchTab('settings-content');

const APP_OPS_INFO = [{
        code: "WAKE_LOCK",
        label: "Wake Lock",
        icon: "visibility",
        desc: "Keep device awake."
    },
    {
        code: "RUN_IN_BACKGROUND",
        label: "Run in Background",
        icon: "background_replace",
        desc: "Allow execution in background."
    },
    {
        code: "START_FOREGROUND",
        label: "Start Foreground",
        icon: "notification_important",
        desc: "Start foreground services."
    },
    {
        code: "MONITOR_LOCATION",
        label: "Monitor Location",
        icon: "location_on",
        desc: "Access location in background."
    },
    {
        code: "ACTIVITY_RECOGNITION",
        label: "Activity Recognition",
        icon: "directions_walk",
        desc: "Detect physical activity."
    },
    {
        code: "GET_ACCOUNTS",
        label: "Get Accounts",
        icon: "manage_accounts",
        desc: "Read registered accounts."
    },
    {
        code: "SYSTEM_EXEMPT_FROM_HIBERNATION",
        label: "Exempt Hibernation",
        icon: "battery_saver",
        desc: "Avoid app hibernation."
    },
    {
        code: "RUN_ANY_IN_BACKGROUND",
        label: "Run Any BG",
        icon: "motion_photos_on",
        desc: "Force background running."
    },
    {
        code: "INSTANT_APP_START_FOREGROUND",
        label: "Instant App FG",
        icon: "rocket",
        desc: "Start FG service in instant app."
    },
    {
        code: "INTERACT_ACROSS_PROFILES",
        label: "Cross Profile",
        icon: "supervisor_account",
        desc: "Interact across users."
    },
    {
        code: "LOADER_USAGE_STATS",
        label: "Loader Usage",
        icon: "data_usage",
        desc: "Track data loader usage."
    },
    {
        code: "ACTIVITY_RECOGNITION_SOURCE",
        label: "Activity Source",
        icon: "sensors",
        desc: "Access sensor data."
    },
    {
        code: "FOREGROUND_SERVICE_SPECIAL_USE",
        label: "Special Service",
        icon: "medical_services",
        desc: "Special use FG service."
    },
    {
        code: "SYSTEM_EXEMPT_FROM_POWER_RESTRICTIONS",
        label: "Power Exempt",
        icon: "power",
        desc: "Ignore power restrictions."
    }
];

const COMPILE_MODES_INFO = [{
        id: "speed",
        icon: "rocket_launch",
        title: "Speed",
        desc: "Maximize runtime performance."
    },
    {
        id: "everything",
        icon: "all_inclusive",
        title: "Everything",
        desc: "Compile all. Slowest build."
    },
    {
        id: "speed-profile",
        icon: "offline_bolt",
        title: "Speed Profile",
        desc: "Optimize hot methods."
    },
    {
        id: "quicken",
        icon: "bolt",
        title: "Quicken",
        desc: "Fast optimization."
    },
    {
        id: "space-profile",
        icon: "save",
        title: "Space Profile",
        desc: "Prioritize storage space."
    },
    {
        id: "space",
        icon: "compress",
        title: "Space",
        desc: "Maximize storage saving."
    },
    {
        id: "verify",
        icon: "verified_user",
        title: "Verify",
        desc: "Only verify classes."
    },
    {
        id: "assume-verified",
        icon: "fact_check",
        title: "Assume Verified",
        desc: "Skip verification (Risky)."
    },
    {
        id: "extract",
        icon: "unarchive",
        title: "Extract",
        desc: "No optimization."
    }
];

let currentAppPkg = '';
let currentSelectedOpCode = '';
let currentSubView = null;
let currentCompileMode = '';

window.openAppDetails = (pkg) => {
    currentAppPkg = pkg;
    currentSubView = null;

    const listSection = document.getElementById('modules-content');
    const detailSection = document.getElementById('app-detail-content');
    const header = document.getElementById('main-header');
    const nav = document.getElementById('main-nav');

    const info = infoCache[pkg];
    document.getElementById('detail-app-name').textContent = info ? info.label : pkg;
    document.getElementById('detail-app-pkg').textContent = pkg;
    document.getElementById('detail-app-icon').src = info ? info.icon : PLACEHOLDER_ICON;

    document.getElementById('app-dashboard-menu').style.display = 'grid';

    ['view-ops', 'view-compile', 'view-uninstall'].forEach(id => {
        document.getElementById(id).style.display = 'none';
    });

    listSection.style.display = 'none';
    header.style.display = 'none';
    nav.classList.add('nav-hidden');
    detailSection.classList.add('active-subpage');
    window.scrollTo(0, 0);
};

window.openSubFeature = (featureName) => {
    const dashboard = document.getElementById('app-dashboard-menu');
    currentSubView = featureName;

    dashboard.style.display = 'none';

    if (featureName === 'ops') {
        renderOpsList();
        document.getElementById('view-ops').style.display = 'flex';
    } else if (featureName === 'compile') {
        renderCompileList();
        document.getElementById('view-compile').style.display = 'flex';
    } else if (featureName === 'uninstall') {
        document.getElementById('view-uninstall').style.display = 'flex';
    }
};

function renderOpsList() {
    const opsContainer = document.getElementById('ops-list-target');
    opsContainer.innerHTML = APP_OPS_INFO.map(op => `
        <div class="modern-list-item" onclick="openOpDialog('${op.code}', '${op.label}')">
            <div class="modern-icon-box" style="background: var(--md-sys-color-surface-container-high); color: var(--md-sys-color-primary);">
                <span class="material-symbols-rounded">${op.icon}</span>
            </div>
            <div class="modern-text">
                <span class="modern-title">${op.label}</span>
                <span class="modern-desc">${op.desc}</span>
            </div>
            <div class="action-indicator">
                <span class="material-symbols-rounded" style="font-size:18px;">arrow_forward</span>
            </div>
        </div>
    `).join('');
}

function renderCompileList() {
    const container = document.getElementById('compile-list-target');
    if (!container) return;

    container.innerHTML = COMPILE_MODES_INFO.map(mode => `
        <div class="modern-list-item" onclick="openCompileDialog('${mode.id}')">
            <div class="modern-icon-box" style="background: var(--md-sys-color-surface-container-high); color: var(--md-sys-color-tertiary);">
                <span class="material-symbols-rounded">${mode.icon}</span>
            </div>
            <div class="modern-text">
                <span class="modern-title">${mode.title}</span>
                <span class="modern-desc">${mode.desc}</span>
            </div>
            <div class="action-indicator">
                <span class="material-symbols-rounded" style="font-size:18px;">play_arrow</span>
            </div>
        </div>
    `).join('');
}

window.openCompileDialog = (mode) => {
    currentCompileMode = mode;
    document.getElementById('compile-dialog-mode').textContent = mode;
    document.getElementById('compile-dialog').classList.add('show');

    const btn = document.getElementById('btn-confirm-compile');
    btn.innerHTML = `<span class="material-symbols-rounded">play_arrow</span> Start Compile`;
    btn.disabled = false;
    btn.style.opacity = '1';
};

window.closeCompileDialog = () => {
    document.getElementById('compile-dialog').classList.remove('show');
};

window.openUninstallConfirmation = () => {
    if (!currentAppPkg) return;
    document.getElementById('uninstall-pkg-name').textContent = currentAppPkg;
    document.getElementById('uninstall-dialog').classList.add('show');
    document.getElementById('uninstall-logs').style.display = 'none';
    document.getElementById('uninstall-logs').innerHTML = '';

    const btn = document.getElementById('btn-confirm-uninstall');
    btn.innerHTML = `<span class="material-symbols-rounded">delete</span> Yes, Uninstall`;
    btn.disabled = false;
    btn.style.opacity = '1';
};

window.closeUninstallDialog = () => {
    document.getElementById('uninstall-dialog').classList.remove('show');
};

window.confirmUninstall = async () => {
    if (!currentAppPkg) return;

    const btn = document.getElementById('btn-confirm-uninstall');
    const logDiv = document.getElementById('uninstall-logs');
    btn.innerHTML = `<span class="material-symbols-rounded fa-spin">refresh</span> Cleaning...`;
    btn.disabled = true;
    btn.style.opacity = '0.7';
    logDiv.style.display = 'block';

    const DEL = currentAppPkg;

    const cmdList = [
        `pm uninstall-system-updates ${DEL}`,
        `pm clear ${DEL}`,
        `pm uninstall --user 0 ${DEL}`,
        `pm uninstall -k --user 0 ${DEL}`,
        `cmd package uninstall --user 0 ${DEL}`,
        `am force-stop ${DEL}`
    ];

    for (const cmd of cmdList) {
        logDiv.innerHTML += `> ${cmd}\n`;
        logDiv.scrollTop = logDiv.scrollHeight;
        await safeExec(cmd);
    }

    logDiv.innerHTML += `> DONE. Package removed.\n`;
    btn.innerHTML = `<span class="material-symbols-rounded">check</span> Completed`;

    setTimeout(() => {
        window.closeUninstallDialog();
        window.handleBackNavigation();
        loadAppManager();
    }, 1500);
};

window.confirmCompile = async () => {
    if (!currentAppPkg || !currentCompileMode) return;

    const btn = document.getElementById('btn-confirm-compile');
    btn.innerHTML = `<span class="material-symbols-rounded fa-spin">refresh</span> Compiling...`;
    btn.disabled = true;
    btn.style.opacity = '0.7';

    const cmd = `pm compile -m ${currentCompileMode} ${currentAppPkg}`;

    try {
        await safeExec(cmd);
        setTimeout(() => {
            window.closeCompileDialog();
        }, 800);
    } catch (e) {
        btn.innerHTML = `<span class="material-symbols-rounded">error</span> Failed`;
        setTimeout(() => window.closeCompileDialog(), 1500);
    }
};

window.handleBackNavigation = () => {
    if (currentSubView !== null) {
        ['view-ops', 'view-compile', 'view-uninstall'].forEach(id => {
            document.getElementById(id).style.display = 'none';
        });

        document.getElementById('app-dashboard-menu').style.display = 'grid';
        currentSubView = null;
    } else {
        closeAppDetails();
    }
};

document.getElementById('btn-back-ops').onclick = window.handleBackNavigation;

window.closeAppDetails = () => {
    const listSection = document.getElementById('modules-content');
    const detailSection = document.getElementById('app-detail-content');
    const header = document.getElementById('main-header');
    const nav = document.getElementById('main-nav');

    detailSection.classList.remove('active-subpage');

    setTimeout(() => {
        listSection.style.display = 'flex';
        header.style.display = 'flex';
        nav.classList.remove('nav-hidden');
    }, 150);
};

window.openOpDialog = (opCode, opLabel) => {
    currentSelectedOpCode = opCode;
    document.getElementById('op-dialog-title').textContent = opLabel || opCode;
    document.getElementById('op-mode-dialog').classList.add('show');
};

window.closeOpDialog = () => {
    document.getElementById('op-mode-dialog').classList.remove('show');
};

window.executeOp = async (mode) => {
    if (!currentAppPkg || !currentSelectedOpCode) return;
    window.closeOpDialog();
    const cmd = `appops set ${currentAppPkg} ${currentSelectedOpCode} ${mode}`;
    await safeExec(cmd);
};

document.getElementById('daemon-switch').onchange = async (e) => {
    const isChecked = e.target.checked;
    const stateText = document.getElementById('daemon-state-text');
    if (stateText) stateText.textContent = "Processing...";
    e.target.disabled = true;
    
    if (isChecked) {
        await safeExec('sigma &');
    } else {
        await safeExec('pkill -9 -f sigma');
        await safeExec('killall -9 sigma'); 
    }
    
    setTimeout(() => { loadSystemInfo(); e.target.disabled = false; }, 1200);
};

document.getElementById('perf-switch').onchange = async (e) => {
    const isChecked = e.target.checked;
    const stateText = document.getElementById('perf-state-text');
    if (stateText) stateText.textContent = "Processing...";
    e.target.disabled = true;
    
    if (isChecked) {
        await safeExec('gorrfu &');
    } else {
        await safeExec('pkill -9 -f gorrfu');
        await safeExec('killall -9 gorrfu'); 
    }
    
    setTimeout(() => { loadSystemInfo(); e.target.disabled = false; }, 1200);
};

document.getElementById('btn-trim-cache').onclick = async function() {
    const gb = document.getElementById('cache-mb-input').value;
    const btn = this;
    const orig = btn.innerHTML;
    btn.innerHTML = `<span class="material-symbols-rounded fa-spin">refresh</span>`;
    await safeExec(`pm trim-caches ${gb}G`);
    btn.innerHTML = `<span class="material-symbols-rounded">check</span>`;
    setTimeout(() => btn.innerHTML = orig, 1500);
};

document.querySelectorAll('.btn-m3[data-renderer]').forEach(btn => {
    btn.onclick = async () => {
        const r = btn.dataset.renderer;
        const orig = btn.innerHTML;
        btn.innerHTML = `<span class="material-symbols-rounded fa-spin">refresh</span>`;
        await safeExec(`setprop debug.hwui.renderer ${r}`);
        setTimeout(() => {
            btn.innerHTML = orig;
            loadRendererInfo();
        }, 1500);
    };
});

document.querySelectorAll('.btn-m3[data-driver-val]').forEach(btn => {
    btn.onclick = async () => {
        const v = btn.dataset.driverVal;
        const orig = btn.innerHTML;
        btn.innerHTML = `<span class="material-symbols-rounded fa-spin">refresh</span>`;
        await safeExec(`settings put global updatable_driver_all_apps ${v}`);
        if (v === '1') await safeExec(`settings put global game_driver_all_apps 1`);
        else if (v === '0') await safeExec(`settings put global game_driver_all_apps 0`);
        setTimeout(() => {
            btn.innerHTML = orig;
            loadDriverInfo();
        }, 1500);
    };
});

document.getElementById('refresh-rate-slider').oninput = async function() {
    const index = parseInt(this.value);
    const rateValue = REFRESH_RATE_MAP[index];

    updateText('current-refresh-rate-val', `${REFRESH_RATE_TEXT[String(rateValue)]} (Applying...)`, false);

    const execVal = rateValue === -1 ? '0' : rateValue;
    const minVal = rateValue === -1 ? '0' : `${rateValue}.0`;

    await Promise.all([
        safeExec(`settings put system peak_refresh_rate ${execVal}`),
        safeExec(`settings put system min_refresh_rate ${minVal}`)
    ]);

    loadRefreshRateInfo();
};

document.querySelectorAll('#refresh-rate-labels span').forEach((label, index) => {
    label.onclick = async () => {
        const s = document.getElementById('refresh-rate-slider');
        if (s) {
            s.value = index;
            s.dispatchEvent(new Event('input'));
        }
    };
});

document.getElementById('silent-login-btn').onclick = async function() {
    const btn = this;
    const orig = btn.innerHTML;
    btn.innerHTML = `<span class="material-symbols-rounded fa-spin">refresh</span> Stealthing...`;
    await safeExec('silent-trace');
    btn.innerHTML = `<span class="material-symbols-rounded">check</span> Active`;
    setTimeout(() => btn.innerHTML = orig, 2000);
};

async function stopApps(type, btnId) {
    const btn = document.getElementById(btnId);
    const orig = btn.innerHTML;
    btn.innerHTML = `<span class="material-symbols-rounded fa-spin">refresh</span> Stopping...`;
    const flag = type === 'user' ? '-u' : type === 'system' ? '-s' : '-a';
    await safeExec(`app-stopper ${flag}`);
    btn.innerHTML = `<span class="material-symbols-rounded">check</span> Done`;
    setTimeout(() => btn.innerHTML = orig, 2000);
}

document.getElementById('btn-kill-user').onclick = () => stopApps('user', 'btn-kill-user');
document.getElementById('btn-kill-sys').onclick = () => stopApps('system', 'btn-kill-sys');
document.getElementById('btn-kill-all').onclick = () => stopApps('all', 'btn-kill-all');

document.getElementById('reset-data-btn').onclick = async () => {
    if (confirm("Reset Data & Reboot?")) {
        await safeExec('rm -rf /data/local/tmp/battery_threshold.dat');
        await safeExec('reboot');
    }
};

document.getElementById('get-log-btn').onclick = async () => {
    const btn = document.getElementById('get-log-btn');
    const orig = btn.innerHTML;
    btn.innerHTML = "Saving...";
    await safeExec('logcat -d > /sdcard/StarFlow_Log.txt');
    alert('Log Saved to Internal Storage: /sdcard/StarFlow_Log.txt');
    btn.innerHTML = orig;
};

document.addEventListener('DOMContentLoaded', () => {
    switchTab('home-content');
    setTimeout(loadSystemInfo, 300);
});
