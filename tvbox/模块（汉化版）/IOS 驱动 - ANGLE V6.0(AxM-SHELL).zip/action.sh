cmd notification post -S bigtext -t 'IOS DRIVER GAMING' 'Tag' '正在安装进程' > /dev/null 2>&1
echo ""
echo "█▓▒▒░░░IOS DRIVER GAMING░░░▒▒▓█"
echo ""
sleep 0.5

# 保存安装日期
date '+%Y-%m-%d %H:%M:%S' > /data/local/tmp/touch_tweak_install_date

INSTALL_DATE=$(cat /data/local/tmp/touch_tweak_install_date 2>/dev/null || echo "未知")

echo "┌────────────────────────────────────────────┐"
echo "│         设备与硬件信息          │"
echo "├────────────────────────────────────────────┤"
echo "│ 📱 设备   : $(getprop ro.product.manufacturer) $(getprop ro.product.model) │"
echo "│ ⚙️ CPU    : $(getprop ro.board.platform) │"
echo "│ 🎮 GPU    : $(getprop ro.hardware) │"
echo "│ 📲 Android: $(getprop ro.build.version.release) │"
echo "│ 📅 安装时间: $INSTALL_DATE │"
echo "│ 🔰 内核   : $(uname -r) │"
echo "│ 🔹 构建   : $(getprop ro.build.display.id) │"
echo "│ 🛑 Root   : $(if [ $(id -u) -eq 0 ]; then echo '是'; else echo '否'; fi) │"
echo "│ 🔗 SELinux: $(getenforce) │"
echo "└────────────────────────────────────────────┘"
echo ""
echo "█▓▒▒░░░欢迎使用安装程序░░░▒▒▓█"
echo ""
sleep 0.5
echo ""
echo " 

██╗░█████╗░░██████╗
██║██╔══██╗██╔════╝
██║██║░░██║╚█████╗░
██║██║░░██║░╚═══██╗
██║╚█████╔╝██████╔╝
╚═╝░╚════╝░╚═════╝░

░░███╗░░███████╗
░████║░░██╔════╝
██╔██║░░██████╗░
╚═╝██║░░╚════██╗
███████╗██████╔╝
╚══════╝╚═════╝░ "
echo ""
sleep 0.5
echo ""
echo " 
░█▀▀▄ ░█▀▀█ ▀█▀ ░█──░█ ░█▀▀▀ ░█▀▀█ 
░█─░█ ░█▄▄▀ ░█─ ─░█░█─ ░█▀▀▀ ░█▄▄▀ 
░█▄▄▀ ░█─░█ ▄█▄ ──▀▄▀─ ░█▄▄▄ ░█─░█ "
echo ""
sleep 3
# 权限设置
pm grant com.android.angle android.permission.WRITE_SECURE_SETTINGS
pm > /dev/null 2>&1

(
settings put global game_driver_opt_in_apps "$GAME_PACKAGES"
settings put global updatable_driver_production_opt_in_apps "$GAME_PACKAGES"
setprop debug.vulkan.enable true
setprop debug.renderengine.backend skiaglthreaded
setprop debug.graphics.angle.developeroption.enable true
settings put global enable_gpu_debug_layers 1
settings put global force_hw_ui 1
settings put system debug.hwui.layer_cache_size 64
settings put system debug.hwui.text_small_cache_width 2048
settings put system debug.hwui.text_small_cache_height 2048
settings put system debug.hwui.disable_vsync false
setprop debug.hwui.drop_shadow_cache_size 6
setprop debug.hwui.render_dirty_regions false
setprop debug.hwui.use_buffer_age false
settings put global angle_gl_driver_selection_angle egl
) > /dev/null 2>&1

# 授予存储访问权限
pm grant com.android.angle android.permission.READ_EXTERNAL_STORAGE > /dev/null 2>&1
pm grant com.android.angle android.permission.WRITE_EXTERNAL_STORAGE > /dev/null 2>&1
cmd package grant com.android.angle android.permission.READ_EXTERNAL_STORAGE > /dev/null 2>&1
cmd package grant com.android.angle android.permission.WRITE_EXTERNAL_STORAGE > /dev/null 2>&1

# 授予通知权限
pm grant com.android.angle android.permission.POST_NOTIFICATIONS > /dev/null 2>&1
cmd package grant com.android.angle android.permission.POST_NOTIFICATIONS > /dev/null 2>&1

# 授予系统设置权限
pm grant com.android.angle android.permission.WRITE_SECURE_SETTINGS > /dev/null 2>&1
cmd package grant com.android.angle android.permission.WRITE_SECURE_SETTINGS > /dev/null 2>&1

# 允许应用在后台运行
cmd appops set com.android.angle RUN_IN_BACKGROUND allow > /dev/null 2>&1
cmd appops set com.android.angle RUN_ANY_IN_BACKGROUND allow > /dev/null 2>&1
cmd appops set com.android.angle START_FOREGROUND allow > /dev/null 2>&1

# 授予唤醒锁定权限（防止休眠）
cmd appops set com.android.angle WAKE_LOCK allow > /dev/null 2>&1

# 允许应用管理存储
cmd appops set com.android.angle MANAGE_EXTERNAL_STORAGE allow > /dev/null 2>&1
cmd appops set com.android.angle LEGACY_STORAGE allow > /dev/null 2>&1

# 允许修改系统设置
cmd appops set com.android.angle WRITE_SETTINGS allow > /dev/null 2>&1

# 拒绝使用情况统计权限（可选，可删除如果不想限制）
cmd appops set com.android.angle GET_USAGE_STATS deny > /dev/null 2>&1

(
# 提升触控响应速度 iOS 手感
settings put global touch_press_delay 0
settings put global touchboost_enable 1
settings put global touch_gesture_rate 120
settings put global touch_motionfilter_enable 0
settings put global touch_size_scale 0.8
settings put global touch_responsiveness 1
settings put global device_input_boost 1
) > /dev/null 2>&1

(
# 内存与缓存调优
settings put global purgeable_assets 1
settings put global mem_boost 1
settings put global hwui_texture_cache_size 96
settings put global hwui_gradient_cache_size 2
settings put global hwui_path_cache_size 64
settings put global hwui_texture_cache_flushrate 0
) > /dev/null 2>&1

# 线程优化 类似 iOS 调度器
(
setprop debug.angle.force_metal_backend 1
setprop debug.angle.metal.prefer_gpu 1
setprop debug.angle.optimize_render_pass 1
setprop debug.angle.command_buffer_fastpath 1
setprop debug.angle.pipeline_cache 1
) > /dev/null 2>&1

(
# 性能稳定性
setprop debug.performance.tuning 1 
setprop debug.performance.profile 1 
setprop debug.performance.disturb false 
setprop debug.performance_schema_digests_size 9950000 
setprop debug.performance_schema 1 
setprop debug.performance_schema_max_memory_classes 387 
setprop debug.performance_schema_max_socket_classes 10 
) > /dev/null 2>&1 

# ANGLE 使用
(
# 新
setprop debug.angle.overlay FPS:Metal*PipelineCache*
setprop debug.hwui.shadow.renderer metal
setprop debug.renderengine.backend metal
setprop debug.stagefright.renderengine.backend metal
setprop debug.angle.backend metal
setprop debug.stagefright.renderengine.backend metal
setprop debug.angle.feature_overrides_enabled 1 preferLinearFilterForYUV:mapUnspecifiedColorSpaceToPassThrough
setprop debug.composition.type moltengl 
setprop debug.hwui.renderer moltengl
setprop debug.mediatek.composition.type moltengl
) > /dev/null 2>&1 

(
setprop debug.angle.enable_vulkan_api_dump_layer 1 
setprop debug.angle.validation 1 
setprop debug.gles.angle 1 
setprop debug.angle.capture.frame_end 200
setprop debug.angle.capture.enabled 1
setprop debug.angle.capture.out_dir foo
setprop debug.angle.capture.frame_start 0
setprop debug.angle.capture.label bar
setprop debug.angle.capture.trigger 20
setprop debug.gfx.angle.supported true
setprop debug.angle.rules /data/local/tmp/a4a_rules.json
settings put global graphics.egl angle
settings put global build_angle_deqp_tests true
settings put global proprietary_codecs true
setprop debug.angle_enable_vulkan true
setprop debug.angle_enable_vulkan_validation_layers true
setprop debug.angle_libs_suffix angle
setprop debug.angle_enable_null false
setprop debug.angle_force_thread_safety true
setprop debug.angle.markers 1
) > /dev/null 2>&1 

# Renderangle 激活
(
setprop debug.hwui.renderer moltengl
setprop debug.hwui.use_threaded_renderer true
settings put global angle_gl_driver_selection_value angle
settings put global angle_gl_driver_all_angle 0 ) > /dev/null 2>&1

(
# IOS DRIVER 每款应用
settings put global angle_gl_driver_selection_values angle
settings put global angle_gl_driver_selection_package com.vega.alphafgl,com.garena.game.codm,com.levelinfinite.sgameGlobal,com.je.supersus,com.carxtech.sr,com.rockstargames.gtasa,com.rockstargames.gtalcs,com.rockstargames.gtavc,com.rockstargames.gtabycity,com.mojang.minecraftpe,com.levelinfinite.sgameGlobal,com.mobile.legends,com.mobilelegends.hwag,com.mobilelegends.mi,com.dfjz.moba,com.miHoYo.GenshinImpact,com.dts.freefiremax,com.netmarble.sololv,com.dts.freefireth,com.tencent.ig,jp.konami.pesam,com.netease.newspike,com.HoYoverse.hsr.google,com.ea.gp.fifamobile,net.kdt.pojavlaunch,com.mojang.minecraftpe,com.activision.callofduty.shooter,com.activision.callofduty.warzone,com.gamedevltd.wwh,com.galasports.totalfootball,com.pubg.krmobile,com.kurogame.wutheringwaves.global,com.craftsman.go,com.roblox.client,com.global.extremegames.arenabreakout,com.riotgames.league.wildrift,com.tencent.iglite
settings put global angle_allowlist com.vega.alphafgl,com.garena.game.codm,com.levelinfinite.sgameGlobal,com.je.supersus,com.carxtech.sr,com.rockstargames.gtasa,com.rockstargames.gtalcs,com.rockstargames.gtavc,com.rockstargames.gtabycity,com.mojang.minecraftpe,com.levelinfinite.sgameGlobal,com.mobile.legends,com.mobilelegends.hwag,com.mobilelegends.mi,com.dfjz.moba,com.miHoYo.GenshinImpact,com.dts.freefiremax,com.netmarble.sololv,com.dts.freefireth,com.tencent.ig,jp.konami.pesam,com.netease.newspike,com.HoYoverse.hsr.google,com.ea.gp.fifamobile,net.kdt.pojavlaunch,com.mojang.minecraftpe,com.activision.callofduty.shooter,com.activision.callofduty.warzone,com.gamedevltd.wwh,com.galasports.totalfootball,com.pubg.krmobile,com.kurogame.wutheringwaves.global,com.craftsman.go,com.roblox.client,com.global.extremegames.arenabreakout,com.riotgames.league.wildrift,com.tencent.iglite,com.netease.dfjssea,com.garena.game.df,com.hermes.p6gameos,com.pixonic.wwr,com.miraclegames.farlight84,com.digitalextremes.warframe.mobile,com.xd.t3.global,com.studioarm.sigma,com.levelinfinite.sgameGlobal,com.netease.g104na.google,com.ngame.allstar.eu,com.levelinfinite.hotta.gp,com.gameark.ggplay.lon,com.sg.dragonheir,com.nvsgames.dmc,com.carxtech.carxdr2,com.carxtech.sr,com.ea.games.r3_row,com.gameloft.android.ANMP.GloftA9HM,com.and.games505.TerrariaPaid,com.sandboxol.blockymods,com.kitkagames.fallbuddies,com.bhvr.deadbydaylight,com.lightyear.projectevo,com.tencent.undawn,com.rockstargames.gtasa
) > /dev/null 2>&1

(
# IOS DRIVER 每款应用
settings put global angle_gl_driver_selection_values angle
settings put global angle_gl_driver_selection_package com.vega.alphafgl,com.garena.game.codm,com.levelinfinite.sgameGlobal,com.je.supersus,com.carxtech.sr,com.rockstargames.gtasa,com.rockstargames.gtalcs,com.rockstargames.gtavc,com.rockstargames.gtabycity,com.mojang.minecraftpe,com.levelinfinite.sgameGlobal,com.mobile.legends,com.mobilelegends.hwag,com.mobilelegends.mi,com.dfjz.moba,com.miHoYo.GenshinImpact,com.dts.freefiremax,com.netmarble.sololv,com.dts.freefireth,com.tencent.ig,jp.konami.pesam,com.netease.newspike,com.HoYoverse.hsr.google,com.ea.gp.fifamobile,net.kdt.pojavlaunch,com.mojang.minecraftpe,com.activision.callofduty.shooter,com.activision.callofduty.warzone,com.gamedevltd.wwh,com.galasports.totalfootball,com.pubg.krmobile,com.kurogame.wutheringwaves.global,com.craftsman.go,com.roblox.client,com.global.extremegames.arenabreakout,com.riotgames.league.wildrift,com.tencent.iglite
settings put global angle_allowlist com.vega.alphafgl,com.garena.game.codm,com.levelinfinite.sgameGlobal,com.je.supersus,com.carxtech.sr,com.rockstargames.gtasa,com.rockstargames.gtalcs,com.rockstargames.gtavc,com.rockstargames.gtabycity,com.mojang.minecraftpe,com.levelinfinite.sgameGlobal,com.mobile.legends,com.mobilelegends.hwag,com.mobilelegends.mi,com.dfjz.moba,com.miHoYo.GenshinImpact,com.dts.freefiremax,com.netmarble.sololv,com.dts.freefireth,com.tencent.ig,jp.konami.pesam,com.netease.newspike,com.HoYoverse.hsr.google,com.ea.gp.fifamobile,net.kdt.pojavlaunch,com.mojang.minecraftpe,com.activision.callofduty.shooter,com.activision.callofduty.warzone,com.gamedevltd.wwh,com.galasports.totalfootball,com.pubg.krmobile,com.kurogame.wutheringwaves.global,com.craftsman.go,com.roblox.client,com.global.extremegames.arenabreakout,com.riotgames.league.wildrift,com.tencent.iglite,com.netease.dfjssea,com.garena.game.df,com.hermes.p6gameos,com.pixonic.wwr,com.miraclegames.farlight84,com.digitalextremes.warframe.mobile,com.xd.t3.global,com.studioarm.sigma,com.levelinfinite.sgameGlobal,com.netease.g104na.google,com.ngame.allstar.eu,com.levelinfinite.hotta.gp,com.gameark.ggplay.lon,com.sg.dragonheir,com.nvsgames.dmc,com.carxtech.carxdr2,com.carxtech.sr,com.ea.games.r3_row,com.gameloft.android.ANMP.GloftA9HM,com.and.games505.TerrariaPaid,com.sandboxol.blockymods,com.kitkagames.fallbuddies,com.bhvr.deadbydaylight,com.lightyear.projectevo,com.tencent.undawn,com.rockstargames.gtasa
settings put global angle_allowlist com.vega.alphafgl,com.garena.game.codm,com.levelinfinite.sgameGlobal,com.je.supersus,com.carxtech.sr,com.rockstargames.gtasa,com.rockstargames.gtalcs,com.rockstargames.gtavc,com.rockstargames.gtabycity,com.mojang.minecraftpe,com.levelinfinite.sgameGlobal,com.mobile.legends,com.mobilelegends.hwag,com.mobilelegends.mi,com.dfjz.moba,com.miHoYo.GenshinImpact,com.dts.freefiremax,com.netmarble.sololv,com.dts.freefireth,com.tencent.ig,jp.konami.pesam,com.netease.newspike,com.HoYoverse.hsr.google,com.ea.gp.fifamobile,net.kdt.pojavlaunch,com.mojang.minecraftpe,com.activision.callofduty.shooter,com.activision.callofduty.warzone,com.gamedevltd.wwh,com.galasports.totalfootball,com.pubg.krmobile,com.kurogame.wutheringwaves.global,com.craftsman.go,com.roblox.client,com.global.extremegames.arenabreakout,com.riotgames.league.wildrift,com.tencent.iglite
settings put global angle_allowlist com.vega.alphafgl,com.garena.game.codm,com.levelinfinite.sgameGlobal,com.je.supersus,com.carxtech.sr,com.rockstargames.gtasa,com.rockstargames.gtalcs,com.rockstargames.gtavc,com.rockstargames.gtabycity,com.mojang.minecraftpe,com.levelinfinite.sgameGlobal,com.mobile.legends,com.mobilelegends.hwag,com.mobilelegends.mi,com.dfjz.moba,com.miHoYo.GenshinImpact,com.dts.freefiremax,com.netmarble.sololv,com.dts.freefireth,com.tencent.ig,jp.konami.pesam,com.netease.newspike,com.HoYoverse.hsr.google,com.ea.gp.fifamobile,net.kdt.pojavlaunch,com.mojang.minecraftpe,com.activision.callofduty.shooter,com.activision.callofduty.warzone,com.gamedevltd.wwh,com.galasports.totalfootball,com.pubg.krmobile,com.kurogame.wutheringwaves.global,com.craftsman.go,com.roblox.client,com.global.extremegames.arenabreakout,com.riotgames.league.wildrift,com.tencent.iglite,com.netease.dfjssea,com.garena.game.df,com.hermes.p6gameos,com.pixonic.wwr,com.miraclegames.farlight84,com.digitalextremes.warframe.mobile,com.xd.t3.global,com.studioarm.sigma,com.levelinfinite.sgameGlobal,com.netease.g104na.google,com.ngame.allstar.eu,com.levelinfinite.hotta.gp,com.gameark.ggplay.lon,com.sg.dragonheir,com.nvsgames.dmc,com.carxtech.carxdr2,com.carxtech.sr,com.ea.games.r3_row,com.gameloft.android.ANMP.GloftA9HM,com.and.games505.TerrariaPaid,com.sandboxol.blockymods,com.kitkagames.fallbuddies,com.bhvr.deadbydaylight,com.lightyear.projectevo,com.tencent.undawn,com.rockstargames.gtasa
) > /dev/null 2>&1

# ANGLE 驱动
(
settings put global angle_debug_package com.vega.alphafgl,com.garena.game.codm,com.levelinfinite.sgameGlobal,com.je.supersus,com.carxtech.sr,com.rockstargames.gtasa,com.rockstargames.gtalcs,com.rockstargames.gtavc,com.rockstargames.gtabycity,com.mojang.minecraftpe,com.levelinfinite.sgameGlobal,com.mobile.legends,com.mobilelegends.hwag,com.mobilelegends.mi,com.dfjz.moba,com.miHoYo.GenshinImpact,com.dts.freefiremax,com.netmarble.sololv,com.dts.freefireth,com.tencent.ig,jp.konami.pesam,com.netease.newspike,com.HoYoverse.hsr.google,com.ea.gp.fifamobile,net.kdt.pojavlaunch,com.mojang.minecraftpe,com.activision.callofduty.shooter,com.activision.callofduty.warzone,com.gamedevltd.wwh,com.galasports.totalfootball,com.pubg.krmobile,com.kurogame.wutheringwaves.global,com.craftsman.go,com.roblox.client,com.global.extremegames.arenabreakout,com.riotgames.league.wildrift,com.tencent.iglite
settings put global angle_allowlist com.vega.alphafgl,com.garena.game.codm,com.levelinfinite.sgameGlobal,com.je.supersus,com.carxtech.sr,com.rockstargames.gtasa,com.rockstargames.gtalcs,com.rockstargames.gtavc,com.rockstargames.gtabycity,com.mojang.minecraftpe,com.levelinfinite.sgameGlobal,com.mobile.legends,com.mobilelegends.hwag,com.mobilelegends.mi,com.dfjz.moba,com.miHoYo.GenshinImpact,com.dts.freefiremax,com.netmarble.sololv,com.dts.freefireth,com.tencent.ig,jp.konami.pesam,com.netease.newspike,com.HoYoverse.hsr.google,com.ea.gp.fifamobile,net.kdt.pojavlaunch,com.mojang.minecraftpe,com.activision.callofduty.shooter,com.activision.callofduty.warzone,com.gamedevltd.wwh,com.galasports.totalfootball,com.pubg.krmobile,com.kurogame.wutheringwaves.global,com.craftsman.go,com.roblox.client,com.global.extremegames.arenabreakout,com.riotgames.league.wildrift,com.tencent.iglite,com.netease.dfjssea,com.garena.game.df,com.hermes.p6gameos,com.pixonic.wwr,com.miraclegames.farlight84,com.digitalextremes.warframe.mobile,com.xd.t3.global,com.studioarm.sigma,com.levelinfinite.sgameGlobal,com.netease.g104na.google,com.ngame.allstar.eu,com.levelinfinite.hotta.gp,com.gameark.ggplay.lon,com.sg.dragonheir,com.nvsgames.dmc,com.carxtech.carxdr2,com.carxtech.sr,com.ea.games.r3_row,com.gameloft.android.ANMP.GloftA9HM,com.and.games505.TerrariaPaid,com.sandboxol.blockymods,com.kitkagames.fallbuddies,com.bhvr.deadbydaylight,com.lightyear.projectevo,com.tencent.undawn,com.rockstargames.gtasa
settings put global angle_allowlist com.vega.alphafgl,com.garena.game.codm,com.levelinfinite.sgameGlobal,com.je.supersus,com.carxtech.sr,com.rockstargames.gtasa,com.rockstargames.gtalcs,com.rockstargames.gtavc,com.rockstargames.gtabycity,com.mojang.minecraftpe,com.levelinfinite.sgameGlobal,com.mobile.legends,com.mobilelegends.hwag,com.mobilelegends.mi,com.dfjz.moba,com.miHoYo.GenshinImpact,com.dts.freefiremax,com.netmarble.sololv,com.dts.freefireth,com.tencent.ig,jp.konami.pesam,com.netease.newspike,com.HoYoverse.hsr.google,com.ea.gp.fifamobile,net.kdt.pojavlaunch,com.mojang.minecraftpe,com.activision.callofduty.shooter,com.activision.callofduty.warzone,com.gamedevltd.wwh,com.galasports.totalfootball,com.pubg.krmobile,com.kurogame.wutheringwaves.global,com.craftsman.go,com.roblox.client,com.global.extremegames.arenabreakout,com.riotgames.league.wildrift,com.tencent.iglite
settings put global angle_allowlist com.vega.alphafgl,com.garena.game.codm,com.levelinfinite.sgameGlobal,com.je.supersus,com.carxtech.sr,com.rockstargames.gtasa,com.rockstargames.gtalcs,com.rockstargames.gtavc,com.rockstargames.gtabycity,com.mojang.minecraftpe,com.levelinfinite.sgameGlobal,com.mobile.legends,com.mobilelegends.hwag,com.mobilelegends.mi,com.dfjz.moba,com.miHoYo.GenshinImpact,com.dts.freefiremax,com.netmarble.sololv,com.dts.freefireth,com.tencent.ig,jp.konami.pesam,com.netease.newspike,com.HoYoverse.hsr.google,com.ea.gp.fifamobile,net.kdt.pojavlaunch,com.mojang.minecraftpe,com.activision.callofduty.shooter,com.activision.callofduty.warzone,com.gamedevltd.wwh,com.galasports.totalfootball,com.pubg.krmobile,com.kurogame.wutheringwaves.global,com.craftsman.go,com.roblox.client,com.global.extremegames.arenabreakout,com.riotgames.league.wildrift,com.tencent.iglite,com.netease.dfjssea,com.garena.game.df,com.hermes.p6gameos,com.pixonic.wwr,com.miraclegames.farlight84,com.digitalextremes.warframe.mobile,com.xd.t3.global,com.studioarm.sigma,com.levelinfinite.sgameGlobal,com.netease.g104na.google,com.ngame.allstar.eu,com.levelinfinite.hotta.gp,com.gameark.ggplay.lon,com.sg.dragonheir,com.nvsgames.dmc,com.carxtech.carxdr2,com.carxtech.sr,com.ea.games.r3_row,com.gameloft.android.ANMP.GloftA9HM,com.and.games505.TerrariaPaid,com.sandboxol.blockymods,com.kitkagames.fallbuddies,com.bhvr.deadbydaylight,com.lightyear.projectevo,com.tencent.undawn,com.rockstargames.gtasa
 ) > /dev/null 2>&1

(
# 启用游戏驱动
settings put global updatable_driver_production_opt_in_apps com.vega.alphafgl,com.garena.game.codm,com.levelinfinite.sgameGlobal,com.je.supersus,com.carxtech.sr,com.rockstargames.gtasa,com.rockstargames.gtalcs,com.rockstargames.gtavc,com.rockstargames.gtabycity,com.mojang.minecraftpe,com.levelinfinite.sgameGlobal,com.mobile.legends,com.mobilelegends.hwag,com.mobilelegends.mi,com.dfjz.moba,com.miHoYo.GenshinImpact,com.dts.freefiremax,com.netmarble.sololv,com.dts.freefireth,com.tencent.ig,jp.konami.pesam,com.netease.newspike,com.HoYoverse.hsr.google,com.ea.gp.fifamobile,net.kdt.pojavlaunch,com.mojang.minecraftpe,com.activision.callofduty.shooter,com.activision.callofduty.warzone,com.gamedevltd.wwh,com.galasports.totalfootball,com.pubg.krmobile,com.kurogame.wutheringwaves.global,com.craftsman.go,com.roblox.client,com.global.extremegames.arenabreakout,com.riotgames.league.wildrift,com.tencent.iglite
settings put global angle_allowlist com.vega.alphafgl,com.garena.game.codm,com.levelinfinite.sgameGlobal,com.je.supersus,com.carxtech.sr,com.rockstargames.gtasa,com.rockstargames.gtalcs,com.rockstargames.gtavc,com.rockstargames.gtabycity,com.mojang.minecraftpe,com.levelinfinite.sgameGlobal,com.mobile.legends,com.mobilelegends.hwag,com.mobilelegends.mi,com.dfjz.moba,com.miHoYo.GenshinImpact,com.dts.freefiremax,com.netmarble.sololv,com.dts.freefireth,com.tencent.ig,jp.konami.pesam,com.netease.newspike,com.HoYoverse.hsr.google,com.ea.gp.fifamobile,net.kdt.pojavlaunch,com.mojang.minecraftpe,com.activision.callofduty.shooter,com.activision.callofduty.warzone,com.gamedevltd.wwh,com.galasports.totalfootball,com.pubg.krmobile,com.kurogame.wutheringwaves.global,com.craftsman.go,com.roblox.client,com.global.extremegames.arenabreakout,com.riotgames.league.wildrift,com.tencent.iglite,com.netease.dfjssea,com.garena.game.df,com.hermes.p6gameos,com.pixonic.wwr,com.miraclegames.farlight84,com.digitalextremes.warframe.mobile,com.xd.t3.global,com.studioarm.sigma,com.levelinfinite.sgameGlobal,com.netease.g104na.google,com.ngame.allstar.eu,com.levelinfinite.hotta.gp,com.gameark.ggplay.lon,com.sg.dragonheir,com.nvsgames.dmc,com.carxtech.carxdr2,com.carxtech.sr,com.ea.games.r3_row,com.gameloft.android.ANMP.GloftA9HM,com.and.games505.TerrariaPaid,com.sandboxol.blockymods,com.kitkagames.fallbuddies,com.bhvr.deadbydaylight,com.lightyear.projectevo,com.tencent.undawn,com.rockstargames.gtasa
settings put global updatable_driver_production_opt_out_apps 1
# 启用游戏驱动 A11
settings put global game_driver_opt_in_apps com.vega.alphafgl,com.garena.game.codm,com.levelinfinite.sgameGlobal,com.je.supersus,com.carxtech.sr,com.rockstargames.gtasa,com.rockstargames.gtalcs,com.rockstargames.gtavc,com.rockstargames.gtabycity,com.mojang.minecraftpe,com.levelinfinite.sgameGlobal,com.mobile.legends,com.mobilelegends.hwag,com.mobilelegends.mi,com.dfjz.moba,com.miHoYo.GenshinImpact,com.dts.freefiremax,com.netmarble.sololv,com.dts.freefireth,com.tencent.ig,jp.konami.pesam,com.netease.newspike,com.HoYoverse.hsr.google,com.ea.gp.fifamobile,net.kdt.pojavlaunch,com.mojang.minecraftpe,com.activision.callofduty.shooter,com.activision.callofduty.warzone,com.gamedevltd.wwh,com.galasports.totalfootball,com.pubg.krmobile,com.kurogame.wutheringwaves.global,com.craftsman.go,com.roblox.client,com.global.extremegames.arenabreakout,com.riotgames.league.wildrift,com.tencent.iglite
settings put global angle_allowlist com.vega.alphafgl,com.garena.game.codm,com.levelinfinite.sgameGlobal,com.je.supersus,com.carxtech.sr,com.rockstargames.gtasa,com.rockstargames.gtalcs,com.rockstargames.gtavc,com.rockstargames.gtabycity,com.mojang.minecraftpe,com.levelinfinite.sgameGlobal,com.mobile.legends,com.mobilelegends.hwag,com.mobilelegends.mi,com.dfjz.moba,com.miHoYo.GenshinImpact,com.dts.freefiremax,com.netmarble.sololv,com.dts.freefireth,com.tencent.ig,jp.konami.pesam,com.netease.newspike,com.HoYoverse.hsr.google,com.ea.gp.fifamobile,net.kdt.pojavlaunch,com.mojang.minecraftpe,com.activision.callofduty.shooter,com.activision.callofduty.warzone,com.gamedevltd.wwh,com.galasports.totalfootball,com.pubg.krmobile,com.kurogame.wutheringwaves.global,com.craftsman.go,com.roblox.client,com.global.extremegames.arenabreakout,com.riotgames.league.wildrift,com.tencent.iglite,com.netease.dfjssea,com.garena.game.df,com.hermes.p6gameos,com.pixonic.wwr,com.miraclegames.farlight84,com.digitalextremes.warframe.mobile,com.xd.t3.global,com.studioarm.sigma,com.levelinfinite.sgameGlobal,com.netease.g104na.google,com.ngame.allstar.eu,com.levelinfinite.hotta.gp,com.gameark.ggplay.lon,com.sg.dragonheir,com.nvsgames.dmc,com.carxtech.carxdr2,com.carxtech.sr,com.ea.games.r3_row,com.gameloft.android.ANMP.GloftA9HM,com.and.games505.TerrariaPaid,com.sandboxol.blockymods,com.kitkagames.fallbuddies,com.bhvr.deadbydaylight,com.lightyear.projectevo,com.tencent.undawn,com.rockstargames.gtasa
settings put global game_driver_opt_out_apps 1
) > /dev/null 2>&1

# 附加设置（可选，测试稳定性）
(
setprop debug.sf.use_frame_rate_priority 1
setprop debug.hw.vsync 0
setprop debug.sf.hwc.vsync_enqueue 0
setprop debug.generate-debug-info false
setprop debug.egl.traceGpuCompletion false
settings put system surface_flinger_use_frame_rate_api true ) > /dev/null 2>&1

# 可选 vsync 覆盖（谨慎使用）
(
setprop debug.sf.hwc_disable_vsync 1
setprop debug.hwui.disable_vsync 1
 ) > /dev/null 2>&1

sleep 0.5
echo""
echo "全部设置完成[✓]"
sleep 0.5
echo""
echo "成功激活 ANGLE 渲染驱动"
sleep 0.5
echo""
echo "开发者 LIMIT GAMING GANTENG"
echo""
sleep 0.5
echo""
echo "感谢使用"
echo""
sleep 0.5
echo""
echo "享受你的游戏体验"
echo""
sleep 0.5
echo""
echo "█▓▒▒░░░感谢使用本模块 ░░░▒▒▓█"
echo""
cmd notification post -S bigtext -t 'IOS DRIVER GAMING' 'Tag' ' 成功运行。' > /dev/null 2>&1

# 打开 ANGLE 应用
am start -a android.app.action.ANGLE_FOR_ANDROID_TOAST_MESSAGE -e open-app "Your Driver Game Angle" -n com.android.angle/.MainActivity > /dev/null 2>&1

cmd activity start -a android.app.action.ANGLE_FOR_ANDROID_TOAST_MESSAGE -e open-app "Your Driver Game Angle" -n com.android.angle/.MainActivity > /dev/null 2>&1
