cmd notification post -S bigtext -t 'IOS DRIVER GAMING' 'Tag' '正在卸载进程' > /dev/null 2>&1
echo ""
echo "█▓▒▒░░ANGLE 渲染驱动░░░▒▒▓█"
echo ""
sleep 0.5

# 保存安装日期
date '+%Y-%m-%d %H:%M:%S' > /data/local/tmp/touch_tweak_install_date

INSTALL_DATE=$(cat /data/local/tmp/touch_tweak_install_date 2>/dev/null || echo "未知")

echo "┌────────────────────────────────────────────┐"
echo "│         设备与硬件信息          │"
echo "├────────────────────────────────────────────┤"
echo "│ 📱 设备   : $(getprop ro.product.manufacturer) $(getprop ro.product.model) │"
echo "│ ⚙️ CPU    : $(getprop ro.board.platform) │"
echo "│ 🎮 GPU    : $(getprop ro.hardware) │"
echo "│ 📲 Android: $(getprop ro.build.version.release) │"
echo "│ 📅 安装时间: $INSTALL_DATE │"
echo "│ 🔰 内核   : $(uname -r) │"
echo "│ 🔹 构建   : $(getprop ro.build.display.id) │"
echo "│ 🛑 Root   : $(if [ $(id -u) -eq 0 ]; then echo '是'; else echo '否'; fi) │"
echo "│ 🔗 SELinux: $(getenforce) │"
echo "└────────────────────────────────────────────┘"
echo ""
echo "█▓▒▒░░░欢迎使用卸载程序░░░▒▒▓█"
echo ""
sleep 0.5
echo ""

# ASCII 艺术字（保留原样，仅翻译文字部分）
echo "
██████╗░███████╗██╗░░░░░███████╗████████╗███████╗
██╔══██╗██╔════╝██║░░░░░██╔════╝╚══██╔══╝██╔════╝
██║░░██║█████╗░░██║░░░░░█████╗░░░░░██║░░░█████╗░░
██║░░██║██╔══╝░░██║░░░░░██╔══╝░░░░░██║░░░██╔══╝░░
██████╔╝███████╗███████╗███████╗░░░██║░░░███████╗
╚═════╝░╚══════╝╚══════╝╚══════╝░░░╚═╝░░░╚══════╝"
echo ""
sleep 0.5

# 在卸载前停止应用
am force-stop com.android.angle > /dev/null 2>&1

# 在卸载前清除应用数据（可选，如果想彻底删除所有数据）
pm clear com.android.angle > /dev/null 2>&1

# 卸载应用（针对用户安装的应用）
pm uninstall com.android.angle > /dev/null 2>&1

# 卸载应用（如果是系统预装应用，需要 root 权限）
pm uninstall --user 0 com.android.angle > /dev/null 2>&1

echo ""
echo "正在卸载模块"
echo ""
sleep 3

(
settings delete global game_driver_opt_in_apps
settings delete global updatable_driver_production_opt_in_apps 
setprop debug.vulkan.enable ""
setprop debug.renderengine.backend ""
setprop debug.graphics.angle.developeroption.enable ""
settings delete global enable_gpu_debug_layers 
settings delete global force_hw_ui 
settings delete system debug.hwui.layer_cache_size 
settings delete system debug.hwui.text_small_cache_width 
settings delete system debug.hwui.text_small_cache_height 
settings delete system debug.hwui.disable_vsync 
setprop debug.hwui.drop_shadow_cache_size ""
setprop debug.hwui.render_dirty_regions ""
setprop debug.hwui.use_buffer_age ""
settings put global angle_gl_driver_selection_angle egl
) > /dev/null 2>&1

(
# 卸载触控加速（iOS 手感）
settings delete global touch_press_delay
settings delete global touchboost_enable
settings delete global touch_gesture_rate
settings delete global touch_motionfilter_enable
settings delete global touch_size_scale
settings delete global touch_responsiveness
settings delete global device_input_boost

# 卸载内存与缓存调优
settings delete global purgeable_assets
settings delete global mem_boost
settings delete global hwui_texture_cache_size
settings delete global hwui_gradient_cache_size
settings delete global hwui_path_cache_size
settings delete global hwui_texture_cache_flushrate

# 卸载 ANGLE Metal 驱动设置
setprop debug.angle.force_metal_backend ""
setprop debug.angle.metal.prefer_gpu ""
setprop debug.angle.optimize_render_pass ""
setprop debug.angle.command_buffer_fastpath ""
setprop debug.angle.pipeline_cache ""
) > /dev/null 2>&1

# 将所有 ANGLE 属性设置为空值
(
# 性能稳定性
setprop debug.performance.tuning ""
setprop debug.performance.profile ""
setprop debug.performance.disturb ""
setprop debug.performance_schema_digests_size ""
setprop debug.performance_schema ""
setprop debug.performance_schema_max_memory_classes ""
setprop debug.performance_schema_max_socket_classes ""
# ANGLE 使用
# 新
setprop debug.angle.overlay FPS:Metal*PipelineCache*
setprop debug.renderengine.backend ""
setprop debug.stagefright.renderengine.backend ""
setprop debug.angle.backend ""
setprop debug.stagefright.renderengine.backend ""
setprop debug.angle.feature_overrides_enabled ""
setprop debug.composition.type ""
setprop debug.hwui.renderer ""
setprop debug.mediatek.composition.type ""
setprop debug.angle.backend ""
setprop debug.angle.enable_vulkan_api_dump_layer ""
setprop debug.angle.validation ""
setprop debug.gles.angle ""
setprop debug.angle.overlay ""
setprop debug.angle.feature_overrides_enabled ""
setprop debug.angle.capture.frame_end ""
setprop debug.angle.capture.enabled ""
setprop debug.angle.capture.out_dir ""
setprop debug.angle.capture.frame_start ""
setprop debug.angle.capture.label ""
setprop debug.angle.capture.trigger ""
setprop debug.stagefright.renderengine.backend ""
setprop debug.hwui.shadow.renderer ""
setprop debug.renderengine.backend ""
setprop debug.composition.type ""
setprop debug.gfx.angle.supported ""
setprop debug.angle.rules ""
setprop debug.angle_enable_vulkan ""
setprop debug.angle_enable_vulkan_validation_layers ""
setprop debug.angle_libs_suffix ""
setprop debug.angle_enable_null ""
setprop debug.angle_force_thread_safety ""
setprop debug.angle.markers ""
settings put global graphics.egl ""
settings put global build_angle_deqp_tests ""
settings put global proprietary_codecs ""
) > /dev/null 2>&1

(
# IOS DRIVER 每款应用  
settings delete global angle_gl_driver_selection_values 
settings delete global angle_gl_driver_selection_package com.vega.alphafgl,com.garena.game.codm,com.levelinfinite.sgameGlobal,com.je.supersus,com.carxtech.sr,com.rockstargames.gtasa,com.rockstargames.gtalcs,com.rockstargames.gtavc,com.rockstargames.gtabycity,com.mojang.minecraftpe,com.levelinfinite.sgameGlobal,com.mobile.legends,com.mobilelegends.hwag,com.mobilelegends.mi,com.dfjz.moba,com.miHoYo.GenshinImpact,com.dts.freefiremax,com.netmarble.sololv,com.dts.freefireth,com.tencent.ig,jp.konami.pesam,com.netease.newspike,com.HoYoverse.hsr.google,com.ea.gp.fifamobile,net.kdt.pojavlaunch,com.mojang.minecraftpe,com.activision.callofduty.shooter,com.activision.callofduty.warzone,com.gamedevltd.wwh,com.galasports.totalfootball,com.pubg.krmobile,com.kurogame.wutheringwaves.global,com.craftsman.go,com.roblox.client,com.global.extremegames.arenabreakout,com.riotgames.league.wildrift,com.tencent.iglite
settings put global angle_allowlist com.vega.alphafgl,com.garena.game.codm,com.levelinfinite.sgameGlobal,com.je.supersus,com.carxtech.sr,com.rockstargames.gtasa,com.rockstargames.gtalcs,com.rockstargames.gtavc,com.rockstargames.gtabycity,com.mojang.minecraftpe,com.levelinfinite.sgameGlobal,com.mobile.legends,com.mobilelegends.hwag,com.mobilelegends.mi,com.dfjz.moba,com.miHoYo.GenshinImpact,com.dts.freefiremax,com.netmarble.sololv,com.dts.freefireth,com.tencent.ig,jp.konami.pesam,com.netease.newspike,com.HoYoverse.hsr.google,com.ea.gp.fifamobile,net.kdt.pojavlaunch,com.mojang.minecraftpe,com.activision.callofduty.shooter,com.activision.callofduty.warzone,com.gamedevltd.wwh,com.galasports.totalfootball,com.pubg.krmobile,com.kurogame.wutheringwaves.global,com.craftsman.go,com.roblox.client,com.global.extremegames.arenabreakout,com.riotgames.league.wildrift,com.tencent.iglite,com.netease.dfjssea,com.garena.game.df,com.hermes.p6gameos,com.pixonic.wwr,com.miraclegames.farlight84,com.digitalextremes.warframe.mobile,com.xd.t3.global,com.studioarm.sigma,com.levelinfinite.sgameGlobal,com.netease.g104na.google,com.ngame.allstar.eu,com.levelinfinite.hotta.gp,com.gameark.ggplay.lon,com.sg.dragonheir,com.nvsgames.dmc,com.carxtech.carxdr2,com.carxtech.sr,com.ea.games.r3_row,com.gameloft.android.ANMP.GloftA9HM,com.and.games505.TerrariaPaid,com.sandboxol.blockymods,com.kitkagames.fallbuddies,com.bhvr.deadbydaylight,com.lightyear.projectevo,com.tencent.undawn,com.rockstargames.gtasa
) > /dev/null 2>&1

# 卸载 Renderangle 设置
(
setprop debug.hwui.renderer ""
setprop debug.hwui.use_threaded_renderer false
settings delete global angle_gl_driver_selection_value
settings delete global angle_gl_driver_all_angle
) > /dev/null 2>&1

# 卸载 ANGLE 驱动设置
(
settings delete global angle_debug_package
settings delete global angle_allowlist
) > /dev/null 2>&1

# 卸载附加设置（可选，测试稳定性）
(
setprop debug.sf.use_frame_rate_priority 0
setprop debug.hw.vsync 1
setprop debug.sf.hwc.vsync_enqueue 1
setprop debug.generate-debug-info true
setprop debug.egl.traceGpuCompletion true
settings delete system surface_flinger_use_frame_rate_api
) > /dev/null 2>&1

# 卸载可选 vsync 覆盖
(
setprop debug.sf.hwc_disable_vsync 0
setprop debug.hwui.disable_vsync 0
) > /dev/null 2>&1

# 删除游戏驱动
(
settings delete global updatable_driver_production_opt_in_apps
settings delete global updatable_driver_production_opt_out_apps 
settings delete global game_driver_opt_in_apps
settings delete global game_driver_opt_out_apps 
) > /dev/null 2>&1

# 确认恢复默认
echo ""
echo "所有设置已恢复为默认值。"
echo ""
sleep 0.5
echo ""
echo "全部删除完成[✓]"
echo ""
sleep 0.5
echo ""
echo "开发者 LIMIT GAMING GANTENG"
echo ""
sleep 0.5
echo ""
echo "感谢使用"
echo ""
sleep 0.5
echo ""
echo "请重启设备"
echo ""
sleep 0.5
echo ""
echo "█▓▒▒░░░感谢使用本模块 ░░░▒▒▓█"
echo ""
cmd notification post -S bigtext -t 'IOS DRIVER GAMING' 'Tag' '已成功删除所有配置与优化。' > /dev/null 2>&1
