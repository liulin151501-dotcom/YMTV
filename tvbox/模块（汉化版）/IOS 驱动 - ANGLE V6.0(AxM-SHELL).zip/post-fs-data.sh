#!/system/bin/sh
MODDIR=${0%/*}

# 授予所需的权限
pm grant com.android.angle android.permission.WRITE_SECURE_SETTINGS
pm grant com.android.angle android.permission.READ_EXTERNAL_STORAGE
pm grant com.android.angle android.permission.WRITE_EXTERNAL_STORAGE
pm grant com.android.angle android.permission.POST_NOTIFICATIONS

# 允许应用在后台运行
cmd appops set com.android.angle RUN_IN_BACKGROUND allow
cmd appops set com.android.angle RUN_ANY_IN_BACKGROUND allow
cmd appops set com.android.angle START_FOREGROUND allow

# 授予唤醒锁定权限（防止进入睡眠模式）
cmd appops set com.android.angle WAKE_LOCK allow

# 允许完全访问存储空间
cmd appops set com.android.angle MANAGE_EXTERNAL_STORAGE allow
cmd appops set com.android.angle LEGACY_STORAGE allow

# 允许修改系统设置
cmd appops set com.android.angle WRITE_SETTINGS allow

# 拒绝访问使用情况统计的权限（可选）
cmd appops set com.android.angle GET_USAGE_STATS deny

chmod +x /data/adb/modules/IOS_DRIVER/service.sh