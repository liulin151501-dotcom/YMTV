#!/system/bin/sh

alias SP="setprop"
alias STS="settings"
alias CMD="cmd"
alias DVC="device_config"

SP debug.sf.hwc_service_name drmfb
SP debug.sf.disable_backpressure 1
SP debug.sf.enable_gl_backpressure 0
SP debug.sf.disable_client_composition_cache 1
SP debug.sf.disable_hwc_overlays 0
SP debug.sf.disable_hwc 0
SP debug.sf.enable_hwc_vds 1
SP debug.sf.gpu_comp_tiling 1
SP debug.sf.predict_hwc_composition_strategy 0
SP debug.sf.hwc.min.duration 16666666
SP debug.sf.high_fps.hwc.min.duration 11111111

SP debug.hwc.compose_level 1
SP debug.hwc.force_gpu 1
SP debug.hwc.asyncdisp 1
SP debug.hwc.otf 1
SP debug.hwc.bq_count 3
SP debug.hwc.disabletonemapping false

SP debug.hwui.disable_vsync false
SP debug.hwui.use_buffer_age 1
SP debug.hwui.trace_gpu_resources false
SP debug.skia.enable_reuse_scratch_textures 1

SP debug.egl.force_msaa false
SP debug.egl.native_scaling true

SP debug.drm.mode.auto 1

SP persist.sys.hwcomposer.force_gpu 1
SP persist.sys.sf.enable_hwc_vds 1
SP persist.sys.rendercomposer.enable true
SP persist.sys.resolutiontuner.enable true
SP persist.sys.display.resolution_switch 1
SP persist.sys.downscale.disable false
SP sys.hwc.mdp_downscale_enable true

STS put global low_power 0
STS put global low_power_sticky 0
STS put global app_standby_enabled 0
STS put global forced_app_standby_enabled 0
STS put global force_all_apps_standby false
STS put global settings_enable_monitor_phantom_procs false
STS put global enable_gpu_debug_layers 0

CMD deviceidle disable
CMD power set-fixed-performance-mode-enabled true
CMD display set-user-disabled-hdr-types 1 2 3 4

SP debug.sqlite.journalsizelimit 1048576
SP debug.sqlite.pagesize 4096
SP debug.sqlite.wal.autocheckpoint 2000
SP debug.sqlite.idle_connection_timeout 10000
SP debug.sqlite.wal.truncatesize 1048576
SP debug.sqlite.wal.poolsize 1048576
SP debug.sqlite.no_double_quoted_strs false
SP debug.sqlite.close_idle_connections false

STS put --user 0 global sqlite_compatibility_wal_flags legacy_compatibility_wal_enabled=false,truncate_size=524288

DVC put core_graphics com.android.graphics.surfaceflinger.flags.filter_frames_before_trace_starts true
DVC put core_graphics com.android.graphics.surfaceflinger.flags.add_sf_skipped_frames_to_trace false
DVC put core_graphics com.android.graphics.surfaceflinger.flags.correct_dpi_with_display_size true

DVC put display_manager com.android.server.display.feature.flags.enable_display_resolution_range_voting true
DVC put display_manager com.android.server.display.feature.flags.resolution_backup_restore true

DVC put system_performance android.database.sqlite.sqlite_allow_temp_tables true

DVC put staged core_graphics*com.android.graphics.surfaceflinger.flags.filter_frames_before_trace_starts true
DVC put staged core_graphics*com.android.graphics.surfaceflinger.flags.add_sf_skipped_frames_to_trace false
DVC put staged core_graphics*com.android.graphics.surfaceflinger.flags.correct_dpi_with_display_size true

DVC put staged display_manager*com.android.server.display.feature.flags.enable_display_resolution_range_voting true
DVC put staged display_manager*com.android.server.display.feature.flags.resolution_backup_restore true

DVC put staged system_performance*android.database.sqlite.sqlite_allow_temp_tables true