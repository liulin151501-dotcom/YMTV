#!/system/bin/sh

alias SP="setprop"
alias STS="settings"
alias CMD="cmd"
alias DVC="device_config"

SP debug.sf.hwc_service_name ""
SP debug.sf.disable_backpressure 0
SP debug.sf.enable_gl_backpressure 0
SP debug.sf.disable_client_composition_cache 0
SP debug.sf.disable_hwc_overlays 0
SP debug.sf.disable_hwc 0
SP debug.sf.enable_hwc_vds 0
SP debug.sf.gpu_comp_tiling 0
SP debug.sf.predict_hwc_composition_strategy 0
SP debug.sf.hwc.min.duration 0
SP debug.sf.high_fps.hwc.min.duration 0

SP debug.hwc.compose_level 0
SP debug.hwc.force_gpu 0
SP debug.hwc.asyncdisp 0
SP debug.hwc.otf 0
SP debug.hwc.bq_count 0
SP debug.hwc.disabletonemapping false

SP debug.hwui.disable_vsync false
SP debug.hwui.use_buffer_age 0
SP debug.hwui.trace_gpu_resources false
SP debug.skia.enable_reuse_scratch_textures 0

SP debug.egl.force_msaa false
SP debug.egl.native_scaling false

SP debug.drm.mode.auto 0

SP persist.sys.hwcomposer.force_gpu 0
SP persist.sys.sf.enable_hwc_vds 0
SP persist.sys.rendercomposer.enable false
SP persist.sys.resolutiontuner.enable false
SP persist.sys.display.resolution_switch 0
SP persist.sys.downscale.disable true
SP sys.hwc.mdp_downscale_enable false

STS put global low_power 1
STS put global low_power_sticky 1
STS put global app_standby_enabled 1
STS put global forced_app_standby_enabled 1
STS put global force_all_apps_standby true
STS put global settings_enable_monitor_phantom_procs true
STS put global enable_gpu_debug_layers 1

CMD deviceidle enable
CMD power set-fixed-performance-mode-enabled false
CMD display set-user-disabled-hdr-types 0

SP debug.sqlite.journalsizelimit 0
SP debug.sqlite.pagesize 0
SP debug.sqlite.wal.autocheckpoint 0
SP debug.sqlite.idle_connection_timeout 0
SP debug.sqlite.wal.truncatesize 0
SP debug.sqlite.wal.poolsize 0
SP debug.sqlite.no_double_quoted_strs true
SP debug.sqlite.close_idle_connections true

STS put --user 0 global sqlite_compatibility_wal_flags legacy_compatibility_wal_enabled=true,truncate_size=0

DVC put core_graphics com.android.graphics.surfaceflinger.flags.filter_frames_before_trace_starts false
DVC put core_graphics com.android.graphics.surfaceflinger.flags.add_sf_skipped_frames_to_trace true
DVC put core_graphics com.android.graphics.surfaceflinger.flags.correct_dpi_with_display_size false

DVC put display_manager com.android.server.display.feature.flags.enable_display_resolution_range_voting false
DVC put display_manager com.android.server.display.feature.flags.resolution_backup_restore false

DVC put system_performance android.database.sqlite.sqlite_allow_temp_tables false

DVC put staged core_graphics*com.android.graphics.surfaceflinger.flags.filter_frames_before_trace_starts false
DVC put staged core_graphics*com.android.graphics.surfaceflinger.flags.add_sf_skipped_frames_to_trace true
DVC put staged core_graphics*com.android.graphics.surfaceflinger.flags.correct_dpi_with_display_size false

DVC put staged display_manager*com.android.server.display.feature.flags.enable_display_resolution_range_voting false
DVC put staged display_manager*com.android.server.display.feature.flags.resolution_backup_restore false

DVC put staged system_performance*android.database.sqlite.sqlite_allow_temp_tables false

SP debug.hwui.default_renderer ""
SP debug.hwui.renderer ""
SP debug.renderengine.vulkan false
SP debug.renderengine.backend ""
SP debug.renderenginebackend ""
SP debug.renderenginevulkan false
SP debug.angle.backend ""
SP debug.angle.overlay ""

SP debug.sf.hwc_service_name ""
SP debug.sf.disable_backpressure 0
SP debug.sf.enable_gl_backpressure 0
SP debug.sf.disable_client_composition_cache 0
SP debug.sf.disable_hwc_overlays 0
SP debug.sf.disable_hwc 0
SP debug.sf.enable_hwc_vds 0
SP debug.sf.gpu_comp_tiling 0
SP debug.sf.predict_hwc_composition_strategy 0
SP debug.sf.hwc.min.duration 0
SP debug.sf.high_fps.hwc.min.duration 0

SP debug.hwc.compose_level 0
SP debug.hwc.force_gpu 0
SP debug.hwc.asyncdisp 0
SP debug.hwc.otf 0
SP debug.hwc.bq_count 0
SP debug.hwc.disabletonemapping false

SP debug.hwui.disable_vsync false
SP debug.hwui.use_buffer_age 0
SP debug.hwui.trace_gpu_resources false
SP debug.skia.enable_reuse_scratch_textures 0

SP debug.egl.force_msaa false
SP debug.egl.native_scaling false

SP debug.drm.mode.auto 0

SP persist.sys.hwcomposer.force_gpu 0
SP persist.sys.sf.enable_hwc_vds 0
SP persist.sys.rendercomposer.enable false
SP persist.sys.resolutiontuner.enable false
SP persist.sys.display.resolution_switch 0
SP persist.sys.downscale.disable true
SP sys.hwc.mdp_downscale_enable false

STS put global low_power 1
STS put global low_power_sticky 1
STS put global app_standby_enabled 1
STS put global forced_app_standby_enabled 1
STS put global adaptive_battery_management_enabled 1
STS put global force_all_apps_standby true

CMD deviceidle enable

ALL_APPS="$(cmd package list packages --user 0 | cut -f2 -d:)"

for app in $ALL_APPS; do
    am set-standby-bucket --user 0 "$app" default >/dev/null 2>&1
    cmd appops set "$app" RUN_IN_BACKGROUND default >/dev/null 2>&1
    cmd appops set "$app" RUN_ANY_IN_BACKGROUND default >/dev/null 2>&1
    cmd deviceidle whitelist -"${app}" >/dev/null 2>&1
done

SP debug.sf.auto_latch_unsignaled 0

DVC delete activity_manager disable_app_profiler_pss_profiling
DVC delete activity_manager activity_start_pss_defer
DVC delete activity_manager use_compaction

DVC delete interaction_jank_monitor enabled
DVC delete interaction_jank_monitor trace_threshold_frame_time_millis

DVC delete window_manager system_gesture_exclusion_log_debounce_millis

DVC delete content_capture max_buffer_size
DVC delete content_capture log_history_size

DVC delete activity_manager_native_boot modern_queue_enabled
DVC delete activity_manager_native_boot use_freezer

DVC delete device_personalization_services Logging__enable_aiai_clearcut_logging
DVC delete device_personalization_services StatsLog__enable_new_logger_api
DVC delete device_personalization_services StatsLog__active_users_logger_non_persistent
DVC delete device_personalization_services StatsLog__active_users_logger_enabled
DVC delete device_personalization_services SpeechRecognitionService__clear_logging_events_if_too_much_memory
DVC delete device_personalization_services PcsAttestationMeasurement__maximum_jitter_delay_s

DVC delete settings_ui event_logging_enabled
DVC delete media media_metrics_mode

DVC delete runtime_native metrics.write-to-statsd
DVC delete runtime_native use_app_image_startup_cache
DVC delete runtime_native metrics.reporting-num-mods-server
DVC delete runtime_native metrics.reporting-num-mods
DVC delete runtime_native metrics.reporting-mods-server
DVC delete runtime_native metrics.reporting-mods

DVC delete runtime_native_boot enable_uffd_gc_2
DVC delete runtime_native_boot use_generational_gc
DVC delete runtime_native_boot disable_lock_profiling
DVC delete runtime_native_boot iorap_perfetto_enable
DVC delete runtime_native_boot iorap_readahead_enable

DVC delete lmkd_native thrashing_limit_critical

DVC delete netd_native sort_nameservers
DVC delete netd_native parallel_lookup
DVC delete netd_native doh

DVC delete nnapi_native telemetry_enable

DVC delete storage_native_boot smart_idle_maint_enabled

DVC delete surface_flinger_native_boot SkiaTracingFeature__use_skia_tracing

STS delete global battery_tip_constants
STS delete global binder_calls_stats
STS delete global appop_history_parameters
STS delete global battery_stats_constants
STS delete global activity_manager_constants
STS delete system device_idle_constants

cmd notification post -S bigtext -t '🅱️-GpuBoost' '🛑' " 已停止(建议重启)"
