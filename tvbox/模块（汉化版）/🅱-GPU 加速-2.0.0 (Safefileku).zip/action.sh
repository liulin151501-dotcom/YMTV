.#!/system/bin/sh

alias STS="settings"
alias C="cmd"
alias SP="setprop"
alias DVC="device_config"

read_volume_action() {
    getevent -c 5 >/dev/null 2>&1
    while true; do
        key="$(getevent -qlc 1 | awk '{print $3}')"
        case "$key" in
            KEY_VOLUMEUP)
                sleep 0.3
                return 0
                ;;
            KEY_VOLUMEDOWN)
                sleep 0.3
                return 1
                ;;
        esac
    done
}

echo "------------------------------------"
echo "推荐渲染器"
echo "音量加(按 2 次)= 应用"
echo "音量减(按 2 次)= 跳过"
echo "------------------------------------"

if read_volume_action; then
    echo "等待 ⏳ 正在应用推荐渲染器"
    echo "------------------------------------"

    soc="$(getprop ro.board.platform | tr '[:upper:]' '[:lower:]')"
    hardware="$(getprop ro.hardware | tr '[:upper:]' '[:lower:]')"

    echo "芯片组   : $soc"
    echo "硬件信息 : $hardware"

    use_vulkan=0
    renderer_name="opengl / skiagl"

    if echo "$soc $hardware" | grep -Eiq "qcom|qualcomm|msm|sdm|sm"; then
        use_vulkan=1
        renderer_name="vulkan / skiavk"
    fi

    echo "推荐渲染器 : $renderer_name"
    echo "正在处理渲染器优化 ⏳"


    if [ "$use_vulkan" -eq 1 ]; then
        STS put global rendering_type skiavk
        SP debug.hwui.default_renderer skiavk
        SP debug.hwui.renderer skiavk
        SP debug.renderengine.vulkan true
        SP debug.renderengine.backend skiavkthreaded
        SP debug.renderenginebackend skiavkthreaded
        SP debug.renderenginevulkan true
        SP debug.angle.backend skiavkthreaded
        SP debug.angle.overlay "fps:vulkan*pipelinecache*"
        DVC put core_graphics com.android.graphics.libvulkan.flags.swapchain_mutable_format_ext true
        DVC put core_graphics com.android.graphics.surfaceflinger.flags.vulkan_renderengine true
        DVC put staged core_graphics*com.android.graphics.surfaceflinger.flags.vulkan_renderengine true
    else
        STS put global rendering_type skiagl
        SP debug.hwui.default_renderer skiagl
        SP debug.hwui.renderer skiagl
        SP debug.renderengine.vulkan false
        SP debug.renderengine.backend skiaglthreaded
        SP debug.renderenginebackend skiaglthreaded
        SP debug.renderenginevulkan false
        SP debug.angle.backend opengles
        SP debug.angle.overlay "fps:opengles*pipelinecache*"
        DVC put core_graphics com.android.graphics.libvulkan.flags.swapchain_mutable_format_ext false
        DVC put core_graphics com.android.graphics.surfaceflinger.flags.vulkan_renderengine false
        DVC put staged core_graphics*com.android.graphics.surfaceflinger.flags.vulkan_renderengine false
    fi

echo "渲染器优化已成功应用 ✓"
else
    echo "渲染器优化已跳过 ⏭"
fi

echo "------------------------------------"
echo "无限制电池模式"
echo "音量加(按 2 次)= 应用"
echo "音量减(按 2 次)= 跳过"
echo "------------------------------------"

if read_volume_action; then
    echo "等待 ⏳ 正在应用无限制电池模式"
    echo "------------------------------------"

    all_apps="$(C package list packages --user 0 | cut -f2 -d:)"

    C deviceidle disable >/dev/null 2>&1

    STS put global low_power 0
    STS put global low_power_sticky 0
    STS put global app_standby_enabled 0
    STS put global forced_app_standby_enabled 0
    STS put global adaptive_battery_management_enabled 0
    STS put global force_all_apps_standby false

    echo "正在处理电池规则 ⏳"

    for app in $all_apps; do
        am set-standby-bucket --user 0 "$app" active >/dev/null 2>&1
        C appops set "$app" run_in_background allow >/dev/null 2>&1
        C appops set "$app" run_any_in_background allow >/dev/null 2>&1
        C deviceidle whitelist +"$app" >/dev/null 2>&1
    done

    echo "无限制电池模式已成功应用 ✓"
else
    echo "无限制电池模式已跳过 ⏭"
fi

echo "------------------------------------"
echo "编译游戏 (speed-profile)"
echo "音量加(按 2 次)= 应用"
echo "音量减(按 2 次)= 跳过"
echo "------------------------------------"

if read_volume_action; then
    echo "等待 ⏳ 正在编译游戏包"
    echo "------------------------------------"


    GAME_PACKAGES="
    com.ea.gp.apexlegendsmobilefps
com.ea.gp.fifamobile
com.ea.gp.nfsm
com.emulator.fpse64
com.epicgames.fortnite
com.epicgames.portal
com.epsxe.ePSXe
com.eyougame.msen
com.fantablade.icey
com.farlightgames.igame.gp
com.feralinteractive.gridas
com.firewick.p42.bilibili
com.firsttouchgames.dls7
com.fizzd.connectedworlds
com.futuremark.dmandroid.application
com.gabama.monopostolite
com.gaijingames.wtm
com.gakpopuler.gamekecil
com.gameark.ggplay.lonsea
com.gamedevltd.wwh
com.gameloft.android.ANMP.GloftA9HM
com.gameloft.android.ANMP.GloftMVHM
com.gameloft.android.SAMS.GloftA9SS
com.garena.game.codm
com.garena.game.df
com.garena.game.kgid
com.garena.game.kgtw
com.garena.game.kgvn
com.garena.game.lmjx
com.garena.game.nfsm
com.gbits.funnyfighter.android.overseas
com.gravity.romg
com.gravity.roo.sea
com.gryphline.exastris.gp
com.guigugame.guigubahuang
com.guyou.deadstrike
com.h73.jhqyna
com.halo.windf.hero
com.heavenburnsred
com.hermes.j1game
com.hermes.mk
com.herogame.gplay.magicminecraft.mmorpg
com.hg.cosmicshake
com.hg.lbw
com.hottapkgs.hotta
com.humo.yqqsqz.yw
com.hypergryph.arknights
com.hypergryph.exastris
com.idreamsky.klbqm
com.idreamsky.strinova
com.igg.android.doomsdaylastsurvivors
com.ignm.raspberrymash.jp
com.ilongyuan.implosion
com.infoldgames.infinitynikkien
com.jacksparrow.jpmajiang
com.japan.datealive.gp
com.je.supersus
com.jumpw.mobile300
com.kakaogames.eversoul
com.kakaogames.gdts
com.kakaogames.wdfp
com.kiloo.subwaysurf
com.kog.grandchaseglobal
com.komoe.kmumamusumegp
com.kurogame.aki
com.kurogame.gplay.punishing.grayraven.en
com.kurogame.haru
com.kurogame.haru.bilibili
com.kurogame.haru.hero
com.kurogame.mingchao
com.kurogame.wutheringwaves.global
com.leiting.wf
com.lemcnsun.soultide.android
com.levelinfinite.hotta.gp
com.levelinfinite.sgameGlobal
com.levelinfinite.sgameGlobal.midaspay
com.lilithgames.hgame.cn
com.lilithgame.hgame.gp
com.lilithgame.roc.gp
com.linecorp.LGGRTHN
com.linegames.sl
com.longe.allstarhmt
com.lrgame.dldl.sea
com.madfingergames.legends
com.maleo.bussimulatorid
com.miHoYo.GI.samsung
com.miHoYo.GenshinImpact
com.miHoYo.HSoDv2JPOriginalEx
com.miHoYo.Nap
com.miHoYo.Yuanshen
com.miHoYo.bh3
com.miHoYo.bh3global
com.miHoYo.bh3oversea
com.miHoYo.bh3rdJP
com.miHoYo.bh3.bilibili
com.miHoYo.bh3.mi
com.miHoYo.bh3.uc
com.miHoYo.enterprise.NGHSoD
com.miHoYo.hkrpg
com.miHoYo.ys
com.miHoYo.zenless
com.minidragon.idlefantasy
com.miniworldgame.creata.vn
com.miraclegames.farlight84
com.mobiin.gp
com.mobilechess.gp
com.mobilelegends.hwag
com.mobilelegends.mi
com.mobilelegends.taptest
com.mobile.legends
com.modx.daluandou
com.mojang.hostilegg
com.mojang.minecraftpe
com.mojang.minecraftpe.patch
com.morizero.milthm
com.nanostudios.games.twenty.minutes
com.ncsoft.lineagen
com.nebulajoy.act.dmcpoc.asia
com.nekki.shadowfight
com.nekki.shadowfight3
com.neowizgames.game.browndust2
com.neowiz.game.idolypride.en
com.netease.AVALON
com.netease.EVE
com.netease.aceracer
com.netease.allstar
com.netease.dfjs
com.netease.dunkcd
com.netease.dwrg
com.netease.eve.en
com.netease.frxyna
com.netease.g78na.gb
com.netease.g93na
com.netease.h73hmt
com.netease.h75na
com.netease.hyxd
com.netease.idv
com.netease.jddsaef
com.netease.ko
com.netease.l22
com.netease.lagrange
com.netease.lglr
com.netease.lztgglobal
com.netease.ma84
com.netease.ma100asia
com.netease.moba
com.netease.mrzh
com.netease.newspike
com.netease.nshm
com.netease.nshmhmt
com.netease.onmyoji
com.netease.party
com.netease.partyglobal
com.netease.pes
com.netease.qrsj
com.netease.race
com.netease.racerna
com.netease.sky
com.netease.soulofhunter
com.netease.tj
com.netease.tom
com.netease.wotb
com.netease.wyclx
com.netease.x19
com.netease.yhtj
com.netease.yyslscn
com.netflix.NGP.GTAIIIDefinitiveEdition
com.netflix.NGP.GTASanAndreasDefinitiveEdition
com.netflix.NGP.GTAViceCityDefinitiveEdition
com.netmarble.skiagb
com.netmarble.sololv
com.netmarble.tog
com.nexon.bluearchive
com.nexon.kartdrift
com.nexon.konosuba
com.nexon.mdnf
com.nexon.mod
com.ngame.allstar.eu
com.nianticlabs.monsterhunter
com.nianticproject.ingress
com.noctuagames.android.ashechoes
com.noctua.android.crazyones
com.npixel.GranSagaGB
com.olzhass.carparking.multyplayer
com.oninou.FAPI
com.papegames.infinitynikki
com.papegames.nn4.en
com.pearlabyss.blackdesertm
com.pearlabyss.blackdesertm.gl
com.pinkcore.tkfm
com.plarium.raidlegends
com.playdigious.deadcells.mobile
com.playmini.miniworld
com.play.rosea
com.popcap.pvz
com.primatelabs.geekbench6
com.proximabeta.dn2.global
com.proximabeta.mf.aceforce2
com.proximabeta.mf.liteuamo
com.proximabeta.mf.uamo
com.proximabeta.nikke
com.proxima.dfm
com.prpr.musedash
com.pubg
com.pubg.imobile
com.pubg.krmobile
com.pubg.newstate
com.pwrd.hotta.laohu
com.pwrd.huanta
com.pwrd.opmwsea
com.pwrd.p5x
com.pwrd.persona5x.laohu
com.r2games.myhero.bilibili
com.rayark.cytus2
com.rayark.deemo2
com.rayark.deemoreborn
com.rayark.implosion
com.rayark.sdorica
com.rekoo.pubgm
com.retroarch
com.rinzz.projectmuse
com.riotgames.league.teamfighttactics
com.riotgames.league.teamfighttacticstw
com.riotgames.league.teamfighttacticsvn
com.riotgames.league.wildrift
com.roblox.client
com.roblox.client.vnggames
com.robtopx.geometryjump
com.rockstargames.gta3
com.rockstargames.gta3.de
com.rockstargames.gtasa
com.rockstargames.gtasa.de
com.rockstargames.gtavc
com.rockstargames.gtavc.de
com.rsg.myheroesen
com.sandboxinteractive.albiononline
com.sandboxol.blockymods
com.seasun.jx3
com.seasun.snowbreak.google
com.sega.ColorfulStage.en
com.sega.pjsekai
com.sega.soniccd.classic
com.sgra.dragon
com.shangyoo.neon
com.shatteredpixel.shatteredpixeldungeon
com.shenlan.m.reverse1999
com.silverstarstudio.angellegion
com.smokoko.race
com.sofunny.Sausage
com.soulgamechst.majsoul
com.spaceapegames.beatstar
com.sprduck.garena.vn
com.squareenix.lis
com.starform.metalstorm
com.stove.epic7.google
com.studiobside.CounterSide
com.studiowildcard.wardrumstudios.ark
com.studiowildcard.wardrumstudios.ark.ncr
com.sugarfun.gp.sea.lzgwy
com.sunborn.girlsfrontline.en
com.sunborn.neuralcloud
com.sunborn.neuralcloud.en
com.superb.rhv
com.supercell.boombeach
com.supercell.brawlstars
com.supercell.clashofclans
com.supercell.clashroyale
com.supercell.hayday
com.supercell.squad
com.sybogames.subway.surfers.game
com.sy.dldlhsdj
com.t2ksports.nba2k20and
com.tencent.KiHan
com.tencent.af
com.tencent.baiyeint
com.tencent.hhw
com.tencent.ig
com.tencent.iglite
com.tencent.jkchess
com.tencent.letsgo
com.tencent.lolm
com.tencent.mf.uam
com.tencent.msgame
com.tencent.nba2kx
com.tencent.nfsonline
com.tencent.tmgp.WePop
com.tencent.tmgp.bh3
com.tencent.tmgp.cf
com.tencent.tmgp.cod
com.tencent.tmgp.dfjs
com.tencent.tmgp.dfm
com.tencent.tmgp.dnf
com.tencent.tmgp.dwrg
com.tencent.tmgp.ffom
com.tencent.tmgp.gnyx
com.tencent.tmgp.kr.codm
com.tencent.tmgp.pubgmhd
com.tencent.tmgp.sgame
com.tencent.tmgp.sgamece
com.tencent.tmgp.speedmobile
com.tencent.tmgp.sskeus
com.tencent.tmgp.supercell.boombeach
com.tencent.tmgp.wuxia
com.tencent.tmgp.yys.zqb
com.tencent.toaa
com.ea.game.pvz2_rfl
com.ea.game.pvz2_row
com.ea.game.pvzfree_row
com.feralinteractive.gridautosport_edition_android
com.miHoYo.bh3oversea_vn
cyou.joiplay.joiplay
hg.toriteling.neetchan
game.qualiarts.idolypride
gplay.punishing.grayraven
id.rj01117883.liomeko
jp.co.bandainamcoent.BNEI0242
jp.co.craftegg.band
jp.co.cygames.princessconnectredive
jp.co.cygames.umamusume
jp.co.koeitecmo.ReslerianaGL
jp.garud.ssimulator
jp.konami.duellinks
jp.konami.masterduel
jp.konami.pesam
jp.pokemon.pokemonunite
jp.goodsmile.touhoulostwordglobal_android
lega.feisl.hhera
me.magnum.melonds.nightly
me.mugzone.emiria
me.pou.app
me.tigerhix.cytoid
minitech.miniworld
moe.low.arc
net.kdt.pojavlaunch
net.kdt.pojavlaunch.debug
net.kdt.pojavlaunch.firefly
net.wargaming.wot.blitz
nlch.game.Imouto
org.citra.emu
org.dolphinemu.dolphinemu
org.flos.phira
org.godotengine.godot4
org.maxbytes.lfs
org.mm.jr
org.mupen64plusae.v3.alpha
org.mupen64plusae.v3.fzurita.pro
org.openttd.sdl
org.ppsspp.ppsspp
org.ppsspp.ppssppgold
org.vita3k.emulator
org.citron.citron_emu
org.sudachi.sudachi_emu.ea
org.uzuy.uzuy_emu.ea
org.yuzu.yuzu_emu
pro.archiemeng.waifu2x
ro.alyn_sampmobile.game
ru.nsu.ccfit.zuev.osuplus
ru.unisamp_mobile.game
sh.ppy.osulazer
skyline.emu
skyline.purple
skynet.cputhrottlingtest
tw.sonet.allbw
tw.sonet.princessconnect
uk.co.powdertoy.tpt
vng.games.revelation.mobile
www.townofmagic.com
xd.sce.promotion
xyz.aethersx2.android
com.levelinfinite.sgameGlobal
com.tgc.sky.android
com.the10tons.dysmantle
com.tinybuildgames.helloneighbor
com.tipsworks.android.pascalswager
com.tipsworks.pascalswager
com.trampolinetales.lbal
com.tumuyan.ncnn.realsr
com.tungsten.fcl
com.cygames.umamusume
com.ubisoft.rainbowsixmobile.r6.fps.pvp.shooter
com.unity.mmd
com.valvesoftware.cswgsm
com.valvesoftware.source
com.vng.mlbbvn
com.vng.pubgmobile
com.vng.speedvn
com.wb.goog.scribblenauts3
com.winlator
com.winlator.cmod
com.ludashi.benchmark
com.wondergames.warpath.gp
com.xd.TLglobal
com.xd.dxlzz.taptap
com.xd.muffin.gp.global
com.xd.rotaeno.googleplay
com.xd.rotaeno.tapcn
com.xd.ssrpgen
com.xd.terraria
com.xd.xdt
com.xindong.torchlight
com.yinhan.hunter
com.yongshi.tenojo
com.yoozoo.jgame.global
com.yoozoo.jgame.us
com.zlongame.mhmnz
com.ztgame.bob
Nekootan.kfkj
adventure.rpg.anime.game.vng.ys6
age.of.civilizations2.jakowski.lukasz
air.com.ubisoft.brawl.halla.platform.fighting.action.pvp
brownmonster.app.game.rushrally3
com.AlfaBravo.Combat
com.CarXTech.highWay
com.CarXTech.street
com.ChillyRoom.DungeonShooter
com.EndlessClouds.Treeverse
com.EtherGaming.PocketRogues
com.Flanne.MinutesTillDawn.roguelike.shooting.gp
com.FosFenes.Sonolus
com.GameCoaster.ProtectDungeon
com.HoYoverse.Nap
com.HoYoverse.hkrpgoversea
com.LanPiaoPiao.PlantsVsZombiesRH
com.MOBGames.PoppyMobileChap1
com.OxGames.Pluvia
com.PigeonGames.Phigros
com.ProjectMoon.LimbusCompany
com.Psyonix.RL2D
com.RickyG.DONTFORGET
com.RoamingStar.BlueArchive
com.ShinyShoe.MonsterTrain.mtap
com.Shooter.ModernWarfront
com.Shooter.ModernWarship
com.Shooter.ModernWarships
com.Sunborn.SnqxExilium
com.Sunborn.SnqxExilium.Glo
com.TeamCherry.HollowKnight
com.TechTreeGames.TheTower
com.Vince.AlamobileFormula
com.WandaSoftware.TruckersofEurope3
com.Wispwood.ArrowQuest
com.YoStarEN.Arknights
com.YoStarEN.HBR
com.YoStarEN.MahjongSoul
com.YoStarJP.MajSoul
com.YoStar.AetherGazer
com.YostarJP.BlueArchive
com.ZeroCastleGameStudioINTL.StrikeBusterPrototype
com.ZeroCastleGameStudio.StrikeBusterPrototype
com.actgames.bbee
com.activision.callofduty.shooter
com.activision.callofduty.warzone
com.albiononline
com.aligames.kuang.kybc
com.aligames.kuang.kybc.huawei
com.alightcreative.motion
com.android.test.uibench
com.andromeda.androbench2
com.and.games505.Terraria
com.archosaur.sea.dr.gp
com.asobimo.toramonline
com.autumn.skullgirls
com.axlebolt.standoff2
com.bairimeng.dmmdzz
com.bandainamcoent.opbrww
com.bandainamcoent.sao
com.bandainamcoent.shinycolorsprism
com.bandainamcoent.tensuramrkww
com.bandainamcoent.ultimateninjastorm
com.bandainamcogames.dbzdokkanww
com.bf.sgs.hdexp.bd
com.bhvr.deadbydaylight
com.bilibiligame.heglgp
com.bilibili.azurlane
com.bilibili.deadcells.mobile
com.bilibili.fatego
com.bilibili.heaven
com.bilibili.priconne
com.bilibili.star.bili
com.bilibili.warmsnow
com.biligamekr.aggp
com.bingkolo.kleins.cn
com.blizzard.diablo.immortal
com.blizzard.wtcg.hearthstone
com.bluepoch.m.en.reverse1999
com.bscotch.crashlands2
com.bushiroad.d4dj
com.bushiroad.en.bangdreamgbp
com.bushiroad.lovelive.schoolidolfestival2
com.carxtech.sr
com.chillyroom.soulknightprequel
com.chucklefish.stardewvalley
com.citra.emu
com.cnvcs.xiangqi
com.com2us.starseedgl.android.google.global.normal
com.companyname.AM2RWrapper
com.criticalforceentertainment.criticalops
com.crunchyroll.princessconnectredive
com.denachina.g13002010
com.dena.a12026801
com.denchi.vtubestudio
com.devsisters.ck
com.dfjz.moba
com.dgames.g15002002
com.dishii.mm
com.dishii.soh
com.dois.greedgame
com.dolphinemu.dolphinemu
com.dragonli.projectsnow.lhm
com.drivezone.car.race.game
com.dts.freefireadv
com.dts.freefiremax
com.dts.freefireth
com.dts.freefireth.huawei
com.dxx.firenow
com.ztgame.yyzy
com.zy.wqmt.cn
com.bandainamcoent.dblegends_ww
com.bandainamcoent.idolmaster_gakuen
com.bandainamcoent.imas_millionlive_theaterdays
com.ea.games.r3_row
    "

    android_version="$(getprop ro.build.version.release | cut -d. -f1)"

for app in $GAME_PACKAGES; do
    pm list packages | grep -q "^package:$app$" || continue

    pm compile --reset "$app" >/dev/null 2>&1

    if [ "$android_version" -ge 14 ]; then
        pm compile -r cmdline -m speed-profile -f \
            --primary-dex --secondary-dex --force-merge-profile \
            "$app" >/dev/null 2>&1
    else
        pm compile -m speed-profile -f "$app" >/dev/null 2>&1
    fi

    echo "已编译 : $app ✓"
done

    echo "编译过程已完成 ✓"
else
    echo "游戏编译已跳过 ⏭"
fi

echo "------------------------------------"
echo "性能优化"
echo "音量加(按 2 次)= 应用"
echo "音量减(按 2 次)= 跳过"
echo "------------------------------------"

if read_volume_action; then
    echo "等待 ⏳ 正在应用性能优化"
    echo "------------------------------------"


SP debug.sf.auto_latch_unsignaled 1

DVC put activity_manager disable_app_profiler_pss_profiling true
DVC put activity_manager activity_start_pss_defer 1000
DVC put activity_manager use_compaction false

DVC put interaction_jank_monitor enabled false
DVC put interaction_jank_monitor trace_threshold_frame_time_millis -1

DVC put window_manager system_gesture_exclusion_log_debounce_millis 0
DVC put content_capture max_buffer_size 0
DVC put content_capture log_history_size 0

DVC put activity_manager_native_boot modern_queue_enabled true
DVC put activity_manager_native_boot use_freezer true

DVC put device_personalization_services Logging__enable_aiai_clearcut_logging false
DVC put device_personalization_services StatsLog__enable_new_logger_api false
DVC put device_personalization_services StatsLog__active_users_logger_non_persistent true
DVC put device_personalization_services StatsLog__active_users_logger_enabled false
DVC put device_personalization_services SpeechRecognitionService__clear_logging_events_if_too_much_memory true
DVC put device_personalization_services PcsAttestationMeasurement__maximum_jitter_delay_s 2

DVC put settings_ui event_logging_enabled false
DVC put media media_metrics_mode 0

DVC set_sync_disabled_for_tests persistent >/dev/null 2>&1

DVC put runtime_native metrics.write-to-statsd false
DVC put runtime_native use_app_image_startup_cache true
DVC put runtime_native metrics.reporting-num-mods-server 0
DVC put runtime_native metrics.reporting-num-mods 0
DVC put runtime_native metrics.reporting-mods-server 0
DVC put runtime_native metrics.reporting-mods 0

DVC put runtime_native_boot enable_uffd_gc_2 true
DVC put runtime_native_boot use_generational_gc true
DVC put runtime_native_boot disable_lock_profiling true
DVC put runtime_native_boot iorap_perfetto_enable false
DVC put runtime_native_boot iorap_readahead_enable true

DVC put lmkd_native thrashing_limit_critical 0

DVC put netd_native sort_nameservers true
DVC put netd_native parallel_lookup true
DVC put netd_native doh false

DVC put nnapi_native telemetry_enable false
DVC put storage_native_boot smart_idle_maint_enabled true
DVC put surface_flinger_native_boot SkiaTracingFeature__use_skia_tracing false

STS put global battery_tip_constants battery_tip_enabled=false

STS put global binder_calls_stats enabled=false,detailed_tracking=false,upload_data=false,track_screen_state=false,track_calling_uid=false,track_screen_interactive=false,collect_latency_data=false,ignore_battery_status=true,max_call_stats_count=0

STS put global appop_history_parameters mode=0,baseIntervalMillis=0,intervalMultiplier=0

STS put global battery_stats_constants track_cpu_times_by_proc_state=false,track_cpu_active_cluster_time=false,read_binary_cpu_time=false,max_history_files=0,max_history_buffer_kb=0,phone_on_external_stats_collection=false

STS put global activity_manager_constants power_check_max_cpu_1=1,power_check_max_cpu_2=1,power_check_max_cpu_3=1,power_check_max_cpu_4=1,memory_info_throttle_time=1500,full_pss_min_interval=2000,full_pss_lowered_interval=2000,power_check_interval=2000,usage_stats_interaction_interval=2000,usage_stats_interaction_interval_post_s=2000,service_usage_interaction_time=2000,service_usage_interaction_time_post_s=2000

STS put system device_idle_constants inactive_to=40000,idle_after_inactive_to=0,idle_pending_to=80000,idle_factor=1.8
echo "性能优化已成功应用 ✓"
else
    echo "性能优化已跳过 ⏭"
fi

echo "------------------------------------"
echo "所有选中的优化已完成 ✓"
echo ""
am start -a AxManager.TOAST -e text "🅱️-GpuBoost 优化成功" >/dev/null 2>&1
C notification post -S bigtext -t '🅱️-GpuBoost' '✅' "优化成功" >/dev/null 2>&1