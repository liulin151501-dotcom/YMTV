#!/system/bin/sh
logcat -G 128K &>/dev/null

# 以更清晰格式打印的函数
print_line() {
    ui_print "***************************************"
}

# 裁剪分区（释放空间+优化读写）
trim_partition () {
    for partition in system vendor data cache metadata odm system_ext product;do sm fstrim "/$partition";done>/dev/null 2>&1 &
    sleep 3
}

# 删除垃圾文件与日志 by @Bias_khaliq
delete_trash_logs () {
# 清理/data/data目录下的应用垃圾
for DIR in /data/data/*; do
  if [ -d "${DIR}" ]; then
    rm -rf ${DIR}/cache/*
    rm -rf ${DIR}/no_backup/*
    rm -rf ${DIR}/app_webview/*
    rm -rf ${DIR}/code_cache/*
  fi
done

# 缓存清理逻辑 by Taka
    # 查找并清除"/data/data"目录中应用的缓存
    find /data/data/*/cache/* -delete &>/dev/null
    # 查找并清除"/data/data"目录中应用的代码缓存
    find /data/data/*/code_cache/* -delete &>/dev/null
    # 查找并清除"/data/user_de/{UID}"目录中应用的缓存
    find /data/user_de/*/*/cache/* -delete &>/dev/null
    # 查找并清除"/data/user_de/{UID}"目录中应用的代码缓存
    find /data/user_de/*/*/code_cache/* -delete &>/dev/null
    # 查找并清除"/sdcard/Android/data"目录中应用的缓存
    find /sdcard/Android/data/*/cache/* -delete &>/dev/null
}

ANDROIDVERSION=$(getprop ro.build.version.release)
DEVICES=$(getprop ro.product.board)
MANUFACTURER=$(getprop ro.product.manufacturer)
API=$(getprop ro.build.version.sdk)
NAME="天界投射器通量 | Kzyo"
VERSION="1.6 | 基于动态垂直同步"
DATE=$(date)

printf "░█▀▀█ ── ░█▀▀▀ ░█─── ░█▀▀█ ── ░█▀▀▀ ▀▄░▄▀ 
░█─── ▀▀ ░█▀▀▀ ░█─── ░█▄▄▀ ▀▀ ░█▀▀▀ ─░█── 
░█▄▄█ ── ░█─── ░█▄▄█ ░█─░█ ── ░█─── ▄▀░▀▄"
ui_print ""
sleep 0.5
printf " 提升显示流畅度与响应速度。"
sleep 0.2
ui_print ""
print_line
printf "- 名称            : ${NAME}"
sleep 0.2
printf "- 版本            : ${VERSION}"
sleep 0.2
printf "- 安卓版本        : ${ANDROIDVERSION:-未知}"
sleep 0.2
printf "- 当前日期        : ${DATE}"
sleep 0.2
print_line
printf "- 设备代号        : ${DEVICES:-未知}"
sleep 0.2
printf "- 制造商          : ${MANUFACTURER:-未知}"
sleep 0.2
print_line
printf "- 正在裁剪分区"
trim_partition &>/dev/null
printf "- 正在删除缓存与垃圾文件"
delete_trash_logs &>/dev/null
sleep 2

# 结束或完成刷入模块
logcat -c &>/dev/null
