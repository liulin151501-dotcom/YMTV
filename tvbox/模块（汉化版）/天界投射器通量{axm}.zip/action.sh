#!/system/bin/sh
# 获取 SurfaceFlinger 和 Display 的数据
surface=$(dumpsys SurfaceFlinger)
display_info=$(dumpsys display)

# 获取帧率
FPS=$(echo "$display_info" | grep -oE 'fps=[0-9]+' | grep -oE '[0-9]+' | sort -nr | head -n 1)

# 从 VSYNC 获取帧时间
ft=$(echo "$surface" | grep -m1 -E "VSYNC period|vsyncPeriod" | awk '{print $7}' | grep -oE '[0-9]+')

# 获取相位
app_phase=$(echo "$surface" | grep -m1 "app phase" | awk '{print $3}')
sf_phase=$(echo "$surface" | grep -m1 "SF phase" | awk '{print $3}')

# 获取丢帧计数
missed=$(echo "$surface" | grep -m1 "Total missed frame count" | awk '{print $5}')

# ----------------- 计算结果 -----------------
vspan=$(getprop debug.sf.hwc.min.duration)
early=$(getprop debug.sf.early.app.duration)
late=$(getprop debug.sf.late.app.duration)
thresh=$(getprop debug.sf.set_idle_timer_ms)
sync=$(getprop debug.sf.frame_rate_multiple_threshold)

# ----------------- 打印结果 -----------------
echo "============= SurfaceFlinger 信息 ============="
echo " 显示帧率          : ${FPS:-不可用}"
echo " VSYNC 帧时间      : ${ft:-不可用} ns"
echo " 应用相位偏移      : ${app_phase:-不可用} ns"
echo " SF 相位偏移       : ${sf_phase:-不可用} ns"
echo " 丢帧总数          : ${missed:-不可用}"
echo "------------------------------------------------------"
echo " 计算结果 ->"
echo "  • 帧率同步容差    : $sync"
echo "  • 阈值            : $thresh ms"
echo "  • 垂直跨度        : $vspan ns"
echo "  • 提前偏移        : $early ns"
echo "  • 延迟偏移        : $late ns"
echo "======================================================"