#!/system/bin/sh
#
# Celestial-Flinger-Flux by the kazuyoo
# 开源项目 — 感谢 GL-DP 及所有贡献者。
# 采用 MIT 许可证授权。
#
# 系统 Surface 属性已精确调校，以提升帧调度精度、
# 渲染延迟和响应速度 — 尤其在 60Hz 至 120Hz 显示屏上效果显著。
# 这些优化旨在提供更流畅的 UI 过渡和更优的应用性能，
# 同时不牺牲系统稳定性。
#

# ----------------- 辅助函数 -----------------
# --- 获取 SurfaceFlinger 和 display 数据 ---
  surface=$(dumpsys SurfaceFlinger)
  display_info=$(dumpsys display)

# 从 display 服务获取帧率
  FPS=$(echo "$display_info" | grep -oE 'fps=[0-9]+' | grep -oE '[0-9]+' | sort -nr | head -n 1)

# 从 VSYNC 获取帧时间
  ft=$(echo "$surface" | grep -m1 -E "VSYNC period|vsyncPeriod" | awk '{print $7}' | grep -oE '[0-9]+')

# 获取相位
  app_phase=$(echo "$surface" | grep -m1 "app phase" | awk '{print $3}')
  sf_phase=$(echo "$surface" | grep -m1 "SF phase" | awk '{print $3}')

# 获取总丢帧数
  missed=$(echo "$surface" | grep -m1 "Total missed frame count" | awk '{print $5}')
  
send_notification() {
    # 通知用户优化已完成
    cmd notification post -S bigtext -t 'Celestial-Flinger-Flux ☣️' 'tag' '状态 :  优化完成！' >/dev/null 2>&1
}

# ----------------- 优化模块 -----------------
surfaceflinger_autoset() {
# 设置 SurfaceFlinger 属性
  setprop debug.sf.hwc.min.duration "$vspan"
  setprop debug.sf.early.app.duration "$early"
  setprop debug.sf.late.app.duration "$late"
  setprop debug.sf.early.sf.duration "$early"
  setprop debug.sf.late.sf.duration "$late"
  setprop debug.sf.earlyGl.sf.duration "$early"
  setprop debug.sf.earlyGl.app.duration "$early"

  setprop debug.sf.set_idle_timer_ms "$thresh"
  setprop debug.sf.phase_offset_threshold_for_next_vsync_ns "$((thresh * 1000000))"

# --- 高帧率模式 ---
  if [ "$FPS" -gt 60 ]; then
    setprop debug.sf.early_phase_offset_ns "$early"
    setprop debug.sf.early_gl_phase_offset_ns "$early"
    setprop debug.sf.early_app_phase_offset_ns "$early"
    setprop debug.sf.early_gl_app_phase_offset_ns "$early"

    setprop debug.sf.high_fps_late_app_phase_offset_ns "$late"
    setprop debug.sf.high_fps_late_sf_phase_offset_ns "$late"
    setprop debug.sf.high_fps_early_phase_offset_ns "$early"
    setprop debug.sf.high_fps_early_gl_phase_offset_ns "$early"
    setprop debug.sf.high_fps_early_app_phase_offset_ns "$early"
    setprop debug.sf.high_fps_early_gl_app_phase_offset_ns "$early"
  fi
}

surfaceflinger_fallback() {
# 回退：使用固定 SurfaceFlinger 设置
  setprop debug.sf.hwc.min.duration "$vspan"
  setprop debug.sf.early.app.duration "$early"
  setprop debug.sf.late.app.duration "$late"
  setprop debug.sf.early.sf.duration "$early"
  setprop debug.sf.late.sf.duration "$late"
  setprop debug.sf.earlyGl.sf.duration "$early"
  setprop debug.sf.earlyGl.app.duration "$early"

  setprop debug.sf.set_idle_timer_ms "$thresh"
  setprop debug.sf.phase_offset_threshold_for_next_vsync_ns "$((thresh * 1000000))"
}

other() {
# SurfaceFlinger 优化 PrimeShader
# Shader 缓存非常重要
  for i in solid_layers shadow_layers image_layers clipped_layers pip_image_layers; do
      setprop debug.sf.prime_shader_cache.$i true
  done

# 禁用极少使用的缓存
  for i in edge_extension_shader hole_punch solid_dimmed_layers image_dimmed_layers transparent_image_dimmed_layers clipped_dimmed_image_layers; do
      setprop debug.sf.prime_shader_cache.$i false
  done
  
# 平滑动画
   settings put global window_animation_scale 0.3
   settings put global transition_animation_scale 0.3
   settings put global animator_duration_scale 0.3
    
# 用于 CPU 工作的帧时间百分比。
   setprop debug.hwui.target_cpu_time_percent $(awk -v base=$(cat /proc/sys/kernel/perf_cpu_time_max_percent 2>/dev/null || echo 25) '{norm=$1/base; print int(60+(norm*40)/(1+norm))}' /proc/loadavg)
   
# 应用帧率与屏幕刷新率的同步容差。
   setprop debug.sf.frame_rate_multiple_threshold $(awk "BEGIN {printf \"%.6f\", (1000000000/$ft)/$FPS}")
}
  
# ----------------- 主执行流程 -----------------
main() {
  dumpsys SurfaceFlinger --latency-clear
  sleep 1
  # --- 自适应计算 ---
  if [ -n "$ft" ] && [ "$ft" -gt 0 ]; then
    base_const=83
    if [ -n "$missed" ] && [ "$missed" -gt 50 ]; then
        base_const=103
    fi

    thresh=$(( (ft / 1000000) + (1000000000 / ft / 13) + base_const ))

    vspan=$(( ft * 38 / 1000 ))

    early=$(( ft * 294 / 1000 ))
    late=$(( ft * 688 / 1000 ))

    if [ -n "$missed" ] && [ "$missed" -gt 10 ]; then
        early=$(( early - (ft * 2 / 1000) ))
        late=$(( late - (ft * 2 / 1000) ))
        thresh=$(( thresh + 2 ))
        [ "$early" -lt 0 ] && early=0
        [ "$late"  -lt 0 ] && late=0
    fi

    surfaceflinger_autoset
  else
    # --- 回退模式：60Hz ---
    ft=16666667
    thresh=142
    vspan=$(( ft * 38 / 1000 ))
    early=$(( ft * 294 / 1000 ))
    late=$(( ft * 688 / 1000 ))

    surfaceflinger_fallback
  fi
    other
}

# 主执行流程 & 成功退出脚本
 sync && main && send_notification